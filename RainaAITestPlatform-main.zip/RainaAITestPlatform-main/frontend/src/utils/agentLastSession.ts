/** Persist / restore the last opened agent chat session per project. */

export function agentLastSessionKey(prefix: string, projectId: number): string {
  return `${prefix}:last:${projectId}`
}

export function readAgentLastSessionId(prefix: string, projectId: number): number | null {
  try {
    const key = agentLastSessionKey(prefix, projectId)
    const raw = localStorage.getItem(key) || sessionStorage.getItem(key)
    if (!raw) return null
    const n = Number(raw)
    return Number.isFinite(n) ? n : null
  } catch {
    return null
  }
}

export function writeAgentLastSessionId(
  prefix: string,
  projectId: number,
  id: number | null,
): void {
  const key = agentLastSessionKey(prefix, projectId)
  try {
    if (id == null) {
      localStorage.removeItem(key)
      sessionStorage.removeItem(key)
      return
    }
    localStorage.setItem(key, String(id))
    sessionStorage.removeItem(key)
  } catch {
    /* ignore */
  }
}
