/** Line-level LCS diff for script preview (no external deps). */

export type DiffOp = 'equal' | 'add' | 'del'

export type DiffLine = {
  op: DiffOp
  text: string
}

export type DiffHunk = {
  index: number
  /** Inclusive start index into the flat diff lines array. */
  start: number
  /** Exclusive end index. */
  end: number
  lines: DiffLine[]
}

export type HunkDecision = 'accept' | 'reject'

function splitLines(text: string): string[] {
  if (!text) return []
  const parts = text.replace(/\r\n/g, '\n').replace(/\r/g, '\n').split('\n')
  // Keep trailing empty line only if source ended with newline; drop single trailing ''
  // from split so empty scripts stay empty.
  if (parts.length > 1 && parts[parts.length - 1] === '') {
    parts.pop()
  }
  return parts
}

/** Myers-style LCS via DP; fine for typical UI scripts (hundreds of lines). */
export function lineDiff(before: string, after: string): DiffLine[] {
  const a = splitLines(before)
  const b = splitLines(after)
  const n = a.length
  const m = b.length
  if (n === 0 && m === 0) return []
  if (n === 0) return b.map((text) => ({ op: 'add' as const, text }))
  if (m === 0) return a.map((text) => ({ op: 'del' as const, text }))

  const dp: number[][] = Array.from({ length: n + 1 }, () => Array(m + 1).fill(0))
  for (let i = n - 1; i >= 0; i--) {
    for (let j = m - 1; j >= 0; j--) {
      if (a[i] === b[j]) dp[i][j] = dp[i + 1][j + 1] + 1
      else dp[i][j] = Math.max(dp[i + 1][j], dp[i][j + 1])
    }
  }

  const out: DiffLine[] = []
  let i = 0
  let j = 0
  while (i < n && j < m) {
    if (a[i] === b[j]) {
      out.push({ op: 'equal', text: a[i] })
      i++
      j++
    } else if (dp[i + 1][j] >= dp[i][j + 1]) {
      out.push({ op: 'del', text: a[i] })
      i++
    } else {
      out.push({ op: 'add', text: b[j] })
      j++
    }
  }
  while (i < n) {
    out.push({ op: 'del', text: a[i++] })
  }
  while (j < m) {
    out.push({ op: 'add', text: b[j++] })
  }
  return out
}

/** Group consecutive non-equal lines into change hunks. */
export function groupDiffHunks(lines: DiffLine[]): DiffHunk[] {
  const hunks: DiffHunk[] = []
  let i = 0
  while (i < lines.length) {
    if (lines[i].op === 'equal') {
      i++
      continue
    }
    const start = i
    while (i < lines.length && lines[i].op !== 'equal') i++
    hunks.push({
      index: hunks.length,
      start,
      end: i,
      lines: lines.slice(start, i),
    })
  }
  return hunks
}

/** Stable key for a hunk (content-based) so UI can mark accepted across re-renders. */
export function hunkKey(hunk: DiffHunk): string {
  return hunk.lines.map((l) => `${l.op}:${l.text}`).join('\n')
}

/**
 * Rebuild script text from a diff.
 * Target hunk: accept → keep adds only; reject → keep dels only.
 * Other hunks default to accept (keep adds).
 */
export function applyHunkDecision(
  lines: DiffLine[],
  hunkIndex: number,
  decision: HunkDecision,
): string {
  const hunks = groupDiffHunks(lines)
  const target = hunks.find((h) => h.index === hunkIndex)
  if (!target) {
    return lines.filter((l) => l.op !== 'del').map((l) => l.text).join('\n')
  }

  const out: string[] = []
  let cursor = 0
  for (const hunk of hunks) {
    while (cursor < hunk.start) {
      if (lines[cursor].op === 'equal') out.push(lines[cursor].text)
      cursor++
    }
    const keepOp: DiffOp = hunk.index === hunkIndex ? (decision === 'reject' ? 'del' : 'add') : 'add'
    for (let k = hunk.start; k < hunk.end; k++) {
      if (lines[k].op === keepOp) out.push(lines[k].text)
    }
    cursor = hunk.end
  }
  while (cursor < lines.length) {
    if (lines[cursor].op === 'equal') out.push(lines[cursor].text)
    cursor++
  }
  return out.join('\n')
}
