export type GeneratedCaseStep = {
  order: number
  action: string
  expected?: string
}

export type GeneratedCase = {
  title: string
  overall_expected?: string | null
  module?: string | null
  precondition?: string | null
  test_data?: string | null
  case_type?: string | null
  priority?: string | null
  test_point_id?: string | null
  acceptance_refs?: string[]
  steps: GeneratedCaseStep[]
}

export type ReviewIssueRef = {
  case_title?: string
  issue_type?: string
  detail?: string
}

export type CaseChangeKind = 'modified' | 'added' | 'removed'

export type CaseFieldDiff = {
  label: string
  before: string
  after: string
}

export type CaseChange = {
  id: string
  kind: CaseChangeKind
  draftIndex: number | null
  before: GeneratedCase | null
  after: GeneratedCase | null
  fields: CaseFieldDiff[]
  issues: ReviewIssueRef[]
}

export type CaseDecision = 'accepted' | 'rejected'

const FIELD_DEFS: { label: string; value: (row: GeneratedCase) => string }[] = [
  { label: '标题', value: (row) => text(row.title) },
  { label: '模块', value: (row) => text(row.module) },
  { label: '类型', value: (row) => text(row.case_type) },
  { label: '优先级', value: (row) => text(row.priority) },
  { label: '前置条件', value: (row) => text(row.precondition) },
  { label: '测试数据', value: (row) => text(row.test_data) },
  { label: '总体期望', value: (row) => text(row.overall_expected) },
  {
    label: '验收标准',
    value: (row) =>
      [...(row.acceptance_refs ?? [])]
        .map((item) => item.trim())
        .filter(Boolean)
        .sort()
        .join('、'),
  },
  { label: '步骤', value: (row) => stepsText(row.steps) },
]

function text(value: string | null | undefined): string {
  return (value ?? '').trim()
}

function stepsText(steps: GeneratedCaseStep[] | undefined): string {
  return [...(steps ?? [])]
    .filter((step) => text(step.action))
    .sort((a, b) => a.order - b.order)
    .map((step, index) => {
      const expected = text(step.expected)
      const action = text(step.action)
      return expected ? `${index + 1}. ${action} / ${expected}` : `${index + 1}. ${action}`
    })
    .join('\n')
}

export function casesEqual(left: GeneratedCase, right: GeneratedCase): boolean {
  return FIELD_DEFS.every((field) => field.value(left) === field.value(right))
}

function fieldDiffs(before: GeneratedCase | null, after: GeneratedCase | null): CaseFieldDiff[] {
  return FIELD_DEFS.flatMap((field) => {
    const previous = before ? field.value(before) : ''
    const next = after ? field.value(after) : ''
    if (previous === next) return []
    if (!previous && !next) return []
    return [{ label: field.label, before: previous, after: next }]
  })
}

function issuesFor(issues: ReviewIssueRef[], titles: string[]): ReviewIssueRef[] {
  const names = new Set(titles.map((title) => title.trim()).filter(Boolean))
  if (names.size === 0) return []
  return issues.filter((issue) => names.has((issue.case_title ?? '').trim()))
}

function snapshot(row: GeneratedCase): GeneratedCase {
  return {
    ...row,
    acceptance_refs: [...(row.acceptance_refs ?? [])],
    steps: (row.steps ?? []).map((step) => ({ ...step })),
  }
}

function usableIndexes(
  draftIndexes: Array<number | null> | null | undefined,
  nextCount: number,
): Array<number | null> | null {
  if (!draftIndexes || draftIndexes.length !== nextCount) return null
  if (!draftIndexes.some((index) => typeof index === 'number')) return null
  return draftIndexes
}

export function buildCaseChanges(
  drafts: GeneratedCase[],
  next: GeneratedCase[],
  draftIndexes: Array<number | null> | null | undefined,
  issues: ReviewIssueRef[] = [],
): CaseChange[] {
  const indexes = usableIndexes(draftIndexes, next.length)
  const used = new Set<number>()
  const changes: CaseChange[] = []

  next.forEach((row, position) => {
    const after = snapshot(row)
    let draftIndex: number | null = null
    if (indexes) {
      const hinted = indexes[position]
      if (typeof hinted === 'number' && hinted >= 0 && hinted < drafts.length && !used.has(hinted)) {
        draftIndex = hinted
      }
    } else {
      const title = text(row.title)
      const found = drafts.findIndex(
        (item, index) => !used.has(index) && text(item.title) === title && title !== '',
      )
      draftIndex = found >= 0 ? found : null
    }
    if (draftIndex == null) {
      changes.push({
        id: `add-${position}`,
        kind: 'added',
        draftIndex: null,
        before: null,
        after,
        fields: fieldDiffs(null, after),
        issues: issuesFor(issues, [after.title]),
      })
      return
    }
    used.add(draftIndex)
    const before = snapshot(drafts[draftIndex])
    if (casesEqual(before, after)) return
    changes.push({
      id: `mod-${draftIndex}`,
      kind: 'modified',
      draftIndex,
      before,
      after,
      fields: fieldDiffs(before, after),
      issues: issuesFor(issues, [before.title, after.title]),
    })
  })

  drafts.forEach((row, index) => {
    if (used.has(index)) return
    const before = snapshot(row)
    changes.push({
      id: `rm-${index}`,
      kind: 'removed',
      draftIndex: index,
      before,
      after: null,
      fields: fieldDiffs(before, null),
      issues: issuesFor(issues, [before.title]),
    })
  })

  return changes
}

export function materializeDrafts(
  baseline: GeneratedCase[],
  changes: CaseChange[],
  decisions: Record<string, CaseDecision | undefined>,
): GeneratedCase[] {
  const byDraft = new Map<number, CaseChange>()
  const additions: GeneratedCase[] = []
  for (const change of changes) {
    if (change.kind === 'added') {
      if (decisions[change.id] === 'accepted' && change.after) additions.push(change.after)
      continue
    }
    if (change.draftIndex != null) byDraft.set(change.draftIndex, change)
  }
  const out: GeneratedCase[] = []
  baseline.forEach((row, index) => {
    const change = byDraft.get(index)
    if (!change) {
      out.push(row)
      return
    }
    const decision = decisions[change.id]
    if (change.kind === 'removed') {
      if (decision !== 'accepted') out.push(row)
      return
    }
    if (decision === 'accepted' && change.after) out.push(change.after)
    else out.push(row)
  })
  out.push(...additions)
  return out
}
