import {
  AuditOutlined,
  BookOutlined,
  DeleteOutlined,
  FileTextOutlined,
  ImportOutlined,
  NodeIndexOutlined,
  SendOutlined,
  ThunderboltOutlined,
  UnorderedListOutlined,
} from '@ant-design/icons'
import {
  Alert,
  App,
  Button,
  Checkbox,
  Input,
  Modal,
  Pagination,
  Popover,
  Select,
  Space,
  Switch,
  Table,
  Tabs,
  Tag,
  Tooltip,
  Typography,
} from 'antd'
import type { ColumnsType } from 'antd/es/table'
import { useQuery, useQueryClient } from '@tanstack/react-query'
import { useEffect, useMemo, useRef, useState } from 'react'
import ReactMarkdown from 'react-markdown'
import { useParams, useSearchParams } from 'react-router-dom'
import remarkGfm from 'remark-gfm'
import { apiJson, apiSse, ApiError } from '../api/client'
import {
  AgentChatCollapseButton,
  useAgentChatCollapsed,
} from '../components/AgentChatCollapse'
import AgentSessionHistory, {
  type AgentSessionSummary,
} from '../components/AgentSessionHistory'
import ListViewToggle, { useListViewMode } from '../components/ListViewToggle'
import { VariablesTags } from '../components/TestDataVariables'
import {
  CASE_REVIEW_DIMENSIONS,
  CASE_REVIEW_DIM_TITLE,
  DEFAULT_REVIEW_WEIGHT,
  defaultReviewDimensions,
  type ReviewDimensionConfig,
} from '../constants/caseReviewDims'
import { STEPS_EXPECTED_PLACEHOLDER } from '../constants/testcase'
import { useTableScrollY } from '../hooks/useTableScrollY'
import PageBanner from './PageBanner'
import {
  buildCaseChanges,
  materializeDrafts,
  type CaseChange,
  type CaseDecision,
} from './aiGenerateChanges'
type CaseReviewIssue = {
  case_title?: string
  issue_type?: string
  detail?: string
}

type CaseReviewReport = {
  summary: string
  issues: CaseReviewIssue[]
  dimension_scores: Record<string, number> | null
}

type GeneratedCase = {
  title: string
  overall_expected?: string | null
  module?: string | null
  precondition?: string | null
  test_data?: string | null
  case_type?: string | null
  priority?: string | null
  test_point_id?: string | null
  acceptance_refs?: string[]
  steps: { order: number; action: string; expected?: string }[]
}

type TestPoint = {
  id: string
  module: string
  title: string
  category: string
  priority_hint?: string | null
  acceptance_refs?: string[]
}

type RagContext = {
  requirement_id: number | null
  knowledge_library_id: number | null
  context: string
}

type CaseProposal = {
  baseline: GeneratedCase[]
  changes: CaseChange[]
  decisions: Record<string, CaseDecision>
}

type AgentArtifacts = {
  requirement_analysis?: Record<string, unknown> | null
  test_points?: TestPoint[]
  review?: CaseReviewReport | null
  rag_context?: RagContext | null
  review_stale?: boolean
  proposal?: CaseProposal | null
}

type LlmOptions = { default_model: string; models: string[] }

type PageRes<T> = {
  items: T[]
  total: number
  page: number
  page_size: number
}

type ReqBrief = { id: number; title: string }

type KnowledgeLibraryBrief = {
  id: number
  name: string
  document_count: number
}

type ChatMsg = { role: 'user' | 'assistant'; content: string }

type ChatBubble = {
  id: string
  role: 'user' | 'assistant' | 'system' | 'log'
  content: string
}

type ExecutionLog = {
  id: string
  level: 'info' | 'warning' | 'success' | 'error'
  message: string
}

type AiSessionOut = {
  id: number
  title: string
  messages: ChatMsg[]
  drafts: GeneratedCase[]
  requirement_id: number | null
  knowledge_library_id: number | null
  llm_model: string | null
  generate_mode: 'fast' | 'agent'
  artifacts: AgentArtifacts | null
  created_at: string
  updated_at: string
}

type FormPrefs = {
  requirementId?: string
  knowledgeLibraryId?: string
  llmModel?: string
  enableCaseReview?: boolean
  reviewDimensions?: ReviewDimensionConfig[]
  generateMode?: 'fast' | 'agent'
}

const WELCOME =
  '你好，我是用例生成助手。\n\n1. 点击输入框下方图标选择需求文档、知识库、大模型，并可开启多维用例评审\n2. 用自然语言描述要测的范围（可不填，将按所选需求/知识库生成）\n3. 生成后可继续对话修改：改优先级、补异常、删某条等，左侧草稿会整表更新\n4. 确认后才会写入项目用例'

const REVIEW_REVISE_PROMPT =
  '请根据评审问题修改用例：补缺失、改写含糊步骤和预期、合并重复。未点名的用例保持原样。'

function cloneCases(rows: GeneratedCase[]): GeneratedCase[] {
  return rows.map((row) => ({
    ...row,
    acceptance_refs: [...(row.acceptance_refs ?? [])],
    steps: row.steps.map((step) => ({ ...step })),
  }))
}

function normalizeProposal(raw: unknown): CaseProposal | null {
  if (!raw || typeof raw !== 'object') return null
  const value = raw as Partial<CaseProposal>
  if (!Array.isArray(value.baseline) || !Array.isArray(value.changes) || value.changes.length === 0) {
    return null
  }
  const decisions: Record<string, CaseDecision> = {}
  if (value.decisions && typeof value.decisions === 'object') {
    for (const [key, decision] of Object.entries(value.decisions)) {
      if (decision === 'accepted' || decision === 'rejected') decisions[key] = decision
    }
  }
  return {
    baseline: value.baseline,
    changes: value.changes,
    decisions,
  }
}

function proposalHasPending(proposal: CaseProposal | null): boolean {
  if (!proposal) return false
  return proposal.changes.some((change) => !proposal.decisions[change.id])
}

function artifactsForResume(artifacts: AgentArtifacts): AgentArtifacts {
  const rest = { ...artifacts }
  delete rest.proposal
  return rest
}

const WEIGHT_OPTIONS = [1, 2, 3, 4, 5].map((n) => ({ value: n, label: String(n) }))

function normalizeReviewPrefs(
  raw: ReviewDimensionConfig[] | undefined,
): ReviewDimensionConfig[] {
  if (!raw?.length) return defaultReviewDimensions()
  const known = new Set(CASE_REVIEW_DIMENSIONS.map((d) => d.key))
  const seen = new Set<string>()
  const out: ReviewDimensionConfig[] = []
  for (const item of raw) {
    if (!known.has(item.key) || seen.has(item.key)) continue
    seen.add(item.key)
    const weight = Number(item.weight)
    out.push({
      key: item.key,
      weight:
        Number.isFinite(weight) && weight >= 1 && weight <= 5
          ? Math.round(weight)
          : DEFAULT_REVIEW_WEIGHT,
    })
  }
  return out.length > 0 ? out : defaultReviewDimensions()
}

function formPrefsStorageKey(projectId: number) {
  return `ai-generate-form:${projectId}`
}

function loadFormPrefs(projectId: number): FormPrefs {
  try {
    const raw = localStorage.getItem(formPrefsStorageKey(projectId))
    if (!raw) return {}
    return JSON.parse(raw) as FormPrefs
  } catch {
    return {}
  }
}

function saveFormPrefs(projectId: number, prefs: FormPrefs) {
  localStorage.setItem(formPrefsStorageKey(projectId), JSON.stringify(prefs))
}

function modelAllowedByOptions(current: string, options: LlmOptions | undefined): string {
  if (!options) return ''
  const models = options.models ?? []
  const name = current.trim()
  if (name && models.includes(name)) return name
  const fallback = (options.default_model || '').trim()
  if (fallback && (models.length === 0 || models.includes(fallback))) return fallback
  return models[0] ?? ''
}

function errText(ex: unknown): string {
  if (ex instanceof ApiError && typeof ex.body === 'object' && ex.body !== null) {
    const b = ex.body as { message?: string }
    return b.message ?? `请求失败 (${ex.status})`
  }
  if (ex instanceof Error && ex.message.trim()) return ex.message
  return '请求失败'
}

function normalizeReviewReport(raw: unknown): CaseReviewReport | null {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return null
  const value = raw as Record<string, unknown>
  const issues = Array.isArray(value.issues)
    ? value.issues
        .filter((item): item is Record<string, unknown> =>
          Boolean(item && typeof item === 'object' && !Array.isArray(item)),
        )
        .map((item) => ({
          case_title: typeof item.case_title === 'string' ? item.case_title : '',
          issue_type: typeof item.issue_type === 'string' ? item.issue_type : '',
          detail: typeof item.detail === 'string' ? item.detail : '',
        }))
    : []
  let dimensionScores: Record<string, number> | null = null
  if (
    value.dimension_scores &&
    typeof value.dimension_scores === 'object' &&
    !Array.isArray(value.dimension_scores)
  ) {
    const scores = Object.fromEntries(
      Object.entries(value.dimension_scores).filter(
        (entry): entry is [string, number] => typeof entry[1] === 'number',
      ),
    )
    dimensionScores = Object.keys(scores).length > 0 ? scores : null
  }
  return {
    summary: typeof value.summary === 'string' ? value.summary : '',
    issues,
    dimension_scores: dimensionScores,
  }
}

function normalizeTestPoints(items: TestPoint[] | undefined): TestPoint[] {
  const seen = new Set<string>()
  return (items ?? []).map((item, index) => {
    const rawId = item.id?.trim() || `TP-${String(index + 1).padStart(2, '0')}`
    let id = rawId
    let suffix = 2
    while (seen.has(id)) {
      id = `${rawId}-${suffix}`
      suffix += 1
    }
    seen.add(id)
    return { ...item, id, module: item.module ?? '' }
  })
}

function sortedSteps(steps: GeneratedCase['steps']) {
  return (steps ?? [])
    .filter((s) => s.action?.trim())
    .sort((a, b) => a.order - b.order)
    .map((s, i) => ({
      order: i,
      action: s.action.trim(),
    }))
}

function normalizeStepsForApi(steps: GeneratedCase['steps']) {
  return sortedSteps(steps).map((s, i) => ({
    order: i,
    action: s.action,
    expected: STEPS_EXPECTED_PLACEHOLDER,
  }))
}

const PRIORITY_TAG_COLORS: Record<string, string> = {
  P0: 'magenta',
  P1: 'volcano',
  P2: 'gold',
  P3: 'blue',
  P4: 'default',
}

function renderPriorityTag(priority: string | null | undefined) {
  if (!priority?.trim()) return '—'
  const value = priority.trim()
  return <Tag color={PRIORITY_TAG_COLORS[value] ?? 'default'}>{value}</Tag>
}

function caseIndexFromKey(key: string): number | null {
  const match = /^case-(\d+)$/.exec(key)
  if (!match) return null
  const index = Number(match[1])
  return Number.isFinite(index) ? index : null
}

function roleLabel(role: ChatBubble['role']): string {
  if (role === 'user') return '你'
  if (role === 'system') return '系统'
  if (role === 'log') return '执行日志'
  return '助手'
}

function AssistantMarkdown({ content }: { content: string }) {
  return (
    <div className="api-scenario-agent-bubble-body ai-generate-md markdown-body">
      <ReactMarkdown remarkPlugins={[remarkGfm]}>{content}</ReactMarkdown>
    </div>
  )
}

function executionLogSymbol(level: ExecutionLog['level']): string {
  if (level === 'success') return '✓'
  if (level === 'warning') return '!'
  if (level === 'error') return '×'
  return '•'
}

function parseExecutionLogs(content: string): ExecutionLog[] {
  try {
    const value = JSON.parse(content)
    return Array.isArray(value) ? (value as ExecutionLog[]) : []
  } catch {
    return []
  }
}

function ExecutionLogFold({
  logs,
  defaultExpanded = false,
}: {
  logs: ExecutionLog[]
  defaultExpanded?: boolean
}) {
  const [expanded, setExpanded] = useState(defaultExpanded)
  return (
    <div className={`api-scenario-agent-log-fold${expanded ? ' is-expanded' : ''}`}>
      <div className="api-scenario-agent-log-fold-header">
        <button
          type="button"
          className="api-scenario-agent-log-fold-toggle"
          onClick={() => setExpanded((value) => !value)}
        >
          <span className="api-scenario-agent-log-fold-chevron" aria-hidden>
            {expanded ? '▾' : '▸'}
          </span>
          <span className="api-scenario-agent-log-fold-label">执行日志</span>
          <span className="api-scenario-agent-log-fold-count">{logs.length} 条</span>
        </button>
      </div>
      {expanded && (
        <div className="api-scenario-agent-log-fold-body">
          {logs.map((log) => (
            <div
              key={log.id}
              className={`api-scenario-agent-log-fold-line is-${log.level}`}
            >
              <span className="ai-generate-log-symbol">{executionLogSymbol(log.level)}</span>
              {log.message}
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

function defaultFirstPrompt(requirementId?: string, knowledgeLibraryId?: string): string {
  if (requirementId) return '根据所选需求文档生成测试用例'
  if (knowledgeLibraryId) return '根据项目知识库生成测试用例'
  return '请生成测试用例'
}

export default function AiGenerate() {
  const { message } = App.useApp()
  const qc = useQueryClient()
  const { projectId } = useParams()
  const [searchParams, setSearchParams] = useSearchParams()
  const pid = Number(projectId)

  const savedPrefs = Number.isFinite(pid) ? loadFormPrefs(pid) : {}
  const libraryFromUrl = searchParams.get('library')
  const libraryFromUrlOk = libraryFromUrl != null && /^\d+$/.test(libraryFromUrl)
  const requirementFromUrl = searchParams.get('requirement')
  const requirementFromUrlOk = requirementFromUrl != null && /^\d+$/.test(requirementFromUrl)

  const [requirementId, setRequirementId] = useState<string | undefined>(
    requirementFromUrlOk ? requirementFromUrl : savedPrefs.requirementId,
  )
  const [knowledgeLibraryId, setKnowledgeLibraryId] = useState<string | undefined>(
    libraryFromUrlOk ? libraryFromUrl : savedPrefs.knowledgeLibraryId,
  )
  const [llmModel, setLlmModel] = useState(savedPrefs.llmModel ?? '')
  const [enableCaseReview, setEnableCaseReview] = useState(
    Boolean(savedPrefs.enableCaseReview),
  )
  const [reviewDimensions, setReviewDimensions] = useState<ReviewDimensionConfig[]>(() =>
    normalizeReviewPrefs(savedPrefs.reviewDimensions),
  )
  const [reviewReport, setReviewReport] = useState<CaseReviewReport | null>(null)
  const [generateMode, setGenerateMode] = useState<'fast' | 'agent'>(
    savedPrefs.generateMode ?? 'fast',
  )
  const [agentArtifacts, setAgentArtifacts] = useState<AgentArtifacts | null>(null)
  const [testPoints, setTestPoints] = useState<TestPoint[]>([])
  const [input, setInput] = useState('')
  const [chatMessages, setChatMessages] = useState<ChatMsg[]>([])
  const [pendingUser, setPendingUser] = useState<string | null>(null)
  const [notices, setNotices] = useState<ChatBubble[]>([])
  const [thinking, setThinking] = useState<string | null>(null)
  const [executionLogs, setExecutionLogs] = useState<ExecutionLog[]>([])
  const [generatedCases, setGeneratedCases] = useState<GeneratedCase[]>([])
  const [writingMode, setWritingMode] = useState<null | 'all' | 'batch' | number>(null)
  const [selectedRowKeys, setSelectedRowKeys] = useState<string[]>([])
  const [stepsModalCase, setStepsModalCase] = useState<GeneratedCase | null>(null)
  const [busy, setBusy] = useState(false)
  const [reqPopoverOpen, setReqPopoverOpen] = useState(false)
  const [libPopoverOpen, setLibPopoverOpen] = useState(false)
  const [modelPopoverOpen, setModelPopoverOpen] = useState(false)
  const [reviewPopoverOpen, setReviewPopoverOpen] = useState(false)
  const [modePopoverOpen, setModePopoverOpen] = useState(false)
  const [sessionId, setSessionId] = useState<number | null>(null)
  const [sessionList, setSessionList] = useState<AgentSessionSummary[]>([])
  const [historyLoading, setHistoryLoading] = useState(false)
  const { collapsed: chatCollapsed, toggleCollapsed: toggleChatCollapsed } = useAgentChatCollapsed(
    Number.isFinite(pid) ? `ai-generate-chat-collapsed:${pid}` : 'ai-generate-chat-collapsed',
  )
  const { containerRef: draftTableRef, scrollY: draftScrollY } = useTableScrollY(80)
  const [draftViewMode, setDraftViewMode] = useListViewMode('list-view:ai-generate-drafts')
  const [gridPage, setGridPage] = useState(1)
  const [gridPageSize, setGridPageSize] = useState(10)
  const [proposal, setProposal] = useState<CaseProposal | null>(null)
  const [resultTab, setResultTab] = useState('drafts')

  const chatEndRef = useRef<HTMLDivElement>(null)
  const sessionIdRef = useRef<number | null>(null)
  const pinnedRequirementRef = useRef<string | undefined>(
    requirementFromUrlOk ? requirementFromUrl : undefined,
  )

  useEffect(() => {
    sessionIdRef.current = sessionId
  }, [sessionId])

  const llmOpts = useQuery({
    queryKey: ['ai', 'llm-options', pid],
    queryFn: () => apiJson<LlmOptions>(`/api/v1/projects/${pid}/ai/llm-options`),
    enabled: Number.isFinite(pid),
  })
  const resolvedLlmModel = modelAllowedByOptions(llmModel, llmOpts.data)

  const requirementsQuery = useQuery({
    queryKey: ['requirements', 'picker', pid],
    queryFn: () =>
      apiJson<PageRes<ReqBrief>>(`/api/v1/projects/${pid}/requirements/?page=1&page_size=100`),
    enabled: Number.isFinite(pid),
  })

  const librariesQuery = useQuery({
    queryKey: ['knowledge-libraries', pid],
    queryFn: () =>
      apiJson<KnowledgeLibraryBrief[]>(`/api/v1/projects/${pid}/knowledge/libraries`),
    enabled: Number.isFinite(pid),
  })

  useEffect(() => {
    const next = new URLSearchParams(searchParams)
    let changed = false
    if (/^\d+$/.test(next.get('library') || '')) {
      next.delete('library')
      changed = true
    }
    if (/^\d+$/.test(next.get('requirement') || '')) {
      next.delete('requirement')
      changed = true
    }
    if (changed) setSearchParams(next, { replace: true })
  }, [searchParams, setSearchParams])

  useEffect(() => {
    if (!Number.isFinite(pid)) return
    saveFormPrefs(pid, {
      requirementId,
      knowledgeLibraryId,
      llmModel: llmOpts.data ? resolvedLlmModel : undefined,
      enableCaseReview,
      reviewDimensions,
      generateMode,
    })
  }, [
    pid,
    requirementId,
    knowledgeLibraryId,
    llmOpts.data,
    resolvedLlmModel,
    enableCaseReview,
    reviewDimensions,
    generateMode,
  ])

  async function refreshSessionList(): Promise<AgentSessionSummary[]> {
    const list = await apiJson<AgentSessionSummary[]>(`/api/v1/projects/${pid}/ai/sessions`)
    setSessionList(list)
    return list
  }

  function applySession(s: AiSessionOut) {
    setSessionId(s.id)
    setChatMessages(
      (s.messages ?? []).map((m) => ({
        role: m.role === 'user' ? 'user' : 'assistant',
        content: m.content,
      })),
    )
    const restoredProposal = normalizeProposal(s.artifacts?.proposal)
    setGeneratedCases(s.drafts ?? [])
    setProposal(restoredProposal)
    setResultTab(proposalHasPending(restoredProposal) ? 'changes' : 'drafts')
    setSelectedRowKeys([])
    setPendingUser(null)
    setNotices([])
    setThinking(null)
    setExecutionLogs([])
    setInput('')
    setStepsModalCase(null)
    setReviewReport(normalizeReviewReport(s.artifacts?.review))
    setGenerateMode(s.generate_mode === 'agent' ? 'agent' : 'fast')
    setAgentArtifacts(s.artifacts ?? null)
    setTestPoints(normalizeTestPoints(s.artifacts?.test_points))
    if (s.requirement_id != null) setRequirementId(String(s.requirement_id))
    else setRequirementId(undefined)
    if (s.knowledge_library_id != null) setKnowledgeLibraryId(String(s.knowledge_library_id))
    else setKnowledgeLibraryId(undefined)
    const sessionModel = (s.llm_model || '').trim()
    const allowed = llmOpts.data?.models ?? []
    if (sessionModel && allowed.includes(sessionModel)) setLlmModel(sessionModel)
  }

  async function persistSession(opts?: {
    messages?: ChatMsg[]
    drafts?: GeneratedCase[]
    artifacts?: AgentArtifacts | null
  }) {
    const sid = sessionIdRef.current
    if (!sid || !Number.isFinite(pid)) return
    const messages = opts?.messages ?? chatMessages
    const drafts = opts?.drafts ?? generatedCases
    const artifacts = opts?.artifacts === undefined ? agentArtifacts : opts.artifacts
    try {
      const updated = await apiJson<AiSessionOut>(`/api/v1/projects/${pid}/ai/sessions/${sid}`, {
        method: 'PUT',
        body: JSON.stringify({
          messages,
          drafts,
          requirement_id: requirementId !== undefined ? Number(requirementId) : null,
          knowledge_library_id:
            knowledgeLibraryId !== undefined ? Number(knowledgeLibraryId) : null,
          llm_model: resolvedLlmModel || null,
          generate_mode: generateMode,
          artifacts,
        }),
      })
      setSessionList((prev) => {
        const next = prev.filter((x) => x.id !== updated.id)
        return [
          {
            id: updated.id,
            title: updated.title,
            updated_at: updated.updated_at,
            message_count: updated.messages?.length ?? 0,
            draft_count: updated.drafts?.length ?? 0,
          },
          ...next,
        ]
      })
    } catch {
      // persistence best-effort; chat already succeeded
    }
  }

  useEffect(() => {
    if (!Number.isFinite(pid)) return
    let cancelled = false
    ;(async () => {
      setHistoryLoading(true)
      try {
        const list = await apiJson<AgentSessionSummary[]>(`/api/v1/projects/${pid}/ai/sessions`)
        if (cancelled) return
        setSessionList(list)
        if (list.length === 0) {
          const created = await apiJson<AiSessionOut>(`/api/v1/projects/${pid}/ai/sessions`, {
            method: 'POST',
          })
          if (cancelled) return
          applySession(created)
          const again = await apiJson<AgentSessionSummary[]>(
            `/api/v1/projects/${pid}/ai/sessions`,
          )
          if (!cancelled) setSessionList(again)
        } else {
          const latest = await apiJson<AiSessionOut>(
            `/api/v1/projects/${pid}/ai/sessions/${list[0].id}`,
          )
          if (cancelled) return
          applySession(latest)
        }
        const pinned = pinnedRequirementRef.current
        if (pinned) {
          setRequirementId(pinned)
          pinnedRequirementRef.current = undefined
        }
      } catch (e) {
        if (!cancelled) message.error(errText(e))
      } finally {
        if (!cancelled) setHistoryLoading(false)
      }
    })()
    return () => {
      cancelled = true
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps -- bootstrap per project
  }, [pid])

  const started = chatMessages.length > 0
  const canStart = !started && !busy
  const canChat = started && !busy

  const displayMessages = useMemo(() => {
    const bubbles: ChatBubble[] = [{ id: 'welcome', role: 'assistant', content: WELCOME }]
    chatMessages.forEach((m, i) => {
      bubbles.push({
        id: `m-${i}`,
        role: m.role,
        content: m.content,
      })
    })
    if (pendingUser && !chatMessages.some((m) => m.role === 'user' && m.content === pendingUser)) {
      bubbles.push({ id: 'pending-user', role: 'user', content: pendingUser })
    }
    bubbles.push(...notices)
    return bubbles
  }, [chatMessages, pendingUser, notices])

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [displayMessages, busy, thinking, executionLogs])

  function pushNotice(role: ChatBubble['role'], content: string) {
    setNotices((prev) => [
      ...prev,
      { id: `n-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`, role, content },
    ])
  }

  function canSendNow(): boolean {
    if (busy) return false
    if (!resolvedLlmModel) return false
    if (canStart) {
      return Boolean(requirementId || knowledgeLibraryId || input.trim())
    }
    if (canChat) return Boolean(input.trim())
    return false
  }

  function normalizeDraftIndexes(raw: unknown, count: number): Array<number | null> | null {
    if (!Array.isArray(raw) || raw.length !== count) return null
    return raw.map((item) =>
      typeof item === 'number' && Number.isInteger(item) && item >= 0 ? item : null,
    )
  }

  function commitChangeDecisions(ids: string[], decision: CaseDecision) {
    if (!proposal) return
    const decisions = { ...proposal.decisions }
    let changed = false
    for (const id of ids) {
      if (!decisions[id]) {
        decisions[id] = decision
        changed = true
      }
    }
    if (!changed) return
    const drafts = materializeDrafts(proposal.baseline, proposal.changes, decisions)
    const accepted = Object.values(decisions).some((item) => item === 'accepted')
    const finished = proposal.changes.every((change) => decisions[change.id])
    const nextProposal = finished ? null : { ...proposal, decisions }
    const artifacts: AgentArtifacts = {
      ...(agentArtifacts ?? {}),
      proposal: nextProposal,
    }
    if (accepted) {
      artifacts.review = agentArtifacts?.review ?? reviewReport
      artifacts.review_stale = true
    }
    setAgentArtifacts(artifacts)
    setGeneratedCases(drafts)
    setSelectedRowKeys([])
    if (finished) {
      setProposal(null)
      setResultTab('drafts')
      message.success(accepted ? '变更已处理，草稿已更新' : '已保留原草稿')
    } else {
      setProposal(nextProposal)
    }
    void persistSession({ drafts, artifacts })
  }

  async function sendTurn(
    userText: string,
    resumeArtifacts?: AgentArtifacts,
    options?: { proposal?: boolean },
  ) {
    if (!resolvedLlmModel) {
      message.warning('请选择大模型')
      setModelPopoverOpen(true)
      return
    }
    if (!requirementId && !knowledgeLibraryId && !userText.trim() && !started) {
      message.warning('请至少选择需求、知识库或填写说明')
      return
    }
    if (busy) return

    const proposalTurn = Boolean(options?.proposal)
    if (!proposalTurn) setProposal(null)
    const isResume = Boolean(resumeArtifacts)
    const text = isResume
      ? ''
      : userText.trim() || defaultFirstPrompt(requirementId, knowledgeLibraryId)
    const nextMessages: ChatMsg[] = isResume
      ? chatMessages
      : [...chatMessages, { role: 'user', content: text }]

    setBusy(true)
    setThinking('等待中…')
    setExecutionLogs([])
    setPendingUser(text || null)
    setInput('')

    const body: Record<string, unknown> = {
      generate_mode: generateMode,
      llm_model: resolvedLlmModel,
      messages: nextMessages,
      enable_case_review: enableCaseReview,
    }
    if (enableCaseReview) {
      body.review_dimensions =
        reviewDimensions.length > 0 ? reviewDimensions : defaultReviewDimensions()
    }
    if (requirementId !== undefined) {
      body.requirement_id = Number(requirementId)
    }
    if (knowledgeLibraryId !== undefined) {
      body.knowledge_library_id = Number(knowledgeLibraryId)
    }
    const isRevisionTurn = generatedCases.length > 0 && !resumeArtifacts
    if (generatedCases.length > 0) {
      body.current_drafts = generatedCases
    }
    if (isRevisionTurn && reviewReport) {
      body.last_review = {
        summary: reviewReport.summary,
        issues: reviewReport.issues.map((issue) => ({
          case_title: issue.case_title ?? '',
          issue_type: issue.issue_type ?? '',
          detail: issue.detail ?? '',
        })),
        dimension_scores: reviewReport.dimension_scores,
      }
    }
    if (isRevisionTurn && agentArtifacts?.rag_context?.context) {
      body.cached_rag = {
        requirement_id: agentArtifacts.rag_context.requirement_id,
        knowledge_library_id: agentArtifacts.rag_context.knowledge_library_id,
        context: agentArtifacts.rag_context.context.slice(0, 8000),
      }
    }
    if (resumeArtifacts) {
      body.agent_resume_from = 'cases'
      body.agent_artifacts = resumeArtifacts
    }

    const turnLogs: ExecutionLog[] = []
    const appendExecutionLog = (
      level: ExecutionLog['level'],
      messageText: string,
    ) => {
      const normalized = messageText.trim()
      if (!normalized || turnLogs.at(-1)?.message === normalized) return
      turnLogs.push({
        id: `log-${Date.now()}-${turnLogs.length}`,
        level,
        message: normalized,
      })
      setExecutionLogs([...turnLogs])
    }

    // Mutable bag so assignments inside the SSE callback are visible after await and in catch.
    const streamAcc: {
      doneCases: GeneratedCase[] | null
      draftIndexes: Array<number | null> | null
      assistantText: string
      latestReview: CaseReviewReport | null
      terminalMessage: string
      latestArtifacts: AgentArtifacts | null
      latestTestPoints: TestPoint[] | null
      partialCases: GeneratedCase[]
    } = {
      doneCases: null,
      draftIndexes: null,
      assistantText: '',
      latestReview: null,
      terminalMessage: '',
      latestArtifacts: agentArtifacts
        ? { ...agentArtifacts, ...(proposalTurn ? {} : { proposal: null }) }
        : null,
      latestTestPoints: null,
      partialCases: [],
    }
    try {
      await apiSse(
        `/api/v1/projects/${pid}/ai/generate-testcases/stream`,
        {
          method: 'POST',
          body: JSON.stringify(body),
        },
        (event) => {
          if (event.type === 'error') {
            throw new Error(
              typeof event.message === 'string' ? event.message : '用例生成失败',
            )
          }
          if (event.type === 'log' && typeof event.message === 'string') {
            const level =
              event.level === 'warning' ||
              event.level === 'success' ||
              event.level === 'error'
                ? event.level
                : 'info'
            appendExecutionLog(level, event.message)
            setThinking(event.message)
            return
          }
          if (event.type === 'rag_context' && typeof event.context === 'string') {
            const ragContext: RagContext = {
              requirement_id:
                typeof event.requirement_id === 'number' ? event.requirement_id : null,
              knowledge_library_id:
                typeof event.knowledge_library_id === 'number'
                  ? event.knowledge_library_id
                  : null,
              context: event.context.slice(0, 8000),
            }
            streamAcc.latestArtifacts = {
              ...(streamAcc.latestArtifacts ?? {}),
              rag_context: ragContext,
            }
            return
          }
          if (event.type === 'status' && typeof event.message === 'string') {
            setThinking(event.message)
            appendExecutionLog('info', event.message)
            return
          }
          if (event.type === 'phase' && typeof event.phase === 'string') {
            const labels: Record<string, string> = {
              requirement_analysis: '正在分析需求…',
              test_points: '正在生成测试点…',
              cases: '正在生成用例…',
              review: '正在检查用例…',
            }
            const phaseMessage = labels[event.phase] ?? '处理中…'
            setThinking(phaseMessage)
            if (event.status === 'done') {
              appendExecutionLog('success', phaseMessage.replace('正在', '').replace('…', '') + '完成')
            }
          }
          if (event.artifacts && typeof event.artifacts === 'object') {
            const eventArtifacts = event.artifacts as AgentArtifacts
            const previous = streamAcc.latestArtifacts
            streamAcc.latestArtifacts = {
              ...previous,
              ...eventArtifacts,
              rag_context: eventArtifacts.rag_context ?? previous?.rag_context,
              review:
                streamAcc.latestReview ??
                normalizeReviewReport(eventArtifacts.review),
            }
          }
          if (event.type === 'test_points' && Array.isArray(event.items)) {
            streamAcc.latestTestPoints = normalizeTestPoints(event.items as TestPoint[])
          }
          if (
            (event.type === 'clarification' ||
              event.type === 'await_test_points_confirm') &&
            typeof event.assistant_message === 'string'
          ) {
            streamAcc.terminalMessage = event.assistant_message
            if (Array.isArray(event.items)) {
              streamAcc.latestTestPoints = normalizeTestPoints(event.items as TestPoint[])
            }
          }
          if (event.type === 'delta' && typeof event.content === 'string') {
            streamAcc.assistantText += event.content
            return
          }
          if (event.type === 'cases_batch' && Array.isArray(event.cases)) {
            const batch = event.cases as GeneratedCase[]
            streamAcc.partialCases = [...streamAcc.partialCases, ...batch]
            setGeneratedCases(streamAcc.partialCases)
            setSelectedRowKeys([])
            setResultTab('drafts')
            return
          }
          if (event.type === 'review') {
            const review = normalizeReviewReport({
              summary: typeof event.summary === 'string' ? event.summary : '',
              issues: Array.isArray(event.issues) ? (event.issues as CaseReviewIssue[]) : [],
              dimension_scores: event.dimension_scores,
            })
            streamAcc.latestReview = review
            streamAcc.latestArtifacts = {
              ...(streamAcc.latestArtifacts ?? agentArtifacts ?? {}),
              review,
              review_stale: false,
            }
            setReviewReport(review)
            return
          }
          if (event.type === 'done') {
            streamAcc.doneCases = (event.cases as GeneratedCase[] | undefined) ?? []
            streamAcc.draftIndexes = normalizeDraftIndexes(
              event.draft_indexes,
              streamAcc.doneCases.length,
            )
            streamAcc.assistantText =
              (typeof event.assistant_message === 'string' && event.assistant_message.trim()) ||
              (streamAcc.doneCases.length > 0
                ? `已生成 ${streamAcc.doneCases.length} 条用例`
                : '未生成用例')
            appendExecutionLog(
              'success',
              `本轮完成，共生成 ${streamAcc.doneCases.length} 条用例`,
            )
          }
        },
      )
      if (streamAcc.latestReview) {
        setReviewReport(streamAcc.latestReview)
        streamAcc.latestArtifacts = {
          ...(streamAcc.latestArtifacts ?? {}),
          review: streamAcc.latestReview,
          review_stale: false,
        }
      } else if (isRevisionTurn) {
        const keptReview =
          streamAcc.latestArtifacts?.review ?? agentArtifacts?.review ?? reviewReport
        streamAcc.latestArtifacts = {
          ...(streamAcc.latestArtifacts ?? {}),
          review: keptReview,
          review_stale: proposalTurn ? Boolean(agentArtifacts?.review_stale) : true,
        }
      } else {
        setReviewReport(null)
        if (streamAcc.latestArtifacts) {
          streamAcc.latestArtifacts = {
            ...streamAcc.latestArtifacts,
            review: null,
            review_stale: false,
          }
        }
      }
      if (turnLogs.length > 0) {
        pushNotice('log', JSON.stringify(turnLogs))
      }
      if (streamAcc.latestArtifacts) setAgentArtifacts(streamAcc.latestArtifacts)
      if (streamAcc.latestTestPoints) setTestPoints(streamAcc.latestTestPoints)
      if (streamAcc.doneCases) {
        const doneCases = streamAcc.doneCases
        if (proposalTurn) {
          const changes = buildCaseChanges(
            generatedCases,
            doneCases,
            streamAcc.draftIndexes,
            reviewReport?.issues ?? [],
          )
          const assistantText = changes.length
            ? `已对照评审生成 ${changes.length} 条变更，请在左侧逐条接受或拒绝。`
            : '没有可应用的变更'
          const nextChat: ChatMsg[] = [
            ...nextMessages,
            { role: 'assistant', content: assistantText },
          ]
          setChatMessages(nextChat)
          const nextProposal: CaseProposal | null =
            changes.length > 0
              ? {
                  baseline: cloneCases(generatedCases),
                  changes,
                  decisions: {},
                }
              : null
          if (nextProposal) {
            setProposal(nextProposal)
            setResultTab('changes')
            message.success(assistantText)
          } else {
            setProposal(null)
            message.info(assistantText)
          }
          const artifacts: AgentArtifacts = {
            ...(streamAcc.latestArtifacts ?? {}),
            proposal: nextProposal,
          }
          streamAcc.latestArtifacts = artifacts
          setAgentArtifacts(artifacts)
          await persistSession({
            messages: nextChat,
            drafts: generatedCases,
            artifacts,
          })
        } else {
          const assistantText = streamAcc.assistantText
          const nextChat: ChatMsg[] = [
            ...nextMessages,
            { role: 'assistant', content: assistantText },
          ]
          setGeneratedCases(doneCases)
          setSelectedRowKeys([])
          setChatMessages(nextChat)
          const artifacts: AgentArtifacts = {
            ...(streamAcc.latestArtifacts ?? {}),
            proposal: null,
          }
          streamAcc.latestArtifacts = artifacts
          setAgentArtifacts(artifacts)
          await persistSession({
            messages: nextChat,
            drafts: doneCases,
            artifacts,
          })
          if (doneCases.length > 0) {
            message.success(assistantText.split('\n')[0])
          } else {
            message.warning(assistantText.split('\n')[0])
          }
        }
      } else if (streamAcc.terminalMessage) {
        const nextChat: ChatMsg[] = [
          ...nextMessages,
          { role: 'assistant', content: streamAcc.terminalMessage },
        ]
        setChatMessages(nextChat)
        const artifacts: AgentArtifacts = proposalTurn
          ? (streamAcc.latestArtifacts ?? {})
          : { ...(streamAcc.latestArtifacts ?? {}), proposal: null }
        streamAcc.latestArtifacts = artifacts
        setAgentArtifacts(artifacts)
        await persistSession({
          messages: nextChat,
          artifacts,
        })
      }
      setPendingUser(null)
    } catch (e) {
      const errorMessage = errText(e)
      appendExecutionLog('error', errorMessage)
      if (turnLogs.length > 0) {
        pushNotice('log', JSON.stringify(turnLogs))
      }
      if (streamAcc.partialCases.length > 0 && !streamAcc.doneCases) {
        setGeneratedCases(streamAcc.partialCases)
        const artifacts: AgentArtifacts = proposalTurn
          ? (streamAcc.latestArtifacts ?? {})
          : { ...(streamAcc.latestArtifacts ?? {}), proposal: null }
        streamAcc.latestArtifacts = artifacts
        setAgentArtifacts(artifacts)
        await persistSession({
          drafts: streamAcc.partialCases,
          artifacts,
        })
      } else if (!proposalTurn && agentArtifacts?.proposal) {
        const artifacts: AgentArtifacts = {
          ...(streamAcc.latestArtifacts ?? agentArtifacts),
          proposal: null,
        }
        setAgentArtifacts(artifacts)
        await persistSession({ artifacts })
      }
      message.error(errorMessage)
      pushNotice('system', errorMessage)
      setPendingUser(null)
    } finally {
      setBusy(false)
      setThinking(null)
      setExecutionLogs([])
    }
  }

  async function onSend() {
    if (!canSendNow()) return
    await sendTurn(input)
  }

  async function confirmTestPoints() {
    if (!agentArtifacts || testPoints.length === 0 || busy) return
    if (testPoints.some((item) => !item.module?.trim() || !item.title.trim())) {
      message.warning('请先补全所有测试点的模块和名称')
      return
    }
    const nextArtifacts: AgentArtifacts = {
      ...agentArtifacts,
      test_points: testPoints,
    }
    setAgentArtifacts(nextArtifacts)
    await sendTurn('', artifactsForResume(nextArtifacts))
  }

  async function createNewSession() {
    if (busy) return
    setBusy(true)
    try {
      const created = await apiJson<AiSessionOut>(`/api/v1/projects/${pid}/ai/sessions`, {
        method: 'POST',
      })
      applySession(created)
      await refreshSessionList()
    } catch (e) {
      message.error(errText(e))
    } finally {
      setBusy(false)
    }
  }

  async function openSession(id: number) {
    if (busy || id === sessionId) return
    setBusy(true)
    setHistoryLoading(true)
    try {
      const s = await apiJson<AiSessionOut>(`/api/v1/projects/${pid}/ai/sessions/${id}`)
      applySession(s)
    } catch (e) {
      message.error(errText(e))
    } finally {
      setBusy(false)
      setHistoryLoading(false)
    }
  }

  async function deleteSession(id: number) {
    if (busy) return
    setBusy(true)
    try {
      await apiJson(`/api/v1/projects/${pid}/ai/sessions/${id}`, { method: 'DELETE' })
      const list = await refreshSessionList()
      if (id === sessionId) {
        if (list.length > 0) {
          const s = await apiJson<AiSessionOut>(
            `/api/v1/projects/${pid}/ai/sessions/${list[0].id}`,
          )
          applySession(s)
        } else {
          const created = await apiJson<AiSessionOut>(`/api/v1/projects/${pid}/ai/sessions`, {
            method: 'POST',
          })
          applySession(created)
          await refreshSessionList()
        }
      }
    } catch (e) {
      message.error(errText(e))
    } finally {
      setBusy(false)
    }
  }

  function partitionWritableIndices(indices: number[]) {
    const unique = [...new Set(indices)].filter((i) => i >= 0 && i < generatedCases.length)
    const valid: number[] = []
    let noSteps = 0
    let noExpected = 0
    for (const index of unique) {
      const row = generatedCases[index]
      if (!row) continue
      const steps = normalizeStepsForApi(row.steps)
      if (steps.length === 0) {
        noSteps += 1
        continue
      }
      if (!row.overall_expected?.trim()) {
        noExpected += 1
        continue
      }
      valid.push(index)
    }
    return { valid, noSteps, noExpected }
  }

  async function writeCases(indices: number[], mode: 'all' | 'batch' | number) {
    const { valid, noSteps, noExpected } = partitionWritableIndices(indices)
    const skipped = noSteps + noExpected
    if (skipped > 0) {
      const parts: string[] = []
      if (noSteps > 0) parts.push(`${noSteps} 条缺少有效步骤`)
      if (noExpected > 0) parts.push(`${noExpected} 条缺少总体期望`)
      message.warning(`跳过 ${skipped} 条：${parts.join('，')}`)
    }
    if (valid.length === 0) {
      if (skipped === 0) message.warning('没有可写入的用例')
      return
    }

    const body: Record<string, unknown> = {
      cases: valid.map((index) => {
        const row = generatedCases[index]
        return {
          title: row.title,
          module: row.module?.trim() || null,
          precondition: row.precondition?.trim() || null,
          test_data: row.test_data?.trim() || null,
          case_type: row.case_type?.trim() || null,
          overall_expected: row.overall_expected ?? null,
          priority: row.priority ?? null,
          acceptance_refs: row.acceptance_refs ?? [],
          steps: normalizeStepsForApi(row.steps),
        }
      }),
    }
    if (requirementId !== undefined) {
      body.requirement_id = Number(requirementId)
    }

    setWritingMode(mode)
    try {
      const saved = await apiJson<unknown[]>(`/api/v1/projects/${pid}/ai/confirm-testcases`, {
        method: 'POST',
        body: JSON.stringify(body),
      })
      const duplicateCount = valid.length - saved.length
      message.success(`已写入 ${saved.length} 条用例`)
      if (duplicateCount > 0) message.info(`已跳过 ${duplicateCount} 条重复用例`)
      const removeSet = new Set(valid)
      const nextDrafts = generatedCases.filter((_, i) => !removeSet.has(i))
      setGeneratedCases(nextDrafts)
      setSelectedRowKeys([])
      await persistSession({ drafts: nextDrafts })
      qc.invalidateQueries({ queryKey: ['testcases', pid] })
    } catch (e) {
      message.error(errText(e))
    } finally {
      setWritingMode(null)
    }
  }

  async function writeOneCase(index: number) {
    await writeCases([index], index)
  }

  function writeAllCases() {
    void writeCases(
      generatedCases.map((_, i) => i),
      'all',
    )
  }

  function writeSelectedCases() {
    const indices = selectedRowKeys
      .map(caseIndexFromKey)
      .filter((i): i is number => i !== null)
    void writeCases(indices, 'batch')
  }

  if (!Number.isFinite(pid)) {
    return <p className="error">无效项目</p>
  }

  const llmModels = llmOpts.data?.models ?? []
  const llmModelsLoading = llmOpts.isLoading && llmModels.length === 0
  const reqName = (requirementsQuery.data?.items ?? []).find(
    (r) => String(r.id) === requirementId,
  )
  const libName = (librariesQuery.data ?? []).find(
    (l) => String(l.id) === knowledgeLibraryId,
  )

  const requirementOptions = (requirementsQuery.data?.items ?? []).map((r) => ({
    value: String(r.id),
    label: `${r.id} · ${r.title}`,
  }))

  const libraryOptions = (librariesQuery.data ?? []).map((lib) => ({
    value: String(lib.id),
    label: `${lib.name}（${lib.document_count} 个文件）`,
  }))

  const columns: ColumnsType<GeneratedCase> = [
    {
      title: '标题',
      dataIndex: 'title',
      width: 140,
      ellipsis: true,
      render: (t: string) => (
        <Typography.Text ellipsis title={t}>
          {t}
        </Typography.Text>
      ),
    },
    {
      title: '模块',
      dataIndex: 'module',
      width: 88,
      ellipsis: true,
      render: (v: string | null | undefined) => v?.trim() || '—',
    },
    {
      title: '类型',
      dataIndex: 'case_type',
      width: 72,
      render: (v: string | null | undefined) => v?.trim() || '—',
    },
    {
      title: '步骤',
      key: 'steps',
      width: 88,
      render: (_: unknown, r) => {
        const steps = sortedSteps(r.steps)
        if (steps.length === 0) return '—'
        return (
          <Button
            type="link"
            size="small"
            style={{ padding: 0, height: 'auto' }}
            onClick={() => setStepsModalCase(r)}
          >
            查看步骤
          </Button>
        )
      },
    },
    {
      title: '测试数据',
      dataIndex: 'test_data',
      width: 180,
      ellipsis: true,
      render: (v: string | null | undefined) => (
        <VariablesTags fallbackText={v} />
      ),
    },
    {
      title: '总体期望',
      dataIndex: 'overall_expected',
      width: 160,
      ellipsis: true,
      render: (v: string | null | undefined) => v?.trim() || '—',
    },
    {
      title: '优先级',
      dataIndex: 'priority',
      width: 96,
      render: (p: string | null | undefined) => renderPriorityTag(p),
    },
    {
      title: '验收标准',
      dataIndex: 'acceptance_refs',
      width: 130,
      render: (refs: string[] | undefined) =>
        refs?.length ? refs.map((ref) => <Tag key={ref}>{ref}</Tag>) : '—',
    },
    {
      title: '操作',
      key: 'actions',
      width: 72,
      fixed: 'right',
      render: (_: unknown, record) => {
        const index = generatedCases.indexOf(record)
        return (
          <Button
            type="primary"
            size="small"
            loading={writingMode === index}
            disabled={writingMode !== null && writingMode !== index}
            onClick={() => void writeOneCase(index)}
          >
            写入
          </Button>
        )
      },
    },
  ]

  const stepsModalColumns: ColumnsType<{ order: number; action: string }> = [
    {
      title: '序号',
      key: 'idx',
      width: 56,
      render: (_: unknown, __, index) => index + 1,
    },
    {
      title: '操作',
      dataIndex: 'action',
      ellipsis: true,
    },
  ]

  const reqPicker = (
    <div className="api-scenario-agent-picker">
      <Typography.Text type="secondary" style={{ fontSize: 12, display: 'block', marginBottom: 8 }}>
        需求文档（可选）
      </Typography.Text>
      <Select
        allowClear
        showSearch
        optionFilterProp="label"
        placeholder="不关联需求"
        value={requirementId}
        loading={requirementsQuery.isLoading}
        options={requirementOptions}
        onChange={(v) => {
          setRequirementId(v)
          setReqPopoverOpen(false)
        }}
        style={{ width: '100%' }}
        disabled={busy}
        getPopupContainer={(n) => n.parentElement ?? document.body}
      />
    </div>
  )

  const libPicker = (
    <div className="api-scenario-agent-picker">
      <Typography.Text type="secondary" style={{ fontSize: 12, display: 'block', marginBottom: 8 }}>
        知识库 RAG（可选）
      </Typography.Text>
      <Select
        allowClear
        showSearch
        optionFilterProp="label"
        placeholder="不使用知识库"
        value={knowledgeLibraryId}
        loading={librariesQuery.isLoading}
        options={libraryOptions}
        onChange={(v) => {
          setKnowledgeLibraryId(v)
          setLibPopoverOpen(false)
        }}
        style={{ width: '100%' }}
        disabled={busy}
        getPopupContainer={(n) => n.parentElement ?? document.body}
      />
    </div>
  )

  const modelPicker = (
    <div className="api-scenario-agent-picker api-scenario-agent-picker--env">
      <Typography.Text type="secondary" style={{ fontSize: 12, display: 'block', marginBottom: 8 }}>
        大模型（必选）
      </Typography.Text>
      <Select
        showSearch
        optionFilterProp="label"
        placeholder="选择大模型"
        value={resolvedLlmModel || undefined}
        loading={llmModelsLoading}
        options={llmModels.map((m) => ({ value: m, label: m }))}
        onChange={(v) => {
          setLlmModel(v)
          setModelPopoverOpen(false)
        }}
        style={{ width: '100%' }}
        disabled={busy}
        getPopupContainer={(n) => n.parentElement ?? document.body}
      />
    </div>
  )

  const selectedReviewKeys = reviewDimensions.map((d) => d.key)
  const reviewWeightByKey = Object.fromEntries(
    reviewDimensions.map((d) => [d.key, d.weight]),
  ) as Record<string, number>

  function toggleReviewKey(key: string, checked: boolean) {
    setReviewDimensions((prev) => {
      if (checked) {
        if (prev.some((d) => d.key === key)) return prev
        return [...prev, { key, weight: DEFAULT_REVIEW_WEIGHT }]
      }
      const next = prev.filter((d) => d.key !== key)
      return next.length > 0 ? next : prev
    })
  }

  function setReviewWeight(key: string, weight: number) {
    setReviewDimensions((prev) =>
      prev.map((d) => (d.key === key ? { ...d, weight } : d)),
    )
  }

  const reviewPicker = (
    <div className="api-scenario-agent-picker" style={{ width: 320 }}>
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          marginBottom: 10,
          gap: 12,
        }}
      >
        <Typography.Text type="secondary" style={{ fontSize: 12 }}>
          用例评审（仅首次生成时自动评审，后续修改轮不再评审）
        </Typography.Text>
        <Switch
          size="small"
          checked={enableCaseReview}
          disabled={busy}
          onChange={(v) => {
            setEnableCaseReview(v)
            if (v && reviewDimensions.length === 0) {
              setReviewDimensions(defaultReviewDimensions())
            }
          }}
        />
      </div>
      {enableCaseReview && (
        <>
          <Typography.Text
            type="secondary"
            style={{ fontSize: 12, display: 'block', marginBottom: 8 }}
          >
            勾选维度并设置权重（1–5，越高越优先）
          </Typography.Text>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
            {CASE_REVIEW_DIMENSIONS.map((dim) => {
              const checked = selectedReviewKeys.includes(dim.key)
              return (
                <div
                  key={dim.key}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    gap: 8,
                  }}
                >
                  <Checkbox
                    checked={checked}
                    disabled={busy || (checked && selectedReviewKeys.length <= 1)}
                    onChange={(e) => toggleReviewKey(dim.key, e.target.checked)}
                  >
                    {dim.title}
                  </Checkbox>
                  <Select
                    size="small"
                    style={{ width: 64 }}
                    disabled={busy || !checked}
                    value={reviewWeightByKey[dim.key] ?? DEFAULT_REVIEW_WEIGHT}
                    options={WEIGHT_OPTIONS}
                    onChange={(w) => setReviewWeight(dim.key, w)}
                    getPopupContainer={(n) => n.parentElement ?? document.body}
                  />
                </div>
              )
            })}
          </div>
        </>
      )}
    </div>
  )

  const modePicker = (
    <div className="api-scenario-agent-picker" style={{ width: 260 }}>
      <Typography.Text type="secondary" style={{ fontSize: 12, display: 'block', marginBottom: 8 }}>
        生成模式
      </Typography.Text>
      <Select
        value={generateMode}
        options={[
          { value: 'fast', label: '快速生成' },
          { value: 'agent', label: '分步生成（需求分析 → 测试点 → 用例）' },
        ]}
        onChange={(value: 'fast' | 'agent') => {
          setGenerateMode(value)
          setModePopoverOpen(false)
          if (value === 'fast') {
            setTestPoints([])
            setAgentArtifacts(null)
          }
        }}
        style={{ width: '100%' }}
        disabled={busy}
        getPopupContainer={(node) => node.parentElement ?? document.body}
      />
    </div>
  )

  const pendingChangeIds =
    proposal?.changes.filter((change) => !proposal.decisions[change.id]).map((change) => change.id) ??
    []

  const changePane = proposal ? (
    <div className="ai-generate-change-pane">
      <div className="ai-generate-change-toolbar">
        <Typography.Text type="secondary">
          共 {proposal.changes.length} 条，待确认 {pendingChangeIds.length} 条
        </Typography.Text>
        <Space size="small">
          <Button
            type="primary"
            size="small"
            disabled={pendingChangeIds.length === 0 || busy}
            onClick={() => commitChangeDecisions(pendingChangeIds, 'accepted')}
          >
            全部接受
          </Button>
          <Button
            size="small"
            disabled={pendingChangeIds.length === 0 || busy}
            onClick={() => commitChangeDecisions(pendingChangeIds, 'rejected')}
          >
            全部拒绝
          </Button>
        </Space>
      </div>
      <div className="ai-generate-change-list">
        {proposal.changes.map((change) => {
          const decision = proposal.decisions[change.id]
          const title = change.after?.title || change.before?.title || '未命名用例'
          const kindLabel = change.kind === 'added' ? '新增' : change.kind === 'removed' ? '删除' : '修改'
          const kindColor = change.kind === 'added' ? 'green' : change.kind === 'removed' ? 'red' : 'blue'
          return (
            <article key={change.id} className="ai-generate-change-card">
              <div className="ai-generate-change-head">
                <Tag color={kindColor}>{kindLabel}</Tag>
                <div className="ai-generate-change-title" title={title}>
                  {title}
                </div>
                {decision === 'accepted' ? <Tag color="success">已接受</Tag> : null}
                {decision === 'rejected' ? <Tag>已拒绝</Tag> : null}
                {!decision ? (
                  <Space size={4}>
                    <Button
                      type="primary"
                      size="small"
                      disabled={busy}
                      onClick={() => commitChangeDecisions([change.id], 'accepted')}
                    >
                      接受
                    </Button>
                    <Button
                      size="small"
                      disabled={busy}
                      onClick={() => commitChangeDecisions([change.id], 'rejected')}
                    >
                      拒绝
                    </Button>
                  </Space>
                ) : null}
              </div>
              {change.issues.length > 0 ? (
                <ul className="ai-generate-change-issues">
                  {change.issues.map((issue, index) => (
                    <li key={`${change.id}-issue-${index}`}>
                      {issue.issue_type
                        ? `${CASE_REVIEW_DIM_TITLE[issue.issue_type] ?? issue.issue_type}：`
                        : ''}
                      {issue.detail || '—'}
                    </li>
                  ))}
                </ul>
              ) : null}
              <div className="ai-generate-change-fields">
                {change.fields.map((field) => (
                  <div key={`${change.id}-${field.label}`} className="ai-generate-change-field">
                    <div className="ai-generate-change-field-label">{field.label}</div>
                    {change.kind !== 'added' ? (
                      <div className="ai-generate-change-before">{field.before || '—'}</div>
                    ) : null}
                    {change.kind !== 'removed' ? (
                      <div className="ai-generate-change-after">{field.after || '—'}</div>
                    ) : null}
                  </div>
                ))}
              </div>
            </article>
          )
        })}
      </div>
    </div>
  ) : null

  const issuesByDim = useMemo(() => {
    if (!reviewReport?.issues?.length) return []
    const groups = new Map<string, CaseReviewIssue[]>()
    for (const issue of reviewReport.issues) {
      const key = (issue.issue_type || '').trim() || 'other'
      const list = groups.get(key) ?? []
      list.push(issue)
      groups.set(key, list)
    }
    return Array.from(groups.entries())
  }, [reviewReport])

  const hasMissingTestPointModule = testPoints.some(
    (item) => !item.module?.trim(),
  )

  const gridPageItems = useMemo(() => {
    const start = (gridPage - 1) * gridPageSize
    return generatedCases.slice(start, start + gridPageSize).map((row, i) => ({
      row,
      index: start + i,
    }))
  }, [generatedCases, gridPage, gridPageSize])

  useEffect(() => {
    const maxPage = Math.max(1, Math.ceil(generatedCases.length / gridPageSize) || 1)
    if (gridPage > maxPage) setGridPage(maxPage)
  }, [generatedCases.length, gridPage, gridPageSize])

  useEffect(() => {
    if (!proposal && resultTab === 'changes') setResultTab('drafts')
  }, [proposal, resultTab])

  function toggleDraftKey(key: string, checked: boolean) {
    setSelectedRowKeys((prev) =>
      checked ? (prev.includes(key) ? prev : [...prev, key]) : prev.filter((k) => k !== key),
    )
  }

  const draftEmpty = (
    <div className="ai-generate-empty">
      <span className="ai-generate-empty-title">暂无草稿</span>
      <span className="ai-generate-empty-hint">请在右侧对话生成用例，确认后再写入项目</span>
    </div>
  )

  return (
    <div className="api-scenario-agent-page ai-generate-page">
      <PageBanner title="AI 生成用例" />
      <div className="api-scenario-agent-split">
        <aside className="api-scenario-agent-plan card">
          <div className="api-scenario-agent-chat-toolbar">
            <Typography.Text strong>AI 生成结果</Typography.Text>
            <Space size="small">
              <Button
                type="primary"
                size="small"
                loading={writingMode === 'all'}
                disabled={
                  generatedCases.length === 0 || (writingMode !== null && writingMode !== 'all')
                }
                onClick={() => writeAllCases()}
              >
                一键写入
              </Button>
              <Button
                size="small"
                loading={writingMode === 'batch'}
                disabled={
                  selectedRowKeys.length === 0 ||
                  (writingMode !== null && writingMode !== 'batch')
                }
                onClick={() => writeSelectedCases()}
              >
                写入选中{selectedRowKeys.length > 0 ? `（${selectedRowKeys.length}）` : ''}
              </Button>
            </Space>
          </div>
          <p className="field-hint" style={{ marginTop: 0 }}>
            对话生成后可在此预览；继续对话会更新整表；确认写入后才会进项目。
          </p>
          {generateMode === 'agent' && testPoints.length > 0 && generatedCases.length === 0 ? (
            <div className="ai-generate-test-points-panel">
              <div className="ai-generate-test-points-heading">
                <Typography.Text strong>待确认测试点</Typography.Text>
                <Typography.Text type={hasMissingTestPointModule ? 'danger' : 'secondary'}>
                  {hasMissingTestPointModule
                    ? '该测试点由旧版本生成，请重新生成测试点以自动补齐模块'
                    : `共 ${testPoints.length} 条，可修改模块、测试点与分类`}
                </Typography.Text>
              </div>
              <div className="ai-generate-test-points-table">
              <Table<TestPoint>
                rowKey="id"
                size="small"
                scroll={{ x: 920, y: 300 }}
                pagination={{
                  pageSize: 10,
                  showSizeChanger: true,
                  pageSizeOptions: [10, 20, 50],
                  showTotal: (total) => `共 ${total} 条`,
                }}
                dataSource={testPoints}
                columns={[
                  {
                    title: '模块',
                    dataIndex: 'module',
                    width: 160,
                    fixed: 'left',
                    render: (value: string | undefined, row) => (
                      <Input
                        value={value ?? ''}
                        placeholder="所属业务模块"
                        status={!value?.trim() ? 'error' : undefined}
                        disabled={busy}
                        onChange={(event) =>
                          setTestPoints((prev) =>
                            prev.map((item) =>
                              item.id === row.id
                                ? { ...item, module: event.target.value }
                                : item,
                            ),
                          )
                        }
                      />
                    ),
                  },
                  {
                    title: '测试点',
                    dataIndex: 'title',
                    width: 420,
                    render: (value: string, row) => (
                      <Input
                        value={value}
                        status={!value.trim() ? 'error' : undefined}
                        disabled={busy}
                        onChange={(event) =>
                          setTestPoints((prev) =>
                            prev.map((item) =>
                              item.id === row.id
                                ? { ...item, title: event.target.value }
                                : item,
                            ),
                          )
                        }
                      />
                    ),
                  },
                  {
                    title: '分类',
                    dataIndex: 'category',
                    width: 110,
                    render: (value: string, row) => (
                      <Select
                        value={value || '功能'}
                        style={{ width: '100%' }}
                        disabled={busy}
                        options={['功能', '边界', '异常', '权限'].map((item) => ({
                          value: item,
                          label: item,
                        }))}
                        onChange={(category) =>
                          setTestPoints((prev) =>
                            prev.map((item) =>
                              item.id === row.id ? { ...item, category } : item,
                            ),
                          )
                        }
                      />
                    ),
                  },
                  {
                    title: '验收标准',
                    dataIndex: 'acceptance_refs',
                    width: 160,
                    render: (refs: string[] | undefined) =>
                      refs?.length
                        ? refs.map((ref) => <Tag key={ref}>{ref}</Tag>)
                        : '—',
                  },
                  {
                    title: '',
                    width: 48,
                    fixed: 'right',
                    render: (_value: unknown, row) => (
                      <Button
                        type="text"
                        danger
                        icon={<DeleteOutlined />}
                        disabled={busy || testPoints.length <= 1}
                        onClick={() =>
                          setTestPoints((prev) =>
                            prev.filter((item) => item.id !== row.id),
                          )
                        }
                      />
                    ),
                  },
                ]}
              />
              </div>
              <div className="ai-generate-test-points-footer">
                <Typography.Text type="secondary">
                  模块和测试点名称不能为空
                </Typography.Text>
              <Button
                type="primary"
                loading={busy}
                disabled={testPoints.some(
                  (item) => !item.module?.trim() || !item.title.trim(),
                )}
                onClick={() => void confirmTestPoints()}
              >
                确认测试点并生成用例
              </Button>
              </div>
            </div>
          ) : (
          <Tabs
            className="ai-generate-result-tabs"
            activeKey={resultTab}
            onChange={setResultTab}
            items={[
              {
                key: 'drafts',
                label: `用例草稿${generatedCases.length > 0 ? `（${generatedCases.length}）` : ''}`,
                children: (
                  <div className={`ai-generate-drafts-body is-${draftViewMode}`}>
                    <div className="ai-generate-drafts-toolbar">
                      <ListViewToggle value={draftViewMode} onChange={setDraftViewMode} />
                    </div>
                    {draftViewMode === 'table' ? (
                      <div className="api-scenario-agent-plan-table" ref={draftTableRef}>
                        <Table<GeneratedCase>
                          rowKey={(record) => `case-${generatedCases.indexOf(record)}`}
                          size="small"
                          scroll={{ x: 1060, y: draftScrollY }}
                          pagination={{
                            pageSize: 10,
                            showSizeChanger: true,
                            pageSizeOptions: [10, 20, 50],
                            showTotal: (t) => `共 ${t} 条`,
                          }}
                          rowSelection={{
                            selectedRowKeys,
                            onChange: (keys) => setSelectedRowKeys(keys as string[]),
                            getCheckboxProps: () => ({ disabled: writingMode !== null }),
                          }}
                          columns={columns}
                          dataSource={generatedCases}
                          locale={{ emptyText: draftEmpty }}
                        />
                      </div>
                    ) : (
                      <>
                        {generatedCases.length === 0 ? (
                          draftEmpty
                        ) : (
                          <div className="ai-generate-draft-grid">
                            {gridPageItems.map(({ row, index }) => {
                              const key = `case-${index}`
                              const steps = sortedSteps(row.steps)
                              return (
                                <article key={key} className="ai-generate-draft-card">
                                  <div className="ai-generate-draft-card-head">
                                    <Checkbox
                                      checked={selectedRowKeys.includes(key)}
                                      disabled={writingMode !== null}
                                      onChange={(e) => toggleDraftKey(key, e.target.checked)}
                                    />
                                    <div className="ai-generate-draft-card-title-wrap">
                                      <div className="ai-generate-draft-card-title" title={row.title}>
                                        {row.title}
                                      </div>
                                    </div>
                                    <Space size={4} className="ai-generate-draft-card-ops">
                                      <Tooltip title={steps.length > 0 ? '查看步骤' : '无步骤'}>
                                        <span>
                                          <Button
                                            type="text"
                                            size="small"
                                            icon={<UnorderedListOutlined />}
                                            disabled={steps.length === 0}
                                            onClick={() => setStepsModalCase(row)}
                                          />
                                        </span>
                                      </Tooltip>
                                      <Tooltip title="写入">
                                        <span>
                                          <Button
                                            type="text"
                                            size="small"
                                            icon={<ImportOutlined />}
                                            loading={writingMode === index}
                                            disabled={
                                              writingMode !== null && writingMode !== index
                                            }
                                            onClick={() => void writeOneCase(index)}
                                          />
                                        </span>
                                      </Tooltip>
                                    </Space>
                                  </div>
                                  <div className="ai-generate-draft-card-meta">
                                    <span>{row.module?.trim() || '—'}</span>
                                    <span>{row.case_type?.trim() || '—'}</span>
                                    <span>{renderPriorityTag(row.priority)}</span>
                                  </div>
                                </article>
                              )
                            })}
                          </div>
                        )}
                        <div className="list-card-pagination">
                          <Pagination
                            current={gridPage}
                            pageSize={gridPageSize}
                            total={generatedCases.length}
                            showSizeChanger
                            showTotal={(t) => `共 ${t} 条`}
                            pageSizeOptions={[10, 20, 50]}
                            onChange={(p, s) => {
                              setGridPage(p)
                              setGridPageSize(s)
                            }}
                          />
                        </div>
                      </>
                    )}
                  </div>
                ),
              },
              {
                key: 'review',
                label: '多维评审报告',
                children: (
                  <div className="ai-generate-review-pane">
                    {!reviewReport ? (
                      <div className="ai-generate-empty">
                        <span className="ai-generate-empty-title">暂无评审报告</span>
                        <span className="ai-generate-empty-hint">
                          开启多维评审并生成用例后，报告会显示在这里
                        </span>
                      </div>
                    ) : (
                      <div style={{ fontSize: 13 }}>
                        <div className="ai-generate-review-toolbar">
                          <Tooltip
                            title={
                              reviewReport.issues.length === 0
                                ? '没有需要修改的问题'
                                : '按评审报告生成变更，确认后才会改草稿'
                            }
                          >
                            <span>
                              <Button
                                type="primary"
                                size="small"
                                disabled={
                                  busy ||
                                  generatedCases.length === 0 ||
                                  reviewReport.issues.length === 0
                                }
                                onClick={() =>
                                  void sendTurn(REVIEW_REVISE_PROMPT, undefined, { proposal: true })
                                }
                              >
                                按评审修改用例
                              </Button>
                            </span>
                          </Tooltip>
                        </div>
                        {agentArtifacts?.review_stale ? (
                          <Alert
                            type="warning"
                            showIcon
                            message="此报告基于修改前的草稿"
                            style={{ marginBottom: 8 }}
                          />
                        ) : null}
                        {reviewReport.summary.trim() ? (
                          <p style={{ marginTop: 0 }}>{reviewReport.summary.trim()}</p>
                        ) : (
                          <p className="field-hint" style={{ marginTop: 0 }}>
                            无摘要
                          </p>
                        )}
                        {reviewReport.dimension_scores &&
                          Object.keys(reviewReport.dimension_scores).length > 0 && (
                            <div
                              style={{
                                marginBottom: 8,
                                display: 'flex',
                                flexWrap: 'wrap',
                                gap: 6,
                              }}
                            >
                              {Object.entries(reviewReport.dimension_scores).map(([key, score]) => (
                                <Tag key={key}>
                                  {CASE_REVIEW_DIM_TITLE[key] ?? key}: {score}/5
                                </Tag>
                              ))}
                            </div>
                          )}
                        {issuesByDim.length === 0 ? (
                          <Typography.Text type="secondary">未发现具体问题</Typography.Text>
                        ) : (
                          issuesByDim.map(([dimKey, items]) => (
                            <div key={dimKey} style={{ marginBottom: 8 }}>
                              <Typography.Text strong>
                                {CASE_REVIEW_DIM_TITLE[dimKey] ?? dimKey}
                              </Typography.Text>
                              <ul style={{ margin: '4px 0 0', paddingLeft: 18 }}>
                                {items.map((iss, i) => (
                                  <li key={`${dimKey}-${i}`}>
                                    {iss.case_title ? (
                                      <Typography.Text type="secondary">
                                        [{iss.case_title}]{' '}
                                      </Typography.Text>
                                    ) : null}
                                    {iss.detail || '—'}
                                  </li>
                                ))}
                              </ul>
                            </div>
                          ))
                        )}
                      </div>
                    )}
                  </div>
                ),
              },
              ...(proposal && changePane
                ? [
                    {
                      key: 'changes',
                      label: `变更（${pendingChangeIds.length}）`,
                      children: changePane,
                    },
                  ]
                : []),
            ]}
          />
          )}
          <Modal
            className="draft-steps-modal"
            title={stepsModalCase?.title ?? '用例步骤'}
            open={stepsModalCase !== null}
            footer={
              <Button type="primary" onClick={() => setStepsModalCase(null)}>
                关闭
              </Button>
            }
            width={480}
            destroyOnHidden
            onCancel={() => setStepsModalCase(null)}
          >
            <p className="draft-overall-expected">
              <span className="draft-overall-expected-label">类型：</span>
              {stepsModalCase?.case_type?.trim() || '—'}
            </p>
            <p className="draft-overall-expected">
              <span className="draft-overall-expected-label">前置条件：</span>
              {stepsModalCase?.precondition?.trim() || '—'}
            </p>
            <p className="draft-overall-expected">
              <span className="draft-overall-expected-label">测试数据：</span>
              <VariablesTags fallbackText={stepsModalCase?.test_data} />
            </p>
            <p className="draft-overall-expected">
              <span className="draft-overall-expected-label">总体期望：</span>
              {stepsModalCase?.overall_expected?.trim() || '—'}
            </p>
            <Table
              rowKey={(_, i) => `step-${i}`}
              size="small"
              pagination={false}
              columns={stepsModalColumns}
              dataSource={stepsModalCase ? sortedSteps(stepsModalCase.steps) : []}
              locale={{ emptyText: '暂无步骤' }}
            />
          </Modal>
        </aside>

        <section
          className={`api-scenario-agent-chat ai-generate-chat card${chatCollapsed ? ' is-collapsed' : ''}`}
        >
          <div className="api-scenario-agent-chat-toolbar">
            <div className="api-scenario-agent-chat-toolbar-left">
              <Space size="small" wrap>
                {started && <Tag color={busy ? 'processing' : 'blue'}>对话中</Tag>}
              </Space>
            </div>
            <div className="api-scenario-agent-chat-toolbar-right">
              <AgentChatCollapseButton
                collapsed={chatCollapsed}
                onToggle={toggleChatCollapsed}
              />
              {!chatCollapsed && (
                <AgentSessionHistory
                  items={sessionList}
                  activeId={sessionId}
                  loading={historyLoading}
                  busy={busy || writingMode !== null}
                  showStatus={false}
                  onSelect={(id) => void openSession(id)}
                  onNew={() => void createNewSession()}
                  onDelete={(id) => void deleteSession(id)}
                />
              )}
            </div>
          </div>

          <div className="api-scenario-agent-messages">
            {displayMessages.map((m) =>
              m.role === 'log' ? (
                <ExecutionLogFold
                  key={m.id}
                  logs={parseExecutionLogs(m.content)}
                />
              ) : (
                <div
                  key={m.id}
                  className={`api-scenario-agent-bubble api-scenario-agent-bubble--${m.role}`}
                >
                  <div className="api-scenario-agent-bubble-role">{roleLabel(m.role)}</div>
                  {m.role === 'assistant' ? (
                    <AssistantMarkdown content={m.content} />
                  ) : (
                    <div className="api-scenario-agent-bubble-body">{m.content}</div>
                  )}
                </div>
              ),
            )}
            {busy && (
              <div className="api-scenario-agent-bubble api-scenario-agent-bubble--assistant">
                <div className="api-scenario-agent-bubble-role">助手</div>
                <div className="api-scenario-agent-bubble-body">
                  <div className="muted">{thinking || '思考中…'}</div>
                  {executionLogs.length > 0 && (
                    <div style={{ marginTop: 8 }}>
                      <ExecutionLogFold logs={executionLogs} defaultExpanded />
                    </div>
                  )}
                </div>
              </div>
            )}
            <div ref={chatEndRef} />
          </div>

          <div className="api-scenario-agent-composer">
            <Input.TextArea
              className="api-scenario-agent-composer-input"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder={
                !started
                  ? '描述要测的范围，例如：覆盖登录失败与锁定策略'
                  : '继续修改草稿，例如：把第 2 条改成 P0，再补异常场景'
              }
              autoSize={{ minRows: 2, maxRows: 5 }}
              disabled={busy}
              variant="borderless"
              onPressEnter={(e) => {
                if (!e.shiftKey) {
                  e.preventDefault()
                  void onSend()
                }
              }}
            />
            <div className="api-scenario-agent-composer-bar">
              <div className="api-scenario-agent-composer-tools">
                <Popover
                  content={reqPicker}
                  trigger="click"
                  open={reqPopoverOpen}
                  onOpenChange={setReqPopoverOpen}
                  placement="topLeft"
                  overlayClassName="api-scenario-agent-popover"
                >
                  <Tooltip title={reqName ? `需求：${reqName.title}` : '需求文档（可选）'}>
                    <Button
                      type="text"
                      size="small"
                      className={
                        requirementId
                          ? 'api-scenario-agent-tool-btn is-active'
                          : 'api-scenario-agent-tool-btn'
                      }
                      icon={<FileTextOutlined />}
                      disabled={busy}
                    />
                  </Tooltip>
                </Popover>

                <Popover
                  content={libPicker}
                  trigger="click"
                  open={libPopoverOpen}
                  onOpenChange={setLibPopoverOpen}
                  placement="topLeft"
                  overlayClassName="api-scenario-agent-popover"
                >
                  <Tooltip title={libName ? `知识库：${libName.name}` : '知识库（可选）'}>
                    <Button
                      type="text"
                      size="small"
                      className={
                        knowledgeLibraryId
                          ? 'api-scenario-agent-tool-btn is-active'
                          : 'api-scenario-agent-tool-btn'
                      }
                      icon={<BookOutlined />}
                      disabled={busy}
                    />
                  </Tooltip>
                </Popover>

                <Popover
                  content={modelPicker}
                  trigger="click"
                  open={modelPopoverOpen}
                  onOpenChange={setModelPopoverOpen}
                  placement="topLeft"
                  overlayClassName="api-scenario-agent-popover"
                >
                  <Tooltip title={resolvedLlmModel ? `模型：${resolvedLlmModel}` : '选择大模型'}>
                    <Button
                      type="text"
                      size="small"
                      className={
                        resolvedLlmModel
                          ? 'api-scenario-agent-tool-btn is-active'
                          : 'api-scenario-agent-tool-btn'
                      }
                      icon={<ThunderboltOutlined />}
                      disabled={busy}
                    />
                  </Tooltip>
                </Popover>

                <Popover
                  content={modePicker}
                  trigger="click"
                  open={modePopoverOpen}
                  onOpenChange={setModePopoverOpen}
                  placement="topLeft"
                  overlayClassName="api-scenario-agent-popover"
                >
                  <Tooltip title={generateMode === 'agent' ? '分步生成' : '快速生成'}>
                    <Button
                      type="text"
                      size="small"
                      className={
                        generateMode === 'agent'
                          ? 'api-scenario-agent-tool-btn is-active'
                          : 'api-scenario-agent-tool-btn'
                      }
                      icon={<NodeIndexOutlined />}
                      disabled={busy}
                    />
                  </Tooltip>
                </Popover>

                <Popover
                  content={reviewPicker}
                  trigger="click"
                  open={reviewPopoverOpen}
                  onOpenChange={setReviewPopoverOpen}
                  placement="topLeft"
                  overlayClassName="api-scenario-agent-popover"
                >
                  <Tooltip
                    title={
                      enableCaseReview
                        ? `用例评审：已开（${selectedReviewKeys.length} 维）`
                        : '用例评审（可选）'
                    }
                  >
                    <Button
                      type="text"
                      size="small"
                      className={
                        enableCaseReview
                          ? 'api-scenario-agent-tool-btn is-active'
                          : 'api-scenario-agent-tool-btn'
                      }
                      icon={<AuditOutlined />}
                      disabled={busy}
                    />
                  </Tooltip>
                </Popover>
              </div>

              <Tooltip title={canStart ? '生成用例' : '发送'}>
                <Button
                  type="primary"
                  shape="circle"
                  size="small"
                  className="api-scenario-agent-send-btn"
                  icon={<SendOutlined />}
                  loading={busy}
                  disabled={!canSendNow()}
                  onClick={() => void onSend()}
                />
              </Tooltip>
            </div>
          </div>
        </section>
      </div>
    </div>
  )
}
