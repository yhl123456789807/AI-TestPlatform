import {
  CloudServerOutlined,
  DesktopOutlined,
  DownOutlined,
  FileTextOutlined,
  KeyOutlined,
  RightOutlined,
  SendOutlined,
  StopOutlined,
} from '@ant-design/icons'
import {
  App,
  Badge,
  Button,
  Checkbox,
  Input,
  Tabs,
  Modal,
  Popover,
  Segmented,
  Select,
  Space,
  Switch,
  Tag,
  Tooltip,
  Typography,
} from 'antd'
import { useQuery, useQueryClient } from '@tanstack/react-query'
import { useEffect, useMemo, useRef, useState } from 'react'
import { Link, useParams } from 'react-router-dom'
import { apiJson, apiSse, ApiError, type SseEvent } from '../api/client'
import {
  eventScreenshotKey,
  ExploreShotPreviewButton,
} from '../components/ExploreShotThumb'
import {
  TrialRunResult,
  formatTrialFailMessage,
  trialFailureSummaryForLabel,
  type TrialStepResult,
} from '../components/TrialRunResult'
import ScriptCodeEditor from '../components/ScriptCodeEditor'
import ScriptDiffView from '../components/ScriptDiffView'
import { applyHunkDecision, lineDiff } from '../utils/lineDiff'
import PageBanner from './PageBanner'
import {
  AgentChatCollapseButton,
  useAgentChatCollapsed,
} from '../components/AgentChatCollapse'
import AgentSessionHistory, {
  type AgentSessionSummary,
} from '../components/AgentSessionHistory'
import { useStickToBottom } from '../hooks/useStickToBottom'
import {
  readAgentLastSessionId,
  writeAgentLastSessionId,
} from '../utils/agentLastSession'

const LAST_SESSION_PREFIX = 'ui-scenario-agent'
type TestCase = { id: number; title: string; steps?: Array<{ action: string; expected: string }> }
type UiEnv = {
  id: number
  name: string
  is_default: boolean
  base_url: string
  browsers?: string[]
  browser?: string
  accounts?: Array<{ name: string; has_storage_state?: boolean }>
}
type PageRes<T> = { items: T[]; total: number }

type UiStep = {
  action?: string
  intent?: string
  selector?: string
  value?: string
  assert?: string
  driver?: 'playwright' | 'midscene' | string
  reason?: string
  prompt?: string
  locate?: string
  index?: number
  case_id?: string
}

type MatrixStep = {
  action?: string
  target?: string
  value?: string | number | boolean
  driver?: 'playwright' | 'midscene' | string
  ready?: boolean
  placeholder?: string
  role?: string
  name?: string
  selector?: string
  prompt?: string
  locate?: string
}

type MatrixRow = {
  id?: string
  name?: string
  start_url?: string
  preconditions?: string
  steps?: Array<string | MatrixStep>
  data?: string
  expected?: string
  ready?: boolean
  has_assert?: boolean
}

type ExploreReport = {
  case_name?: string
  matrix?: MatrixRow[]
  steps?: UiStep[]
  midscene_checklist?: Array<Record<string, unknown>>
  page_knowledge?: {
    summary?: { pages_visited?: number; control_count?: number; edge_count?: number }
  }
  recon_warnings?: string[]
  summary?: {
    total_steps?: number
    playwright_steps?: number
    midscene_steps?: number
    pages_visited?: number
    recon_controls?: number
  }
  captcha?: Record<string, unknown> | null
}

type CaseScript = {
  id?: string
  name?: string
  ready?: boolean
  code?: string
  start_url?: string
}

type ScenarioPlan = {
  goal?: string
  start_path?: string
  checklist?: string[]
  case_name?: string
  warnings?: string[]
  matrix?: MatrixRow[]
  case_scripts?: CaseScript[]
  saved_ui_case_ids?: number[]
  saved_ui_suite_id?: number
  explore_report?: ExploreReport
  engine?: 'midscene' | 'playwright' | string
  _trial?: {
    case_id?: string
    status?: string
    error?: string
    failure?: Record<string, unknown> | null
    repair_attempts?: number
    repair_status?: string | null
    repair_requested?: boolean
    repair_preview?: {
      before?: string
      after?: string
      issues?: string[]
      status?: string
      created_at?: string
    } | null
    step_results?: TrialStepResult[]
  }
}

type UiAgentSession = {
  id: number
  status: string
  prompt: string
  testcase_id: number | null
  testcase_ids?: number[]
  env_id: number | null
  browser: string
  headed: boolean
  auth_mode?: string | null
  account_name?: string | null
  messages: Array<{ role: string; content: string }>
  plan: ScenarioPlan | null
  matrix: MatrixRow[]
  explore_report: ExploreReport | null
  trace: Array<Record<string, unknown>>
  result_steps: UiStep[]
  playwright_code: string
  has_credentials: boolean
  events: Array<Record<string, unknown>>
  dry_run_status: string | null
  dry_run_error: string
  error_message: string
  saved_ui_case_id: number | null
  saved_ui_suite_id: number | null
  run_id: number | null
}

type ChatBubble = {
  id: string
  role: 'user' | 'assistant' | 'system' | 'log'
  content: string
  screenshotKey?: string
  eventSeq?: number
  arrivalSeq?: number
}

function isRunnableUiScript(code: string): boolean {
  const text = (code || '').trim()
  if (!text) return false
  if (text.includes('MISSING_STABLE_LOCATOR')) return false
  return /\bdef\s+run\s*\(/.test(text) || /async\s+function\s+run\s*\(/.test(text)
}

const WELCOME =
  '你好，我是 UI 自动化 Agent。\n\n1. 探索引擎为 playwright+midscene（Playwright CLI 逐步 + Midscene 验证码读图等）\n2. 可选：点下方图标多选功能用例 / UI 环境；桌面图标切换有头/无头\n3. 选择功能用例后按所选用例各生成一条脚本；仅输入描述则先探索，再按测试设计扩展多条用例\n4. 账号密码可写在对话里（例如：账号 demo 密码 secret）\n5. 左侧可看报告与脚本；勾选后批量试跑，或点「查看脚本」单条试跑，再确认写入 UI 用例'

/** Align with backend ui_scenario_agent.MANUAL_STOP_MESSAGE */
const MANUAL_STOP_MESSAGE = '已手动停止探索'

function isManualStop(msg?: string | null): boolean {
  return (msg || '').startsWith(MANUAL_STOP_MESSAGE)
}

function errText(ex: unknown): string {
  if (ex instanceof ApiError && typeof ex.body === 'object' && ex.body !== null) {
    const b = ex.body as { message?: string }
    return b.message ?? `请求失败 (${ex.status})`
  }
  return '请求失败'
}

function formatEventLine(ev: Record<string, unknown>): string | null {
  const t = String(ev.type || '')
  if (t === 'log') return `[${String(ev.node || '')}] ${String(ev.message || '')}`
  if (t === 'need_human') return `[人工协助] ${String(ev.message || '请在浏览器操作或对话中回复')}`
  if (t === 'plan') return '[plan] 已收到探索计划'
  if (t === 'matrix') {
    const matrix = Array.isArray(ev.matrix) ? ev.matrix : []
    return `[cases] 用例 ${matrix.length} 条`
  }
  if (t === 'explore_report') {
    const report = ev.report as ExploreReport | undefined
    const s = report?.summary
    if (s) {
      return `[report] 步骤 ${s.total_steps ?? 0}（PW ${s.playwright_steps ?? 0} / Mid ${s.midscene_steps ?? 0}）`
    }
    return '[report] 已生成探索报告'
  }
  if (t === 'trial_start') {
    return `[trial] 开始试跑 ${String(ev.case_id || '')}${ev.headed ? '（有头）' : '（无头）'}`
  }
  if (t === 'trial_step') {
    const status = String(ev.status || '')
    const action = String(ev.action || 'script')
    const phase = ev.phase === 'login' ? '前置登录' : '业务步骤'
    const duration = typeof ev.duration_ms === 'number' ? ` ${ev.duration_ms}ms` : ''
    return `[trial] ${phase} ${action} ${status}${duration}`
  }
  if (t === 'trial_repair_preview') {
    return `[repair] 已生成修复预览 ${String(ev.case_id || '')}`
  }
  if (t === 'trial_repair_applied') {
    return `[repair] 已应用修复 ${String(ev.case_id || '')}`
  }
  if (t === 'trial_repair_discarded') {
    return `[repair] 已放弃修复预览`
  }
  if (t === 'trial_done') {
    const st = String(ev.status || '')
    const err = String(ev.error || '')
    return err
      ? `[trial] ${String(ev.case_id || '')} ${st}：${err}`
      : `[trial] ${String(ev.case_id || '')} ${st}`
  }
  if (t === 'interrupted') return `[wait] ${String(ev.message || '等待确认')}`
  if (t === 'done') return `[done] status=${String(ev.status || '')}`
  if (t === 'error') return `[error] ${String(ev.message || '')}`
  return null
}

const TRIAL_EVENT_TYPES = new Set([
  'trial_start',
  'trial_step',
  'trial_done',
  'trial_repair_start',
  'trial_repair_preview',
  'trial_repair_applied',
  'trial_repair_discarded',
])

function isTrialStreamEvent(ev: Record<string, unknown>): boolean {
  const t = String(ev.type || '')
  if (TRIAL_EVENT_TYPES.has(t)) return true
  if (t === 'log' && String(ev.node || '') === 'trial') return true
  return false
}

function eventDedupeKey(ev: Record<string, unknown>): string {
  const explicitId = ev.event_id ?? ev.id ?? ev.seq
  if (explicitId != null && String(explicitId).trim()) {
    return `event:${String(explicitId)}`
  }
  return JSON.stringify([
    ev.ts ?? '',
    ev.type ?? '',
    ev.level ?? '',
    ev.node ?? '',
    ev.message ?? '',
    ev.data ?? null,
    eventScreenshotKey(ev) ?? '',
  ])
}

function statusLabel(s: string): string {
  const map: Record<string, string> = {
    running: '探索中',
    awaiting_human: '待人工协助',
    awaiting_confirm: '待确认',
    confirmed: '已确认',
    cancelled: '已取消',
    error: '失败',
    done: '完成',
  }
  return map[s] || s
}

function roleLabel(role: ChatBubble['role']): string {
  if (role === 'user') return '你'
  if (role === 'system') return '系统'
  if (role === 'log') return '日志'
  return 'Agent'
}

function statusColor(s: string): string {
  if (s === 'confirmed' || s === 'passed') return 'success'
  if (s === 'failed' || s === 'error') return 'error'
  if (s === 'awaiting_confirm' || s === 'running' || s === 'awaiting_human') return 'processing'
  return 'default'
}

type ScriptPhase = 'exploring' | 'draft' | 'archive'

const HISTORY_REOPEN_STATUSES = new Set(['cancelled', 'confirmed', 'done', 'error'])

function sessionHasScriptDraft(
  session: UiAgentSession | null,
  scripts: CaseScript[],
): boolean {
  if (scripts.some((c) => (c.code || '').trim())) return true
  return Boolean((session?.playwright_code || '').trim())
}

function scriptPhaseOf(session: UiAgentSession | null, hasScriptDraft: boolean): ScriptPhase {
  if (!session) return 'archive'
  const st = session.status
  if (st === 'running' || st === 'awaiting_human') return 'exploring'
  if (st === 'awaiting_confirm' || (st === 'error' && hasScriptDraft)) return 'draft'
  return 'archive'
}

function scriptModalReadonlyHint(phase: ScriptPhase, status?: string): string {
  if (phase === 'exploring') return '探索进行中，脚本仅供预览；完成或停止后可编辑。'
  if (phase === 'archive') {
    if (status === 'confirmed') {
      return '会话已确认（只读）；点工具栏「编辑」可改脚本、试跑或再次导入。'
    }
    if (status === 'done') {
      return '会话已结束（只读）；点工具栏「编辑」可改脚本、试跑或导入。'
    }
    if (status === 'cancelled') return '会话已取消写入；点工具栏「编辑」后可试跑与导入。'
    if (status === 'error') return '会话失败归档（只读）；点工具栏「编辑」可恢复草稿后继续。'
    return '当前无可用草稿，仅可查看脚本。'
  }
  return ''
}

export default function UiScenarioAgent() {
  const { message } = App.useApp()
  const { projectId } = useParams()
  const pid = Number(projectId)
  const qc = useQueryClient()

  const [testcaseIds, setTestcaseIds] = useState<number[]>([])
  const [envId, setEnvId] = useState<number | undefined>()
  const [browser, setBrowser] = useState<string | undefined>()
  const [headed, setHeaded] = useState(true)
  /** follow = env inject; account = captured storageState; none = login / skip inject */
  const [authMode, setAuthMode] = useState<'follow' | 'account' | 'none'>('follow')
  const [accountName, setAccountName] = useState<string | undefined>()
  const [input, setInput] = useState('')
  const [session, setSession] = useState<UiAgentSession | null>(null)
  const [scriptBound, setScriptBound] = useState<{ id: number | null; code: string; text: string }>({
    id: null,
    code: '',
    text: '',
  })
  const [pendingUser, setPendingUser] = useState<string | null>(null)
  const [notices, setNotices] = useState<ChatBubble[]>([])
  const [logBubbles, setLogBubbles] = useState<ChatBubble[]>([])
  const [busy, setBusy] = useState(false)
  const [stopping, setStopping] = useState(false)
  const [casePopoverOpen, setCasePopoverOpen] = useState(false)
  const [envPopoverOpen, setEnvPopoverOpen] = useState(false)
  const [caseFilter, setCaseFilter] = useState('')
  const engine = 'midscene' as const
  const [sessionList, setSessionList] = useState<AgentSessionSummary[]>([])
  const [historyLoading, setHistoryLoading] = useState(false)
  const [selectedCaseId, setSelectedCaseId] = useState<string | null>(null)
  const [writeSelectedIds, setWriteSelectedIds] = useState<string[]>([])
  const [importCreateSuite, setImportCreateSuite] = useState(true)
  const [importDialogOpen, setImportDialogOpen] = useState(false)
  const [importDialogMode, setImportDialogMode] = useState<'all' | 'selected'>('all')
  const [importSuiteName, setImportSuiteName] = useState('')
  const [importSuiteDescription, setImportSuiteDescription] = useState('')
  const [importSuiteEnvId, setImportSuiteEnvId] = useState<number | undefined>()
  const [importSuiteBrowsers, setImportSuiteBrowsers] = useState<string[]>([])
  const [importSuiteStopOnFail, setImportSuiteStopOnFail] = useState(true)
  const [scriptModal, setScriptModal] = useState<{ id: string; name: string; code: string } | null>(
    null,
  )
  const [scriptReviseInput, setScriptReviseInput] = useState('')
  const [scriptReviseBusy, setScriptReviseBusy] = useState(false)
  const [scriptReviseChat, setScriptReviseChat] = useState<ChatBubble[]>([])
  const scriptReviseScrollRef = useRef<HTMLDivElement | null>(null)
  const [trialHeaded, setTrialHeaded] = useState(true)
  const [trialBusy, setTrialBusy] = useState(false)
  const [scriptModalTab, setScriptModalTab] = useState<'chat' | 'trial'>('chat')
  const [repairPreviewBusy, setRepairPreviewBusy] = useState(false)
  const [repairPanelOpen, setRepairPanelOpen] = useState(false)
  const [repairViewMode, setRepairViewMode] = useState<'diff' | 'edit'>('diff')
  const [repairBefore, setRepairBefore] = useState('')
  const [repairDraft, setRepairDraft] = useState('')
  const [acceptedRepairHunkKeys, setAcceptedRepairHunkKeys] = useState<Set<string>>(
    () => new Set(),
  )
  const [repairChatExpanded, setRepairChatExpanded] = useState(false)
  /** False until last-session restore attempt finishes for current project. */
  const [sessionReady, setSessionReady] = useState(false)
  const { collapsed: chatCollapsed, toggleCollapsed: toggleChatCollapsed } = useAgentChatCollapsed(
    Number.isFinite(pid) ? `ui-agent-chat-collapsed:${pid}` : 'ui-agent-chat-collapsed',
  )
  /** null = follow exploring default; boolean = user override for explore-log fold */
  const [logsExpandedOverride, setLogsExpandedOverride] = useState<boolean | null>(null)
  const wasExploringRef = useRef(false)

  const logSeqRef = useRef(0)
  const pollRef = useRef<number | null>(null)
  const seenLogKeysRef = useRef<Set<string>>(new Set())
  const fetchGenRef = useRef(0)
  const restoredGenRef = useRef(0)
  const [listLoadGen, setListLoadGen] = useState(0)

  const cases = useQuery({
    queryKey: ['test-cases', pid, 'ui-agent'],
    queryFn: () =>
      apiJson<PageRes<TestCase>>(`/api/v1/projects/${pid}/test-cases/?page=1&page_size=100`),
    enabled: Number.isFinite(pid),
  })

  const envs = useQuery({
    queryKey: ['ui-envs', pid],
    queryFn: () => apiJson<PageRes<UiEnv>>(`/api/v1/projects/${pid}/ui-envs/?page=1&page_size=100`),
    enabled: Number.isFinite(pid),
  })

  const selectedEnv =
    (envs.data?.items ?? []).find((e) => e.id === envId) ??
    (envs.data?.items ?? []).find((e) => e.is_default) ??
    envs.data?.items?.[0]

  const envName = useMemo(() => {
    if (!selectedEnv) return null
    return selectedEnv.is_default ? `${selectedEnv.name}（默认）` : selectedEnv.name
  }, [selectedEnv])

  const browserOptions = selectedEnv?.browsers?.length
    ? selectedEnv.browsers
    : [selectedEnv?.browser || 'chromium']
  const storageAccounts = useMemo(
    () => (selectedEnv?.accounts ?? []).filter((a) => a.has_storage_state),
    [selectedEnv?.accounts],
  )

  useEffect(() => {
    if (authMode !== 'account') return
    if (storageAccounts.length === 1) {
      setAccountName(storageAccounts[0].name)
    } else if (!storageAccounts.some((a) => a.name === accountName)) {
      setAccountName(undefined)
    }
  }, [authMode, accountName, selectedEnv?.id, storageAccounts])

  const filteredCases = useMemo(() => {
    const q = caseFilter.trim().toLowerCase()
    const items = cases.data?.items ?? []
    if (!q) return items
    return items.filter((c) => c.title.toLowerCase().includes(q))
  }, [cases.data, caseFilter])

  const waitingHuman = session?.status === 'awaiting_human'
  const finished =
    session != null && ['confirmed', 'cancelled', 'done'].includes(session.status)
  const canStart = !session && !busy && sessionReady
  const exploring = session?.status === 'running' || waitingHuman
  const restoring = !sessionReady && !session

  async function refreshSessionList() {
    if (!Number.isFinite(pid)) return
    const list = await apiJson<AgentSessionSummary[]>(
      `/api/v1/projects/${pid}/ui-scenario-agent/sessions`,
    )
    setSessionList(list)
  }

  const caseScripts: CaseScript[] = useMemo(() => {
    const fromPlan = session?.plan?.case_scripts
    const rows = Array.isArray(fromPlan) ? fromPlan : []
    // Preserve all designed cases even when some/all scripts are not ready yet.
    // Only synthesize a single draft when the backend returned no case rows at all.
    if (rows.length > 0) return rows
    const code = (session?.playwright_code || '').trim()
    if (!code) return rows
    return [
      {
        id: 'TC-001',
        name:
          session?.plan?.case_name || session?.plan?.goal || '探索草稿',
        ready: true,
        code,
        start_url: session?.plan?.start_path,
      },
    ]
  }, [
    session?.plan?.case_scripts,
    session?.plan?.case_name,
    session?.plan?.goal,
    session?.plan?.start_path,
    session?.playwright_code,
  ])

  const hasScriptDraft = useMemo(
    () => sessionHasScriptDraft(session, caseScripts),
    [session, caseScripts],
  )
  const scriptPhase = useMemo(
    () => scriptPhaseOf(session, hasScriptDraft),
    [session, hasScriptDraft],
  )
  const canEditScript = scriptPhase === 'draft'
  const showSessionEdit =
    Boolean(session) &&
    hasScriptDraft &&
    !canEditScript &&
    HISTORY_REOPEN_STATUSES.has(session?.status || '')
  const canChat = canEditScript || waitingHuman
  const canEditEnv = canStart || canEditScript
  /** After stop (error), allow retuning layout / case / headed / auth before re-explore. */
  const canTuneExplore = canStart || canEditScript

  const activeCase = useMemo(() => {
    if (!caseScripts.length) return null
    const hit = caseScripts.find((c) => c.id === selectedCaseId)
    return hit || caseScripts.find((c) => c.ready && c.code) || caseScripts[0]
  }, [caseScripts, selectedCaseId])

  const serverScript = (activeCase?.code || session?.playwright_code || '').trim()
    ? activeCase?.code || session?.playwright_code || ''
    : session?.playwright_code || ''
  const scriptDraft =
    scriptBound.id === (session?.id ?? null) && scriptBound.code === serverScript
      ? scriptBound.text
      : serverScript
  const trialMeta = session?.plan?._trial
  const repairAttempts = Number(trialMeta?.repair_attempts || 0)
  const hasRepairFailure =
    (session?.dry_run_status === 'failed' || session?.dry_run_status === 'error') &&
    Boolean(trialMeta?.failure)
  const canRepairTrial = hasRepairFailure && repairAttempts < 2
  const serverRepairPreview = trialMeta?.repair_preview
  const scriptModalInRepair = Boolean(
    repairPanelOpen &&
      trialMeta?.case_id &&
      scriptModal?.id &&
      trialMeta.case_id === scriptModal.id,
  )
  const scriptModalTrialReady = Boolean(
    session?.dry_run_status &&
      trialMeta &&
      (!scriptModal?.id || trialMeta.case_id === scriptModal.id),
  )
  const trialTabFailureSummary = useMemo(
    () =>
      scriptModalTrialReady
        ? trialFailureSummaryForLabel(trialMeta, session?.dry_run_status, session?.dry_run_error)
        : null,
    [scriptModalTrialReady, trialMeta, session?.dry_run_status, session?.dry_run_error],
  )
  const repairDiffLines = useMemo(() => {
    if (!repairPanelOpen && !serverRepairPreview?.after) return []
    const before = repairBefore || serverRepairPreview?.before || ''
    const after = repairDraft || serverRepairPreview?.after || ''
    return lineDiff(before, after)
  }, [repairPanelOpen, repairBefore, repairDraft, serverRepairPreview?.before, serverRepairPreview?.after])

  const effectiveCodeForCase = useMemo(() => {
    return (caseId: string, rowCode: string) => {
      const base = (rowCode || '').trim()
      if (scriptModal?.id === caseId && (scriptModal.code || '').trim()) {
        return scriptModal.code.trim()
      }
      const activeId = selectedCaseId || activeCase?.id
      if (
        caseId === activeId &&
        scriptBound.id === (session?.id ?? null) &&
        scriptBound.text.trim()
      ) {
        return scriptBound.text.trim()
      }
      return base
    }
  }, [
    scriptModal,
    selectedCaseId,
    activeCase?.id,
    scriptBound.id,
    scriptBound.text,
    session?.id,
  ])

  const writableCaseIds = useMemo(() => {
    return caseScripts
      .map((row, idx) => {
        const id = row.id || `UC-${idx + 1}`
        const code = effectiveCodeForCase(id, String(row.code || ''))
        return isRunnableUiScript(code) ? id : null
      })
      .filter((id): id is string => Boolean(id))
  }, [caseScripts, effectiveCodeForCase])

  useEffect(() => {
    if (!canEditScript) {
      setWriteSelectedIds([])
      return
    }
    setWriteSelectedIds((prev) => prev.filter((id) => writableCaseIds.includes(id)))
  }, [canEditScript, writableCaseIds.join('|')])

  useEffect(() => {
    if (!caseScripts.length) {
      setSelectedCaseId(null)
      return
    }
    if (selectedCaseId && caseScripts.some((c) => c.id === selectedCaseId)) return
    const firstReady = caseScripts.find((c) => c.ready && c.code)
    setSelectedCaseId(firstReady?.id || caseScripts[0]?.id || null)
  }, [caseScripts, selectedCaseId])

  useEffect(() => {
    const el = scriptReviseScrollRef.current
    if (!el) return
    el.scrollTop = el.scrollHeight
  }, [scriptReviseChat, scriptReviseBusy])

  useEffect(() => {
    if (!Number.isFinite(pid)) return
    const gen = ++fetchGenRef.current
    setSessionReady(false)
    stopPoll()
    setSession(null)
    setSessionList([])
    setLogBubbles([])
    logSeqRef.current = 0
    seenLogKeysRef.current = new Set()
    setNotices([])
    setPendingUser(null)
    setInput('')
    setTestcaseIds([])
    setCaseFilter('')
    setHistoryLoading(true)
    ;(async () => {
      let list: AgentSessionSummary[] = []
      try {
        list = await apiJson<AgentSessionSummary[]>(
          `/api/v1/projects/${pid}/ui-scenario-agent/sessions`,
        )
      } catch {
        /* best-effort */
      }
      if (gen !== fetchGenRef.current) return
      setSessionList(list)
      setHistoryLoading(false)
      setListLoadGen(gen)
    })()
  }, [pid])

  const displayMessages = useMemo(() => {
    const bubbles: ChatBubble[] = [{ id: 'welcome', role: 'assistant', content: WELCOME }]
    const apiMsgs = [...(session?.messages ?? [])]
    const trailingAssistant =
      logBubbles.length > 0 && apiMsgs[apiMsgs.length - 1]?.role === 'assistant'
        ? apiMsgs.pop()
        : undefined
    apiMsgs.forEach((m, i) => {
      bubbles.push({
        id: `api-${session?.id ?? 0}-${i}`,
        role: m.role === 'user' ? 'user' : 'assistant',
        content: m.content,
      })
    })
    if (pendingUser && !apiMsgs.some((m) => m.role === 'user' && m.content === pendingUser)) {
      bubbles.push({ id: 'pending-user', role: 'user', content: pendingUser })
    }
    bubbles.push(...logBubbles)
    if (trailingAssistant) {
      bubbles.push({
        id: `api-${session?.id ?? 0}-final`,
        role: 'assistant',
        content: trailingAssistant.content,
      })
    }
    bubbles.push(...notices)
    return bubbles
  }, [session, pendingUser, notices, logBubbles])

  type MessageChunk =
    | { kind: 'bubble'; message: ChatBubble }
    | { kind: 'logs'; id: string; messages: ChatBubble[] }

  const messageChunks = useMemo((): MessageChunk[] => {
    const chunks: MessageChunk[] = []
    let logBuf: ChatBubble[] = []
    const flushLogs = () => {
      if (!logBuf.length) return
      chunks.push({ kind: 'logs', id: logBuf[0].id, messages: logBuf })
      logBuf = []
    }
    for (const m of displayMessages) {
      if (m.role === 'log') {
        logBuf.push(m)
        continue
      }
      flushLogs()
      chunks.push({ kind: 'bubble', message: m })
    }
    flushLogs()
    return chunks
  }, [displayMessages])

  const logsExpanded = logsExpandedOverride ?? exploring

  useEffect(() => {
    if (wasExploringRef.current && !exploring) {
      // Leave explore → collapse by default; clear override so default applies
      setLogsExpandedOverride(null)
    }
    if (!wasExploringRef.current && exploring) {
      setLogsExpandedOverride(null)
    }
    wasExploringRef.current = exploring
  }, [exploring])

  const {
    containerRef: messagesRef,
    onScroll: updateStickToBottom,
    pinToBottom: pinChatToBottom,
  } = useStickToBottom([displayMessages, busy, logsExpanded])

  const {
    containerRef: logFoldRef,
    onScroll: updateLogStickToBottom,
    pinToBottom: pinLogToBottom,
  } = useStickToBottom([logBubbles, logsExpanded, exploring])

  function pinChatAndLogsToBottom() {
    pinChatToBottom()
    pinLogToBottom()
  }

  // When explore starts, pin log fold so new lines stick to bottom
  useEffect(() => {
    if (exploring) pinLogToBottom()
    // pinLogToBottom identity changes each render; only re-pin on explore edge
    // eslint-disable-next-line react-hooks/exhaustive-deps -- exploring edge only
  }, [exploring])

  useEffect(() => {
    return () => {
      if (pollRef.current != null) window.clearInterval(pollRef.current)
    }
  }, [])

  function appendLog(
    line: string,
    key?: string,
    screenshotKey?: string,
    eventSeq?: number,
  ) {
    const dedupeKey = key || line
    if (seenLogKeysRef.current.has(dedupeKey)) return
    seenLogKeysRef.current.add(dedupeKey)
    logSeqRef.current += 1
    const id = `log-${logSeqRef.current}`
    const next: ChatBubble = {
      id,
      role: 'log',
      content: line,
      screenshotKey,
      eventSeq,
      arrivalSeq: logSeqRef.current,
    }
    setLogBubbles((prev) =>
      [...prev, next].sort((a, b) => {
        const aSeq = a.eventSeq
        const bSeq = b.eventSeq
        if (aSeq != null && bSeq != null && aSeq !== bSeq) return aSeq - bSeq
        if (aSeq != null && bSeq == null) return -1
        if (aSeq == null && bSeq != null) return 1
        return (a.arrivalSeq ?? 0) - (b.arrivalSeq ?? 0)
      }),
    )
  }

  function ingestEvents(events: Array<Record<string, unknown>>) {
    events.forEach((ev) => {
      if (isTrialStreamEvent(ev)) return
      const line = formatEventLine(ev)
      if (!line) return
      const key = eventDedupeKey(ev)
      const seq = typeof ev.seq === 'number' && Number.isFinite(ev.seq) ? ev.seq : undefined
      appendLog(line, key, eventScreenshotKey(ev), seq)
    })
  }

  function pushNotice(role: Exclude<ChatBubble['role'], 'log'>, content: string) {
    setNotices((prev) => {
      if (prev.some((item) => item.role === role && item.content === content)) return prev
      return [
        ...prev,
        { id: `n-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`, role, content },
      ]
    })
  }

  function stopPoll() {
    if (pollRef.current != null) {
      window.clearInterval(pollRef.current)
      pollRef.current = null
    }
  }

  async function waitUntilSettled(sessionId: number): Promise<UiAgentSession> {
    stopPoll()
    let ticks = 0
    let baselineEventCount: number | null = null
    return new Promise((resolve, reject) => {
      const tick = async () => {
        try {
          const refreshed = await apiJson<UiAgentSession>(
            `/api/v1/projects/${pid}/ui-scenario-agent/sessions/${sessionId}`,
          )
          setSession(refreshed)
          if (refreshed.status === 'awaiting_human') {
            setBusy(false)
          } else if (refreshed.status === 'running') {
            setBusy(true)
          }
          const eventCount = refreshed.events?.length ?? 0
          if (baselineEventCount == null) baselineEventCount = eventCount
          ingestEvents(refreshed.events || [])
          ticks += 1
          if (
            refreshed.status === 'running' &&
            ticks === 15 &&
            eventCount <= (baselineEventCount ?? 0)
          ) {
            appendLog(
              '[hint] 仍在 running：请确认已启动 Celery Worker（uv run celery -A app.tasks.celery_app worker -l info -Q ui,celery）',
              'hint-celery',
            )
          }
          if (
            ['awaiting_confirm', 'confirmed', 'cancelled', 'error', 'done'].includes(
              refreshed.status,
            )
          ) {
            stopPoll()
            setStopping(false)
            resolve(refreshed)
          }
        } catch (e) {
          stopPoll()
          reject(e)
        }
      }
      void tick()
      pollRef.current = window.setInterval(() => void tick(), 1500)
    })
  }

  async function startPlan(prompt: string) {
    if (!envs.data?.items?.length) {
      message.warning('请先配置 UI 环境')
      setEnvPopoverOpen(true)
      return
    }
    const userText = prompt.trim() || '请根据所选功能用例生成 UI 脚本'
    if (!prompt.trim() && testcaseIds.length === 0) {
      message.warning('请描述流程，或选择功能用例')
      return
    }
    if (authMode === 'account' && !accountName) {
      message.warning(
        storageAccounts.length
          ? '请选择本次使用的环境账号'
          : '当前环境没有已采集 storageState 的账号',
      )
      return
    }
    setBusy(true)
    setLogBubbles([])
    logSeqRef.current = 0
    seenLogKeysRef.current = new Set()
    setNotices([])
    setPendingUser(userText)
    try {
      const created = await apiJson<UiAgentSession>(
        `/api/v1/projects/${pid}/ui-scenario-agent/sessions`,
        {
          method: 'POST',
          body: JSON.stringify({
            prompt: prompt.trim(),
            testcase_ids: testcaseIds,
            env_id: envId ?? selectedEnv?.id ?? null,
            browser: browser || null,
            headed,
            engine,
            max_steps: 25,
            auth_mode: authMode === 'follow' ? null : authMode,
            account_name: authMode === 'account' ? accountName : null,
          }),
        },
      )
      setSession(created)
      if (created.env_id != null) setEnvId(created.env_id)
      if (Array.isArray(created.testcase_ids) && created.testcase_ids.length) {
        setTestcaseIds(created.testcase_ids)
      } else if (created.testcase_id != null) {
        setTestcaseIds([created.testcase_id])
      }
      if (created.browser) setBrowser(created.browser)
      ingestEvents(created.events || [])

      // SSE for live logs (may end early); poll until settled
      const ssePromise = apiSse(
        `/api/v1/projects/${pid}/ui-scenario-agent/sessions/${created.id}/events`,
        { method: 'GET' },
        (ev: SseEvent) => {
          ingestEvents([ev as Record<string, unknown>])
        },
      ).catch(() => undefined)

      const refreshed = await waitUntilSettled(created.id)
      await ssePromise
      setPendingUser(null)
      void refreshSessionList()
      if (refreshed.status === 'error') {
        if (!isManualStop(refreshed.error_message)) {
          message.error(refreshed.error_message || '探索失败')
          pushNotice('system', refreshed.error_message || '探索失败')
        }
      } else if (refreshed.status === 'awaiting_confirm') {
        pushNotice(
          'assistant',
          '左侧可编辑脚本：勾选批量试跑，或点「查看脚本」单条试跑；修改满意后再导入 UI 用例。',
        )
      }
    } catch (e) {
      message.error(errText(e))
      pushNotice('system', errText(e))
      setPendingUser(null)
    } finally {
      stopPoll()
      setBusy(false)
      setStopping(false)
    }
  }

  function codeForCase(updated: UiAgentSession, caseId: string): string {
    const rows = Array.isArray(updated.plan?.case_scripts) ? updated.plan!.case_scripts! : []
    const hit = rows.find((c) => c.id === caseId)
    return (hit?.code || updated.playwright_code || '').trim()
  }

  function syncScriptModalFromSession(updated: UiAgentSession, caseId?: string | null) {
    const id = caseId || scriptModal?.id
    if (!id || !scriptModal) return
    const code = codeForCase(updated, id)
    if (!code) return
    setScriptModal((prev) => (prev && prev.id === id ? { ...prev, code } : prev))
    setScriptBound({
      id: updated.id,
      code,
      text: code,
    })
  }

  function openScriptModalForCase(updated: UiAgentSession, caseId: string, codeOverride?: string) {
    const rows = Array.isArray(updated.plan?.case_scripts) ? updated.plan!.case_scripts! : []
    const hit = rows.find((c) => c.id === caseId)
    const name = hit?.name || caseId
    const code = (codeOverride || codeForCase(updated, caseId)).trim()
    if (!code) return
    setSelectedCaseId(caseId)
    setScriptModal({ id: caseId, name, code })
    setScriptReviseInput('')
    setScriptReviseChat([
      {
        id: 'script-welcome',
        role: 'assistant',
        content:
          '用自然语言描述要改的地方，例如：「登录改用 getByRole」「去掉重复点击标题」。改完左侧脚本会同步更新。',
      },
    ])
    setScriptBound({ id: updated.id, code, text: code })
    const trial = updated.plan?._trial
    const st = updated.dry_run_status
    if (
      st &&
      st !== 'running' &&
      trial?.case_id === caseId &&
      (st === 'failed' || st === 'error')
    ) {
      setScriptModalTab('trial')
    }
  }

  useEffect(() => {
    if (!scriptModal) {
      setScriptModalTab('chat')
    }
  }, [scriptModal])

  function trialStatusTag(caseId: string): { color: string; label: string } | null {
    const trialId = trialMeta?.case_id
    if (!session?.dry_run_status || !trialId || trialId !== caseId) return null
    const st = session.dry_run_status
    if (st === 'passed') return { color: 'success', label: '试跑通过' }
    if (st === 'running') return { color: 'processing', label: '试跑中' }
    return { color: 'error', label: '试跑未通过' }
  }

  async function sendRevise(content: string, opts?: { caseId?: string }) {
    if (!session) return
    const caseId = (opts?.caseId || selectedCaseId || '').trim()
    const wasWaitingHuman = session.status === 'awaiting_human'
    const fromError = session.status === 'error'
    setBusy(true)
    setPendingUser(content)
    try {
      const payload: Record<string, unknown> = { content, case_id: caseId }
      if (fromError) {
        payload.env_id = envId ?? selectedEnv?.id ?? null
        payload.browser = browser || null
        payload.headed = headed
        payload.auth_mode = authMode === 'follow' ? null : authMode
        payload.account_name = authMode === 'account' ? accountName : null
        payload.testcase_ids = testcaseIds
      }
      const updated = await apiJson<UiAgentSession>(
        `/api/v1/projects/${pid}/ui-scenario-agent/sessions/${session.id}/messages`,
        {
          method: 'POST',
          body: JSON.stringify(payload),
        },
      )
      setSession(updated)
      ingestEvents(updated.events || [])
      if (caseId) syncScriptModalFromSession(updated, caseId)
      else if (scriptModal) syncScriptModalFromSession(updated, scriptModal.id)
      if (wasWaitingHuman) {
        // Parent startPlan/waitUntilSettled keeps polling; just hand reply to worker.
        setPendingUser(null)
        setBusy(true)
        void refreshSessionList()
        return
      }
      if (updated.status === 'running') {
        const settled = await waitUntilSettled(updated.id)
        setPendingUser(null)
        void refreshSessionList()
        if (settled.status === 'error' && !isManualStop(settled.error_message)) {
          pushNotice('system', settled.error_message || '重新探索失败')
        }
      } else {
        setPendingUser(null)
        void refreshSessionList()
        if (updated.status === 'error' && !isManualStop(updated.error_message)) {
          pushNotice('system', updated.error_message || '修改失败')
        }
      }
    } catch (e) {
      message.error(errText(e))
      pushNotice('system', errText(e))
      setPendingUser(null)
    } finally {
      if (!wasWaitingHuman) {
        stopPoll()
        setBusy(false)
      }
    }
  }

  async function sendScriptModalRevise() {
    const text = scriptReviseInput.trim()
    if (!session || !scriptModal || !text || scriptReviseBusy || !canEditScript) return
    const caseId = scriptModal.id
    const userBubble: ChatBubble = {
      id: `script-u-${Date.now()}`,
      role: 'user',
      content: text,
    }
    setScriptReviseChat((prev) => [...prev, userBubble])
    setScriptReviseInput('')
    setScriptReviseBusy(true)
    try {
      const updated = await apiJson<UiAgentSession>(
        `/api/v1/projects/${pid}/ui-scenario-agent/sessions/${session.id}/messages`,
        {
          method: 'POST',
          body: JSON.stringify({ content: text, case_id: caseId }),
        },
      )
      setSession(updated)
      ingestEvents(updated.events || [])
      syncScriptModalFromSession(updated, caseId)
      const msgs = Array.isArray(updated.messages) ? updated.messages : []
      const lastAsst = [...msgs].reverse().find((m) => m.role === 'assistant')
      setScriptReviseChat((prev) => [
        ...prev,
        {
          id: `script-a-${Date.now()}`,
          role: 'assistant',
          content: lastAsst?.content || '已更新脚本。',
        },
      ])
      void refreshSessionList()
    } catch (e) {
      message.error(errText(e))
      setScriptReviseChat((prev) => [
        ...prev,
        { id: `script-e-${Date.now()}`, role: 'system', content: errText(e) },
      ])
    } finally {
      setScriptReviseBusy(false)
    }
  }

  async function onSend() {
    const text = input.trim()
    if (busy && !waitingHuman) return
    if (canStart) {
      pinChatAndLogsToBottom()
      setInput('')
      await startPlan(text)
      return
    }
    if (canChat) {
      if (!text) return
      pinChatAndLogsToBottom()
      setInput('')
      await sendRevise(text)
    }
  }

  async function stopExplore() {
    if (!session || (session.status !== 'running' && session.status !== 'awaiting_human')) return
    if (stopping) return
    setStopping(true)
    try {
      const updated = await apiJson<UiAgentSession>(
        `/api/v1/projects/${pid}/ui-scenario-agent/sessions/${session.id}/stop`,
        { method: 'POST' },
      )
      setSession(updated)
      ingestEvents(updated.events || [])
      void refreshSessionList()
      // Backend already appends the assistant stop message; avoid a duplicate notice.
      message.info('已停止探索')
      // waitUntilSettled will resolve on next poll tick when status is error
    } catch (e) {
      message.error(errText(e))
      pushNotice('system', errText(e))
      setStopping(false)
    }
  }

  async function waitUntilTrialSettled(sessionId: number): Promise<UiAgentSession> {
    stopPoll()
    return new Promise((resolve, reject) => {
      const tick = async () => {
        try {
          const refreshed = await apiJson<UiAgentSession>(
            `/api/v1/projects/${pid}/ui-scenario-agent/sessions/${sessionId}`,
          )
          setSession(refreshed)
          ingestEvents(refreshed.events || [])
          if (refreshed.dry_run_status !== 'running') {
            stopPoll()
            resolve(refreshed)
          }
        } catch (e) {
          stopPoll()
          reject(e)
        }
      }
      void tick()
      pollRef.current = window.setInterval(() => void tick(), 1500)
    })
  }

  async function trialRun(opts?: {
    caseId?: string
    code?: string
    quietSuccess?: boolean
    openModalOnPass?: boolean
    retainTrialBusy?: boolean
  }): Promise<'passed' | 'failed' | null> {
    if (!session) return null
    const caseId = opts?.caseId || scriptModal?.id || selectedCaseId || ''
    const code = (opts?.code ?? scriptModal?.code ?? scriptDraft).trim()
    if (!code) {
      if (!opts?.retainTrialBusy) message.warning('没有可试跑的脚本')
      return null
    }
    if (!opts?.retainTrialBusy) setTrialBusy(true)
    try {
      const started = await apiJson<UiAgentSession>(
        `/api/v1/projects/${pid}/ui-scenario-agent/sessions/${session.id}/trial-run`,
        {
          method: 'POST',
          body: JSON.stringify({
            case_id: caseId,
            headed: trialHeaded,
            script: code,
          }),
        },
      )
      setSession(started)
      ingestEvents(started.events || [])
      const settled = await waitUntilTrialSettled(started.id)
      setSession(settled)
      const resolvedId =
        settled.plan?._trial?.case_id || caseId || scriptModal?.id || selectedCaseId || ''
      const passed = settled.dry_run_status === 'passed'
      const openOnPass = opts?.openModalOnPass !== false
      if (resolvedId && (passed ? openOnPass : true)) {
        openScriptModalForCase(settled, resolvedId, code)
        syncScriptModalFromSession(settled, resolvedId)
        setScriptModalTab('trial')
      }
      if (passed) {
        if (!opts?.quietSuccess) {
          message.success(`试跑 ${resolvedId || ''} 通过`)
        }
        return 'passed'
      }
      message.error(formatTrialFailMessage(resolvedId, settled.dry_run_error || ''), 8)
      return 'failed'
    } catch (e) {
      message.error(errText(e))
      return null
    } finally {
      stopPoll()
      if (!opts?.retainTrialBusy) setTrialBusy(false)
    }
  }

  async function trialRunBatch(caseIds: string[]) {
    if (!session) return
    const items = buildCaseOverrides(caseIds)
    if (!items.length) {
      message.warning('没有可试跑的脚本')
      return
    }
    setTrialBusy(true)
    try {
      let passed = 0
      for (const item of items) {
        const result = await trialRun({
          caseId: item.id,
          code: item.code,
          quietSuccess: true,
          openModalOnPass: false,
          retainTrialBusy: true,
        })
        if (result !== 'passed') return
        passed += 1
      }
      message.success(`试跑 ${passed} 条全部通过`)
    } finally {
      stopPoll()
      setTrialBusy(false)
    }
  }

  function hydrateRepairPreview(sess: UiAgentSession) {
    const preview = sess.plan?._trial?.repair_preview
    if (!preview?.after) return
    setRepairBefore(preview.before || '')
    setRepairDraft(preview.after || '')
    setAcceptedRepairHunkKeys(new Set())
    setRepairViewMode('diff')
    setRepairPanelOpen(true)
    setRepairChatExpanded(false)
  }

  useEffect(() => {
    if (serverRepairPreview?.after && serverRepairPreview.status === 'pending') {
      setRepairBefore(serverRepairPreview.before || '')
      setRepairDraft(serverRepairPreview.after || '')
      setRepairPanelOpen(true)
      setRepairChatExpanded(false)
    }
  }, [session?.id, serverRepairPreview?.after, serverRepairPreview?.before, serverRepairPreview?.status])

  async function previewTrialRepair(caseId: string) {
    if (!session) return
    setRepairPreviewBusy(true)
    try {
      const updated = await apiJson<UiAgentSession>(
        `/api/v1/projects/${pid}/ui-scenario-agent/sessions/${session.id}/trial-repair/preview`,
        {
          method: 'POST',
          body: JSON.stringify({ case_id: caseId }),
        },
      )
      setSession(updated)
      ingestEvents(updated.events || [])
      hydrateRepairPreview(updated)
      const issues = updated.plan?._trial?.repair_preview?.issues || []
      if (issues.length) {
        message.warning('修复建议可能不完整，请仔细检查 diff 后再应用')
      } else {
        message.success('已生成 AI 修复预览')
      }
    } catch (e) {
      message.error(errText(e))
    } finally {
      setRepairPreviewBusy(false)
    }
  }

  async function discardTrialRepairPreview() {
    if (!session) return
    setRepairPreviewBusy(true)
    try {
      const updated = await apiJson<UiAgentSession>(
        `/api/v1/projects/${pid}/ui-scenario-agent/sessions/${session.id}/trial-repair/discard`,
        { method: 'POST' },
      )
      setSession(updated)
      setRepairPanelOpen(false)
      setRepairBefore('')
      setRepairDraft('')
      setAcceptedRepairHunkKeys(new Set())
      setRepairChatExpanded(false)
    } catch (e) {
      message.error(errText(e))
    } finally {
      setRepairPreviewBusy(false)
    }
  }

  async function applyTrialRepair(caseId: string, thenRun: boolean) {
    if (!session) return
    const script = repairDraft.trim()
    if (!isRunnableUiScript(script)) {
      message.warning('脚本缺少可执行的 run 函数')
      return
    }
    setRepairPreviewBusy(true)
    try {
      const applied = await apiJson<UiAgentSession>(
        `/api/v1/projects/${pid}/ui-scenario-agent/sessions/${session.id}/trial-repair/apply`,
        {
          method: 'POST',
          body: JSON.stringify({ script }),
        },
      )
      setSession(applied)
      ingestEvents(applied.events || [])
      setRepairPanelOpen(false)
      setRepairBefore('')
      setRepairDraft('')
      setAcceptedRepairHunkKeys(new Set())
      setRepairChatExpanded(false)
      openScriptModalForCase(applied, caseId, script)
      syncScriptModalFromSession(applied, caseId)
      message.success(`已应用 AI 修复到 ${caseId}`)
      if (thenRun) {
        await trialRun({ caseId, code: script })
      }
    } catch (e) {
      message.error(errText(e))
    } finally {
      setRepairPreviewBusy(false)
    }
  }

  function handleRepairAcceptHunk(_hunkIndex: number, key: string) {
    setAcceptedRepairHunkKeys((prev) => {
      const next = new Set(prev)
      next.add(key)
      return next
    })
  }

  function handleRepairRejectHunk(hunkIndex: number) {
    const lines =
      repairDiffLines.length > 0
        ? repairDiffLines
        : lineDiff(repairBefore, repairDraft)
    const nextScript = applyHunkDecision(lines, hunkIndex, 'reject')
    setRepairDraft(nextScript)
    setAcceptedRepairHunkKeys(new Set())
  }

  function buildCaseOverrides(ids: string[]) {
    return ids
      .map((caseId) => {
        const idx = caseScripts.findIndex(
          (row, i) => (row.id || `UC-${i + 1}`) === caseId,
        )
        const row = idx >= 0 ? caseScripts[idx] : null
        const code = row ? effectiveCodeForCase(caseId, String(row.code || '')) : ''
        return { id: caseId, code }
      })
      .filter((item) => isRunnableUiScript(item.code))
  }

  type ImportSuiteOpts = {
    name: string
    description: string
    env_id?: number
    browsers: string[]
    stop_on_fail: boolean
  }

  function defaultImportSuiteName(): string {
    return (
      session?.plan?.case_name?.trim() ||
      session?.plan?.goal?.trim() ||
      (session ? `UI Agent 会话 #${session.id}` : '')
    )
  }

  function openImportDialog(mode: 'all' | 'selected') {
    setImportDialogMode(mode)
    setImportCreateSuite(true)
    setImportSuiteName(defaultImportSuiteName())
    setImportSuiteDescription('')
    setImportSuiteEnvId(envId ?? selectedEnv?.id)
    setImportSuiteBrowsers([])
    setImportSuiteStopOnFail(true)
    setImportDialogOpen(true)
  }

  function submitImportDialog() {
    const count =
      importDialogMode === 'all' ? writableCaseIds.length : writeSelectedIds.length
    if (!count) {
      message.warning('没有可写入的脚本')
      return
    }
    if (importCreateSuite && !importSuiteName.trim()) {
      message.warning('请填写套件名称')
      return
    }
    const mode = importDialogMode === 'all' ? 'all' : writeSelectedIds
    const suiteOpts: ImportSuiteOpts | undefined = importCreateSuite
      ? {
          name: importSuiteName,
          description: importSuiteDescription,
          env_id: importSuiteEnvId,
          browsers: importSuiteBrowsers,
          stop_on_fail: importSuiteStopOnFail,
        }
      : undefined
    setImportDialogOpen(false)
    void confirmWrite(mode, importCreateSuite, suiteOpts)
  }

  async function confirmWrite(
    mode: 'all' | string[],
    createSuite: boolean,
    suiteOpts?: ImportSuiteOpts,
  ) {
    if (!session) return
    const ids = mode === 'all' ? writableCaseIds : mode.filter((id) => writableCaseIds.includes(id))
    if (!ids.length) {
      message.warning('没有可写入的脚本')
      return
    }
    setBusy(true)
    try {
      const payload: Record<string, unknown> = {
        action: 'confirm',
        status: 'ready',
        create_suite: createSuite,
        case_ids: mode === 'all' ? undefined : ids,
        case_overrides: buildCaseOverrides(ids),
      }
      if (createSuite && suiteOpts) {
        const name = suiteOpts.name.trim()
        if (name) payload.suite_name = name
        const desc = suiteOpts.description.trim()
        if (desc) payload.suite_description = desc
        if (suiteOpts.env_id != null) payload.suite_env_id = suiteOpts.env_id
        if (suiteOpts.browsers.length) payload.suite_browsers = suiteOpts.browsers
        payload.suite_stop_on_fail = suiteOpts.stop_on_fail
      }
      const result = await apiJson<UiAgentSession>(
        `/api/v1/projects/${pid}/ui-scenario-agent/sessions/${session.id}/confirm`,
        {
          method: 'POST',
          body: JSON.stringify(payload),
        },
      )
      setSession(result)
      ingestEvents(result.events || [])
      void refreshSessionList()
      if (result.saved_ui_case_id) {
        qc.invalidateQueries({ queryKey: ['ui-cases', pid] })
        if (result.saved_ui_suite_id != null) {
          qc.invalidateQueries({ queryKey: ['ui-suites', pid] })
        }
        const multi = result.plan?.saved_ui_case_ids
        const label =
          Array.isArray(multi) && multi.length
            ? multi.map((n) => `#${n}`).join('、')
            : `#${result.saved_ui_case_id}`
        const suiteLabel =
          result.saved_ui_suite_id != null
            ? `，已创建 UI 套件 #${result.saved_ui_suite_id}`
            : ''
        message.success(`已写入 UI 用例 ${label}${suiteLabel}`)
        pushNotice('assistant', `已写入 UI 用例 ${label}${suiteLabel}。`)
      } else if (result.status === 'error') {
        message.error(result.error_message || '写入失败')
        pushNotice('system', result.error_message || '写入失败')
      }
    } catch (e) {
      message.error(errText(e))
      pushNotice('system', errText(e))
    } finally {
      setBusy(false)
    }
  }

  async function reopenDraftAt(id: number) {
    const result = await apiJson<UiAgentSession>(
      `/api/v1/projects/${pid}/ui-scenario-agent/sessions/${id}/reopen`,
      { method: 'POST', body: '{}' },
    )
    setSession(result)
    ingestEvents(result.events || [])
    void refreshSessionList()
    return result
  }

  async function reopenDraft() {
    if (!session) return
    setBusy(true)
    try {
      await reopenDraftAt(session.id)
      message.success('已进入编辑，可试跑或使用一键/批量导入')
      pushNotice('assistant', '已恢复为草稿，可试跑或导入 UI 用例。')
    } catch (e) {
      message.error(errText(e))
      pushNotice('system', errText(e))
    } finally {
      setBusy(false)
    }
  }

  function toggleWriteSelected(caseId: string, checked: boolean) {
    setWriteSelectedIds((prev) => {
      if (checked) return prev.includes(caseId) ? prev : [...prev, caseId]
      return prev.filter((id) => id !== caseId)
    })
  }

  function resetSession() {
    stopPoll()
    pinChatAndLogsToBottom()
    setSession(null)
    setLogBubbles([])
    setLogsExpandedOverride(null)
    wasExploringRef.current = false
    logSeqRef.current = 0
    seenLogKeysRef.current = new Set()
    setInput('')
    setPendingUser(null)
    setNotices([])
    setStopping(false)
    setAuthMode('follow')
    setTestcaseIds([])
    setCaseFilter('')
    setWriteSelectedIds([])
    setSessionReady(true)
    if (Number.isFinite(pid)) {
      writeAgentLastSessionId(LAST_SESSION_PREFIX, pid, null)
    }
  }

  async function loadSession(
    id: number,
    opts?: { quiet?: boolean; force?: boolean },
  ): Promise<UiAgentSession | undefined> {
    if (!opts?.force && (busy || session?.id === id)) return undefined
    stopPoll()
    pinChatAndLogsToBottom()
    setBusy(true)
    setHistoryLoading(true)
    setLogBubbles([])
    setLogsExpandedOverride(null)
    logSeqRef.current = 0
    seenLogKeysRef.current = new Set()
    setNotices([])
    setPendingUser(null)
    try {
      const s = await apiJson<UiAgentSession>(
        `/api/v1/projects/${pid}/ui-scenario-agent/sessions/${id}`,
      )
      setSession(s)
      if (s.env_id != null) setEnvId(s.env_id)
      if (Array.isArray(s.testcase_ids) && s.testcase_ids.length) {
        setTestcaseIds(s.testcase_ids)
      } else if (s.testcase_id != null) {
        setTestcaseIds([s.testcase_id])
      } else {
        setTestcaseIds([])
      }
      if (s.browser) setBrowser(s.browser)
      setHeaded(Boolean(s.headed))
      setTrialHeaded(Boolean(s.headed))
      setAuthMode(
        s.auth_mode === 'none' ? 'none' : s.auth_mode === 'account' ? 'account' : 'follow',
      )
      setAccountName(s.account_name || undefined)
      ingestEvents(s.events || [])
      if (!opts?.quiet) {
        const openedDraft =
          (Array.isArray(s.plan?.case_scripts) &&
            s.plan.case_scripts.some((c) => (c.code || '').trim())) ||
          Boolean(s.playwright_code?.trim())
        if (s.status === 'cancelled') {
          pushNotice(
            'assistant',
            openedDraft
              ? '该会话曾取消写入；点工具栏「编辑」可继续试跑与导入。'
              : '已打开已取消会话（只读）。可点「新会话」重新开始。',
          )
        } else if (['confirmed', 'done'].includes(s.status)) {
          pushNotice(
            'assistant',
            openedDraft
              ? '已打开历史会话（只读）。点工具栏「编辑」可改脚本、试跑或导入。'
              : '已打开历史会话（只读）。可点「新会话」重新开始。',
          )
        } else if (s.status === 'error') {
          pushNotice('assistant', '已打开失败会话，可继续描述并重新探索。')
        } else if (s.status === 'awaiting_confirm') {
          pushNotice('assistant', '已打开历史会话，可继续修改或确认写入。')
        } else if (s.status === 'awaiting_human') {
          pushNotice(
            'assistant',
            '探索暂停等待人工协助：浏览器应仍打开，可输入验证码或「继续」。',
          )
        } else if (s.status === 'running') {
          pushNotice('assistant', '会话仍在探索中，正在同步进度…')
        }
      }
      if (s.status === 'running' || s.status === 'awaiting_human') {
        void waitUntilSettled(s.id).finally(() => {
          stopPoll()
          void refreshSessionList()
        })
      }
      return s
    } catch (e) {
      if (!opts?.quiet) message.error(errText(e))
      return undefined
    } finally {
      setBusy(false)
      setHistoryLoading(false)
    }
  }

  async function openHistorySession(id: number) {
    await loadSession(id)
  }

  async function deleteHistorySession(id: number) {
    if (busy) return
    setBusy(true)
    try {
      await apiJson(`/api/v1/projects/${pid}/ui-scenario-agent/sessions/${id}`, {
        method: 'DELETE',
      })
      const list = await apiJson<AgentSessionSummary[]>(
        `/api/v1/projects/${pid}/ui-scenario-agent/sessions`,
      )
      setSessionList(list)
      if (session?.id === id) {
        if (list[0]) {
          setBusy(false)
          await loadSession(list[0].id, { quiet: true, force: true })
          return
        }
        resetSession()
      }
    } catch (e) {
      message.error(errText(e))
    } finally {
      setBusy(false)
    }
  }

  useEffect(() => {
    if (!Number.isFinite(pid) || session?.id == null) return
    writeAgentLastSessionId(LAST_SESSION_PREFIX, pid, session.id)
  }, [pid, session?.id])

  useEffect(() => {
    if (!Number.isFinite(pid) || !listLoadGen) return
    if (restoredGenRef.current === listLoadGen) return
    restoredGenRef.current = listLoadGen
    let cancelled = false

    async function restoreLastSession() {
      const saved = readAgentLastSessionId(LAST_SESSION_PREFIX, pid)
      const fallbackId = sessionList[0]?.id ?? null
      const candidates = [
        ...(saved != null ? [saved] : []),
        ...(fallbackId != null && fallbackId !== saved ? [fallbackId] : []),
      ]

      for (const targetId of candidates) {
        if (cancelled) return
        try {
          const s = await apiJson<UiAgentSession>(
            `/api/v1/projects/${pid}/ui-scenario-agent/sessions/${targetId}`,
          )
          if (cancelled) return
          setSession(s)
          if (s.env_id != null) setEnvId(s.env_id)
          // Auto-restore keeps composer unbound; only explicit history open syncs testcase.
          setTestcaseIds([])
          if (s.browser) setBrowser(s.browser)
          setHeaded(Boolean(s.headed))
          setTrialHeaded(Boolean(s.headed))
          setAuthMode(
            s.auth_mode === 'none'
              ? 'none'
              : s.auth_mode === 'account'
                ? 'account'
                : 'follow',
          )
          setAccountName(s.account_name || undefined)
          setLogBubbles([])
          logSeqRef.current = 0
          seenLogKeysRef.current = new Set()
          setNotices([])
          setPendingUser(null)
          ingestEvents(s.events || [])
          writeAgentLastSessionId(LAST_SESSION_PREFIX, pid, s.id)
          if (s.status === 'running' || s.status === 'awaiting_human') {
            void waitUntilSettled(s.id).finally(() => {
              stopPoll()
              void refreshSessionList()
            })
          }
          break
        } catch {
          if (saved === targetId) {
            writeAgentLastSessionId(LAST_SESSION_PREFIX, pid, null)
          }
        }
      }
      if (!cancelled) setSessionReady(true)
    }

    void restoreLastSession()
    return () => {
      cancelled = true
    }
    // Intentionally only after list fetch for this pid settles
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pid, listLoadGen, sessionList])

  const canSend =
    sessionReady &&
    !finished &&
    (canStart || (canChat && !!input.trim())) &&
    (!busy || waitingHuman)

  const casePicker = (
    <div className="api-scenario-agent-picker">
      <Typography.Text type="secondary" style={{ fontSize: 12, display: 'block', marginBottom: 8 }}>
        功能用例（可多选）
      </Typography.Text>
      <Input
        size="small"
        allowClear
        placeholder="搜索用例标题"
        value={caseFilter}
        onChange={(e) => setCaseFilter(e.target.value)}
        disabled={!canTuneExplore}
        style={{ marginBottom: 8 }}
      />
      <div className="api-scenario-agent-picker-list">
        <Space direction="vertical" style={{ width: '100%' }} size={4}>
          <Button
            size="small"
            type={testcaseIds.length === 0 ? 'primary' : 'default'}
            block
            disabled={!canTuneExplore}
            onClick={() => {
              setTestcaseIds([])
            }}
          >
            不绑定功能用例
          </Button>
          {filteredCases.map((c) => {
            const selected = testcaseIds.includes(c.id)
            return (
              <Button
                key={c.id}
                size="small"
                type={selected ? 'primary' : 'default'}
                block
                disabled={!canTuneExplore}
                className="api-scenario-agent-picker-item"
                onClick={() => {
                  setTestcaseIds((prev) =>
                    prev.includes(c.id) ? prev.filter((id) => id !== c.id) : [...prev, c.id],
                  )
                }}
              >
                <span className="api-scenario-agent-picker-item-title">{c.title}</span>
              </Button>
            )
          })}
          {filteredCases.length === 0 && (
            <Typography.Text type="secondary" style={{ fontSize: 12 }}>
              无匹配用例
            </Typography.Text>
          )}
        </Space>
      </div>
    </div>
  )

  const envPicker = (
    <div className="api-scenario-agent-picker api-scenario-agent-picker--env">
      <Typography.Text type="secondary" style={{ fontSize: 12, display: 'block', marginBottom: 8 }}>
        UI 环境
      </Typography.Text>
      <Select
        allowClear
        placeholder="选择环境"
        value={envId}
        onChange={(v) => {
          setEnvId(v)
          setBrowser(undefined)
        }}
        style={{ width: '100%', marginBottom: 8 }}
        options={(envs.data?.items ?? []).map((e) => ({
          value: e.id,
          label: e.is_default ? `${e.name}（默认）` : e.name,
        }))}
        disabled={!canEditEnv}
        getPopupContainer={(n) => n.parentElement ?? document.body}
      />
      <Typography.Text type="secondary" style={{ fontSize: 12, display: 'block', marginBottom: 8 }}>
        浏览器
      </Typography.Text>
      <Select
        allowClear
        placeholder="浏览器"
        value={browser}
        onChange={(v) => {
          setBrowser(v)
          setEnvPopoverOpen(false)
        }}
        style={{ width: '100%' }}
        options={browserOptions.map((b) => ({ value: b, label: b }))}
        disabled={!canEditEnv}
        getPopupContainer={(n) => n.parentElement ?? document.body}
      />
      {selectedEnv?.base_url && (
        <Typography.Paragraph type="secondary" style={{ fontSize: 12, marginTop: 8, marginBottom: 0 }}>
          {selectedEnv.base_url}
        </Typography.Paragraph>
      )}
    </div>
  )

  const authPicker = (
    <div style={{ width: 260 }}>
      <Typography.Text type="secondary" style={{ fontSize: 12, display: 'block', marginBottom: 8 }}>
        登录态
      </Typography.Text>
      <Select
        value={authMode}
        onChange={(value: 'follow' | 'account' | 'none') => setAuthMode(value)}
        style={{ width: '100%', marginBottom: authMode === 'account' ? 8 : 0 }}
        options={[
          { value: 'follow', label: '跟随环境 Token 注入' },
          { value: 'account', label: '指定环境账号 storageState' },
          { value: 'none', label: '跳过登录态（测试登录）' },
        ]}
        getPopupContainer={(node) => node.parentElement ?? document.body}
      />
      {authMode === 'account' && (
        <>
          <Select
            value={accountName}
            placeholder={
              storageAccounts.length ? '选择已采集登录态的账号' : '没有可用的账号登录态'
            }
            onChange={setAccountName}
            style={{ width: '100%' }}
            options={storageAccounts.map((account) => ({
              value: account.name,
              label: account.name,
            }))}
            disabled={!storageAccounts.length}
            getPopupContainer={(node) => node.parentElement ?? document.body}
          />
          {!storageAccounts.length && (
            <Typography.Text type="danger" style={{ fontSize: 12 }}>
              请先在 UI 环境中为账号采集 storageState
            </Typography.Text>
          )}
        </>
      )}
    </div>
  )

  const selectedCaseTitles = (cases.data?.items ?? [])
    .filter((c) => testcaseIds.includes(c.id))
    .map((c) => c.title)
  const selectedCaseTitle =
    selectedCaseTitles.length === 0
      ? ''
      : selectedCaseTitles.length === 1
        ? selectedCaseTitles[0]
        : `${selectedCaseTitles[0]} 等 ${selectedCaseTitles.length} 条`

  const importDialogCount =
    importDialogMode === 'all' ? writableCaseIds.length : writeSelectedIds.length
  const importOkDisabled =
    !importDialogCount || busy || (importCreateSuite && !importSuiteName.trim())

  return (
    <div className="api-scenario-agent-page">
      <PageBanner title="UI 自动化 Agent" />
      <Modal
        title={`导入 ${importDialogCount} 条到 UI 用例`}
        open={importDialogOpen}
        okText="导入"
        cancelText="取消"
        confirmLoading={busy}
        okButtonProps={{ disabled: importOkDisabled }}
        onOk={submitImportDialog}
        onCancel={() => setImportDialogOpen(false)}
        destroyOnClose
        width={480}
      >
        <Checkbox
          checked={importCreateSuite}
          onChange={(e) => setImportCreateSuite(e.target.checked)}
          style={{ marginBottom: importCreateSuite ? 12 : 0 }}
        >
          同时创建 1 个 UI 套件（按当前列表顺序）
        </Checkbox>
        {importCreateSuite ? (
          <div className="ui-agent-import-suite-form">
            <Typography.Text type="secondary" style={{ display: 'block', marginBottom: 8 }}>
              套件信息
            </Typography.Text>
            <div style={{ marginBottom: 12 }}>
              <Typography.Text style={{ display: 'block', marginBottom: 4 }}>
                名称 <Typography.Text type="danger">*</Typography.Text>
              </Typography.Text>
              <Input
                value={importSuiteName}
                onChange={(e) => setImportSuiteName(e.target.value)}
                placeholder="套件名称"
                maxLength={512}
              />
            </div>
            <div style={{ marginBottom: 12 }}>
              <Typography.Text style={{ display: 'block', marginBottom: 4 }}>
                描述
              </Typography.Text>
              <Input.TextArea
                value={importSuiteDescription}
                onChange={(e) => setImportSuiteDescription(e.target.value)}
                placeholder="选填；留空则使用默认说明"
                rows={2}
                maxLength={2000}
              />
            </div>
            <div style={{ marginBottom: 12 }}>
              <Typography.Text style={{ display: 'block', marginBottom: 4 }}>
                默认环境
              </Typography.Text>
              <Select
                allowClear
                style={{ width: '100%' }}
                value={importSuiteEnvId}
                onChange={(v) => setImportSuiteEnvId(v)}
                placeholder="未选择则使用会话环境"
                options={(envs.data?.items ?? []).map((e) => ({
                  value: e.id,
                  label: e.is_default ? `${e.name}（默认）` : e.name,
                }))}
              />
            </div>
            <div style={{ marginBottom: 12 }}>
              <Typography.Text style={{ display: 'block', marginBottom: 4 }}>
                浏览器矩阵
              </Typography.Text>
              <Select
                mode="multiple"
                allowClear
                style={{ width: '100%' }}
                value={importSuiteBrowsers}
                onChange={(v) => setImportSuiteBrowsers(v)}
                placeholder="不选则执行时使用默认浏览器"
                options={[
                  { value: 'chromium', label: 'Chromium' },
                  { value: 'firefox', label: 'Firefox' },
                  { value: 'webkit', label: 'WebKit' },
                ]}
              />
            </div>
            <Space>
              <Switch
                checked={importSuiteStopOnFail}
                onChange={setImportSuiteStopOnFail}
                checkedChildren="失败即停"
                unCheckedChildren="继续"
              />
              <Typography.Text type="secondary">失败即停止后续用例</Typography.Text>
            </Space>
          </div>
        ) : null}
      </Modal>
      <div className="api-scenario-agent-split">
        <aside className="api-scenario-agent-plan card">
          <div className="api-scenario-agent-chat-toolbar api-scenario-agent-plan-toolbar">
            <Typography.Text strong>
              {session?.plan?.case_name || session?.plan?.goal || '探索计划 / 脚本'}
            </Typography.Text>
            {showSessionEdit && (
              <Button size="small" type="primary" loading={busy} onClick={() => void reopenDraft()}>
                编辑
              </Button>
            )}
            {canEditScript && (
              <Space size="small" wrap>
                <Button
                  size="small"
                  type="primary"
                  disabled={!writableCaseIds.length || busy}
                  loading={busy}
                  onClick={() => openImportDialog('all')}
                >
                  一键导入
                </Button>
                <Button
                  size="small"
                  disabled={!writeSelectedIds.length || busy}
                  loading={busy}
                  onClick={() => openImportDialog('selected')}
                >
                  批量导入 ({writeSelectedIds.length})
                </Button>
                <Button
                  size="small"
                  disabled={!writeSelectedIds.length || trialBusy || busy}
                  loading={trialBusy}
                  onClick={() => void trialRunBatch(writeSelectedIds)}
                >
                  批量试跑 ({writeSelectedIds.length})
                </Button>
              </Space>
            )}
          </div>
          <div className="api-scenario-agent-plan-body ui-agent-script-body">
            {session?.plan?.goal && (
              <p className="api-scenario-agent-summary">
                目标：{session.plan.goal}
                {session.plan.start_path ? ` · 起始 ${session.plan.start_path}` : ''}
              </p>
            )}
            {(() => {
              const report = session?.explore_report || session?.plan?.explore_report || null
              const hasScripts = caseScripts.some((c) => (c.code || '').trim())
              // Hide script entry while exploring so users don't think codegen finished early
              const showScriptUi = !exploring && hasScripts
              // Explore-first: hide skeleton「待探索」matrix; show scripts and/or report summary only
              if (!showScriptUi && !report?.summary) return null
              return (
                <div className="ui-agent-explore-report">
                  {showScriptUi && (
                    <div className="ui-agent-case-scripts">
                      <div className="ui-agent-case-scripts-head">
                        <Typography.Text strong style={{ fontSize: 12, flexShrink: 0 }}>
                          用例脚本
                        </Typography.Text>
                        {canEditScript && writableCaseIds.length > 0 ? (
                          <Space size={4} className="ui-agent-case-select-actions">
                            <Button
                              type="link"
                              size="small"
                              style={{ paddingInline: 0, fontSize: 12 }}
                              onClick={() => setWriteSelectedIds([...writableCaseIds])}
                            >
                              全选
                            </Button>
                            <Button
                              type="link"
                              size="small"
                              style={{ paddingInline: 0, fontSize: 12 }}
                              onClick={() => setWriteSelectedIds([])}
                            >
                              全不选
                            </Button>
                          </Space>
                        ) : null}
                      </div>
                      <div className="ui-agent-case-list">
                        {caseScripts.map((row, idx) => {
                          const id = row.id || `UC-${idx + 1}`
                          const name = row.name || id
                          const code = String(row.code || '')
                          const effectiveCode = effectiveCodeForCase(id, code)
                          const writable = isRunnableUiScript(effectiveCode)
                          const selected = id === (activeCase?.id || selectedCaseId)
                          const checked = writeSelectedIds.includes(id)
                          return (
                            <div
                              key={`${id}-${name}`}
                              className={`ui-agent-case-row${selected ? ' is-selected' : ''}`}
                              role="button"
                              tabIndex={0}
                              onClick={() => {
                                setSelectedCaseId(id)
                                setScriptBound({ id: session?.id ?? null, code: '', text: '' })
                              }}
                              onKeyDown={(e) => {
                                if (e.key === 'Enter' || e.key === ' ') {
                                  e.preventDefault()
                                  setSelectedCaseId(id)
                                  setScriptBound({ id: session?.id ?? null, code: '', text: '' })
                                }
                              }}
                            >
                              {canEditScript && writable ? (
                                <Checkbox
                                  className="ui-agent-case-row-check"
                                  checked={checked}
                                  onClick={(e) => e.stopPropagation()}
                                  onChange={(e) => toggleWriteSelected(id, e.target.checked)}
                                />
                              ) : canEditScript ? (
                                <span className="ui-agent-case-row-check is-placeholder" aria-hidden />
                              ) : null}
                              <Space size={4} wrap style={{ flex: 1, minWidth: 0 }}>
                                <Tag>{id}</Tag>
                                <span style={{ wordBreak: 'break-word' }}>{name}</span>
                                {writable ? (
                                  <Tag color="success">有脚本</Tag>
                                ) : code.trim() ? (
                                  <Tag>草稿</Tag>
                                ) : (
                                  <Tag>未就绪</Tag>
                                )}
                                {(() => {
                                  const trialTag = trialStatusTag(id)
                                  return trialTag ? (
                                    <Tag color={trialTag.color}>{trialTag.label}</Tag>
                                  ) : null
                                })()}
                              </Space>
                              {code.trim() ? (
                                <Button
                                  type="link"
                                  size="small"
                                  style={{ flexShrink: 0, paddingInline: 4 }}
                                  onClick={(e) => {
                                    e.stopPropagation()
                                    const sameCase = id === (selectedCaseId || activeCase?.id)
                                    const draftCode =
                                      sameCase &&
                                      scriptBound.id === (session?.id ?? null) &&
                                      scriptBound.text.trim()
                                        ? scriptBound.text
                                        : code
                                    setSelectedCaseId(id)
                                    setScriptModal({ id, name, code: draftCode })
                                    setScriptReviseInput('')
                                    setScriptReviseChat([
                                      {
                                        id: 'script-welcome',
                                        role: 'assistant',
                                        content:
                                          '用自然语言描述要改的地方，例如：「登录改用 getByRole」「去掉重复点击标题」。改完左侧脚本会同步更新。',
                                      },
                                    ])
                                  }}
                                >
                                  查看脚本
                                </Button>
                              ) : null}
                            </div>
                          )
                        })}
                      </div>
                    </div>
                  )}
                  {report?.summary && (
                    <Space size={4} wrap style={{ marginBottom: 8 }}>
                      {(report.summary.pages_visited ?? 0) > 0 ? (
                        <Tag color="green">
                          已记录 {report.summary.pages_visited} 页 · {report.summary.recon_controls ?? 0} 控件
                        </Tag>
                      ) : null}
                      <Tag>步骤 {report.summary.total_steps ?? 0}</Tag>
                      <Tag color="blue">PW {report.summary.playwright_steps ?? 0}</Tag>
                      <Tag color="purple">Mid {report.summary.midscene_steps ?? 0}</Tag>
                    </Space>
                  )}
                </div>
              )
            })()}
            <Modal
              title={scriptModal ? `${scriptModal.id} ${scriptModal.name}` : '用例脚本'}
              open={Boolean(scriptModal)}
              centered
              onCancel={() => {
                setScriptModal(null)
                setScriptReviseInput('')
                setScriptReviseChat([])
                setRepairChatExpanded(false)
                setScriptModalTab('chat')
              }}
              footer={[
                scriptModalInRepair ? (
                  <Space key="repair-actions" size="small" style={{ marginRight: 'auto' }}>
                    <Button
                      disabled={repairPreviewBusy}
                      onClick={() => void discardTrialRepairPreview()}
                    >
                      放弃
                    </Button>
                    <Button
                      type="primary"
                      loading={repairPreviewBusy}
                      disabled={!repairDraft.trim()}
                      onClick={() => void applyTrialRepair(trialMeta!.case_id!, false)}
                    >
                      应用修改
                    </Button>
                    <Button
                      type="primary"
                      loading={repairPreviewBusy || trialBusy}
                      disabled={!repairDraft.trim()}
                      onClick={() => void applyTrialRepair(trialMeta!.case_id!, true)}
                    >
                      应用并试跑
                    </Button>
                  </Space>
                ) : (
                  <Space key="trial-mode" size="small" style={{ marginRight: 'auto' }}>
                    <Switch
                      size="small"
                      checked={trialHeaded}
                      onChange={setTrialHeaded}
                      checkedChildren="有头"
                      unCheckedChildren="无头"
                      disabled={trialBusy || !canEditScript}
                    />
                    <Button
                      key="trial"
                      loading={trialBusy}
                      disabled={!scriptModal?.code?.trim() || !canEditScript || trialBusy}
                      onClick={() =>
                        void trialRun({
                          caseId: scriptModal?.id,
                          code: scriptModal?.code,
                        })
                      }
                    >
                      试跑
                    </Button>
                    {hasRepairFailure && trialMeta?.case_id === scriptModal?.id && (
                      <>
                        <Button
                          key="repair-preview"
                          loading={repairPreviewBusy}
                          disabled={trialBusy || repairPreviewBusy || !canRepairTrial}
                          onClick={() => void previewTrialRepair(trialMeta!.case_id!)}
                        >
                          {canRepairTrial
                            ? `AI 修复（${repairAttempts + 1}/2）`
                            : 'AI 修复已达 2 轮上限'}
                        </Button>
                        <Button
                          key="repair-preview-run"
                          type="primary"
                          loading={repairPreviewBusy}
                          disabled={trialBusy || repairPreviewBusy || !canRepairTrial}
                          onClick={() => void previewTrialRepair(trialMeta!.case_id!)}
                        >
                          {canRepairTrial
                            ? `AI 修复并试跑（${repairAttempts + 1}/2）`
                            : 'AI 修复已达 2 轮上限'}
                        </Button>
                      </>
                    )}
                  </Space>
                ),
                <Button
                  key="close"
                  onClick={() => {
                    setScriptModal(null)
                    setScriptReviseInput('')
                    setScriptReviseChat([])
                  }}
                >
                  关闭
                </Button>,
                <Button
                  key="copy"
                  type="primary"
                  disabled={!scriptModal?.code?.trim()}
                  onClick={async () => {
                    try {
                      await navigator.clipboard.writeText(scriptModal?.code || '')
                      message.success('已复制脚本')
                    } catch {
                      message.error('复制失败')
                    }
                  }}
                >
                  复制
                </Button>,
              ]}
              width={1080}
              height="calc(100dvh - 48px)"
              destroyOnClose
              styles={{
                container: {
                  display: 'flex',
                  flexDirection: 'column',
                  height: '100%',
                  minHeight: 0,
                  overflow: 'hidden',
                },
                body: {
                  display: 'flex',
                  flexDirection: 'column',
                  flex: 1,
                  minHeight: 0,
                  overflow: 'hidden',
                  paddingTop: 12,
                },
              }}
              className={
                scriptModalInRepair
                  ? 'ui-agent-script-modal is-repair-mode'
                  : 'ui-agent-script-modal'
              }
            >
              <div className="ui-agent-script-modal-split">
                <div className="ui-agent-script-modal-code">
                  {scriptModalInRepair ? (
                    <div className="ui-agent-repair-pane">
                      <div className="ui-agent-repair-pane-head">
                        <Space size={8} wrap>
                          <Typography.Text strong>AI 修复预览</Typography.Text>
                          <Tag color="processing">第 {repairAttempts + 1}/2 轮</Tag>
                        </Space>
                        <Segmented
                          size="small"
                          value={repairViewMode}
                          onChange={(v) => setRepairViewMode(v as 'diff' | 'edit')}
                          options={[
                            { label: '差异', value: 'diff' },
                            { label: '编辑', value: 'edit' },
                          ]}
                        />
                      </div>
                      {(serverRepairPreview?.issues?.length || 0) > 0 ? (
                        <Typography.Paragraph
                          type="warning"
                          className="ui-agent-repair-pane-warn"
                        >
                          修复建议可能不完整：{(serverRepairPreview?.issues || [])
                            .slice(0, 3)
                            .join('；')}
                        </Typography.Paragraph>
                      ) : null}
                      <div className="ui-agent-repair-pane-body">
                        {repairViewMode === 'diff' ? (
                          <ScriptDiffView
                            lines={repairDiffLines}
                            acceptedKeys={acceptedRepairHunkKeys}
                            onAcceptHunk={handleRepairAcceptHunk}
                            onRejectHunk={handleRepairRejectHunk}
                          />
                        ) : (
                          <ScriptCodeEditor
                            className="ui-agent-script-monaco"
                            value={repairDraft}
                            height="100%"
                            onChange={(text) => {
                              setRepairDraft(text)
                              setAcceptedRepairHunkKeys(new Set())
                            }}
                          />
                        )}
                      </div>
                    </div>
                  ) : (
                    <ScriptCodeEditor
                      className="ui-agent-script-monaco"
                      value={scriptModal?.code || ''}
                      readOnly={!canEditScript}
                      height="100%"
                      onChange={
                        canEditScript
                          ? (text) => {
                              setScriptModal((prev) => (prev ? { ...prev, code: text } : prev))
                              setScriptBound({
                                id: session?.id ?? null,
                                code: serverScript,
                                text,
                              })
                            }
                          : undefined
                      }
                    />
                  )}
                </div>
                {scriptModalInRepair && !repairChatExpanded ? (
                  <Tooltip title="展开对话改脚本">
                    <button
                      type="button"
                      className="ui-agent-script-modal-chat-rail"
                      onClick={() => setRepairChatExpanded(true)}
                    >
                      对话
                    </button>
                  </Tooltip>
                ) : scriptModalInRepair ? (
                  <div className="ui-agent-script-modal-chat">
                    <div className="ui-agent-script-modal-chat-title">
                      <span>对话改脚本</span>
                      <Button type="link" size="small" onClick={() => setRepairChatExpanded(false)}>
                        收起
                      </Button>
                    </div>
                    <div className="ui-agent-script-modal-chat-list" ref={scriptReviseScrollRef}>
                      {scriptReviseChat.map((m) => (
                        <div
                          key={m.id}
                          className={`ui-agent-script-modal-bubble is-${m.role}`}
                        >
                          {m.content}
                        </div>
                      ))}
                      {scriptReviseBusy ? (
                        <div className="ui-agent-script-modal-bubble is-assistant">
                          正在修改脚本…
                        </div>
                      ) : null}
                    </div>
                    {canEditScript ? (
                      <div className="ui-agent-script-modal-chat-composer">
                        <Input.TextArea
                          value={scriptReviseInput}
                          onChange={(e) => setScriptReviseInput(e.target.value)}
                          placeholder="例如：登录改用 getByRole；去掉带日期的 getByText"
                          autoSize={{ minRows: 4, maxRows: 8 }}
                          disabled={scriptReviseBusy}
                          onPressEnter={(e) => {
                            if (!e.shiftKey) {
                              e.preventDefault()
                              void sendScriptModalRevise()
                            }
                          }}
                        />
                        <Button
                          type="primary"
                          size="small"
                          loading={scriptReviseBusy}
                          disabled={!scriptReviseInput.trim() || scriptReviseBusy}
                          onClick={() => void sendScriptModalRevise()}
                        >
                          发送
                        </Button>
                      </div>
                    ) : (
                      <div className="ui-agent-script-modal-chat-hint">
                        {scriptModalReadonlyHint(scriptPhase, session?.status)}
                      </div>
                    )}
                  </div>
                ) : (
                  <Tabs
                    className="ui-agent-script-modal-tabs"
                    activeKey={scriptModalTab}
                    onChange={(key) => setScriptModalTab(key as 'chat' | 'trial')}
                    items={[
                      {
                        key: 'chat',
                        label: '对话改脚本',
                        children: (
                          <div className="ui-agent-script-modal-chat ui-agent-script-modal-chat--in-tab">
                            <div className="ui-agent-script-modal-chat-list" ref={scriptReviseScrollRef}>
                              {scriptReviseChat.map((m) => (
                                <div
                                  key={m.id}
                                  className={`ui-agent-script-modal-bubble is-${m.role}`}
                                >
                                  {m.content}
                                </div>
                              ))}
                              {scriptReviseBusy ? (
                                <div className="ui-agent-script-modal-bubble is-assistant">
                                  正在修改脚本…
                                </div>
                              ) : null}
                            </div>
                            {canEditScript ? (
                              <div className="ui-agent-script-modal-chat-composer">
                                <Input.TextArea
                                  value={scriptReviseInput}
                                  onChange={(e) => setScriptReviseInput(e.target.value)}
                                  placeholder="例如：登录改用 getByRole；去掉带日期的 getByText"
                                  autoSize={{ minRows: 4, maxRows: 8 }}
                                  disabled={scriptReviseBusy}
                                  onPressEnter={(e) => {
                                    if (!e.shiftKey) {
                                      e.preventDefault()
                                      void sendScriptModalRevise()
                                    }
                                  }}
                                />
                                <Button
                                  type="primary"
                                  size="small"
                                  loading={scriptReviseBusy}
                                  disabled={!scriptReviseInput.trim() || scriptReviseBusy}
                                  onClick={() => void sendScriptModalRevise()}
                                >
                                  发送
                                </Button>
                              </div>
                            ) : (
                              <div className="ui-agent-script-modal-chat-hint">
                                {scriptModalReadonlyHint(scriptPhase, session?.status)}
                              </div>
                            )}
                          </div>
                        ),
                      },
                      {
                        key: 'trial',
                        label: (
                          <Tooltip
                            title={trialTabFailureSummary || undefined}
                            open={trialTabFailureSummary ? undefined : false}
                          >
                            <Space size={6}>
                              <span>试跑明细</span>
                              {scriptModalTrialReady && session?.dry_run_status === 'passed' ? (
                                <Badge status="success" text="通过" />
                              ) : null}
                              {scriptModalTrialReady &&
                              (session?.dry_run_status === 'failed' ||
                                session?.dry_run_status === 'error') ? (
                                <Badge status="error" text="失败" />
                              ) : null}
                              {scriptModalTrialReady && session?.dry_run_status === 'running' ? (
                                <Badge status="processing" text="执行中" />
                              ) : null}
                            </Space>
                          </Tooltip>
                        ),
                        disabled: !scriptModalTrialReady,
                        children: scriptModalTrialReady && session ? (
                          <TrialRunResult
                            projectId={pid}
                            sessionId={session.id}
                            trial={trialMeta}
                            status={session.dry_run_status}
                            caseId={scriptModal?.id}
                            errorMessage={session.dry_run_error}
                            className="ui-agent-trial-result--in-modal"
                            hideHead
                            variant="modal"
                          />
                        ) : (
                          <Typography.Text type="secondary">请先试跑，再在此查看执行明细。</Typography.Text>
                        ),
                      },
                    ]}
                  />
                )}
              </div>
            </Modal>
          </div>
          {session?.saved_ui_case_id != null ? (
            <div className="ui-agent-script-foot">
              <span className="ui-agent-script-foot-meta">
                已写入{' '}
                <Link to={`/projects/${pid}/ui-cases`}>用例 #{session.saved_ui_case_id}</Link>
                {session.saved_ui_suite_id != null ? (
                  <>
                    {' · '}
                    <Link to={`/projects/${pid}/ui-suites`}>
                      套件 #{session.saved_ui_suite_id}
                    </Link>
                  </>
                ) : null}
              </span>
            </div>
          ) : null}
        </aside>

        <section
          className={`api-scenario-agent-chat card${chatCollapsed ? ' is-collapsed' : ''}`}
        >
          <div className="api-scenario-agent-chat-toolbar">
            <div className="api-scenario-agent-chat-toolbar-left">
              <Space size="small" wrap>
                {session && (
                  <Tag color={statusColor(session.status)}>{statusLabel(session.status)}</Tag>
                )}
                {session?.has_credentials && <Tag>已解析对话账号</Tag>}
                {(session?.headed || (canStart && headed)) && <Tag color="blue">有头</Tag>}
                {(session?.auth_mode === 'none' || (canStart && authMode === 'none')) && (
                  <Tag>跳过登录态</Tag>
                )}
                {(session?.auth_mode === 'account' || (canStart && authMode === 'account')) && (
                  <Tag color="blue">账号登录态：{session?.account_name || accountName || '未选择'}</Tag>
                )}
                {session?.dry_run_status === 'passed' && <Tag color="success">试跑通过</Tag>}
                {session?.dry_run_status === 'running' && <Tag color="processing">试跑中</Tag>}
                {(session?.dry_run_status === 'failed' || session?.dry_run_status === 'error') && (
                  <Tag color="error">试跑未通过</Tag>
                )}
                {selectedCaseTitle && canStart && (
                  <Tag>
                    用例：
                    {selectedCaseTitle.length > 16
                      ? `${selectedCaseTitle.slice(0, 16)}…`
                      : selectedCaseTitle}
                  </Tag>
                )}
              </Space>
            </div>
            <div className="api-scenario-agent-chat-toolbar-right">
              <AgentChatCollapseButton
                collapsed={chatCollapsed}
                onToggle={toggleChatCollapsed}
              />
              {!chatCollapsed && (
                <AgentSessionHistory
                  items={sessionList}
                  activeId={session?.id ?? null}
                  loading={historyLoading}
                  busy={busy}
                  showStatus={false}
                  onSelect={(id) => void openHistorySession(id)}
                  onNew={resetSession}
                  onDelete={(id) => void deleteHistorySession(id)}
                />
              )}
            </div>
          </div>

          <div
            className="api-scenario-agent-messages"
            ref={messagesRef}
            onScroll={updateStickToBottom}
          >
            {messageChunks.map((chunk) => {
              if (chunk.kind === 'logs') {
                const n = chunk.messages.length
                const chunkShotKeys = [
                  ...new Set(
                    chunk.messages
                      .map((m) => m.screenshotKey)
                      .filter((key): key is string => Boolean(key)),
                  ),
                ]
                return (
                  <div
                    key={chunk.id}
                    className={`api-scenario-agent-log-fold${logsExpanded ? ' is-expanded' : ''}`}
                  >
                    <div className="api-scenario-agent-log-fold-header">
                      <button
                        type="button"
                        className="api-scenario-agent-log-fold-toggle"
                        aria-expanded={logsExpanded}
                        onClick={() => setLogsExpandedOverride(!logsExpanded)}
                      >
                        <span className="api-scenario-agent-log-fold-chevron" aria-hidden>
                          {logsExpanded ? <DownOutlined /> : <RightOutlined />}
                        </span>
                        <span className="api-scenario-agent-log-fold-label">探索日志</span>
                        <span className="api-scenario-agent-log-fold-count">{n}</span>
                      </button>
                      {session && chunkShotKeys.length > 0 && (
                        <ExploreShotPreviewButton
                          projectId={pid}
                          sessionId={session.id}
                          storageKeys={chunkShotKeys}
                        />
                      )}
                    </div>
                    {logsExpanded ? (
                      <div
                        className="api-scenario-agent-log-fold-body"
                        ref={logFoldRef}
                        onScroll={updateLogStickToBottom}
                      >
                        {chunk.messages.map((m) => (
                          <div key={m.id} className="api-scenario-agent-log-fold-line">
                            {m.content}
                          </div>
                        ))}
                      </div>
                    ) : null}
                  </div>
                )
              }
              const m = chunk.message
              return (
                <div
                  key={m.id}
                  className={`api-scenario-agent-bubble api-scenario-agent-bubble--${m.role}`}
                >
                  <div className="api-scenario-agent-bubble-role">{roleLabel(m.role)}</div>
                  <div className="api-scenario-agent-bubble-body">{m.content}</div>
                </div>
              )
            })}
            {busy && !waitingHuman && (
              <div className="api-scenario-agent-bubble api-scenario-agent-bubble--assistant">
                <div className="api-scenario-agent-bubble-role">Agent</div>
                <div className="api-scenario-agent-bubble-body muted">
                  {session?.status === 'running' ? '探索中…' : '思考中…'}
                </div>
              </div>
            )}
            {waitingHuman && (
              <div className="api-scenario-agent-bubble api-scenario-agent-bubble--assistant">
                <div className="api-scenario-agent-bubble-role">Agent</div>
                <div className="api-scenario-agent-bubble-body muted">
                  浏览器保持打开。请手动操作，或输入验证码/「继续」后发送。
                </div>
              </div>
            )}
          </div>

          <div className="api-scenario-agent-composer">
            <Input.TextArea
              className="api-scenario-agent-composer-input"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder={
                restoring
                  ? '正在恢复上次会话…'
                  : canStart
                    ? '描述流程，例如：账号 demo 密码 xxx，登录后打开公寓列表并搜索'
                    : waitingHuman
                      ? '输入验证码/说明，或「继续」（浏览器保持打开）'
                      : exploring
                        ? '探索进行中，可点右侧停止…'
                        : session?.status === 'error'
                          ? '继续描述，将重新探索页面'
                          : canChat
                            ? '继续修改，例如：第 2 步改用 role=button[name="查询"]；或说「重新探索」'
                            : '当前会话已结束，请点「新会话」'
              }
              autoSize={{ minRows: 2, maxRows: 5 }}
              disabled={
                restoring ||
                finished ||
                (!canStart && !canChat) ||
                (busy && !waitingHuman)
              }
              variant="borderless"
              onPressEnter={(e) => {
                if (!e.shiftKey) {
                  e.preventDefault()
                  void onSend()
                }
              }}
            />
            <div className="api-scenario-agent-composer-bar">
              <div className="api-scenario-agent-composer-tools">
                <div className="api-scenario-agent-composer-icons">
                  <Popover
                    content={casePicker}
                    trigger="click"
                    open={casePopoverOpen}
                    onOpenChange={setCasePopoverOpen}
                    placement="topRight"
                    autoAdjustOverflow={{ adjustX: 1, adjustY: 0 }}
                    getPopupContainer={() => document.body}
                    overlayClassName="api-scenario-agent-popover"
                  >
                    <Tooltip
                      title={
                        testcaseIds.length
                          ? `已选 ${testcaseIds.length} 条功能用例`
                          : '功能用例（可多选）'
                      }
                      open={casePopoverOpen ? false : undefined}
                    >
                      <Badge
                        count={testcaseIds.length}
                        size="small"
                        offset={[-2, 2]}
                        showZero={false}
                      >
                        <Button
                          type="text"
                          size="small"
                          className={
                            testcaseIds.length
                              ? 'api-scenario-agent-tool-btn is-active'
                              : 'api-scenario-agent-tool-btn'
                          }
                          icon={<FileTextOutlined />}
                          disabled={!canTuneExplore}
                        />
                      </Badge>
                    </Tooltip>
                  </Popover>

                  <Popover
                    content={envPicker}
                    trigger="click"
                    open={envPopoverOpen}
                    onOpenChange={setEnvPopoverOpen}
                    placement="topRight"
                    autoAdjustOverflow={{ adjustX: 1, adjustY: 0 }}
                    getPopupContainer={() => document.body}
                    overlayClassName="api-scenario-agent-popover"
                  >
                    <Tooltip
                      title={envName ? `环境：${envName}` : 'UI 环境'}
                      open={envPopoverOpen ? false : undefined}
                    >
                      <Button
                        type="text"
                        size="small"
                        className={
                          envId != null || selectedEnv
                            ? 'api-scenario-agent-tool-btn is-active'
                            : 'api-scenario-agent-tool-btn'
                        }
                        icon={<CloudServerOutlined />}
                        disabled={!canEditEnv}
                      />
                    </Tooltip>
                  </Popover>

                  <Tooltip title={headed ? '有头模式（默认，可见浏览器）' : '无头模式'}>
                    <Button
                      type="text"
                      size="small"
                      className={
                        headed
                          ? 'api-scenario-agent-tool-btn is-active'
                          : 'api-scenario-agent-tool-btn'
                      }
                      icon={<DesktopOutlined />}
                      disabled={!canTuneExplore}
                      onClick={() => setHeaded((v) => !v)}
                    />
                  </Tooltip>

                  <Popover
                    content={authPicker}
                    trigger="click"
                    placement="topRight"
                    getPopupContainer={() => document.body}
                  >
                    <Tooltip
                      title={
                        authMode === 'none'
                          ? '跳过登录态'
                          : authMode === 'account'
                            ? `账号登录态：${accountName || '未选择'}`
                            : '跟随环境 Token 注入'
                      }
                    >
                      <Button
                        type="text"
                        size="small"
                        className={
                          authMode !== 'follow'
                            ? 'api-scenario-agent-tool-btn is-active'
                            : 'api-scenario-agent-tool-btn'
                        }
                        icon={<KeyOutlined />}
                        disabled={!canTuneExplore}
                      />
                    </Tooltip>
                  </Popover>
                </div>
              </div>

              {exploring && !waitingHuman ? (
                <Tooltip title="停止探索">
                  <Button
                    danger
                    shape="circle"
                    size="small"
                    className="api-scenario-agent-send-btn"
                    icon={<StopOutlined />}
                    loading={stopping}
                    onClick={() => void stopExplore()}
                  />
                </Tooltip>
              ) : waitingHuman ? (
                <Space size={4}>
                  <Tooltip title="停止探索并关闭浏览器">
                    <Button
                      danger
                      shape="circle"
                      size="small"
                      className="api-scenario-agent-send-btn"
                      icon={<StopOutlined />}
                      loading={stopping}
                      onClick={() => void stopExplore()}
                    />
                  </Tooltip>
                  <Tooltip title="发送协助信息">
                    <Button
                      type="primary"
                      shape="circle"
                      size="small"
                      className="api-scenario-agent-send-btn"
                      icon={<SendOutlined />}
                      disabled={!input.trim()}
                      onClick={() => void onSend()}
                    />
                  </Tooltip>
                </Space>
              ) : (
                <Tooltip title={canStart ? '开始探索' : '发送'}>
                  <Button
                    type="primary"
                    shape="circle"
                    size="small"
                    className="api-scenario-agent-send-btn"
                    icon={<SendOutlined />}
                    loading={busy}
                    disabled={!canSend}
                    onClick={() => void onSend()}
                  />
                </Tooltip>
              )}
            </div>
          </div>
        </section>
      </div>
    </div>
  )
}
