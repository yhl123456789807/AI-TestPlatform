import { Button, Image, Modal } from 'antd'
import { useQueries, useQuery } from '@tanstack/react-query'
import { useState, type MouseEvent } from 'react'
import { apiFetch } from '../api/client'

async function fetchExploreShot(projectId: number, sessionId: number, storageKey: string) {
  const res = await apiFetch(
    `/api/v1/projects/${projectId}/ui-scenario-agent/sessions/${sessionId}/screenshots?key=${encodeURIComponent(storageKey)}`,
  )
  if (!res.ok) throw new Error('截图加载失败')
  const blob = await res.blob()
  return URL.createObjectURL(blob)
}

export function ExploreShotThumb({
  projectId,
  sessionId,
  storageKey,
  width = 220,
}: {
  projectId: number
  sessionId: number
  storageKey: string
  width?: number
}) {
  const q = useQuery({
    queryKey: ['ui-explore-shot', projectId, sessionId, storageKey],
    queryFn: () => fetchExploreShot(projectId, sessionId, storageKey),
    enabled: Boolean(storageKey),
  })
  if (q.isLoading) return <span className="explore-shot-loading">加载截图…</span>
  if (!q.data) return null
  return (
    <div className="explore-shot-thumb">
      <Image src={q.data} width={width} alt="explore step" />
    </div>
  )
}

export function ExploreShotRail({
  projectId,
  sessionId,
  storageKeys,
  width = 200,
}: {
  projectId: number
  sessionId: number
  storageKeys: string[]
  width?: number
}) {
  const keys: string[] = []
  const seen = new Set<string>()
  for (const key of storageKeys) {
    if (!key || seen.has(key)) continue
    seen.add(key)
    keys.push(key)
  }
  if (!keys.length) return null
  return (
    <aside className="explore-shot-rail">
      <Image.PreviewGroup>
        {keys.map((key) => (
          <ExploreShotThumb
            key={key}
            projectId={projectId}
            sessionId={sessionId}
            storageKey={key}
            width={width}
          />
        ))}
      </Image.PreviewGroup>
    </aside>
  )
}

export function ExploreShotStrip({
  projectId,
  sessionId,
  storageKeys,
  width = 120,
}: {
  projectId: number
  sessionId: number
  storageKeys: string[]
  width?: number
}) {
  const keys = [...new Set(storageKeys.filter(Boolean))]
  if (!keys.length) return null
  return (
    <div className="explore-shot-strip" aria-label="执行截图">
      <Image.PreviewGroup>
        {keys.map((key) => (
          <ExploreShotThumb
            key={key}
            projectId={projectId}
            sessionId={sessionId}
            storageKey={key}
            width={width}
          />
        ))}
      </Image.PreviewGroup>
    </div>
  )
}

export function ExploreShotPreviewButton({
  projectId,
  sessionId,
  storageKeys,
}: {
  projectId: number
  sessionId: number
  storageKeys: string[]
}) {
  const keys = [...new Set(storageKeys.filter(Boolean))]
  const [modalOpen, setModalOpen] = useState(false)
  const [previewOpen, setPreviewOpen] = useState(false)
  const [current, setCurrent] = useState(0)
  const queries = useQueries({
    queries: keys.map((storageKey) => ({
      queryKey: ['ui-explore-shot', projectId, sessionId, storageKey],
      queryFn: () => fetchExploreShot(projectId, sessionId, storageKey),
      enabled: Boolean(storageKey),
    })),
  })
  const loadedUrls = queries.map((query) => query.data).filter((url): url is string => Boolean(url))
  const loading = loadedUrls.length === 0 && queries.some((query) => query.isPending)

  if (!keys.length) return null

  function openModal(event: MouseEvent<HTMLElement>) {
    event.stopPropagation()
    if (!loadedUrls.length && !loading) return
    setModalOpen(true)
  }

  function openPreviewAtKeyIndex(keyIndex: number, event: MouseEvent<HTMLElement>) {
    event.stopPropagation()
    const url = queries[keyIndex]?.data
    if (!url) return
    const previewIndex = loadedUrls.indexOf(url)
    if (previewIndex < 0) return
    setCurrent(previewIndex)
    setPreviewOpen(true)
  }

  return (
    <span className="api-scenario-agent-log-fold-shots" onClick={(e) => e.stopPropagation()}>
      <Button
        type="link"
        size="small"
        loading={loading}
        disabled={!loading && !loadedUrls.length}
        onClick={openModal}
      >
        查看截图 ({keys.length})
      </Button>
      <Modal
        title={`执行截图（${keys.length}）`}
        open={modalOpen}
        onCancel={() => setModalOpen(false)}
        footer={null}
        width={720}
        destroyOnHidden
      >
        <div className="explore-shot-modal-grid">
          {keys.map((key, i) => {
            const query = queries[i]
            const url = query?.data
            const itemLoading = query?.isPending
            const failed = query?.isError
            return (
              <button
                key={key}
                type="button"
                className="explore-shot-modal-item"
                disabled={!url}
                onClick={(e) => openPreviewAtKeyIndex(i, e)}
              >
                {itemLoading ? (
                  <span className="explore-shot-loading">加载截图…</span>
                ) : url ? (
                  <Image src={url} alt={`explore step ${i + 1}`} preview={false} />
                ) : (
                  <span className="explore-shot-loading">{failed ? '加载失败' : '暂无截图'}</span>
                )}
              </button>
            )
          })}
        </div>
      </Modal>
      <Image.PreviewGroup
        items={loadedUrls}
        preview={{
          open: previewOpen,
          current,
          onChange: setCurrent,
          onOpenChange: setPreviewOpen,
        }}
      />
    </span>
  )
}

export function CaseRunShotThumb({
  projectId,
  runId,
  storageKey,
  width = 220,
}: {
  projectId: number
  runId: number
  storageKey: string
  width?: number
}) {
  const q = useQuery({
    queryKey: ['case-run-shot', projectId, runId, storageKey],
    queryFn: async () => {
      const res = await apiFetch(
        `/api/v1/projects/${projectId}/test-case-runs/${runId}/screenshots?key=${encodeURIComponent(storageKey)}`,
      )
      if (!res.ok) throw new Error('截图加载失败')
      const blob = await res.blob()
      return URL.createObjectURL(blob)
    },
    enabled: Boolean(storageKey),
  })
  if (q.isLoading) return <span className="explore-shot-loading">加载截图…</span>
  if (!q.data) return null
  return (
    <div className="explore-shot-thumb">
      <Image src={q.data} width={width} alt="case run step" />
    </div>
  )
}

export function CaseRunShotRail({
  projectId,
  runId,
  storageKeys,
  width = 200,
}: {
  projectId: number
  runId: number
  storageKeys: string[]
  width?: number
}) {
  const keys: string[] = []
  const seen = new Set<string>()
  for (const key of storageKeys) {
    if (!key || seen.has(key)) continue
    seen.add(key)
    keys.push(key)
  }
  if (!keys.length) return null
  return (
    <aside className="explore-shot-rail">
      <Image.PreviewGroup>
        {keys.map((key) => (
          <CaseRunShotThumb
            key={key}
            projectId={projectId}
            runId={runId}
            storageKey={key}
            width={width}
          />
        ))}
      </Image.PreviewGroup>
    </aside>
  )
}

export function eventScreenshotKey(ev: Record<string, unknown>): string | undefined {
  const data = ev.data
  if (data && typeof data === 'object' && data !== null && 'screenshot_key' in data) {
    const key = (data as { screenshot_key?: unknown }).screenshot_key
    if (typeof key === 'string' && key) return key
  }
  return undefined
}
