import { Alert, App, Button, Checkbox, Drawer, Image, Space, Tag, Typography } from 'antd'
import { useEffect, useMemo, useRef, useState } from 'react'
import { useQuery, useQueryClient } from '@tanstack/react-query'
import { Link } from 'react-router-dom'
import { apiFetch, apiJson, ApiError } from '../api/client'
import { eventScreenshotKey, ExploreShotRail } from './ExploreShotThumb'
import ScriptCodeEditor from './ScriptCodeEditor'

export type UiRunFixPatch = {
  kind?: 'replace'
  old?: string
  new?: string
  rationale?: string
}

export type UiRunFixPlan = {
  category?: string
  recommended_action?: 'patch_script' | 'explore_repair' | 'fix_env' | 'file_bug' | 'rerun_only'
  apply_mode?: 'none' | 'patch' | 'replace'
  summary?: string
  likely_causes?: string[]
  changes?: string[]
  warnings?: string[]
  suggested_patches?: UiRunFixPatch[]
  suggested_script?: string
}

type FixEvent = {
  type?: string
  node?: string
  message?: string
  ts?: string
  data?: { screenshot_key?: string }
}

export type UiRunFixSession = {
  id: string
  run_id: number
  case_id: number | null
  status: string
  plan: UiRunFixPlan | null
  current_script: string
  error_message: string
  patch_message?: string
  rerun_id?: number | null
  explore_session_id?: number | null
  failure_screenshot_key?: string | null
  failure_step_id?: number | null
  events?: FixEvent[]
}

type UiRunInfo = {
  id: number
  status: string
}

type UiRunStepInfo = {
  id: number
  order: number
  action: string
  status: string
  error_message: string
}

const CATEGORY_LABEL: Record<string, string> = {
  locator_drift: '定位漂移',
  timing_wait: '等待/时机',
  assertion_mismatch: '断言不匹配',
  auth_env: '环境/账号',
  product_bug: '产品缺陷',
  flake_infra: '抖动/基建',
  nav_flow: '流程漂移',
}

const ACTION_LABEL: Record<string, string> = {
  patch_script: '建议局部改脚本',
  explore_repair: '已重新探索并生成脚本',
  fix_env: '建议检查环境/账号，不改脚本',
  file_bug: '疑似产品问题，不改脚本',
  rerun_only: '建议重试，不改脚本',
}

function errText(ex: unknown): string {
  if (ex instanceof ApiError && typeof ex.body === 'object' && ex.body !== null) {
    const b = ex.body as { message?: string }
    return b.message ?? `请求失败 (${ex.status})`
  }
  return '请求失败'
}

function eventLine(ev: FixEvent): string {
  const msg = (ev.message || '').trim()
  if (msg) return msg
  if (ev.type === 'interrupted') return '等待确认写入'
  if (ev.type === 'error') return '探索失败'
  return ''
}

type LogKind = 'shot' | 'snapshot' | 'action' | 'system' | 'error'

function summarizeSnapshot(text: string): string {
  const url = text.match(/url=(\S+)/)?.[1]
  const count = text.match(/等\s*(\d+)\s*行/)?.[1]
  if (url && count) return `${url} · ${count} 个控件`
  if (url) return url
  return '已获取页面结构'
}

function stripLeadingAction(body: string, action: string): string {
  const re = new RegExp(`^(?:用例\\s+\\S+\\s+·\\s+)?${action}\\b\\s*`, 'i')
  const rest = body.replace(re, '').replace(/^[·\s]+/, '').trim()
  return rest || body
}

function classifyLog(text: string): { kind: LogKind; label: string; body: string } | null {
  const t = text.trim()
  if (!t) return null
  if (/^已截图\b/.test(t) || /已截图 step=/.test(t)) return { kind: 'shot', label: '', body: t }
  if (t.includes('LangGraph：snapshot')) {
    return { kind: 'snapshot', label: 'snapshot', body: summarizeSnapshot(t) }
  }
  if (/操作失败|截图失败|LLM 决策失败|探索失败/.test(t)) {
    return { kind: 'error', label: 'error', body: t.replace(/^LangGraph：/, '') }
  }
  const stripped = t.replace(/^LangGraph：/, '')
  if (/^decide\b/i.test(stripped)) {
    const raw = stripped.replace(/^decide\s*/, '')
    const act = raw.match(/(?:^用例\s+\S+\s+·\s+)?(fill|click|goto|press|done)\b/i)
    const label = (act?.[1] || 'decide').toLowerCase()
    return { kind: 'action', label, body: stripLeadingAction(raw, label) }
  }
  const head = stripped.match(/^(fill|click|goto|press)\b/i)
  if (head) {
    const label = head[1].toLowerCase()
    return { kind: 'action', label, body: stripLeadingAction(stripped, label) }
  }
  return { kind: 'system', label: '', body: stripped }
}

function dedupeVisibleLogs(
  rows: Array<{ id: string; kind: LogKind; label: string; body: string }>,
): Array<{ id: string; kind: LogKind; label: string; body: string }> {
  const out: Array<{ id: string; kind: LogKind; label: string; body: string }> = []
  for (const row of rows) {
    const prev = out[out.length - 1]
    if (
      prev &&
      prev.kind === row.kind &&
      prev.label === row.label &&
      prev.body === row.body
    ) {
      continue
    }
    if (
      prev &&
      row.kind === 'snapshot' &&
      prev.kind === 'snapshot' &&
      prev.body === row.body
    ) {
      continue
    }
    out.push(row)
  }
  return out
}

function syncApplyDefaults(plan: UiRunFixPlan | null | undefined): { applyPatch: boolean; rerun: boolean } {
  const mode = plan?.apply_mode || 'replace'
  if (mode === 'none') {
    const action = plan?.recommended_action
    return { applyPatch: false, rerun: action === 'rerun_only' || action === 'fix_env' }
  }
  return { applyPatch: Boolean(plan?.suggested_script?.trim()), rerun: true }
}

function FailureShot({
  projectId,
  runId,
  stepId,
}: {
  projectId: number
  runId: number
  stepId: number
}) {
  const q = useQuery({
    queryKey: ['ui-fix-fail-shot', projectId, runId, stepId],
    queryFn: async () => {
      const res = await apiFetch(
        `/api/v1/projects/${projectId}/ui-runs/${runId}/steps/${stepId}/screenshot`,
      )
      if (!res.ok) throw new Error('截图加载失败')
      const blob = await res.blob()
      return URL.createObjectURL(blob)
    },
  })
  if (q.isLoading) return <Typography.Text type="secondary">加载失败截图…</Typography.Text>
  if (!q.data) return null
  return <Image src={q.data} width={280} alt="failure screenshot" />
}

export function useUiRunFix(projectId: number, runId: number | null) {
  const { message } = App.useApp()
  const qc = useQueryClient()
  const [open, setOpen] = useState(false)
  const [busy, setBusy] = useState(false)
  const [session, setSession] = useState<UiRunFixSession | null>(null)
  const [applyPatch, setApplyPatch] = useState(true)
  const [rerun, setRerun] = useState(true)

  const poll = useQuery({
    queryKey: ['ui-run-fix', projectId, runId, session?.id],
    queryFn: () =>
      apiJson<UiRunFixSession>(`/api/v1/projects/${projectId}/ui-runs/${runId}/ai-fix/${session!.id}`),
    enabled:
      open &&
      runId != null &&
      Boolean(session?.id) &&
      (session?.status === 'exploring' || session?.status === 'analyzing'),
    refetchInterval: 1500,
  })

  useEffect(() => {
    if (!poll.data) return
    setSession(poll.data)
    if (poll.data.status === 'awaiting_confirm') {
      const defaults = syncApplyDefaults(poll.data.plan)
      setApplyPatch(defaults.applyPatch)
      setRerun(defaults.rerun)
    }
    if (poll.data.status === 'error') {
      message.error(poll.data.error_message || '修复失败')
    }
  }, [poll.data, message])

  async function startFix() {
    if (runId == null) return
    setBusy(true)
    setSession(null)
    setApplyPatch(true)
    setRerun(true)
    setOpen(true)
    try {
      const next = await apiJson<UiRunFixSession>(
        `/api/v1/projects/${projectId}/ui-runs/${runId}/ai-fix`,
        { method: 'POST', body: '{}' },
      )
      setSession(next)
      const defaults = syncApplyDefaults(next.plan)
      setApplyPatch(defaults.applyPatch)
      setRerun(defaults.rerun)
      if (next.status === 'error') {
        message.error(next.error_message || '修复失败')
      }
    } catch (e) {
      message.error(errText(e))
      setOpen(false)
    } finally {
      setBusy(false)
    }
  }

  async function confirmFix(
    action: 'confirm' | 'cancel',
    onApplied?: (rerunId: number | null) => void,
  ) {
    if (!session || runId == null) return
    setBusy(true)
    try {
      const next = await apiJson<UiRunFixSession>(
        `/api/v1/projects/${projectId}/ui-runs/${runId}/ai-fix/${session.id}/confirm`,
        {
          method: 'POST',
          body: JSON.stringify({
            action,
            apply_patch: action === 'confirm' ? applyPatch : false,
            rerun: action === 'confirm' ? rerun : false,
          }),
        },
      )
      setSession(next)
      if (action === 'cancel') {
        message.info('已取消')
        setOpen(false)
      } else if (next.status === 'error') {
        message.error(next.error_message || next.patch_message || '写入失败')
      } else if (next.patch_message?.startsWith('已写入')) {
        message.success(next.patch_message)
        void qc.invalidateQueries({ queryKey: ['ui-cases', projectId] })
        void qc.invalidateQueries({ queryKey: ['ui-run', projectId] })
        void qc.invalidateQueries({ queryKey: ['ui-run-steps', projectId] })
        onApplied?.(next.rerun_id ?? null)
        setOpen(false)
      } else if (next.patch_message) {
        if (next.rerun_id != null) {
          message.success(next.patch_message)
          void qc.invalidateQueries({ queryKey: ['ui-run', projectId] })
          onApplied?.(next.rerun_id)
        } else {
          message.warning(next.patch_message)
        }
        setOpen(false)
      }
    } catch (e) {
      message.error(errText(e))
    } finally {
      setBusy(false)
    }
  }

  return {
    open,
    setOpen,
    busy,
    session,
    applyPatch,
    setApplyPatch,
    rerun,
    setRerun,
    startFix,
    confirmFix,
  }
}

export function UiRunFixPanel({
  projectId,
  open,
  busy,
  session,
  applyPatch,
  rerun,
  zIndex,
  onApplyPatchChange,
  onRerunChange,
  onConfirm,
  onClose,
}: {
  projectId: number
  open: boolean
  busy: boolean
  session: UiRunFixSession | null
  applyPatch: boolean
  rerun: boolean
  zIndex?: number
  onApplyPatchChange: (value: boolean) => void
  onRerunChange: (value: boolean) => void
  onConfirm: (action: 'confirm' | 'cancel') => void
  onClose: () => void
}) {
  const analyzing = session?.status === 'analyzing' || (open && !session && busy)
  const exploring = session?.status === 'exploring'
  const failed = session?.status === 'error'
  const ready = session?.status === 'awaiting_confirm'
  const plan = session?.plan
  const applyMode = plan?.apply_mode || 'replace'
  const canWrite = applyMode === 'patch' || applyMode === 'replace'
  const canConfirm = ready && !busy
  const canCancel = Boolean(session && (analyzing || exploring || ready || failed) && !busy)
  const suggested = plan?.suggested_script || ''
  const showSuggested = canWrite && Boolean(suggested.trim()) && suggested !== session?.current_script
  const failMessage = (session?.error_message || '').trim() || '修复失败'
  const logBoxRef = useRef<HTMLDivElement | null>(null)
  const visibleLogs = useMemo(() => {
    const rows: Array<{ id: string; kind: LogKind; label: string; body: string }> = []
    for (const [i, ev] of (session?.events ?? []).entries()) {
      const text = eventLine(ev)
      const classified = classifyLog(text)
      if (!classified || classified.kind === 'shot') continue
      rows.push({ id: `${ev.ts || i}-${i}`, ...classified })
    }
    return dedupeVisibleLogs(rows)
  }, [session?.events])
  const shotKeys = useMemo(() => {
    const keys: string[] = []
    for (const ev of session?.events ?? []) {
      const key = eventScreenshotKey(ev)
      if (key) keys.push(key)
    }
    return keys
  }, [session?.events])

  useEffect(() => {
    const el = logBoxRef.current
    if (el) el.scrollTop = el.scrollHeight
  }, [visibleLogs.length])

  const drawerTitle = failed
    ? '修复失败'
    : analyzing
      ? '正在分析失败原因'
      : exploring
        ? '正在重新探索'
        : 'AI 修复建议'

  const confirmLabel = !canWrite
    ? rerun
      ? '确认并试跑'
      : '知道了'
    : applyPatch
      ? rerun
        ? '确认写入并试跑'
        : '确认并写入'
      : '确认'

  return (
    <Drawer
      title={drawerTitle}
      open={open}
      onClose={onClose}
      width={ready ? 560 : 720}
      destroyOnHidden
      zIndex={zIndex}
    >
      {failed ? (
        <Alert type="error" showIcon style={{ marginBottom: 16 }} message={failMessage} />
      ) : null}
      {!failed && analyzing ? (
        <Typography.Paragraph type="secondary">正在分析失败原因…</Typography.Paragraph>
      ) : null}
      {!failed && exploring ? (
        <Typography.Paragraph type="secondary">
          正在按原环境重新探索页面，完成后才会给出修改建议。
        </Typography.Paragraph>
      ) : null}
      {!failed && (exploring || visibleLogs.length > 0 || shotKeys.length > 0) && (
        <div className="testcase-automate-explore ui-run-fix-explore">
          <div className="testcase-automate-log" ref={logBoxRef}>
            {visibleLogs.length === 0 ? (
              <div className="testcase-automate-log-empty">等待探索日志…</div>
            ) : (
              visibleLogs.map((line) => (
                <div
                  key={line.id}
                  className={`testcase-automate-log-line testcase-automate-log-line--${line.kind}`}
                >
                  {line.label ? <span className="testcase-automate-log-tag">{line.label}</span> : null}
                  <span className="testcase-automate-log-body">{line.body}</span>
                </div>
              ))
            )}
          </div>
          {session?.explore_session_id && shotKeys.length > 0 ? (
            <ExploreShotRail
              projectId={projectId}
              sessionId={session.explore_session_id}
              storageKeys={shotKeys}
            />
          ) : null}
        </div>
      )}
      {ready && plan ? (
        <Space wrap style={{ marginBottom: 12 }}>
          {plan.category ? (
            <Tag color="blue">{CATEGORY_LABEL[plan.category] || plan.category}</Tag>
          ) : null}
          {plan.recommended_action ? (
            <Tag>{ACTION_LABEL[plan.recommended_action] || plan.recommended_action}</Tag>
          ) : null}
        </Space>
      ) : null}
      {ready && session?.failure_step_id != null && session.failure_screenshot_key ? (
        <div style={{ marginBottom: 12 }}>
          <Typography.Text strong>失败截图</Typography.Text>
          <div style={{ marginTop: 8 }}>
            <FailureShot
              projectId={projectId}
              runId={session.run_id}
              stepId={session.failure_step_id}
            />
          </div>
        </div>
      ) : null}
      {ready && plan?.summary ? (
        <Typography.Paragraph>{plan.summary}</Typography.Paragraph>
      ) : null}
      {ready && (plan?.likely_causes ?? []).length > 0 && (
        <div style={{ marginBottom: 12 }}>
          <Typography.Text strong>可能原因</Typography.Text>
          <ul>
            {(plan?.likely_causes ?? []).map((item, i) => (
              <li key={i}>{item}</li>
            ))}
          </ul>
        </div>
      )}
      {ready && (plan?.suggested_patches ?? []).length > 0 && (
        <div style={{ marginBottom: 12 }}>
          <Typography.Text strong>局部修补</Typography.Text>
          <ul>
            {(plan?.suggested_patches ?? []).map((p, i) => (
              <li key={i}>
                {p.rationale || '替换片段'}
                {p.old ? (
                  <Typography.Paragraph
                    type="secondary"
                    style={{ marginBottom: 0, whiteSpace: 'pre-wrap', fontSize: 12 }}
                  >
                    {p.old.slice(0, 120)}
                    {p.old.length > 120 ? '…' : ''}
                    {' → '}
                    {(p.new || '').slice(0, 120)}
                    {(p.new || '').length > 120 ? '…' : ''}
                  </Typography.Paragraph>
                ) : null}
              </li>
            ))}
          </ul>
        </div>
      )}
      {ready && (plan?.changes ?? []).length > 0 && (
        <div style={{ marginBottom: 12 }}>
          <Typography.Text strong>拟修改</Typography.Text>
          <ul>
            {(plan?.changes ?? []).map((item, i) => (
              <li key={i}>{item}</li>
            ))}
          </ul>
        </div>
      )}
      {ready && (plan?.warnings ?? []).length > 0 && (
        <Alert
          type="warning"
          showIcon
          style={{ marginBottom: 12 }}
          message={(plan?.warnings ?? []).join('；')}
        />
      )}
      {ready && canWrite && session?.current_script ? (
        <>
          <div className="ui-run-fix-script-label">当前脚本</div>
          <ScriptCodeEditor
            className="ui-run-fix-script-monaco"
            value={session.current_script}
            readOnly
            height={220}
          />
        </>
      ) : null}
      {ready && showSuggested ? (
        <>
          <div className="ui-run-fix-script-label">建议脚本</div>
          <ScriptCodeEditor
            className="ui-run-fix-script-monaco"
            value={suggested}
            readOnly
            height={220}
          />
        </>
      ) : null}
      <Space wrap style={{ marginTop: 16 }}>
        {ready ? (
          <>
            {canWrite ? (
              <Checkbox
                checked={applyPatch}
                disabled={busy || !suggested}
                onChange={(e) => onApplyPatchChange(e.target.checked)}
              >
                确认时写入修补
              </Checkbox>
            ) : null}
            <Checkbox
              checked={rerun}
              disabled={busy || (canWrite && !applyPatch)}
              onChange={(e) => onRerunChange(e.target.checked)}
            >
              {canWrite ? '写入后再试跑' : '确认后再试跑'}
            </Checkbox>
            <Button type="primary" disabled={!canConfirm} loading={busy} onClick={() => onConfirm('confirm')}>
              {confirmLabel}
            </Button>
          </>
        ) : null}
        {failed ? (
          <Button type="primary" onClick={onClose}>
            关闭
          </Button>
        ) : (
          <Button disabled={!canCancel || analyzing} onClick={() => onConfirm('cancel')}>
            取消
          </Button>
        )}
      </Space>
    </Drawer>
  )
}

export function UiTrialRunBanner({
  projectId,
  runId,
  zIndex,
  onRerun,
}: {
  projectId: number
  runId: number
  zIndex?: number
  onRerun?: (rerunId: number) => void
}) {
  const fix = useUiRunFix(projectId, runId)
  const run = useQuery({
    queryKey: ['ui-run', projectId, runId],
    queryFn: () => apiJson<UiRunInfo>(`/api/v1/projects/${projectId}/ui-runs/${runId}`),
    enabled: Number.isFinite(projectId) && Number.isFinite(runId),
    refetchInterval: (q) => {
      const st = q.state.data?.status
      return st === 'pending' || st === 'running' ? 1500 : false
    },
  })
  const steps = useQuery({
    queryKey: ['ui-run-steps', projectId, runId],
    queryFn: () => apiJson<UiRunStepInfo[]>(`/api/v1/projects/${projectId}/ui-runs/${runId}/steps`),
    enabled: Number.isFinite(projectId) && Number.isFinite(runId),
    refetchInterval: () => {
      const st = run.data?.status
      return st === 'pending' || st === 'running' ? 1500 : false
    },
  })
  const failed = useMemo(
    () => (steps.data ?? []).find((s) => s.status === 'failed' || s.status === 'error'),
    [steps.data],
  )
  const status = run.data?.status
  const runLink = (
    <Link to={`/projects/${projectId}/ui-runs/${runId}`}>试跑 #{runId}</Link>
  )

  return (
    <div className="ui-trial-run-banner">
      {status === 'pending' || status === 'running' || !status ? (
        <p>
          {runLink}
          {status === 'running' ? ' 执行中…' : ' 排队中…'}
        </p>
      ) : null}
      {status === 'passed' ? <p>{runLink} 已通过</p> : null}
      {(status === 'failed' || status === 'error') && (
        <Alert
          type="error"
          showIcon
          message={`${status === 'error' ? '试跑出错' : '试跑失败'} · ${runLink}`}
          description={
            <div>
              <Typography.Paragraph style={{ marginBottom: 8 }}>
                {failed?.error_message || '无详细错误信息'}
              </Typography.Paragraph>
              <Button type="primary" size="small" loading={fix.busy} onClick={() => void fix.startFix()}>
                AI 修复
              </Button>
            </div>
          }
        />
      )}
      {status && !['pending', 'running', 'passed', 'failed', 'error'].includes(status) ? (
        <p>
          {runLink}
          {' · '}
          <Tag>{status}</Tag>
        </p>
      ) : null}
      <UiRunFixPanel
        projectId={projectId}
        open={fix.open}
        busy={fix.busy}
        session={fix.session}
        applyPatch={fix.applyPatch}
        rerun={fix.rerun}
        zIndex={zIndex}
        onApplyPatchChange={fix.setApplyPatch}
        onRerunChange={fix.setRerun}
        onConfirm={(action) =>
          void fix.confirmFix(action, (rerunId) => {
            if (rerunId != null) onRerun?.(rerunId)
          })
        }
        onClose={() => fix.setOpen(false)}
      />
    </div>
  )
}
