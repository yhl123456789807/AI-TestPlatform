import { Tag, Typography } from 'antd'
import { useMemo } from 'react'
import { ExploreShotThumb } from './ExploreShotThumb'

export type TrialStepResult = {
  phase?: 'login' | 'business' | string
  order?: number
  action?: string
  selector?: string
  status?: string
  duration_ms?: number | null
  error_message?: string
  screenshot_key?: string
  url?: string
}

export type TrialResult = {
  case_id?: string
  status?: string
  error?: string
  failure?: { error_message?: string } | Record<string, unknown> | null
  step_results?: TrialStepResult[]
}

/** Toast / banner text when a trial run fails. */
export function formatTrialFailMessage(
  caseId: string,
  dryRunError: string,
  baseOverride?: string,
) {
  const base = baseOverride ?? (caseId ? `试跑 ${caseId} 未通过` : '试跑未通过')
  const detail = (dryRunError || '').trim()
  if (!detail) return base
  const oneLine = detail.length > 280 ? `${detail.slice(0, 277)}…` : detail
  return `${base}：${oneLine}`
}

export function splitTrialError(message: string): { summary: string; callLog: string } {
  const text = (message || '').trim()
  if (!text) return { summary: '', callLog: '' }
  const marker = /\nCall log:\s*/i
  const idx = text.search(marker)
  if (idx >= 0) {
    const head = text.slice(0, idx).trim()
    const tail = text.slice(idx).trim()
    const summary = head.split('\n').find((line) => line.trim()) || head || text.split('\n')[0] || text
    return { summary: summary.trim(), callLog: tail }
  }
  const lines = text.split('\n')
  const summary = (lines.find((line) => line.trim()) || text).trim()
  const rest = lines.slice(lines.indexOf(summary) + 1).join('\n').trim()
  return { summary, callLog: rest }
}

function resolveTrialErrorMessage(
  errorMessage: string | undefined,
  trial: TrialResult | null | undefined,
): string {
  const fromProp = (errorMessage || '').trim()
  if (fromProp) return fromProp
  const fromTrial = (trial?.error || '').trim()
  if (fromTrial) return fromTrial
  const failure = trial?.failure
  if (failure && typeof failure === 'object') {
    const fromFailure = String(
      (failure as { error_message?: string }).error_message || '',
    ).trim()
    if (fromFailure) return fromFailure
  }
  return ''
}

export function trialFailureSummaryForLabel(
  trial: TrialResult | null | undefined,
  status: string | null | undefined,
  errorMessage?: string,
  maxLen = 80,
): string | null {
  if (!trial || !status || status === 'passed' || status === 'running') return null
  const steps = Array.isArray(trial.step_results) ? trial.step_results : []
  const failed = steps.find((s) => isBadStepStatus(String(s.status || '')))
  const raw = (failed?.error_message || resolveTrialErrorMessage(errorMessage, trial)).trim()
  if (!raw) return null
  const { summary } = splitTrialError(raw)
  const line = (summary || raw).trim()
  return line.length > maxLen ? `${line.slice(0, maxLen - 1)}…` : line
}

function statusLabel(status: string) {
  if (status === 'passed') return '通过'
  if (status === 'running') return '执行中'
  if (status === 'failed') return '失败'
  return '出错'
}

function statusColor(status: string) {
  if (status === 'passed') return 'success'
  if (status === 'running') return 'processing'
  return 'error'
}

function isBadStepStatus(status: string) {
  const s = status.trim().toLowerCase()
  return s !== 'passed' && s !== 'running'
}

function formatStepDuration(ms: number | null | undefined): string | null {
  if (typeof ms !== 'number' || !Number.isFinite(ms)) return null
  if (ms >= 1000) return `${(ms / 1000).toFixed(1)} s`
  return `${Math.round(ms)} ms`
}

function orderStepsForDisplay(steps: TrialStepResult[], modal: boolean): TrialStepResult[] {
  if (!modal) return steps
  const bad: TrialStepResult[] = []
  const good: TrialStepResult[] = []
  for (const step of steps) {
    if (isBadStepStatus(String(step.status || ''))) bad.push(step)
    else good.push(step)
  }
  return [...bad, ...good]
}

function stepPhaseLabel(step: TrialStepResult) {
  return step.phase === 'login' ? '前置登录' : '业务步骤'
}

function totalStepDurationMs(steps: TrialStepResult[]): number {
  return steps.reduce(
    (sum, s) => sum + (typeof s.duration_ms === 'number' && Number.isFinite(s.duration_ms) ? s.duration_ms : 0),
    0,
  )
}

function formatTotalDuration(steps: TrialStepResult[]): string | null {
  const ms = totalStepDurationMs(steps)
  if (ms <= 0) return null
  if (ms >= 1000) return `${(ms / 1000).toFixed(1)} s`
  return `${Math.round(ms)} ms`
}

function allStepsPassed(steps: TrialStepResult[]): boolean {
  return (
    steps.length > 0 &&
    steps.every((s) => String(s.status || '').trim().toLowerCase() === 'passed')
  )
}

function PassedTimelineStep({
  projectId,
  sessionId,
  step,
  displayIndex,
}: {
  projectId: number
  sessionId: number
  step: TrialStepResult
  displayIndex: number
}) {
  const duration = formatStepDuration(step.duration_ms)
  const phase = stepPhaseLabel(step)
  const line = (
    <span className="ui-agent-trial-passed-line-text">
      {displayIndex}. {step.action || 'script'} · {phase}
      {duration ? ` · ${duration}` : ''}
    </span>
  )
  const hasExtra = Boolean(step.screenshot_key || step.url || step.selector)
  if (!hasExtra) {
    return <div className="ui-agent-trial-passed-line">{line}</div>
  }
  const shot = step.screenshot_key ? (
    <ExploreShotThumb
      projectId={projectId}
      sessionId={sessionId}
      storageKey={step.screenshot_key}
      width={160}
    />
  ) : null
  return (
    <details className="ui-agent-trial-passed-line ui-agent-trial-passed-line--expandable">
      <summary className="ui-agent-trial-passed-line-summary">{line}</summary>
      <div className="ui-agent-trial-passed-line-body">
        {step.url ? (
          <Typography.Text type="secondary" className="ui-agent-trial-step-url" ellipsis={{ tooltip: step.url }}>
            {step.url}
          </Typography.Text>
        ) : null}
        {step.selector ? (
          <Typography.Text code className="ui-agent-trial-step-selector">
            {step.selector}
          </Typography.Text>
        ) : null}
        {shot}
      </div>
    </details>
  )
}

function StepErrorBlock({
  message,
  compact,
  modal,
}: {
  message: string
  compact: boolean
  modal: boolean
}) {
  const { summary, callLog } = splitTrialError(message)
  if (modal) {
    return (
      <div className="ui-agent-trial-step-error-block">
        {summary ? (
          <Typography.Text type="danger" strong className="ui-agent-trial-step-error-summary">
            {summary}
          </Typography.Text>
        ) : null}
        {callLog ? <pre className="ui-agent-trial-step-log">{callLog}</pre> : null}
        {!summary && !callLog ? (
          <Typography.Paragraph type="danger" className="ui-agent-trial-step-error">
            {message}
          </Typography.Paragraph>
        ) : null}
      </div>
    )
  }
  if (compact) {
    return (
      <Typography.Paragraph
        type="danger"
        className="ui-agent-trial-step-error is-compact"
        ellipsis={{ rows: 2, expandable: true, tooltip: message }}
      >
        {message}
      </Typography.Paragraph>
    )
  }
  if (callLog) {
    return (
      <div className="ui-agent-trial-step-error-block">
        {summary ? (
          <Typography.Text type="danger" strong className="ui-agent-trial-step-error-summary">
            {summary}
          </Typography.Text>
        ) : null}
        <pre className="ui-agent-trial-step-log">{callLog}</pre>
      </div>
    )
  }
  return (
    <Typography.Paragraph type="danger" className="ui-agent-trial-step-error">
      {message}
    </Typography.Paragraph>
  )
}

function TrialStepCard({
  projectId,
  sessionId,
  step,
  displayIndex,
  variant,
  compact,
}: {
  projectId: number
  sessionId: number
  step: TrialStepResult
  displayIndex: number
  variant: 'default' | 'modal'
  compact: boolean
}) {
  const stepStatus = String(step.status || 'error')
  const phase = stepPhaseLabel(step)
  const duration = formatStepDuration(step.duration_ms)
  const modal = variant === 'modal'
  const failed = isBadStepStatus(stepStatus)
  const thumbWidth = modal ? 200 : 140

  const meta = (
    <div className="ui-agent-trial-step-meta">
      <Tag color={statusColor(stepStatus)}>{statusLabel(stepStatus)}</Tag>
      <Typography.Text strong>
        {displayIndex}. {step.action || 'script'}
      </Typography.Text>
      <Typography.Text type="secondary">{phase}</Typography.Text>
      {duration ? <Typography.Text type="secondary">{duration}</Typography.Text> : null}
    </div>
  )

  const urlRow = step.url ? (
    <Typography.Text type="secondary" className="ui-agent-trial-step-url" ellipsis={{ tooltip: step.url }}>
      {step.url}
    </Typography.Text>
  ) : null

  const selectorRow = step.selector ? (
    <Typography.Text code className="ui-agent-trial-step-selector">
      {step.selector}
    </Typography.Text>
  ) : null

  const shot = step.screenshot_key ? (
    <ExploreShotThumb
      projectId={projectId}
      sessionId={sessionId}
      storageKey={step.screenshot_key}
      width={thumbWidth}
    />
  ) : null

  if (modal && !failed) {
    return (
      <details className="ui-agent-trial-step ui-agent-trial-step--modal ui-agent-trial-step--passed-collapsed is-passed-details">
        <summary className="ui-agent-trial-step-passed-summary">
          <Tag color="success">通过</Tag>
          <span>
            {displayIndex}. {step.action || 'script'} · {phase}
            {duration ? ` · ${duration}` : ''}
          </span>
        </summary>
        <div className="ui-agent-trial-step-passed-body">
          {urlRow}
          {selectorRow}
          {shot ? <div className="ui-agent-trial-step-shot-only">{shot}</div> : null}
        </div>
      </details>
    )
  }

  if (modal && failed) {
    return (
      <div
        className={`ui-agent-trial-step ui-agent-trial-step--modal is-${stepStatus} is-failed`}
      >
        {meta}
        {urlRow}
        {selectorRow}
        <div className="ui-agent-trial-step-body">
          <div className="ui-agent-trial-step-body-main">
            {step.error_message ? (
              <StepErrorBlock message={step.error_message} compact={compact} modal />
            ) : null}
          </div>
          {shot ? <div className="ui-agent-trial-step-body-shot">{shot}</div> : null}
        </div>
      </div>
    )
  }

  return (
    <div className={`ui-agent-trial-step is-${stepStatus}`}>
      <div className="ui-agent-trial-step-info">
        {meta}
        {selectorRow}
        {urlRow}
        {step.error_message ? (
          <StepErrorBlock message={step.error_message} compact={compact} modal={false} />
        ) : null}
      </div>
      {shot}
    </div>
  )
}

export function TrialRunResult({
  projectId,
  sessionId,
  trial,
  status,
  caseId,
  errorMessage,
  className,
  hideHead = false,
  compact = false,
  variant = 'default',
}: {
  projectId: number
  sessionId: number
  trial?: TrialResult | null
  status?: string | null
  caseId?: string | null
  errorMessage?: string
  className?: string
  hideHead?: boolean
  compact?: boolean
  variant?: 'default' | 'modal'
}) {
  const rawSteps = Array.isArray(trial?.step_results) ? trial!.step_results! : []
  const isModal = variant === 'modal'
  const steps = useMemo(
    () => orderStepsForDisplay(rawSteps, isModal),
    [rawSteps, isModal],
  )
  const resolvedError = resolveTrialErrorMessage(errorMessage, trial)
  const effectiveCompact = compact && !isModal

  const indexByStep = useMemo(() => {
    const map = new Map<TrialStepResult, number>()
    rawSteps.forEach((step, i) => map.set(step, i + 1))
    return map
  }, [rawSteps])

  if (!trial || !status || (caseId && trial.case_id !== caseId)) return null

  const allPassedModal = isModal && status === 'passed' && allStepsPassed(rawSteps)
  const totalDuration = formatTotalDuration(rawSteps)

  return (
    <section
      className={[
        'ui-agent-trial-result',
        isModal ? 'ui-agent-trial-result--variant-modal' : '',
        allPassedModal ? 'ui-agent-trial-result--all-passed' : '',
        className,
      ]
        .filter(Boolean)
        .join(' ')}
      aria-label="试跑执行明细"
    >
      {hideHead ? null : (
        <div className="ui-agent-trial-result-head">
          <Typography.Text strong>试跑执行明细</Typography.Text>
          <Tag color={statusColor(status)}>{statusLabel(status)}</Tag>
          <Typography.Text type="secondary">{rawSteps.length} 个步骤</Typography.Text>
        </div>
      )}
      {allPassedModal ? (
        <div className="ui-agent-trial-passed-banner">
          <Tag color="success">试跑通过</Tag>
          <Typography.Text type="secondary">
            {rawSteps.length} 步
            {totalDuration ? ` · 合计 ${totalDuration}` : ''}
          </Typography.Text>
        </div>
      ) : null}
      {steps.length ? (
        <div
          className={[
            'ui-agent-trial-step-list',
            allPassedModal ? 'ui-agent-trial-step-list--all-passed' : '',
          ]
            .filter(Boolean)
            .join(' ')}
        >
          {allPassedModal
            ? rawSteps.map((step, index) => (
                <PassedTimelineStep
                  key={`${step.phase || 'business'}-${step.order ?? index}-${index}`}
                  projectId={projectId}
                  sessionId={sessionId}
                  step={step}
                  displayIndex={index + 1}
                />
              ))
            : steps.map((step, index) => (
                <TrialStepCard
                  key={`${step.phase || 'business'}-${step.order ?? index}-${index}`}
                  projectId={projectId}
                  sessionId={sessionId}
                  step={step}
                  displayIndex={indexByStep.get(step) ?? index + 1}
                  variant={variant}
                  compact={effectiveCompact}
                />
              ))}
        </div>
      ) : resolvedError ? (
        <StepErrorBlock
          message={resolvedError}
          compact={effectiveCompact}
          modal={isModal}
        />
      ) : (
        <Typography.Text type="secondary">
          {status === 'running' ? '正在等待步骤结果…' : '本次试跑没有可展示的页面步骤。'}
        </Typography.Text>
      )}
    </section>
  )
}
