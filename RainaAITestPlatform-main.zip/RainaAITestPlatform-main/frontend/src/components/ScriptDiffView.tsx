import { Button, Space, Tag } from 'antd'
import { useMemo, type ReactNode } from 'react'
import { groupDiffHunks, hunkKey, type DiffLine } from '../utils/lineDiff'

function DiffLineRow({ line }: { line: DiffLine; index?: number }) {
  return (
    <div className={`ui-script-diff-line ui-script-diff-line--${line.op}`}>
      <span className="ui-script-diff-line-mark">
        {line.op === 'add' ? '+' : line.op === 'del' ? '−' : ' '}
      </span>
      <span>{line.text || ' '}</span>
    </div>
  )
}

export type ScriptDiffViewProps = {
  lines: DiffLine[]
  acceptedKeys: Set<string>
  onAcceptHunk: (hunkIndex: number, key: string) => void
  onRejectHunk: (hunkIndex: number) => void
}

export default function ScriptDiffView({
  lines,
  acceptedKeys,
  onAcceptHunk,
  onRejectHunk,
}: ScriptDiffViewProps) {
  const hunks = useMemo(() => groupDiffHunks(lines), [lines])
  const hunkByStart = useMemo(() => {
    const m = new Map<number, (typeof hunks)[number]>()
    for (const h of hunks) m.set(h.start, h)
    return m
  }, [hunks])

  if (lines.length === 0) {
    return <pre className="ui-script-preview-plain">（空脚本）</pre>
  }

  const blocks: ReactNode[] = []
  let i = 0
  let ctxBuf: DiffLine[] = []
  const flushCtx = () => {
    if (!ctxBuf.length) return
    const start = i - ctxBuf.length
    blocks.push(
      <div key={`ctx-${start}`} className="ui-script-diff-context">
        {ctxBuf.map((line, j) => (
          <DiffLineRow key={`e-${start + j}`} line={line} index={start + j} />
        ))}
      </div>,
    )
    ctxBuf = []
  }

  while (i < lines.length) {
    const hunk = hunkByStart.get(i)
    if (hunk) {
      flushCtx()
      const key = hunkKey(hunk)
      const accepted = acceptedKeys.has(key)
      blocks.push(
        <div key={`hunk-${hunk.index}-${key.slice(0, 24)}`} className="ui-script-diff-hunk">
          <div className="ui-script-diff-hunk-bar">
            <span className="ui-script-diff-hunk-bar-label">
              变更块 {hunk.index + 1}
              {accepted ? ' · 已接受' : ''}
            </span>
            <Space size={4}>
              {accepted ? (
                <Tag color="success" style={{ margin: 0 }}>
                  已接受
                </Tag>
              ) : (
                <>
                  <Button
                    size="small"
                    type="link"
                    onClick={() => onAcceptHunk(hunk.index, key)}
                  >
                    接受
                  </Button>
                  <Button
                    size="small"
                    type="link"
                    danger
                    onClick={() => onRejectHunk(hunk.index)}
                  >
                    拒绝
                  </Button>
                </>
              )}
            </Space>
          </div>
          {hunk.lines.map((line, j) => (
            <DiffLineRow key={`h-${hunk.index}-${j}`} line={line} index={hunk.start + j} />
          ))}
        </div>,
      )
      i = hunk.end
      continue
    }
    ctxBuf.push(lines[i])
    i++
  }
  flushCtx()

  return (
    <div className="ui-script-diff" role="region" aria-label="脚本差异">
      {blocks}
    </div>
  )
}
