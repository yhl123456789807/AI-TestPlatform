import { SendOutlined } from '@ant-design/icons'
import { App, Button, Checkbox, Input, Segmented, Space, Tag, Tooltip, Typography } from 'antd'
import { useEffect, useMemo, useRef, useState } from 'react'
import { apiJson, ApiError } from '../api/client'
import {
  AgentChatCollapseButton,
  useAgentChatCollapsed,
} from './AgentChatCollapse'
import AgentPlanWarnings from './AgentPlanWarnings'
import AgentSessionHistory, {
  type AgentSessionSummary,
} from './AgentSessionHistory'
import { useStickToBottom } from '../hooks/useStickToBottom'
import {
  readAgentLastSessionId,
  writeAgentLastSessionId,
} from '../utils/agentLastSession'
import { applyHunkDecision, lineDiff } from '../utils/lineDiff'
import ScriptCodeEditor from './ScriptCodeEditor'
import ScriptDiffView from './ScriptDiffView'

const LAST_SESSION_PREFIX = 'ui-case-edit-agent'
const MAX_CASES = 10

export type UiCaseEditCaseInput = {
  id: number
  name: string
  script: string
}

type CaseSnapshot = {
  case_id: number
  name?: string
  script?: string
}

type CaseRevision = {
  case_id: number
  name?: string
  summary?: string
  draft_script?: string
  skipped?: boolean
  skip_reason?: string | null
  changed?: boolean
}

type EditPlan = {
  title?: string
  summary?: string
  revisions?: CaseRevision[]
  warnings?: string[]
}

type EditSession = {
  id: number
  status: string
  prompt: string
  case_ids: number[]
  base_snapshots: CaseSnapshot[]
  plan: EditPlan | null
  events: Array<Record<string, unknown>>
  messages: Array<{ role: string; content: string }>
  applied_case_ids: number[]
  error_message: string
}

type ChatBubble = {
  id: string
  role: 'user' | 'assistant' | 'system' | 'log'
  content: string
}

export type UiCaseEditAgentPanelProps = {
  projectId: number
  cases: UiCaseEditCaseInput[]
  open: boolean
  onClose: () => void
  onApplied?: () => void
}

function errText(ex: unknown): string {
  if (ex instanceof ApiError) {
    const b = ex.body as { message?: string } | null
    if (b && typeof b === 'object' && typeof b.message === 'string' && b.message) {
      return b.message
    }
    return `请求失败 (${ex.status})`
  }
  return '请求失败'
}

function formatEventLine(ev: Record<string, unknown>): string | null {
  const t = String(ev.type || '')
  if (t === 'log') return `[${String(ev.node || '')}] ${String(ev.message || '')}`
  if (t === 'plan') return '[plan] 已收到修订草稿'
  if (t === 'interrupted') return `[wait] ${String(ev.message || '等待确认')}`
  if (t === 'done') return `[done] status=${String(ev.status || '')}`
  if (t === 'error') return `[error] ${String(ev.message || '')}`
  return null
}

function roleLabel(role: ChatBubble['role']): string {
  if (role === 'user') return '你'
  if (role === 'system') return '系统'
  return 'Agent'
}

export default function UiCaseEditAgentPanel({
  projectId: pid,
  cases: casesProp,
  open,
  onClose,
  onApplied,
}: UiCaseEditAgentPanelProps) {
  const { message } = App.useApp()
  const caseIdsProp = useMemo(() => casesProp.map((c) => c.id), [casesProp])

  const [caseIds, setCaseIds] = useState<number[]>(caseIdsProp)
  const [selectedApplyIds, setSelectedApplyIds] = useState<number[]>([])
  const [previewCaseId, setPreviewCaseId] = useState<number | null>(caseIdsProp[0] ?? null)
  const [draftOverrides, setDraftOverrides] = useState<Record<number, string>>({})
  const [acceptedHunkKeys, setAcceptedHunkKeys] = useState<Set<string>>(() => new Set())
  const [scriptView, setScriptView] = useState<'diff' | 'edit'>('diff')
  const [input, setInput] = useState('')
  const [session, setSession] = useState<EditSession | null>(null)
  const [pendingUser, setPendingUser] = useState<string | null>(null)
  const [notices, setNotices] = useState<ChatBubble[]>([])
  const [logBubbles, setLogBubbles] = useState<ChatBubble[]>([])
  const [busy, setBusy] = useState(false)
  const [sessionList, setSessionList] = useState<AgentSessionSummary[]>([])
  const [historyLoading, setHistoryLoading] = useState(false)
  const [sessionReady, setSessionReady] = useState(false)
  const { collapsed: chatCollapsed, toggleCollapsed: toggleChatCollapsed } = useAgentChatCollapsed(
    Number.isFinite(pid)
      ? `ui-case-edit-agent-chat-collapsed:${pid}`
      : 'ui-case-edit-agent-chat-collapsed',
  )

  const logSeqRef = useRef(0)
  const fetchGenRef = useRef(0)
  const casesPropKey = casesProp.map((c) => `${c.id}:${(c.script || '').length}`).join(',')

  const awaiting = session?.status === 'awaiting_confirm'
  const finished = ['confirmed', 'cancelled', 'error', 'done'].includes(session?.status || '')
  const canStart = sessionReady && (!session || finished)
  const canChat = Boolean(awaiting)
  const restoring = !sessionReady && !session

  const revisions = session?.plan?.revisions ?? []
  const revisionById = useMemo(() => {
    const m = new Map<number, CaseRevision>()
    for (const r of revisions) m.set(r.case_id, r)
    return m
  }, [revisions])

  const propCaseById = useMemo(() => {
    const m = new Map<number, UiCaseEditCaseInput>()
    for (const c of casesProp) m.set(c.id, c)
    return m
  }, [casesProp])

  const snapshotById = useMemo(() => {
    const m = new Map<number, CaseSnapshot>()
    for (const s of session?.base_snapshots || []) {
      m.set(s.case_id, s)
    }
    return m
  }, [session?.base_snapshots])

  const previewIds = useMemo(() => {
    if (session?.case_ids?.length) return session.case_ids
    return caseIds.length ? caseIds : caseIdsProp
  }, [session?.case_ids, caseIds, caseIdsProp])

  useEffect(() => {
    if (!previewIds.length) {
      setPreviewCaseId(null)
      return
    }
    if (previewCaseId == null || !previewIds.includes(previewCaseId)) {
      setPreviewCaseId(previewIds[0])
    }
  }, [previewIds, previewCaseId])

  useEffect(() => {
    if (!session?.plan?.revisions) return
    const ids = session.plan.revisions.filter((r) => !r.skipped).map((r) => r.case_id)
    setSelectedApplyIds(ids)
  }, [session?.id, session?.plan?.revisions])

  useEffect(() => {
    const revs = session?.plan?.revisions
    if (!revs?.length) {
      setDraftOverrides({})
      setAcceptedHunkKeys(new Set())
      return
    }
    const next: Record<number, string> = {}
    for (const r of revs) {
      if (r.skipped) continue
      next[r.case_id] = r.draft_script || ''
    }
    setDraftOverrides(next)
    setAcceptedHunkKeys(new Set())
    setScriptView('diff')
  }, [session?.id, session?.plan?.revisions])

  useEffect(() => {
    setAcceptedHunkKeys(new Set())
  }, [previewCaseId])

  const previewBaseScript = useMemo(() => {
    if (previewCaseId == null) return ''
    const snap = snapshotById.get(previewCaseId)
    if (snap?.script != null) return snap.script
    return propCaseById.get(previewCaseId)?.script || ''
  }, [previewCaseId, snapshotById, propCaseById])

  const previewRevision = previewCaseId != null ? revisionById.get(previewCaseId) : undefined
  const previewDraft =
    previewCaseId != null
      ? (draftOverrides[previewCaseId] ?? previewRevision?.draft_script ?? '')
      : ''
  const hasDraft =
    awaiting && previewCaseId != null && !previewRevision?.skipped && previewDraft.length > 0
  const showDiff = Boolean(hasDraft && previewDraft !== previewBaseScript)
  const diffLines = useMemo(
    () => (hasDraft ? lineDiff(previewBaseScript, previewDraft) : []),
    [hasDraft, previewBaseScript, previewDraft],
  )

  const displayMessages = useMemo(() => {
    const out: ChatBubble[] = []
    for (const m of session?.messages || []) {
      const role = m.role === 'user' ? 'user' : m.role === 'assistant' ? 'assistant' : 'system'
      out.push({
        id: `m-${out.length}`,
        role,
        content: m.content,
      })
    }
    if (pendingUser) {
      out.push({ id: 'pending-user', role: 'user', content: pendingUser })
    }
    out.push(...notices)
    out.push(...logBubbles)
    return out
  }, [session?.messages, pendingUser, notices, logBubbles])

  const {
    containerRef: messagesRef,
    onScroll: updateStickToBottom,
    pinToBottom,
  } = useStickToBottom([displayMessages.length, busy, chatCollapsed])

  function resetSession() {
    pinToBottom()
    setSession(null)
    setLogBubbles([])
    logSeqRef.current = 0
    setInput('')
    setPendingUser(null)
    setNotices([])
    setSelectedApplyIds([])
    setDraftOverrides({})
    setAcceptedHunkKeys(new Set())
    setScriptView('diff')
    setCaseIds(caseIdsProp)
    setPreviewCaseId(caseIdsProp[0] ?? null)
    setSessionReady(true)
    if (Number.isFinite(pid)) {
      writeAgentLastSessionId(LAST_SESSION_PREFIX, pid, null)
    }
  }

  useEffect(() => {
    if (!open) return
    const gen = ++fetchGenRef.current
    setSessionReady(false)
    setCaseIds(caseIdsProp)
    setPreviewCaseId(caseIdsProp[0] ?? null)
    setSession(null)
    setSessionList([])
    setLogBubbles([])
    logSeqRef.current = 0
    setInput('')
    setPendingUser(null)
    setNotices([])
    setSelectedApplyIds([])
    setDraftOverrides({})
    setAcceptedHunkKeys(new Set())
    setScriptView('diff')
    setHistoryLoading(true)
    ;(async () => {
      if (!Number.isFinite(pid)) {
        if (gen === fetchGenRef.current) {
          setHistoryLoading(false)
          setSessionReady(true)
        }
        return
      }
      let list: AgentSessionSummary[] = []
      try {
        list = await apiJson<AgentSessionSummary[]>(
          `/api/v1/projects/${pid}/ui-case-edit-agent/sessions`,
        )
      } catch {
        /* ignore */
      }
      if (gen !== fetchGenRef.current) return
      setSessionList(list)
      setHistoryLoading(false)

      const saved = readAgentLastSessionId(LAST_SESSION_PREFIX, pid)
      const fallbackId = list[0]?.id ?? null
      const candidates = [
        ...(saved != null ? [saved] : []),
        ...(fallbackId != null && fallbackId !== saved ? [fallbackId] : []),
      ]
      for (const targetId of candidates) {
        if (gen !== fetchGenRef.current) return
        try {
          const s = await apiJson<EditSession>(
            `/api/v1/projects/${pid}/ui-case-edit-agent/sessions/${targetId}`,
          )
          if (gen !== fetchGenRef.current) return
          setSession(s)
          if (s.case_ids?.length) {
            setCaseIds(s.case_ids)
            setPreviewCaseId(s.case_ids[0])
          }
          setLogBubbles([])
          logSeqRef.current = 0
          setNotices([])
          setPendingUser(null)
          for (const ev of s.events || []) {
            const line = formatEventLine(ev)
            if (line) {
              logSeqRef.current += 1
              setLogBubbles((prev) => [
                ...prev,
                { id: `log-${logSeqRef.current}`, role: 'log', content: line },
              ])
            }
          }
          writeAgentLastSessionId(LAST_SESSION_PREFIX, pid, s.id)
          break
        } catch {
          if (saved === targetId) {
            writeAgentLastSessionId(LAST_SESSION_PREFIX, pid, null)
          }
        }
      }
      if (gen === fetchGenRef.current) setSessionReady(true)
    })()
    // eslint-disable-next-line react-hooks/exhaustive-deps -- reset only when modal opens / scope changes
  }, [open, casesPropKey, pid])

  async function refreshSessionList() {
    if (!Number.isFinite(pid)) return
    setHistoryLoading(true)
    try {
      const rows = await apiJson<AgentSessionSummary[]>(
        `/api/v1/projects/${pid}/ui-case-edit-agent/sessions`,
      )
      setSessionList(rows)
    } catch {
      /* ignore */
    } finally {
      setHistoryLoading(false)
    }
  }

  function appendLog(line: string) {
    logSeqRef.current += 1
    setLogBubbles((prev) => [
      ...prev,
      { id: `log-${logSeqRef.current}`, role: 'log', content: line },
    ])
  }

  function ingestEvents(events: Array<Record<string, unknown>>) {
    for (const ev of events) {
      const line = formatEventLine(ev)
      if (line) appendLog(line)
    }
  }

  function pushNotice(role: Exclude<ChatBubble['role'], 'log'>, content: string) {
    setNotices((prev) => [
      ...prev,
      { id: `n-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`, role, content },
    ])
  }

  async function startSession(prompt: string) {
    if (caseIds.length === 0) {
      message.warning('请先勾选要修改的用例')
      return
    }
    if (caseIds.length > MAX_CASES) {
      message.warning(`一次最多修订 ${MAX_CASES} 条，请收窄选择`)
      return
    }
    const userText = prompt.trim()
    if (!userText) {
      message.warning('请输入修改说明')
      return
    }
    setBusy(true)
    setLogBubbles([])
    logSeqRef.current = 0
    setNotices([])
    setPendingUser(userText)
    try {
      const created = await apiJson<EditSession>(
        `/api/v1/projects/${pid}/ui-case-edit-agent/sessions`,
        {
          method: 'POST',
          body: JSON.stringify({
            prompt: userText,
            case_ids: caseIds,
          }),
        },
      )
      setSession(created)
      if (created.case_ids?.length) {
        setCaseIds(created.case_ids)
        setPreviewCaseId(created.case_ids[0])
      }
      ingestEvents(created.events || [])
      setPendingUser(null)
      void refreshSessionList()
      if (created.status === 'error') {
        message.error(created.error_message || '生成修订草稿失败')
        pushNotice('system', created.error_message || '生成修订草稿失败')
      } else if (created.status === 'awaiting_confirm') {
        const n = created.plan?.revisions?.filter((r) => !r.skipped).length ?? 0
        pushNotice(
          'assistant',
          `左侧可预览脚本差异（可接受 ${n} 条）。可继续对话修改，点「接受修改」才会写回用例。`,
        )
      }
    } catch (e) {
      message.error(errText(e))
      pushNotice('system', errText(e))
      setPendingUser(null)
    } finally {
      setBusy(false)
    }
  }

  async function sendRevise(content: string) {
    if (!session) return
    setBusy(true)
    setPendingUser(content)
    try {
      const updated = await apiJson<EditSession>(
        `/api/v1/projects/${pid}/ui-case-edit-agent/sessions/${session.id}/messages`,
        {
          method: 'POST',
          body: JSON.stringify({ content }),
        },
      )
      setSession(updated)
      setPendingUser(null)
      ingestEvents(updated.events || [])
      void refreshSessionList()
      if (updated.status === 'error') {
        pushNotice('system', updated.error_message || '修改失败')
      }
    } catch (e) {
      const text = errText(e)
      message.error(text)
      pushNotice('system', text)
      setPendingUser(null)
    } finally {
      setBusy(false)
    }
  }

  async function onSend() {
    const text = input.trim()
    if (busy || !text) return
    if (canStart) {
      pinToBottom()
      setInput('')
      await startSession(text)
      return
    }
    if (canChat) {
      pinToBottom()
      setInput('')
      await sendRevise(text)
    }
  }

  async function confirmAction(action: 'confirm' | 'cancel') {
    if (!session) return
    if (action === 'confirm' && selectedApplyIds.length === 0) {
      message.warning('请至少勾选一条要接受的修订')
      return
    }
    setBusy(true)
    try {
      const drafts =
        action === 'confirm'
          ? selectedApplyIds
              .map((id) => ({
                case_id: id,
                draft_script: draftOverrides[id] ?? revisionById.get(id)?.draft_script ?? '',
              }))
              .filter((d) => d.draft_script.trim())
          : undefined
      const result = await apiJson<EditSession>(
        `/api/v1/projects/${pid}/ui-case-edit-agent/sessions/${session.id}/confirm`,
        {
          method: 'POST',
          body: JSON.stringify({
            action,
            case_ids: action === 'confirm' ? selectedApplyIds : undefined,
            drafts,
          }),
        },
      )
      setSession(result)
      ingestEvents(result.events || [])
      void refreshSessionList()
      if (action === 'confirm') {
        if (result.applied_case_ids?.length) {
          message.success(`已写回 ${result.applied_case_ids.length} 条用例`)
          pushNotice('assistant', `已接受并写回 ${result.applied_case_ids.length} 条用例。`)
          onApplied?.()
          onClose()
        } else {
          const tip = result.error_message || '未写回任何用例'
          message.error(tip)
          pushNotice('system', tip)
        }
      } else if (action === 'cancel') {
        message.info('已拒绝修改')
        pushNotice('assistant', '已拒绝本轮修改，未写回用例。可继续输入说明开始新一轮。')
      } else if (result.status === 'error') {
        message.error(result.error_message || '确认失败')
        pushNotice('system', result.error_message || '确认失败')
      }
    } catch (e) {
      const text = errText(e)
      message.error(text)
      pushNotice('system', text)
    } finally {
      setBusy(false)
    }
  }

  async function loadSession(id: number, opts?: { quiet?: boolean; force?: boolean }) {
    if (!opts?.force && (busy || session?.id === id)) return
    if (opts?.force && session?.id === id) return
    pinToBottom()
    setBusy(true)
    setHistoryLoading(true)
    setLogBubbles([])
    logSeqRef.current = 0
    setNotices([])
    setPendingUser(null)
    try {
      const s = await apiJson<EditSession>(
        `/api/v1/projects/${pid}/ui-case-edit-agent/sessions/${id}`,
      )
      setSession(s)
      if (s.case_ids?.length) {
        setCaseIds(s.case_ids)
        setPreviewCaseId(s.case_ids[0])
      }
      ingestEvents(s.events || [])
      if (!opts?.quiet) {
        if (['confirmed', 'cancelled', 'error', 'done'].includes(s.status)) {
          pushNotice('assistant', '已打开历史会话（只读）。可点「新会话」重新开始。')
        } else if (s.status === 'awaiting_confirm') {
          pushNotice('assistant', '已打开历史会话。可继续修改或接受。')
        }
      }
    } catch (e) {
      if (!opts?.quiet) message.error(errText(e))
    } finally {
      setBusy(false)
      setHistoryLoading(false)
    }
  }

  async function deleteHistorySession(id: number) {
    if (busy) return
    setBusy(true)
    try {
      await apiJson(`/api/v1/projects/${pid}/ui-case-edit-agent/sessions/${id}`, {
        method: 'DELETE',
      })
      const list = await apiJson<AgentSessionSummary[]>(
        `/api/v1/projects/${pid}/ui-case-edit-agent/sessions`,
      )
      setSessionList(list)
      if (session?.id === id) {
        if (list[0]) {
          setBusy(false)
          await loadSession(list[0].id, { quiet: true, force: true })
          return
        }
        resetSession()
      }
    } catch (e) {
      message.error(errText(e))
    } finally {
      setBusy(false)
    }
  }

  useEffect(() => {
    if (!Number.isFinite(pid) || session?.id == null) return
    writeAgentLastSessionId(LAST_SESSION_PREFIX, pid, session.id)
  }, [pid, session?.id])

  const canSend =
    sessionReady &&
    !busy &&
    ((canStart && !!input.trim()) || (canChat && !!input.trim()))
  const warnings = session?.plan?.warnings || []

  function caseLabel(id: number): string {
    const rev = revisionById.get(id)
    const snap = snapshotById.get(id)
    const prop = propCaseById.get(id)
    return rev?.name || snap?.name || prop?.name || `#${id}`
  }

  function handleAcceptHunk(_hunkIndex: number, key: string) {
    setAcceptedHunkKeys((prev) => {
      const next = new Set(prev)
      next.add(key)
      return next
    })
  }

  function handleRejectHunk(hunkIndex: number) {
    if (previewCaseId == null) return
    const lines = diffLines.length ? diffLines : lineDiff(previewBaseScript, previewDraft)
    const nextScript = applyHunkDecision(lines, hunkIndex, 'reject')
    setDraftOverrides((prev) => ({ ...prev, [previewCaseId]: nextScript }))
    setAcceptedHunkKeys(new Set())
  }

  return (
    <div className="api-scenario-agent-split" style={{ height: '100%', minHeight: 0 }}>
      <aside className="api-scenario-agent-plan card" style={{ margin: 0 }}>
        <div className="api-scenario-agent-chat-toolbar">
          <Typography.Text strong>
            {hasDraft ? '脚本变更' : session?.plan?.title || '当前脚本'}
          </Typography.Text>
          <Space size="small">
            <Button
              size="small"
              type="primary"
              disabled={!awaiting || selectedApplyIds.length === 0}
              loading={busy}
              onClick={() => void confirmAction('confirm')}
            >
              接受修改
            </Button>
            <Button
              size="small"
              danger
              disabled={!awaiting}
              onClick={() => void confirmAction('cancel')}
            >
              拒绝修改
            </Button>
          </Space>
        </div>
        <div className="api-scenario-agent-plan-body">
          {previewIds.length > 0 && (
            <div style={{ marginBottom: 12 }}>
              <Typography.Text type="secondary" style={{ fontSize: 12 }}>
                范围（{previewIds.length}）· 点击切换预览
              </Typography.Text>
              <div style={{ marginTop: 6 }}>
                <Space size={[4, 4]} wrap>
                  {previewIds.map((id) => {
                    const rev = revisionById.get(id)
                    const skipped = Boolean(rev?.skipped)
                    const checked = selectedApplyIds.includes(id)
                    return (
                      <Tag
                        key={id}
                        color={previewCaseId === id ? 'blue' : undefined}
                        style={{ cursor: 'pointer', userSelect: 'none' }}
                        onClick={() => setPreviewCaseId(id)}
                      >
                        {awaiting && rev && !skipped ? (
                          <Checkbox
                            checked={checked}
                            onClick={(e) => e.stopPropagation()}
                            onChange={(e) => {
                              setSelectedApplyIds((prev) =>
                                e.target.checked
                                  ? [...prev.filter((x) => x !== id), id]
                                  : prev.filter((x) => x !== id),
                              )
                            }}
                            style={{ marginRight: 4 }}
                          />
                        ) : null}
                        #{id} {caseLabel(id)}
                        {skipped ? ' · 跳过' : ''}
                      </Tag>
                    )
                  })}
                </Space>
              </div>
            </div>
          )}

          {session?.plan?.summary && (
            <p className="api-scenario-agent-summary">{session.plan.summary}</p>
          )}
          <AgentPlanWarnings items={warnings} />

          {previewCaseId == null ? (
            <div className="api-scenario-agent-plan-empty">请勾选用例后再说明修改意图</div>
          ) : previewRevision?.skipped ? (
            <div>
              <Typography.Text type="secondary" style={{ fontSize: 12 }}>
                #{previewCaseId} 已跳过：{previewRevision.skip_reason || previewRevision.summary}
              </Typography.Text>
              <ScriptCodeEditor
                className="ui-script-preview-monaco"
                value={previewBaseScript || '// （空脚本）'}
                readOnly
                height={360}
              />
            </div>
          ) : hasDraft ? (
            <div>
              <div
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  gap: 8,
                  marginBottom: 8,
                  flexWrap: 'wrap',
                }}
              >
                <Typography.Text type="secondary" style={{ fontSize: 12 }}>
                  #{previewCaseId} · {previewRevision?.summary || '已修订'}
                  {showDiff ? '' : ' · 与原文一致'}
                </Typography.Text>
                <Segmented
                  size="small"
                  value={scriptView}
                  onChange={(v) => setScriptView(v as 'diff' | 'edit')}
                  options={[
                    { label: '差异', value: 'diff' },
                    { label: '编辑', value: 'edit' },
                  ]}
                />
              </div>
              {scriptView === 'edit' ? (
                <ScriptCodeEditor
                  className="ui-script-preview-monaco"
                  value={previewDraft}
                  height={360}
                  onChange={(val) => {
                    const id = previewCaseId
                    setDraftOverrides((prev) => ({ ...prev, [id]: val }))
                    setAcceptedHunkKeys(new Set())
                  }}
                />
              ) : (
                <ScriptDiffView
                  lines={diffLines.length ? diffLines : lineDiff(previewBaseScript, previewDraft)}
                  acceptedKeys={acceptedHunkKeys}
                  onAcceptHunk={handleAcceptHunk}
                  onRejectHunk={handleRejectHunk}
                />
              )}
            </div>
          ) : (
            <div>
              <Typography.Text type="secondary" style={{ fontSize: 12 }}>
                #{previewCaseId} · 对话前可先阅读当前脚本
              </Typography.Text>
              <ScriptCodeEditor
                className="ui-script-preview-monaco"
                value={previewBaseScript || '// （空脚本）'}
                readOnly
                height={360}
              />
            </div>
          )}
        </div>
        {session?.applied_case_ids?.length ? (
          <Typography.Paragraph className="api-scenario-agent-plan-foot">
            已写回 {session.applied_case_ids.length} 条用例
          </Typography.Paragraph>
        ) : null}
      </aside>

      <section
        className={`api-scenario-agent-chat card${chatCollapsed ? ' is-collapsed' : ''}`}
        style={{ margin: 0 }}
      >
        <div className="api-scenario-agent-chat-toolbar">
          <div className="api-scenario-agent-chat-toolbar-left">
            <Space size="small" wrap>
              {session && (
                <Tag color={awaiting ? 'processing' : finished ? 'default' : 'blue'}>
                  {session.status}
                </Tag>
              )}
            </Space>
          </div>
          <div className="api-scenario-agent-chat-toolbar-right">
            <AgentChatCollapseButton
              collapsed={chatCollapsed}
              onToggle={toggleChatCollapsed}
            />
            {!chatCollapsed && (
              <AgentSessionHistory
                items={sessionList}
                activeId={session?.id ?? null}
                loading={historyLoading}
                busy={busy}
                onSelect={(id) => void loadSession(id)}
                onNew={resetSession}
                onDelete={(id) => void deleteHistorySession(id)}
              />
            )}
          </div>
        </div>

        <div
          className="api-scenario-agent-messages"
          ref={messagesRef}
          onScroll={updateStickToBottom}
        >
          {displayMessages.map((m) => (
            <div
              key={m.id}
              className={`api-scenario-agent-bubble api-scenario-agent-bubble--${m.role}`}
            >
              {m.role !== 'log' && (
                <div className="api-scenario-agent-bubble-role">{roleLabel(m.role)}</div>
              )}
              <div className="api-scenario-agent-bubble-body">{m.content}</div>
            </div>
          ))}
          {busy && (
            <div className="api-scenario-agent-bubble api-scenario-agent-bubble--assistant">
              <div className="api-scenario-agent-bubble-role">Agent</div>
              <div className="api-scenario-agent-bubble-body muted">思考中…</div>
            </div>
          )}
        </div>

        <div className="api-scenario-agent-composer">
          <Input.TextArea
            className="api-scenario-agent-composer-input"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder={
              restoring
                ? '正在恢复上次会话…'
                : finished && canStart
                  ? caseIds.length
                    ? '会话已结束，输入修改说明开始新一轮修订'
                    : '请先勾选用例后再说明修改意图'
                  : canStart
                    ? caseIds.length
                      ? '说明如何改脚本，例如：登录后增加 waitForURL；验证码用 AI 识别填写'
                      : '请先勾选用例后再说明修改意图'
                    : canChat
                      ? '继续修改草稿，例如：把断言从 heading 改成文本可见'
                      : '当前会话已结束，请点「新会话」'
            }
            autoSize={{ minRows: 2, maxRows: 5 }}
            disabled={
              restoring ||
              busy ||
              (!canStart && !canChat) ||
              (canStart && caseIds.length === 0)
            }
            variant="borderless"
            onPressEnter={(e) => {
              if (!e.shiftKey) {
                e.preventDefault()
                void onSend()
              }
            }}
          />
          <div className="api-scenario-agent-composer-bar">
            <div className="api-scenario-agent-composer-tools">
              {caseIds.length > 0 && canStart ? (
                <Typography.Text type="secondary" style={{ fontSize: 12 }}>
                  已选 {caseIds.length} 条
                </Typography.Text>
              ) : null}
            </div>

            <Tooltip title={canStart ? '生成修订草稿' : '发送'}>
              <Button
                type="primary"
                shape="circle"
                size="small"
                className="api-scenario-agent-send-btn"
                icon={<SendOutlined />}
                loading={busy}
                disabled={!canSend || (canStart && caseIds.length === 0)}
                onClick={() => void onSend()}
              />
            </Tooltip>
          </div>
        </div>
      </section>
    </div>
  )
}
