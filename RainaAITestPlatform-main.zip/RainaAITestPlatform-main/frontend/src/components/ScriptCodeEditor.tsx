import Editor, { loader, type OnChange, type OnMount } from '@monaco-editor/react'
import * as monaco from 'monaco-editor'
// monaco-editor@0.57 exports map `monaco-editor/*` → `esm/vs/*` (not `esm/vs/esm/...`)
import editorWorker from 'monaco-editor/editor/editor.worker.js?worker'
import tsWorker from 'monaco-editor/language/typescript/ts.worker.js?worker'
import { useCallback, useEffect, useState } from 'react'

type Props = {
  value: string
  onChange?: (value: string) => void
  readOnly?: boolean
  /** CSS height, e.g. 360px / 100% / min(60vh, 480px) */
  height?: string | number
  className?: string
  /** Override auto-detect (javascript vs python UI scripts). */
  language?: string
}

function detectLanguage(code: string): string {
  const text = code || ''
  if (/^\s*def\s+run\s*\(/m.test(text)) return 'python'
  if (/async\s+function\s+run\s*\(/.test(text)) {
    return 'javascript'
  }
  if (/^\s*(import|from)\s+\w+/m.test(text) && /page\./.test(text)) return 'python'
  return 'javascript'
}

/** Use npm monaco (Vite) instead of jsDelivr CDN — CDN often hangs in CN networks. */
let monacoConfigured = false
function ensureMonacoLocal(): void {
  if (monacoConfigured || typeof window === 'undefined') return
  monacoConfigured = true
  ;(window as unknown as { MonacoEnvironment?: object }).MonacoEnvironment = {
    getWorker(_workerId: string, label: string) {
      if (label === 'typescript' || label === 'javascript') {
        return new tsWorker()
      }
      return new editorWorker()
    },
  }
  loader.config({ monaco })
}

const DEFAULT_OPTIONS = {
  minimap: { enabled: false },
  fontSize: 12,
  fontFamily: 'ui-monospace, SFMono-Regular, Menlo, Consolas, monospace',
  lineNumbers: 'on' as const,
  lineNumbersMinChars: 3,
  glyphMargin: false,
  folding: true,
  scrollBeyondLastLine: false,
  wordWrap: 'off' as const,
  automaticLayout: true,
  tabSize: 2,
  renderLineHighlight: 'line' as const,
  padding: { top: 8, bottom: 8 },
  scrollbar: {
    verticalScrollbarSize: 8,
    horizontalScrollbarSize: 8,
  },
  overviewRulerLanes: 0,
  hideCursorInOverviewRuler: true,
  overviewRulerBorder: false,
}

ensureMonacoLocal()

export default function ScriptCodeEditor({
  value,
  onChange,
  readOnly = false,
  height = '100%',
  className,
  language,
}: Props) {
  const lang = language || detectLanguage(value)
  const [failed, setFailed] = useState(false)

  useEffect(() => {
    let cancelled = false
    ensureMonacoLocal()
    loader
      .init()
      .then(() => {
        if (!cancelled) setFailed(false)
      })
      .catch(() => {
        if (!cancelled) setFailed(true)
      })
    return () => {
      cancelled = true
    }
  }, [])

  const handleChange: OnChange = useCallback(
    (next) => {
      onChange?.(next ?? '')
    },
    [onChange],
  )

  const handleMount: OnMount = useCallback(
    (editor) => {
      editor.updateOptions({ readOnly })
      setFailed(false)
    },
    [readOnly],
  )

  if (failed) {
    return (
      <div className={`script-code-editor is-fallback${className ? ` ${className}` : ''}`} style={{ height }}>
        {readOnly ? (
          <pre className="script-code-editor-fallback-pre">{value}</pre>
        ) : (
          <textarea
            className="script-code-editor-fallback-textarea"
            value={value}
            spellCheck={false}
            onChange={(e) => onChange?.(e.target.value)}
          />
        )}
      </div>
    )
  }

  return (
    <div className={`script-code-editor${className ? ` ${className}` : ''}`} style={{ height }}>
      <Editor
        height="100%"
        language={lang}
        theme="light"
        value={value}
        onChange={readOnly ? undefined : handleChange}
        onMount={handleMount}
        options={{
          ...DEFAULT_OPTIONS,
          readOnly,
          domReadOnly: readOnly,
        }}
        loading={<div className="script-code-editor-loading">加载编辑器…</div>}
      />
    </div>
  )
}
