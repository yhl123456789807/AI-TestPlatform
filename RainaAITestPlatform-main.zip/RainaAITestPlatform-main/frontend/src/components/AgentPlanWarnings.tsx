import { Alert, Button, Modal } from 'antd'
import { useState } from 'react'

type Props = {
  items: string[]
}

export default function AgentPlanWarnings({ items }: Props) {
  const [open, setOpen] = useState(false)

  if (items.length === 0) return null

  return (
    <>
      <Alert
        className="api-scenario-agent-warnings api-scenario-agent-warnings--compact"
        type="warning"
        showIcon
        message={`共 ${items.length} 条注意事项`}
        action={
          <Button type="link" size="small" onClick={() => setOpen(true)}>
            查看
          </Button>
        }
      />
      <Modal
        title="注意事项"
        open={open}
        onCancel={() => setOpen(false)}
        footer={null}
        destroyOnHidden
      >
        <ul className="api-scenario-agent-warnings-list">
          {items.map((w, i) => (
            <li key={i}>{w}</li>
          ))}
        </ul>
      </Modal>
    </>
  )
}
