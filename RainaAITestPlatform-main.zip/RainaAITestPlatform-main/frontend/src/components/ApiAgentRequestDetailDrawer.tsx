import { Descriptions, Drawer, Tag } from 'antd'

export type ApiAgentRequestDetail = {
  name?: string
  tags?: string[]
  method?: string
  path?: string
  query?: Record<string, string>
  headers?: Record<string, string>
  body_type?: string
  body?: string
  assertions?: Array<Record<string, unknown>>
  extractors?: Array<{ name?: string; type?: string; expr?: string }>
  timeout_ms?: number
  description?: string
  env_vars_needed?: string[]
  rationale?: string
  extract_hints?: string[]
  consume_hints?: Array<{
    var: string
    from_step?: string
    in?: string
    key?: string
    template?: string
  }>
  when?: { op?: string; left?: string; right?: string } | null
  on_pass?: string
  on_fail?: string
}

export type ApiAgentRequestDetailDrawerProps = {
  detail: ApiAgentRequestDetail | null
  fallbackMethod?: string
  fallbackPath?: string
  open: boolean
  onClose: () => void
  title?: string
  /** Show scenario-only rows (产出/消费/条件/跳转) */
  scenarioExtras?: boolean
  loading?: boolean
}

function formatAssertion(a: Record<string, unknown>): string {
  const t = String(a.type || '')
  const expr = String(a.expr || '')
  const op = String(a.op || '')
  const expected = a.expected
  if (t === 'status') return `status=${String(expected ?? '')}`
  if (t === 'jsonpath') {
    if (op === 'exists') return `${expr} exists`
    if (op === 'contains') return `${expr} contains ${String(expected ?? '')}`
    if (op === 'regex') return `${expr} =~ ${String(expected ?? '')}`
    return `${expr}=${String(expected ?? '')}`
  }
  if (t === 'contains' || t === 'not_contains' || t === 'regex') {
    return `${t} ${String(expected ?? expr)}`
  }
  if (t === 'header') return `header ${expr}`
  return t || 'assert'
}

function methodClass(method: string): string {
  const m = method.toLowerCase().replace(/[^a-z]/g, '')
  return `api-scenario-agent-method api-scenario-agent-method--${m || 'other'}`
}

function renderPath(path: string) {
  return path.split('/').map((seg, i) => (
    <span key={i}>
      {i > 0 ? (
        <>
          /<wbr />
        </>
      ) : null}
      {seg}
    </span>
  ))
}

function formatWhen(when: ApiAgentRequestDetail['when']): string {
  if (!when || !when.op) return '—'
  if (when.op === 'exists') return `exists ${when.left || ''}`
  return `${when.left || ''} ${when.op} ${when.right ?? ''}`
}

function consumeLine(h: NonNullable<ApiAgentRequestDetail['consume_hints']>[number]): string {
  const place = `${h.in || 'header'}.${h.key || h.var}`
  const from = h.from_step ? ` ← ${h.from_step}` : ''
  const tpl = h.template ? ` = ${h.template}` : ''
  return `${h.var}${from} · ${place}${tpl}`
}

function KvList({ data }: { data?: Record<string, string> }) {
  const entries = Object.entries(data || {})
  if (!entries.length) return <span className="api-scenario-agent-muted">—</span>
  return (
    <div className="api-scenario-agent-lines">
      {entries.map(([k, v]) => (
        <div key={k} className="api-scenario-agent-line">
          <code>
            {k}={v}
          </code>
        </div>
      ))}
    </div>
  )
}

export default function ApiAgentRequestDetailDrawer({
  detail,
  fallbackMethod,
  fallbackPath,
  open,
  onClose,
  title,
  scenarioExtras = false,
  loading = false,
}: ApiAgentRequestDetailDrawerProps) {
  if (!detail && !loading) return null

  const method = detail?.method || fallbackMethod || ''
  const path = detail?.path || fallbackPath || ''
  const assertions = detail?.assertions || []
  const extractors = detail?.extractors || []
  const envVars = detail?.env_vars_needed || []
  const tags = detail?.tags || []
  const body = (detail?.body || '').trim()
  const extracts = (detail?.extract_hints || []).filter(Boolean)
  const consumes = detail?.consume_hints || []
  const showWhen = Boolean(detail?.when?.op)

  return (
    <Drawer
      title={title || detail?.name || '步骤详情'}
      open={open}
      onClose={onClose}
      width={600}
      destroyOnHidden
    >
      {loading && !detail ? (
        <span className="api-scenario-agent-muted">加载中…</span>
      ) : detail ? (
        <Descriptions column={1} size="small" bordered>
          {tags.length > 0 || !scenarioExtras ? (
            <Descriptions.Item label="标签">
              {tags.length ? (
                <span className="api-scenario-agent-tags">
                  {tags.map((t) => (
                    <Tag key={t}>{t}</Tag>
                  ))}
                </span>
              ) : (
                <span className="api-scenario-agent-muted">—</span>
              )}
            </Descriptions.Item>
          ) : null}
          <Descriptions.Item label="请求">
            {method || path ? (
              <div className="api-scenario-agent-step-endpoint">
                {method ? <span className={methodClass(method)}>{method}</span> : null}
                {path ? (
                  <code className="api-scenario-agent-path">{renderPath(path)}</code>
                ) : null}
              </div>
            ) : (
              <span className="api-scenario-agent-muted">—</span>
            )}
          </Descriptions.Item>
          <Descriptions.Item label="Query">
            <KvList data={detail.query} />
          </Descriptions.Item>
          <Descriptions.Item label="Headers">
            <KvList data={detail.headers} />
          </Descriptions.Item>
          <Descriptions.Item label="Body">
            {body ? (
              <div>
                {detail.body_type ? (
                  <Tag style={{ marginBottom: 8 }}>{detail.body_type}</Tag>
                ) : null}
                <pre
                  style={{
                    margin: 0,
                    whiteSpace: 'pre-wrap',
                    wordBreak: 'break-word',
                    maxHeight: 280,
                    overflow: 'auto',
                    fontSize: 12,
                  }}
                >
                  {body}
                </pre>
              </div>
            ) : (
              <span className="api-scenario-agent-muted">
                {detail.body_type && detail.body_type !== 'none' ? detail.body_type : '—'}
              </span>
            )}
          </Descriptions.Item>
          <Descriptions.Item label="断言">
            {assertions.length ? (
              <div className="api-scenario-agent-lines">
                {assertions.map((a, i) => (
                  <div key={`${String(a.type)}-${i}`} className="api-scenario-agent-line">
                    {formatAssertion(a)}
                  </div>
                ))}
              </div>
            ) : (
              <span className="api-scenario-agent-muted">—</span>
            )}
          </Descriptions.Item>
          <Descriptions.Item label="提取">
            {extractors.length ? (
              <span className="api-scenario-agent-tags">
                {extractors.map((e) => (
                  <Tag key={e.name || e.expr} color="blue">
                    {e.name}
                    {e.expr ? ` ← ${e.expr}` : ''}
                  </Tag>
                ))}
              </span>
            ) : extracts.length ? (
              <span className="api-scenario-agent-tags">
                {extracts.map((name) => (
                  <Tag key={name} color="blue">
                    {name}
                  </Tag>
                ))}
              </span>
            ) : (
              <span className="api-scenario-agent-muted">—</span>
            )}
          </Descriptions.Item>
          {scenarioExtras ? (
            <>
              <Descriptions.Item label="产出">
                {extracts.length ? (
                  <span className="api-scenario-agent-tags">
                    {extracts.map((name) => (
                      <Tag key={name} color="blue">
                        {name}
                      </Tag>
                    ))}
                  </span>
                ) : (
                  <span className="api-scenario-agent-muted">—</span>
                )}
              </Descriptions.Item>
              <Descriptions.Item label="消费">
                {consumes.length ? (
                  <div className="api-scenario-agent-lines">
                    {consumes.map((h, i) => (
                      <div key={`${h.var}-${i}`} className="api-scenario-agent-line">
                        {consumeLine(h)}
                      </div>
                    ))}
                  </div>
                ) : (
                  <span className="api-scenario-agent-muted">—</span>
                )}
              </Descriptions.Item>
              {showWhen ? (
                <Descriptions.Item label="条件">
                  <span className="api-scenario-agent-line">{formatWhen(detail.when)}</span>
                </Descriptions.Item>
              ) : null}
              <Descriptions.Item label="跳转">
                <span>
                  成功 → {detail.on_pass || '—'}；失败 → {detail.on_fail || '—'}
                </span>
              </Descriptions.Item>
            </>
          ) : null}
          <Descriptions.Item label="超时">
            {detail.timeout_ms != null ? `${detail.timeout_ms} ms` : '—'}
          </Descriptions.Item>
          {!scenarioExtras ? (
            <Descriptions.Item label="环境变量">
              {envVars.length ? (
                <span className="api-scenario-agent-tags">
                  {envVars.map((v) => (
                    <Tag key={v}>{`{{${v}}}`}</Tag>
                  ))}
                </span>
              ) : (
                <span className="api-scenario-agent-muted">—</span>
              )}
            </Descriptions.Item>
          ) : null}
          <Descriptions.Item label="说明">
            {detail.rationale || detail.description || (
              <span className="api-scenario-agent-muted">—</span>
            )}
          </Descriptions.Item>
        </Descriptions>
      ) : null}
    </Drawer>
  )
}

export { formatAssertion }
