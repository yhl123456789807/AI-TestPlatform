/**
 * Captcha OCR on the live Chromium page via CDP (same browser as playwright-cli).
 * Uses data-URI / element screenshot vision OCR — does not open a second browser.
 * Must not call browser.close().
 *
 * stdin JSON: { cdpEndpoint, modelConfig?, timeoutMs?, preferMidscene? }
 * stdout: RAINAHUB_RESULT { ok, text?, error? }
 */
import { chromium } from 'playwright';
import { resolveCaptchaCode } from './captcha_ocr.mjs';

const RESULT_PREFIX = 'RAINAHUB_RESULT ';
const LOG_PREFIX = 'RAINAHUB_LOG ';

function emit(payload) {
  process.stdout.write(`${RESULT_PREFIX}${JSON.stringify(payload)}\n`);
}

function log(message) {
  process.stdout.write(
    `${LOG_PREFIX}${JSON.stringify({ message: String(message || '').slice(0, 500) })}\n`,
  );
}

async function readStdin() {
  const chunks = [];
  for await (const chunk of process.stdin) chunks.push(chunk);
  return Buffer.concat(chunks).toString('utf8').trim();
}

function applyModelEnv(modelConfig = {}) {
  const base = modelConfig.MIDSCENE_MODEL_BASE_URL || '';
  const key = modelConfig.MIDSCENE_MODEL_API_KEY || '';
  const name = modelConfig.MIDSCENE_MODEL_NAME || '';
  if (base) process.env.MIDSCENE_MODEL_BASE_URL = base;
  if (key) process.env.MIDSCENE_MODEL_API_KEY = key;
  if (name) process.env.MIDSCENE_MODEL_NAME = name;
}

const raw = await readStdin();
let job;
try {
  job = JSON.parse(raw || '{}');
} catch (ex) {
  emit({ ok: false, error: `任务 JSON 无法解析: ${ex.message || ex}` });
  process.exit(1);
}

const cdpEndpoint = String(job.cdpEndpoint || '').trim();
const timeoutMs = Number(job.timeoutMs) || 30000;
const preferMidscene = job.preferMidscene === true;
const modelConfig =
  job.modelConfig && typeof job.modelConfig === 'object' ? job.modelConfig : {};

if (!cdpEndpoint) {
  emit({ ok: false, error: '缺少 cdpEndpoint' });
  process.exit(1);
}

applyModelEnv(modelConfig);

let browser;
try {
  log(`CDP 同页验证码 OCR ${cdpEndpoint}`);
  browser = await chromium.connectOverCDP(cdpEndpoint);
  const contexts = browser.contexts();
  if (!contexts.length) throw new Error('CDP 浏览器没有 context');
  const pages = contexts[0].pages();
  if (!pages.length) throw new Error('CDP 浏览器没有打开的页面');
  const page = pages[pages.length - 1];
  page.setDefaultTimeout(timeoutMs);

  const text = await resolveCaptchaCode(page, {
    preferMidscene,
    timeoutMs,
    modelConfig,
    env: process.env,
  });
  const code = String(text || '').trim();
  if (!code) throw new Error('captcha ocr empty');
  const masked =
    code.length > 2 ? `${code.slice(0, 2)}${'*'.repeat(code.length - 2)}` : '**';
  log(`同页验证码 OCR 完成：${masked}`);
  emit({ ok: true, text: code, error: '' });
  process.exit(0);
} catch (err) {
  emit({ ok: false, error: String(err?.message || err).slice(0, 2000) });
  process.exit(1);
}
