/**
 * Captcha OCR for Midscene / Playwright explore (CDP same-browser path).
 * Prefer Midscene aiQuery on a Playwright Page; fallback to element data-URI + vision OCR.
 */

export const CAPTCHA_OCR_PROMPT =
  '只读取验证码图片中的字符；忽略输入框已有文字与背景噪点；' +
  '只输出字符本身，不要引号空格或解释';

export const CAPTCHA_OCR_PROMPT_SHORT = '只输出验证码字符';

const MIN_DATA_URI_B64_LEN = 500;
const CAPTCHA_WAIT_TIMEOUT_MS = 15000;
const CAPTCHA_POLL_MS = 500;

export function stripCaptchaText(raw) {
  const cleaned = String(raw || '')
    .replace(/[^a-zA-Z0-9]/g, '')
    .trim();
  if (cleaned.length < 3 || cleaned.length > 8) return '';
  return cleaned;
}

/** Flatten multimodal / string message content. */
export function flattenContent(content) {
  if (content == null) return '';
  if (typeof content === 'string') return content;
  if (Array.isArray(content)) {
    return content
      .map((p) => (typeof p === 'string' ? p : p?.text || p?.content || ''))
      .join('');
  }
  if (typeof content === 'object' && content.text) return String(content.text);
  return String(content);
}

/** Pull readable text from OpenAI-compatible chat completion JSON. */
export function extractModelText(json) {
  const choice = json?.choices?.[0];
  const msg = choice?.message || {};
  const candidates = [
    flattenContent(msg.content),
    flattenContent(msg.reasoning_content),
    flattenContent(choice?.text),
    flattenContent(json?.output_text),
  ];
  for (const c of candidates) {
    const t = String(c || '').trim();
    if (t) return t;
  }
  return '';
}

export function isReadyCaptchaDataUrl(src) {
  const s = String(src || '').trim();
  if (!s.startsWith('data:image/')) return false;
  const comma = s.indexOf(',');
  if (comma < 0) return false;
  return s.slice(comma + 1).length >= MIN_DATA_URI_B64_LEN;
}

/** Very rough near-white check on PNG bytes (skip tiny/corrupt). */
export function isNearWhitePng(buf) {
  if (!Buffer.isBuffer(buf) || buf.length < 100) return true;
  if (buf.length < 200) return true;
  let whiteish = 0;
  let samples = 0;
  for (let i = 32; i < buf.length; i += 17) {
    samples += 1;
    if (buf[i] > 0xe8) whiteish += 1;
  }
  return samples > 0 && whiteish / samples > 0.92;
}

export function modelEnvFromProcess(env = process.env) {
  return {
    baseUrl: String(env.MIDSCENE_MODEL_BASE_URL || '')
      .trim()
      .replace(/\/$/, ''),
    apiKey: String(env.MIDSCENE_MODEL_API_KEY || '').trim(),
    model: String(env.MIDSCENE_MODEL_NAME || '').trim(),
  };
}

export function midsceneModelConfigFromEnv(env = process.env) {
  const { baseUrl, apiKey, model } = modelEnvFromProcess(env);
  const cfg = {};
  if (baseUrl) cfg.MIDSCENE_MODEL_BASE_URL = baseUrl;
  if (apiKey) cfg.MIDSCENE_MODEL_API_KEY = apiKey;
  if (model) cfg.MIDSCENE_MODEL_NAME = model;
  return cfg;
}

/** Real Playwright Page: locator + screenshot/context. */
export function isPlaywrightPage(x) {
  if (!x || typeof x.locator !== 'function') return false;
  return typeof x.screenshot === 'function' || typeof x.context === 'function';
}

/**
 * Resolve a usable Playwright Page.
 * - Playwright Browser → first context's last page
 * - Playwright Page → return as-is
 */
export function playwrightPageFromBrowser(browser) {
  if (isPlaywrightPage(browser)) {
    return browser;
  }
  const ctx =
    (typeof browser?.contexts === 'function' ? browser.contexts()?.[0] : null) ||
    (typeof browser?.context === 'function' ? browser.context() : null) ||
    null;
  if (!ctx) throw new Error('captcha ocr: no browser context');
  const pages = typeof ctx.pages === 'function' ? ctx.pages() : [];
  if (!pages?.length) throw new Error('captcha ocr: no page');
  return pages[pages.length - 1];
}

function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}

async function waitCaptchaImg(page, timeoutMs = CAPTCHA_WAIT_TIMEOUT_MS) {
  const loc = page.locator('.captcha-media img').first();
  await loc.waitFor({ state: 'visible', timeout: timeoutMs }).catch(() => {});
  return loc;
}

async function captureCaptchaDataUrlFromPage(page) {
  const loc = await waitCaptchaImg(page);
  const deadline = Date.now() + CAPTCHA_WAIT_TIMEOUT_MS;
  while (Date.now() < deadline) {
    const count = await loc.count().catch(() => 0);
    if (count > 0) {
      const src = String((await loc.getAttribute('src')) || '').trim();
      if (isReadyCaptchaDataUrl(src)) return src;
      if (src.startsWith('data:image/')) {
        // small / still loading — keep waiting
      } else if (src) {
        try {
          const buf = await loc.screenshot({ type: 'png' });
          if (buf?.length >= 200) {
            return `data:image/png;base64,${Buffer.from(buf).toString('base64')}`;
          }
        } catch {
          /* keep waiting */
        }
      }
    }
    await sleep(CAPTCHA_POLL_MS);
  }

  const canvas = page.locator('canvas').first();
  if ((await canvas.count().catch(() => 0)) > 0) {
    const dataUrl = await canvas
      .evaluate((el) => {
        try {
          return el.toDataURL('image/png');
        } catch {
          return '';
        }
      })
      .catch(() => '');
    if (isReadyCaptchaDataUrl(dataUrl)) return dataUrl;
    const buf = await canvas.screenshot({ type: 'png' }).catch(() => null);
    if (buf?.length) {
      return `data:image/png;base64,${Buffer.from(buf).toString('base64')}`;
    }
  }

  throw new Error('captcha ocr: no captcha image/canvas found');
}

export async function captureCaptchaDataUrl(target, opts = {}) {
  const page = playwrightPageFromBrowser(target);
  return captureCaptchaDataUrlFromPage(page);
}

export async function ocrCaptchaFromDataUrl(
  dataUrl,
  env = process.env,
  fetchImpl = fetch,
  opts = {},
) {
  const url = String(dataUrl || '').trim();
  if (!url.startsWith('data:image/')) {
    throw new Error('captcha ocr: expected data:image URL');
  }

  const { baseUrl, apiKey, model } = modelEnvFromProcess(env);
  if (!baseUrl || !model) {
    throw new Error('captcha ocr: missing MIDSCENE_MODEL_BASE_URL / MIDSCENE_MODEL_NAME');
  }
  const prompt = opts.prompt || CAPTCHA_OCR_PROMPT;
  const endpoint = `${baseUrl}/chat/completions`;
  const res = await fetchImpl(endpoint, {
    method: 'POST',
    headers: {
      'content-type': 'application/json',
      ...(apiKey ? { authorization: `Bearer ${apiKey}` } : {}),
    },
    body: JSON.stringify({
      model,
      temperature: 0,
      max_tokens: 256,
      messages: [
        {
          role: 'user',
          content: [
            { type: 'text', text: prompt },
            { type: 'image_url', image_url: { url, detail: 'high' } },
          ],
        },
      ],
    }),
  });
  if (!res.ok) {
    const body = await res.text().catch(() => '');
    throw new Error(`captcha ocr http ${res.status}: ${body.slice(0, 200)}`);
  }
  const json = await res.json();
  const text = extractModelText(json);
  const code = stripCaptchaText(text);
  if (!code) {
    const raw = String(text || '').replace(/\s+/g, ' ').trim().slice(0, 120);
    throw new Error(
      raw
        ? `captcha ocr: empty model response: ${JSON.stringify(raw)}`
        : 'captcha ocr: empty model response',
    );
  }
  return code;
}

/**
 * Midscene aiQuery on a Playwright Page (injectable for tests).
 */
export async function ocrCaptchaViaMidscene(page, opts = {}) {
  const env = opts.env || process.env;
  const prompt = opts.prompt || CAPTCHA_OCR_PROMPT;
  const AgentCtor = opts.PlaywrightAgent;
  let Agent = AgentCtor;
  if (!Agent) {
    const mod = await import('@midscene/web/playwright');
    Agent = mod.PlaywrightAgent;
  }
  if (!Agent) throw new Error('captcha ocr: PlaywrightAgent unavailable');
  const modelConfig = opts.modelConfig || midsceneModelConfigFromEnv(env);
  const agent = new Agent(page, {
    modelConfig,
    generateReport: false,
    autoPrintReportMsg: false,
    replanningCycleLimit: 4,
  });
  const raw = await agent.aiQuery(prompt);
  const code = stripCaptchaText(raw);
  if (!code) throw new Error('captcha ocr: Midscene aiQuery empty');
  return code;
}

async function refreshCaptcha(page) {
  const btn = page.getByRole?.('button', { name: /换一张|刷新验证码|刷新/ });
  if (btn && (await btn.count().catch(() => 0)) > 0) {
    await btn.first().click();
    await sleep(400);
    return;
  }
  const media = page.locator?.('.captcha-media img, .captcha-media')?.first?.();
  if (media && (await media.count().catch(() => 0)) > 0) {
    await media.click().catch(() => {});
    await sleep(400);
  }
}

async function ocrDataUrlWithPromptRetry(dataUrl, env, fetchImpl) {
  try {
    return await ocrCaptchaFromDataUrl(dataUrl, env, fetchImpl, {
      prompt: CAPTCHA_OCR_PROMPT,
    });
  } catch (err) {
    if (!String(err?.message || err).includes('empty model response')) {
      throw err;
    }
    return ocrCaptchaFromDataUrl(dataUrl, env, fetchImpl, {
      prompt: CAPTCHA_OCR_PROMPT_SHORT,
    });
  }
}

/**
 * Resolve captcha text from a Playwright Page / Browser.
 * Midscene when target is a Page; otherwise data-URI vision OCR.
 */
export async function resolveCaptchaCode(target, opts = {}) {
  const maxAttempts = Math.max(1, Number(opts.maxAttempts) || 2);
  const env = opts.env || process.env;
  const fetchImpl = opts.fetch || fetch;
  const page = playwrightPageFromBrowser(target);
  const preferMidscene = opts.preferMidscene !== false && isPlaywrightPage(page);
  let lastErr;

  for (let i = 0; i < maxAttempts; i++) {
    if (preferMidscene) {
      try {
        return await ocrCaptchaViaMidscene(page, { ...opts, env });
      } catch (err) {
        lastErr = err;
      }
    }
    try {
      const dataUrl = await captureCaptchaDataUrl(page, opts);
      return await ocrDataUrlWithPromptRetry(dataUrl, env, fetchImpl);
    } catch (err) {
      lastErr = err;
    }
    if (i + 1 < maxAttempts) {
      await refreshCaptcha(page);
    }
  }
  throw lastErr || new Error('captcha ocr failed');
}
