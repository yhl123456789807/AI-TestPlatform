"""API routes for UI case script edit agent (multi-turn LLM revise + confirm)."""

from __future__ import annotations

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.deps import get_current_user, get_db, require_project_role
from app.errors import AppError
from app.models.identity.user import User
from app.models.project.project import ProjectMember
from app.models.ui_automation.ui_automation import UiCaseEditAgentSession
from app.schemas.ui_automation.ui_case_edit_agent import (
    UiCaseEditAgentConfirm,
    UiCaseEditAgentMessage,
    UiCaseEditAgentSessionCreate,
    UiCaseEditAgentSessionOut,
    UiCaseEditAgentSessionSummary,
)
from app.services.api_automation.api_scenario_events import get_event_bus
from app.services.ui_automation import ui_case_edit_agent as svc

router = APIRouter(
    prefix="/projects/{project_id}/ui-case-edit-agent",
    tags=["ui-case-edit-agent"],
)


def _session_out(row: UiCaseEditAgentSession) -> UiCaseEditAgentSessionOut:
    case_ids = row.case_ids_json if isinstance(row.case_ids_json, list) else []
    applied = row.applied_case_ids_json if isinstance(row.applied_case_ids_json, list) else []
    messages = row.messages_json if isinstance(row.messages_json, list) else []
    events = row.events_json if isinstance(row.events_json, list) else []
    snapshots = row.base_snapshots_json if isinstance(row.base_snapshots_json, list) else []
    live = get_event_bus().snapshot(row.thread_id)
    if live:
        events = live
    return UiCaseEditAgentSessionOut(
        id=row.id,
        project_id=row.project_id,
        user_id=row.user_id,
        thread_id=row.thread_id,
        status=row.status,
        prompt=row.prompt or "",
        case_ids=[int(x) for x in case_ids],
        base_snapshots=[s for s in snapshots if isinstance(s, dict)],
        messages=[
            {"role": str(m.get("role", "")), "content": str(m.get("content", ""))}
            for m in messages
            if isinstance(m, dict)
        ],
        plan=row.plan_json if isinstance(row.plan_json, dict) else None,
        events=events,
        applied_case_ids=[int(x) for x in applied],
        error_message=row.error_message or "",
        created_at=row.created_at,
        updated_at=row.updated_at,
    )


def _require_session(
    db: Session,
    project_id: int,
    session_id: int,
    user_id: int | None = None,
) -> UiCaseEditAgentSession:
    q = db.query(UiCaseEditAgentSession).filter(
        UiCaseEditAgentSession.id == session_id,
        UiCaseEditAgentSession.project_id == project_id,
    )
    if user_id is not None:
        q = q.filter(UiCaseEditAgentSession.user_id == user_id)
    row = q.first()
    if row is None:
        raise AppError("not_found", "用例修订会话不存在", status_code=404)
    return row


@router.get("/sessions", response_model=list[UiCaseEditAgentSessionSummary])
def list_sessions(
    project_id: int,
    db: Session = Depends(get_db),
    _: ProjectMember = Depends(require_project_role("editor")),
    user: User = Depends(get_current_user),
) -> list[UiCaseEditAgentSessionSummary]:
    rows = (
        db.query(UiCaseEditAgentSession)
        .filter(
            UiCaseEditAgentSession.project_id == project_id,
            UiCaseEditAgentSession.user_id == user.id,
        )
        .order_by(UiCaseEditAgentSession.id.desc())
        .all()
    )
    out: list[UiCaseEditAgentSessionSummary] = []
    for r in rows:
        case_ids = r.case_ids_json if isinstance(r.case_ids_json, list) else []
        out.append(
            UiCaseEditAgentSessionSummary(
                id=r.id,
                title=svc.session_title(r.prompt or "", [int(x) for x in case_ids]),
                status=r.status or "running",
                updated_at=r.updated_at,
                message_count=len(r.messages_json) if isinstance(r.messages_json, list) else 0,
                case_count=len(case_ids),
            )
        )
    return out


@router.post("/sessions", response_model=UiCaseEditAgentSessionOut, status_code=201)
def create_session(
    project_id: int,
    body: UiCaseEditAgentSessionCreate,
    db: Session = Depends(get_db),
    _: ProjectMember = Depends(require_project_role("editor")),
    user: User = Depends(get_current_user),
) -> UiCaseEditAgentSessionOut:
    row = svc.create_session(
        db,
        project_id=project_id,
        user_id=user.id,
        case_ids=body.case_ids,
        prompt=body.prompt,
    )
    return _session_out(row)


@router.get("/sessions/{session_id}", response_model=UiCaseEditAgentSessionOut)
def get_session(
    project_id: int,
    session_id: int,
    db: Session = Depends(get_db),
    _: ProjectMember = Depends(require_project_role("viewer")),
    user: User = Depends(get_current_user),
) -> UiCaseEditAgentSessionOut:
    return _session_out(_require_session(db, project_id, session_id, user_id=user.id))


@router.delete("/sessions/{session_id}", status_code=204)
def delete_session(
    project_id: int,
    session_id: int,
    db: Session = Depends(get_db),
    _: ProjectMember = Depends(require_project_role("editor")),
    user: User = Depends(get_current_user),
) -> None:
    row = _require_session(db, project_id, session_id, user_id=user.id)
    get_event_bus().replace(row.thread_id, [])
    db.delete(row)
    db.commit()


@router.post("/sessions/{session_id}/messages", response_model=UiCaseEditAgentSessionOut)
def post_message(
    project_id: int,
    session_id: int,
    body: UiCaseEditAgentMessage,
    db: Session = Depends(get_db),
    _: ProjectMember = Depends(require_project_role("editor")),
    user: User = Depends(get_current_user),
) -> UiCaseEditAgentSessionOut:
    row = _require_session(db, project_id, session_id, user_id=user.id)
    return _session_out(svc.apply_message(db, row, body.content))


@router.post("/sessions/{session_id}/confirm", response_model=UiCaseEditAgentSessionOut)
def confirm_session(
    project_id: int,
    session_id: int,
    body: UiCaseEditAgentConfirm,
    db: Session = Depends(get_db),
    _: ProjectMember = Depends(require_project_role("editor")),
    user: User = Depends(get_current_user),
) -> UiCaseEditAgentSessionOut:
    row = _require_session(db, project_id, session_id, user_id=user.id)
    drafts = None
    if body.drafts:
        drafts = [
            {"case_id": d.case_id, "draft_script": d.draft_script} for d in body.drafts
        ]
    return _session_out(
        svc.confirm_session(
            db,
            row,
            action=body.action,
            case_ids=body.case_ids,
            drafts=drafts,
        )
    )
