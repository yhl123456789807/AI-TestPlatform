import json
import logging
import re
from collections.abc import Iterator
from typing import Any

from fastapi import APIRouter, Depends
from fastapi.responses import StreamingResponse
from sqlalchemy.orm import Session, selectinload

from app.api.functional.testcases import _case_to_out
from app.deps import SessionLocal, get_current_user, get_db, require_project_role
from app.errors import AppError
from app.models.project.project import ProjectMember
from app.models.functional.requirement import Requirement
from app.models.functional.testcase import TestCase, TestCaseStep
from app.models.identity.user import User
from app.schemas.ai.ai_gen import (
    AiConfirmRequest,
    AiGenerateRequest,
    AiGenerateResponse,
    ChatMessage,
    GeneratedCase,
    LlmOptionsOut,
)
from app.schemas.functional.testcase import TestCaseOut, clean_case_type, clean_precondition
from app.services.ai import llm
from app.services.ai.ai_case_common import (
    cases_and_indexes_from_llm_raw,
    content_with_images,
    format_assistant_message,
    trim_chat_messages,
)
from app.services.ai.embedding import MAX_EMBEDDING_INPUT_CHARS
from app.services.ai.ai_gen_pipeline import (
    format_agent_done_message,
    iter_case_review,
    run_agent_pipeline,
    run_agent_pipeline_resume_cases,
)
from app.services.ai.case_review_dims import normalize_review_dims
from app.services.ai.effective_ai_settings import describe_key_resolution, get_llm_runtime
from app.services.knowledge.rag_retrieval import rag_search_hits, upload_document_ids_for_library
from app.services.functional.requirement_content import (
    requirement_assets_for_ai,
    requirement_text_for_ai,
    usable_requirement_text,
)
from app.services.functional.test_data_vars import parse_test_data_text
from app.tasks.knowledge.reindex_entity import enqueue_reindex
from app.user_messages import (
    LLM_MODEL_NOT_CONFIGURED,
    REQUIREMENT_NOT_IN_PROJECT,
    llm_model_invalid_detail,
)

log = logging.getLogger(__name__)

router = APIRouter(prefix="/projects/{project_id}/ai", tags=["ai"])

STEP_EXPECTED_PLACEHOLDER = "—"

RAG_TOP_K_FOR_GENERATE = 12
MAX_REQUIREMENT_CHARS_FOR_LLM = 12000
MAX_RAG_CONTEXT_CHARS = 8000


def _llm_model_allowlist(db: Session) -> set[str]:
    rt = get_llm_runtime(db)
    raw = rt.allowed_models_csv or ""
    parts = [p.strip() for p in raw.split(",") if p.strip()]
    default = (rt.model or "").strip()
    if not default:
        return set(parts)
    if not parts:
        return {default}
    return set(parts) | {default}


def _resolve_generate_llm_model(db: Session, requested: str | None) -> str:
    allow = _llm_model_allowlist(db)
    if not allow:
        raise AppError("bad_request", LLM_MODEL_NOT_CONFIGURED, status_code=400)
    if requested is None or not str(requested).strip():
        rt = get_llm_runtime(db)
        return (rt.model or "").strip() or next(iter(sorted(allow)))
    name = str(requested).strip()
    if name not in allow:
        allowed_list = ", ".join(sorted(allow))
        raise AppError(
            "bad_request",
            llm_model_invalid_detail(allowed_list),
            status_code=400,
        )
    return name


def _validate_requirement_project(db: Session, project_id: int, requirement_id: int | None) -> None:
    if requirement_id is None:
        return
    r = db.get(Requirement, requirement_id)
    if r is None or r.project_id != project_id:
        raise AppError("bad_request", REQUIREMENT_NOT_IN_PROJECT, status_code=400)


def _normalize_chat_messages(body: AiGenerateRequest) -> list[ChatMessage]:
    if body.messages:
        valid = [m for m in body.messages if m.content.strip()]
        if valid:
            return list(valid)
    if body.user_notes and body.user_notes.strip():
        return [ChatMessage(role="user", content=body.user_notes.strip())]
    if body.requirement_id is not None:
        return [ChatMessage(role="user", content="根据所选需求文档生成测试用例")]
    return [ChatMessage(role="user", content="根据项目知识库生成测试用例")]


def _requirement_prompt_text(r: Requirement) -> str:
    raw = usable_requirement_text(requirement_text_for_ai(r))
    if len(raw) <= MAX_REQUIREMENT_CHARS_FOR_LLM:
        return raw
    return raw[:MAX_REQUIREMENT_CHARS_FOR_LLM] + "\n（需求过长已截断）"


def _truncate_log(text: str, max_len: int = 300) -> str:
    one_line = text.replace("\n", "\\n")
    if len(one_line) <= max_len:
        return one_line
    return f"{one_line[:max_len]}…"


def _load_requirement_for_generate(
    db: Session, project_id: int, requirement_id: int | None
) -> tuple[Requirement | None, list[tuple[str, bytes]]]:
    if requirement_id is None:
        return None, []
    r = (
        db.query(Requirement)
        .options(selectinload(Requirement.attachments))
        .filter(Requirement.id == requirement_id)
        .first()
    )
    if r is None or r.project_id != project_id:
        raise AppError("bad_request", REQUIREMENT_NOT_IN_PROJECT, status_code=400)
    _text, images = requirement_assets_for_ai(r)
    return r, images


def _inject_requirement_content(
    db: Session,
    project_id: int,
    body: AiGenerateRequest,
    chat_messages: list[ChatMessage],
) -> list[ChatMessage]:
    if body.requirement_id is None:
        return chat_messages
    r, _images = _load_requirement_for_generate(db, project_id, body.requirement_id)
    assert r is not None
    body_md = _requirement_prompt_text(r) or "(空)"
    req_block = f"需求标题: {r.title}\n需求正文:\n{body_md}"
    log.info(
        "用例生成注入需求 项目=%s 需求=%s 标题=%s 正文长度=%d",
        project_id,
        body.requirement_id,
        r.title,
        len(body_md),
    )
    if not chat_messages:
        return [
            ChatMessage(
                role="user",
                content=f"{req_block}\n\n请根据上述需求文档生成测试用例。",
            )
        ]
    first = chat_messages[0]
    if body.user_notes and body.user_notes.strip():
        content = f"{req_block}\n\n用户补充说明:\n{first.content}"
    elif first.content == "根据所选需求文档生成测试用例":
        content = f"{req_block}\n\n请根据上述需求文档生成测试用例。"
    else:
        content = f"{req_block}\n\n{first.content}"
    return [ChatMessage(role="user", content=content)] + list(chat_messages[1:])


def _last_user_message(chat_messages: list[ChatMessage]) -> str:
    for m in reversed(chat_messages):
        if m.role == "user":
            return m.content.strip()
    return chat_messages[-1].content.strip() if chat_messages else ""


def _build_retrieval_query(
    db: Session,
    project_id: int,
    body: AiGenerateRequest,
    chat_messages: list[ChatMessage],
) -> str:
    parts: list[str] = []
    raw_messages = list(body.messages or [])
    last_user = _last_user_message(raw_messages)
    if not last_user and body.user_notes:
        last_user = body.user_notes.strip()
    if last_user:
        parts.append(last_user[:400])
    if body.requirement_id is not None:
        r, _images = _load_requirement_for_generate(db, project_id, body.requirement_id)
        assert r is not None
        body_md = usable_requirement_text(requirement_text_for_ai(r), max_chars=1200)
        parts.insert(0, f"需求标题: {r.title}\n需求正文:\n{body_md or '(空)'}")
    query = "\n\n".join(parts) if parts else "根据项目知识库生成测试用例"
    return query[:MAX_EMBEDDING_INPUT_CHARS]


def _system_prompt() -> str:
    return (
        "你是测试工程师。根据用户说明、对话历史与检索到的项目片段，设计测试用例。"
        "需求中若有编号验收标准，每条验收标准至少由一条用例覆盖，并在用例 acceptance_refs 数组中写入编号。"
        "综合使用等价类、边界值、异常路径和权限路径；每个功能点生成 2–5 条，整体不超过 40 条，优先 P0/P1。"
        "若提供了当前用例草稿，且用户要求补充、修改或删除，请输出修订后的完整 cases 列表（不是增量）；"
        "未要求改动的条目保持原意。"
        "只输出一个 JSON 对象，格式为 {\"cases\": [...]}。"
        "每个元素含 title、overall_expected（整条用例的总体期望，必填）、"
        "module（所属功能模块，字符串，可省略）、"
        "case_type（功能、边界、异常、权限之一，无法归类时用功能）、"
        "precondition（执行前需满足的条件，没有则空字符串）、"
        "test_data（步骤要用的具体输入，写成键值文本，如账号、密码、金额、边界值；没有则空字符串）、"
        "acceptance_refs（对应验收标准编号的字符串数组，没有则空数组）、"
        "priority（建议填写 P0、P1、P2、P3 或 P4 之一）、"
        "steps（数组，每项仅含 order、action，不要逐步 expected）。"
        "不要输出 Markdown 或其它说明文字。"
    )


def _is_revision_turn(body: AiGenerateRequest) -> bool:
    return bool(body.current_drafts) and body.agent_resume_from != "cases"


def _matching_cached_context(body: AiGenerateRequest) -> str | None:
    cached = body.cached_rag
    if cached is None or not cached.context.strip():
        return None
    if cached.requirement_id != body.requirement_id:
        return None
    if cached.knowledge_library_id != body.knowledge_library_id:
        return None
    return cached.context[:MAX_RAG_CONTEXT_CHARS]


def _review_issues_block(body: AiGenerateRequest) -> str | None:
    review = body.last_review
    if review is None or not review.issues:
        return None
    lines = ["上一轮评审问题（请逐条处理，再输出修订后的完整 cases 列表）："]
    for issue in review.issues:
        title = issue.case_title.strip() or "未指定用例"
        kind = issue.issue_type.strip() or "未分类"
        detail = issue.detail.strip() or "无具体说明"
        lines.append(f"- [{kind}] {title}：{detail}")
    if review.summary.strip():
        lines.append(f"评审摘要：{review.summary.strip()}")
    return "\n".join(lines)


def _drafts_block(current_drafts: list[GeneratedCase] | None) -> str | None:
    if not current_drafts:
        return None
    payload = [c.model_dump(exclude_none=True, exclude_defaults=True) for c in current_drafts]
    return "当前用例草稿（请按用户最新要求修订后，输出完整 cases 列表）：\n" + json.dumps(
        payload, ensure_ascii=False, separators=(",", ":")
    )


def _build_llm_messages(
    context: str,
    chat_messages: list[ChatMessage],
    current_drafts: list[GeneratedCase] | None = None,
    images: list[tuple[str, bytes]] | None = None,
    review_issues: str | None = None,
) -> list[dict[str, Any]]:
    chat_messages = trim_chat_messages(chat_messages)
    messages: list[dict[str, Any]] = [{"role": "system", "content": _system_prompt()}]
    if not chat_messages:
        first_text = f"检索上下文：\n{context}\n\n请生成若干条高质量测试用例。"
    else:
        first = chat_messages[0]
        first_text = f"检索上下文：\n{context}\n\n{first.content}"
    messages.append({"role": "user", "content": content_with_images(first_text, images)})
    if chat_messages:
        for m in chat_messages[1:]:
            messages.append({"role": m.role, "content": m.content})
    if review_issues:
        messages.append({"role": "user", "content": review_issues})
    drafts_text = _drafts_block(current_drafts)
    if drafts_text:
        messages.append({"role": "user", "content": drafts_text})
    closing = '请输出 JSON 对象 {"cases":[...]}，不要 Markdown。'
    if current_drafts:
        closing = (
            '请输出修订后的完整 JSON 对象 {"cases":[...]}，不要 Markdown。'
            "每条用例必须带 draft_index：沿用原草稿则填其从 0 开始的下标；"
            "新增用例填 null。删除的原草稿不要出现在列表中。"
        )
    messages.append({"role": "user", "content": closing})
    return messages


def _sse_event(event_type: str, data: dict) -> str:
    payload = {"type": event_type, **data}
    return f"data: {json.dumps(payload, ensure_ascii=False)}\n\n"


def _validate_generate_request(
    db: Session,
    project_id: int,
    body: AiGenerateRequest,
) -> tuple[str, list[ChatMessage], list[tuple[str, bytes]], str | None]:
    rt = get_llm_runtime(db)
    has_key = bool(rt.api_key.strip())
    key_diag = describe_key_resolution(db)
    raw_msg_count = len(body.messages) if body.messages else 0
    mode_label = "分步" if body.generate_mode == "agent" else "快速"
    log.info(
        "用例生成开始 项目=%s 需求=%s 知识库=%s 模式=%s 消息数=%d 请求模型=%s 已配置密钥=%s API地址=%s 密钥诊断=%s",
        project_id,
        body.requirement_id,
        body.knowledge_library_id,
        mode_label,
        raw_msg_count,
        body.llm_model,
        has_key,
        rt.api_base,
        key_diag,
    )
    if not has_key:
        raise AppError(
            "bad_request",
            "未配置 LLM API Key，请在系统 AI 配置或 .env 中设置",
            status_code=400,
        )
    use_llm_model = _resolve_generate_llm_model(db, body.llm_model)
    req, images = _load_requirement_for_generate(db, project_id, body.requirement_id)
    requirement_text = _requirement_prompt_text(req) if req is not None else None
    chat_messages = _normalize_chat_messages(body)
    chat_messages = _inject_requirement_content(db, project_id, body, chat_messages)
    user_preview = _truncate_log(_last_user_message(chat_messages), 200)
    log.info(
        "用例生成用户消息 项目=%s 长度=%d 预览=%s 附图=%d",
        project_id,
        len(_last_user_message(chat_messages)),
        user_preview,
        len(images),
    )
    return use_llm_model, chat_messages, images, requirement_text


def _fetch_rag_context(
    db: Session,
    project_id: int,
    body: AiGenerateRequest,
    chat_messages: list[ChatMessage],
) -> tuple[str, list]:
    query = _build_retrieval_query(db, project_id, body, chat_messages)
    upload_filter: list[int] | None = None
    hits = []
    if body.knowledge_library_id is not None:
        upload_filter = upload_document_ids_for_library(
            db, project_id, body.knowledge_library_id
        )
        hits = rag_search_hits(
            db,
            project_id,
            query,
            RAG_TOP_K_FOR_GENERATE,
            upload_document_ids=upload_filter,
        )
    query_preview = (query[:200] + "…") if len(query) > 200 else query
    log.info(
        "用例生成检索 项目=%s 命中=%d 文档过滤=%s 查询长度=%d 查询预览=%s",
        project_id,
        len(hits),
        upload_filter if upload_filter is not None else "未使用",
        len(query),
        query_preview,
    )
    context_blocks: list[str] = []
    seen_text: set[str] = set()
    used_chars = 0
    for h in hits:
        text = h.text.strip()
        if not text or text in seen_text:
            continue
        block = f"[{h.title_resolved}]\n{text}"
        separator_len = 7 if context_blocks else 0
        remaining = MAX_RAG_CONTEXT_CHARS - used_chars - separator_len
        if remaining <= 0:
            break
        if len(block) > remaining:
            block = block[:remaining]
        context_blocks.append(block)
        seen_text.add(text)
        used_chars += len(block) + separator_len
    context = "\n\n---\n\n".join(context_blocks) if context_blocks else "(无检索片段)"
    return context, hits


def _iter_fast_generate_stream_events(
    *,
    project_id: int,
    context: str,
    chat_messages: list[ChatMessage],
    use_llm_model: str,
    llm_cfg,
    current_drafts: list[GeneratedCase] | None = None,
    enable_case_review: bool = False,
    review_dimensions: list | None = None,
    images: list[tuple[str, bytes]] | None = None,
    requirement_text: str | None = None,
    stream_llm: bool = True,
    review_issues: str | None = None,
    skip_review: bool = False,
) -> Iterator[str]:
    messages = _build_llm_messages(
        context,
        chat_messages,
        current_drafts,
        images=images,
        review_issues=review_issues,
    )
    log.info(
        "用例生成调用大模型 模式=快速 模型=%s 上下文长度=%d 对话轮数=%d 消息数=%d",
        use_llm_model,
        len(context),
        len(chat_messages),
        len(messages),
    )
    yield _sse_event("log", {"level": "info", "message": "开始调用模型生成用例"})
    yield _sse_event("status", {"message": "正在生成用例…"})

    raw = ""
    try:
        if stream_llm:
            for delta in llm.chat_complete_stream(
                messages, model=use_llm_model, cfg=llm_cfg, scene="用例生成"
            ):
                raw += delta
                yield _sse_event("delta", {"content": delta})
        else:
            raw = llm.chat_complete(
                messages, model=use_llm_model, cfg=llm_cfg, scene="用例生成"
            )
    except Exception:
        log.exception(
            "用例生成大模型流式调用失败 项目=%s 模型=%s 上下文长度=%d",
            project_id,
            use_llm_model,
            len(context),
        )
        raise

    raw_stripped = raw.strip()
    if not raw_stripped:
        log.warning(
            "用例生成大模型返回空响应 项目=%s 模型=%s 上下文长度=%d",
            project_id,
            use_llm_model,
            len(context),
        )

    cases, draft_indexes = cases_and_indexes_from_llm_raw(
        raw,
        messages,
        use_llm_model=use_llm_model,
        llm_cfg=llm_cfg,
        keep_draft_index=bool(current_drafts),
    )
    yield _sse_event(
        "log",
        {"level": "success", "message": f"模型生成完成，共 {len(cases)} 条用例草稿"},
    )
    dims = [] if skip_review else normalize_review_dims(review_dimensions, enable=enable_case_review)
    review_result = None
    if skip_review:
        yield _sse_event("log", {"level": "info", "message": "修改轮已跳过自动评审"})
    if dims:
        for event in iter_case_review(
            draft_cases=cases,
            dims=dims,
            use_llm_model=use_llm_model,
            llm_cfg=llm_cfg,
            context=context,
            requirement_text=requirement_text,
        ):
            event_type = event.get("type")
            if event_type == "review_done":
                cases = event["cases"]
                review_result = event.get("review")
                continue
            payload = {k: v for k, v in event.items() if k != "type"}
            yield _sse_event(str(event_type), payload)

    if review_result is not None:
        assistant_message = format_agent_done_message(cases, review_result)
    else:
        assistant_message = format_assistant_message(
            cases, revised=bool(current_drafts)
        )
    if cases:
        log.info("用例生成完成 项目=%s 用例数=%d", project_id, len(cases))
    else:
        log.warning(
            "用例生成结果为空 项目=%s 模型=%s 原始响应长度=%d 预览=%s",
            project_id,
            use_llm_model,
            len(raw_stripped),
            _truncate_log(raw_stripped, 500) if raw_stripped else "(空)",
        )
    yield _sse_event(
        "log",
        {"level": "success", "message": f"生成流程完成，最终得到 {len(cases)} 条用例"},
    )
    done_payload: dict[str, Any] = {
        "cases": [c.model_dump() for c in cases],
        "assistant_message": assistant_message,
    }
    if current_drafts and not dims:
        done_payload["draft_indexes"] = draft_indexes
    yield _sse_event("done", done_payload)


def _agent_stream_events(
    *,
    context: str,
    chat_messages: list[ChatMessage],
    body: AiGenerateRequest,
    use_llm_model: str,
    llm_cfg,
    images: list[tuple[str, bytes]] | None = None,
    requirement_text: str | None = None,
) -> Iterator[dict[str, Any]]:
    if body.agent_resume_from == "cases":
        if body.agent_artifacts is None:
            raise AppError("bad_request", "续跑分步生成需携带 agent_artifacts", status_code=400)
        yield from run_agent_pipeline_resume_cases(
            context=context,
            artifacts_payload=body.agent_artifacts.model_dump(),
            use_llm_model=use_llm_model,
            llm_cfg=llm_cfg,
            enable_case_review=body.enable_case_review,
            review_dimensions=body.review_dimensions,
            requirement_text=requirement_text,
        )
        return
    yield from run_agent_pipeline(
        context=context,
        chat_messages=chat_messages,
        use_llm_model=use_llm_model,
        llm_cfg=llm_cfg,
        images=images,
    )


def _iter_agent_generate_stream_events(
    *,
    project_id: int,
    context: str,
    chat_messages: list[ChatMessage],
    body: AiGenerateRequest,
    use_llm_model: str,
    llm_cfg,
    images: list[tuple[str, bytes]] | None = None,
    requirement_text: str | None = None,
) -> Iterator[str]:
    resume_label = "续跑用例" if body.agent_resume_from == "cases" else "完整流程"
    log.info(
        "用例生成调用大模型 模式=分步(%s) 项目=%s 模型=%s 上下文长度=%d 对话轮数=%d 附图=%d",
        resume_label,
        project_id,
        use_llm_model,
        len(context),
        len(chat_messages),
        len(images or []),
    )
    for event in _agent_stream_events(
        context=context,
        chat_messages=chat_messages,
        body=body,
        use_llm_model=use_llm_model,
        llm_cfg=llm_cfg,
        images=images,
        requirement_text=requirement_text,
    ):
        event_type = event.pop("type")
        yield _sse_event(event_type, event)
        if event_type in ("clarification", "await_test_points_confirm", "done"):
            if event_type == "done":
                cases = event.get("cases") or []
                log.info("用例生成完成(分步) 项目=%s 用例数=%d", project_id, len(cases))
            return


def _iter_generate_stream_events(
    *,
    project_id: int,
    body: AiGenerateRequest,
    chat_messages: list[ChatMessage],
    use_llm_model: str,
    llm_cfg,
    images: list[tuple[str, bytes]] | None = None,
    requirement_text: str | None = None,
    stream_llm: bool = True,
    db_override: Session | None = None,
) -> Iterator[str]:
    yield _sse_event("status", {"message": "等待中…"})
    yield _sse_event("log", {"level": "info", "message": "开始处理用例生成请求"})
    db = db_override or SessionLocal()
    try:
        revision = _is_revision_turn(body)
        cached_context = _matching_cached_context(body) if revision else None
        if cached_context is not None:
            context, hits = cached_context, []
            yield _sse_event("log", {"level": "info", "message": "复用上一轮检索结果"})
        else:
            if body.knowledge_library_id is not None:
                yield _sse_event("status", {"message": "正在检索知识库…"})
            context, hits = _fetch_rag_context(db, project_id, body, chat_messages)
            if body.knowledge_library_id is not None:
                yield _sse_event(
                    "log",
                    {
                        "level": "success",
                        "message": f"知识库检索完成，命中 {len(hits)} 个片段",
                    },
                )
            else:
                yield _sse_event(
                    "log",
                    {"level": "info", "message": "未启用知识库检索"},
                )
        yield _sse_event(
            "rag_context",
            {
                "requirement_id": body.requirement_id,
                "knowledge_library_id": body.knowledge_library_id,
                "context": context,
            },
        )

        if body.generate_mode == "agent" and not revision:
            yield from _iter_agent_generate_stream_events(
                project_id=project_id,
                context=context,
                chat_messages=chat_messages,
                body=body,
                use_llm_model=use_llm_model,
                llm_cfg=llm_cfg,
                images=images,
                requirement_text=requirement_text,
            )
        else:
            yield from _iter_fast_generate_stream_events(
                project_id=project_id,
                context=context,
                chat_messages=chat_messages,
                use_llm_model=use_llm_model,
                llm_cfg=llm_cfg,
                current_drafts=body.current_drafts,
                enable_case_review=body.enable_case_review,
                review_dimensions=body.review_dimensions,
                images=images,
                requirement_text=requirement_text,
                stream_llm=stream_llm,
                review_issues=_review_issues_block(body) if revision else None,
                skip_review=revision,
            )
    except AppError as e:
        yield _sse_event("log", {"level": "error", "message": e.message})
        yield _sse_event("error", {"message": e.message})
    except Exception:
        log.exception("用例生成流式失败 项目=%s", project_id)
        yield _sse_event(
            "log",
            {"level": "error", "message": "用例生成失败，请稍后重试"},
        )
        yield _sse_event(
            "error",
            {"message": "用例生成失败，请稍后重试或查看 AI 调用日志"},
        )
    finally:
        if db_override is None:
            db.close()


@router.get("/llm-options", response_model=LlmOptionsOut)
def llm_options(
    project_id: int,
    db: Session = Depends(get_db),
    _: ProjectMember = Depends(require_project_role("viewer")),
) -> LlmOptionsOut:
    allow = _llm_model_allowlist(db)
    models = sorted(allow)
    rt = get_llm_runtime(db)
    default = (rt.model or "").strip()
    if default not in allow and models:
        default = models[0]
    return LlmOptionsOut(default_model=default or (models[0] if models else ""), models=models)


@router.post("/generate-testcases/stream")
def generate_testcases_stream(
    project_id: int,
    body: AiGenerateRequest,
    db: Session = Depends(get_db),
    _: ProjectMember = Depends(require_project_role("editor")),
) -> StreamingResponse:
    use_llm_model, chat_messages, images, requirement_text = _validate_generate_request(
        db, project_id, body
    )
    llm_cfg = get_llm_runtime(db)
    return StreamingResponse(
        _iter_generate_stream_events(
            project_id=project_id,
            body=body,
            chat_messages=chat_messages,
            use_llm_model=use_llm_model,
            llm_cfg=llm_cfg,
            images=images,
            requirement_text=requirement_text,
        ),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        },
    )


@router.post("/generate-testcases", response_model=AiGenerateResponse)
def generate_testcases(
    project_id: int,
    body: AiGenerateRequest,
    db: Session = Depends(get_db),
    _: ProjectMember = Depends(require_project_role("editor")),
) -> AiGenerateResponse:
    use_llm_model, chat_messages, images, requirement_text = _validate_generate_request(
        db, project_id, body
    )
    llm_cfg = get_llm_runtime(db)
    terminal: dict[str, Any] | None = None
    for chunk in _iter_generate_stream_events(
        project_id=project_id,
        body=body,
        chat_messages=chat_messages,
        use_llm_model=use_llm_model,
        llm_cfg=llm_cfg,
        images=images,
        requirement_text=requirement_text,
        stream_llm=False,
        db_override=db,
    ):
        payload = chunk.removeprefix("data: ").strip()
        if not payload:
            continue
        event = json.loads(payload)
        event_type = event.get("type")
        if event_type == "error":
            raise AppError(
                "bad_gateway",
                str(event.get("message") or "用例生成失败"),
                status_code=502,
            )
        if event_type in ("clarification", "await_test_points_confirm", "done"):
            terminal = event
    if terminal is None:
        return AiGenerateResponse(cases=[], assistant_message="生成流程未产出结果")
    cases = [GeneratedCase.model_validate(item) for item in terminal.get("cases") or []]
    return AiGenerateResponse(
        cases=cases,
        assistant_message=str(terminal.get("assistant_message") or format_assistant_message(cases)),
    )


@router.post("/confirm-testcases", response_model=list[TestCaseOut], status_code=201)
def confirm_testcases(
    project_id: int,
    body: AiConfirmRequest,
    db: Session = Depends(get_db),
    _: ProjectMember = Depends(require_project_role("editor")),
    user: User = Depends(get_current_user),
) -> list[TestCaseOut]:
    _validate_requirement_project(db, project_id, body.requirement_id)
    new_ids: list[int] = []
    requirement_filter = (
        TestCase.requirement_id == body.requirement_id
        if body.requirement_id is not None
        else TestCase.requirement_id.is_(None)
    )
    rows = (
        db.query(TestCase.title)
        .filter(TestCase.project_id == project_id, requirement_filter)
        .all()
    )
    existing_titles = {str(row[0]).strip().casefold() for row in rows}
    batch_titles: set[str] = set()
    for gc in body.cases:
        title_key = gc.title.strip().casefold()
        if title_key in existing_titles or title_key in batch_titles:
            continue
        batch_titles.add(title_key)
        td = clean_precondition(gc.test_data)
        parsed_vars = parse_test_data_text(td)
        priority_match = re.search(r"\bP([0-4])\b", (gc.priority or "").upper())
        priority = f"P{priority_match.group(1)}" if priority_match else "P2"
        tags = [
            f"验收:{ref.strip()}"
            for ref in gc.acceptance_refs
            if ref and ref.strip()
        ]
        c = TestCase(
            project_id=project_id,
            requirement_id=body.requirement_id,
            title=gc.title,
            module=(gc.module or "").strip() or None,
            precondition=clean_precondition(gc.precondition),
            test_data=td,
            variables_json=parsed_vars or None,
            case_type=clean_case_type(gc.case_type),
            overall_expected=(gc.overall_expected or "").strip(),
            priority=priority,
            status="draft",
            tags_json=tags or None,
            creator_id=user.id,
        )
        db.add(c)
        db.flush()
        new_ids.append(c.id)
        for order, st in enumerate(gc.steps, start=1):
            step_expected = (st.expected or "").strip() or STEP_EXPECTED_PLACEHOLDER
            db.add(
                TestCaseStep(
                    case_id=c.id,
                    order=order,
                    action=st.action,
                    expected=step_expected,
                )
            )
        enqueue_reindex(project_id, "case", c.id)
    db.commit()
    out: list[TestCaseOut] = []
    for cid in new_ids:
        c = (
            db.query(TestCase)
            .options(selectinload(TestCase.steps))
            .filter(TestCase.id == cid, TestCase.project_id == project_id)
            .one()
        )
        out.append(_case_to_out(c))
    return out
