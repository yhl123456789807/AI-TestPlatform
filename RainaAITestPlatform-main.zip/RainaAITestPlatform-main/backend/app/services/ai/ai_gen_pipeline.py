import json
import logging
from collections.abc import Generator, Iterator
from typing import Any, TypeVar

from pydantic import BaseModel, TypeAdapter

from app.errors import AppError
from app.schemas.ai.ai_agent import (
    AgentArtifacts as PipelineArtifacts,
    CaseReviewOut,
    CaseReviewResult,
    RequirementAnalysisOut,
    TestPointsResponse,
)
from app.schemas.ai.ai_gen import ChatMessage, GeneratedCase, ReviewDimensionConfig
from app.services.ai import llm
from app.services.ai.ai_case_common import (
    cases_from_llm_raw,
    content_with_images,
    trim_chat_messages,
)
from app.services.ai.case_review_dims import (
    build_review_checklist_text,
    issue_type_keys_csv,
    normalize_review_dims,
)
from app.services.ai.effective_ai_settings import LlmRuntime

log = logging.getLogger(__name__)

_CASE_POINT_BATCH_SIZE = 10

_PHASE_LABELS = {
    "requirement_analysis": "需求分析",
    "test_points": "测试点",
    "cases": "用例生成",
    "review": "用例检查",
    "unknown": "未知",
}

T = TypeVar("T", bound=BaseModel)


def _phase_label(phase: str) -> str:
    return _PHASE_LABELS.get(phase, phase)


def _format_chat_history(chat_messages: list[ChatMessage]) -> str:
    messages = trim_chat_messages(chat_messages)
    if not messages:
        return "(无对话)"
    lines: list[str] = []
    for m in messages:
        role = "用户" if m.role == "user" else "助手"
        lines.append(f"{role}: {m.content}")
    return "\n".join(lines)


def _parse_json_model(raw: str, adapter: TypeAdapter[T]) -> T:
    data = json.loads(raw)
    if isinstance(data, dict) and len(data) == 1:
        only_val = next(iter(data.values()))
        if isinstance(only_val, dict):
            data = only_val
    return adapter.validate_python(data)


def _json_complete_with_retry(
    messages: list[dict[str, str]],
    *,
    adapter: TypeAdapter[T],
    use_llm_model: str,
    llm_cfg: LlmRuntime,
    retry_user_hint: str,
    phase: str = "unknown",
    retry_events: list[dict[str, Any]] | None = None,
) -> T:
    log.info(
        "分步生成调用大模型 阶段=%s 模型=%s 消息数=%d",
        _phase_label(phase),
        use_llm_model,
        len(messages),
    )
    scene = f"用例生成-{_phase_label(phase)}"
    raw = llm.chat_complete(messages, model=use_llm_model, db=None, cfg=llm_cfg, scene=scene)
    try:
        return _parse_json_model(raw, adapter)
    except Exception as e1:
        if retry_events is not None:
            retry_events.append(
                {
                    "type": "log",
                    "level": "warning",
                    "message": f"{_phase_label(phase)}输出格式异常，正在自动修复…",
                }
            )
        log.warning("分步生成 JSON 解析失败 阶段=%s 正在重试: %s", _phase_label(phase), e1)
        retry_messages = list(messages)
        retry_messages.append({"role": "assistant", "content": raw})
        retry_messages.append(
            {
                "role": "user",
                "content": f"{retry_user_hint}（解析错误: {e1}）",
            }
        )
        log.info(
            "分步生成大模型重试 阶段=%s 模型=%s 消息数=%d",
            _phase_label(phase),
            use_llm_model,
            len(retry_messages),
        )
        raw2 = llm.chat_complete(
            retry_messages, model=use_llm_model, db=None, cfg=llm_cfg, scene=scene
        )
        try:
            result = _parse_json_model(raw2, adapter)
            if retry_events is not None:
                retry_events.append(
                    {
                        "type": "log",
                        "level": "success",
                        "message": f"{_phase_label(phase)}输出格式已自动修复",
                    }
                )
            return result
        except Exception as e2:
            raise AppError(
                "unprocessable_entity",
                "Agent 阶段输出无法解析为合法 JSON",
                detail=str(e2),
                status_code=422,
            ) from e2


def _requirement_analysis_prompt() -> str:
    return (
        "你是资深测试分析师。根据检索上下文与用户对话，分析测试需求是否足够清晰以设计用例。"
        "只输出 JSON 对象，字段："
        "is_clear（布尔，需求是否已足够明确）、"
        "summary（字符串，需求摘要；is_clear 为 true 时必填）、"
        "ambiguities（字符串数组，不明确点）、"
        "questions（字符串数组，需用户回答的具体问题；is_clear 为 false 时至少 1 条）。"
        "不要输出 Markdown。"
    )


def _test_points_prompt() -> str:
    return (
        "你是测试设计专家。根据需求摘要与上下文，生成覆盖矩阵式测试点。"
        "只输出 JSON 对象 {\"test_points\": [...]}，每项含 "
        "id（如 TP-01）、module（所属业务模块，如登录与认证/项目管理/需求管理）、"
        "title、category（功能/边界/异常/权限等）、"
        "priority_hint（P0-P4 可选）、acceptance_refs（对应验收标准编号数组）。"
        "不要输出 Markdown。"
    )


def _cases_from_points_prompt() -> str:
    return (
        "你是测试工程师。根据给定的测试点生成测试用例。"
        "只输出 JSON 对象 {\"cases\": [...]}。"
        "每个测试点恰好生成 1 条用例，禁止把多个测试点合并成一条。"
        "每条用例必须包含 test_point_id（等于对应测试点的 id）、"
        "title、overall_expected（必填）、"
        "module（必填，必须继承对应测试点的 module，包含用户确认时编辑后的值）、"
        "priority（P0-P4，可参考测试点 priority_hint）、"
        "case_type（与该测试点的 category 一致，只能是功能、边界、异常、权限，对不上时用功能）、"
        "precondition（执行前需满足的条件，没有则空字符串）、"
        "test_data（步骤要用的具体输入，写成键值文本，如账号、密码、金额、边界值；没有则空字符串）、"
        "acceptance_refs（继承对应测试点的验收标准编号数组）、"
        "steps（每项仅 order、action，不要逐步 expected）。"
        "不要输出 Markdown。"
    )


def _review_prompt(dims: list[ReviewDimensionConfig]) -> str:
    checklist = build_review_checklist_text(dims)
    keys = issue_type_keys_csv(dims)
    return (
        "你是测试用例评审专家。请严格按下列维度（权重越高越优先）检查并修订用例：\n"
        f"{checklist}\n"
        "只输出 JSON 对象，字段："
        "summary（检查结论摘要）、"
        "issues（数组，每项含 case_title、issue_type、detail；"
        f"issue_type 只能是：{keys}）、"
        "dimension_scores（对象，键为上述维度 key，值为 1–5 整数评分）、"
        "cases（修订后的最终用例数组，格式与输入 cases 相同）。"
        "可合并冗余、删除不合理、微调标题/步骤/优先级；删除或合并任何用例时，"
        "必须在 issues 中以 redundancy 或对应维度说明并写明被删用例标题。"
        "若用例带有 test_point_id，不得合并不同 test_point_id，"
        "也不得删除后让该 test_point_id 没有用例；修订后的 cases 必须保留 test_point_id。"
        "修订后的 cases 保留 case_type、precondition 与 test_data。"
        "不要输出 Markdown。"
    )


def format_clarification_message(analysis: RequirementAnalysisOut) -> str:
    if not analysis.questions:
        amb = "、".join(analysis.ambiguities) if analysis.ambiguities else "需求描述不够具体"
        return f"需求尚不明确（{amb}），请补充更多信息。"
    lines = "\n".join(f"- {q}" for q in analysis.questions)
    return f"需求尚不明确，请补充以下信息：\n{lines}"


def _artifacts_from_resume_payload(artifacts: PipelineArtifacts | dict[str, Any]) -> tuple[RequirementAnalysisOut, list]:
    if isinstance(artifacts, PipelineArtifacts):
        data = artifacts
    else:
        data = PipelineArtifacts.model_validate(artifacts)
    if data.requirement_analysis is None:
        raise AppError("bad_request", "缺少需求分析结果，无法继续生成用例", status_code=400)
    if not data.test_points:
        raise AppError("bad_request", "缺少测试点，无法继续生成用例", status_code=400)
    return data.requirement_analysis, data.test_points


def _point_batches(points: list, size: int = _CASE_POINT_BATCH_SIZE) -> list[list]:
    return [points[index : index + size] for index in range(0, len(points), size)]


def _point_id(point: Any) -> str:
    return str(getattr(point, "id", "") or "").strip()


def _covered_point_keys(cases: list[GeneratedCase]) -> set[str]:
    return {
        case.test_point_id.strip().casefold()
        for case in cases
        if case.test_point_id and case.test_point_id.strip()
    }


def _uncovered_points(points: list, cases: list[GeneratedCase]) -> list:
    covered = _covered_point_keys(cases)
    return [point for point in points if _point_id(point).casefold() not in covered]


def _assign_point_ids(cases: list[GeneratedCase], points: list) -> None:
    canonical = {_point_id(point).casefold(): _point_id(point) for point in points if _point_id(point)}
    for case in cases:
        raw = (case.test_point_id or "").strip()
        if not raw:
            continue
        case.test_point_id = canonical.get(raw.casefold(), raw)


def _case_messages_for_points(
    *,
    context: str,
    analysis: RequirementAnalysisOut,
    points: list,
) -> list[dict[str, str]]:
    tp_json = json.dumps([point.model_dump() for point in points], ensure_ascii=False)
    return [
        {"role": "system", "content": _cases_from_points_prompt()},
        {
            "role": "user",
            "content": (
                f"检索上下文：\n{context}\n\n"
                f"需求摘要：\n{analysis.summary}\n\n"
                f"测试点：\n{tp_json}\n\n"
                "请为上述每一个测试点各生成恰好一条用例，"
                "test_point_id 必须等于该测试点的 id，不要合并测试点。"
            ),
        },
        {
            "role": "user",
            "content": '请输出 JSON 对象 {"cases":[...]}，不要 Markdown。',
        },
    ]


def _iter_cases_for_points(
    *,
    context: str,
    analysis: RequirementAnalysisOut,
    points: list,
    use_llm_model: str,
    llm_cfg: LlmRuntime,
) -> Generator[dict[str, Any], None, list[GeneratedCase]]:
    messages = _case_messages_for_points(context=context, analysis=analysis, points=points)
    raw_cases = ""
    for delta in llm.chat_complete_stream(
        messages, model=use_llm_model, cfg=llm_cfg, scene="用例生成"
    ):
        raw_cases += delta
        yield {"type": "delta", "content": delta}
    cases = cases_from_llm_raw(
        raw_cases,
        messages,
        use_llm_model=use_llm_model,
        llm_cfg=llm_cfg,
    )
    _assign_point_ids(cases, points)
    return cases


def _restore_missing_point_cases(
    final_cases: list[GeneratedCase],
    draft_cases: list[GeneratedCase],
) -> int:
    covered = _covered_point_keys(final_cases)
    restored = 0
    for draft in draft_cases:
        point_id = (draft.test_point_id or "").strip()
        if not point_id or point_id.casefold() in covered:
            continue
        final_cases.append(draft)
        covered.add(point_id.casefold())
        restored += 1
    return restored


def iter_case_review(
    *,
    draft_cases: list[GeneratedCase],
    dims: list[ReviewDimensionConfig],
    use_llm_model: str,
    llm_cfg: LlmRuntime,
    test_points_json: str | None = None,
    context: str | None = None,
    requirement_text: str | None = None,
) -> Iterator[dict[str, Any]]:
    """Yield phase/status/review events; final event is type=review_done with cases+result."""
    if not dims:
        yield {
            "type": "review_done",
            "cases": draft_cases,
            "review": None,
        }
        return

    log.info("用例检查 状态=开始 模型=%s 维度数=%d", use_llm_model, len(dims))
    yield {"type": "log", "level": "info", "message": "开始按所选维度评审用例"}
    yield {"type": "phase", "phase": "review", "status": "start"}
    yield {"type": "status", "message": "正在按多维度评审用例…"}
    cases_json = json.dumps([c.model_dump() for c in draft_cases], ensure_ascii=False)
    context_parts: list[str] = []
    if requirement_text and requirement_text.strip():
        context_parts.append(f"需求原文：\n{requirement_text.strip()}")
    if context and context.strip() and context.strip() != "(无检索片段)":
        context_parts.append(f"检索上下文：\n{context.strip()}")
    if test_points_json:
        context_parts.append(f"测试点：\n{test_points_json}")
    context_parts.append(f"待检查用例：\n{cases_json}")
    context_parts.append("请按维度评审并输出修订后的 cases。")
    review_messages = [
        {"role": "system", "content": _review_prompt(dims)},
        {"role": "user", "content": "\n\n".join(context_parts)},
    ]
    retry_events: list[dict[str, Any]] = []
    review_out = _json_complete_with_retry(
        review_messages,
        adapter=TypeAdapter(CaseReviewOut),
        use_llm_model=use_llm_model,
        llm_cfg=llm_cfg,
        retry_user_hint="请输出含 summary、issues、dimension_scores、cases 的合法 JSON 对象",
        phase="review",
        retry_events=retry_events,
    )
    yield from retry_events
    final_cases = review_out.cases if review_out.cases else list(draft_cases)
    final_titles = {case.title.strip().casefold() for case in final_cases}
    issue_text = "\n".join(
        f"{issue.case_title}\n{issue.detail}" for issue in review_out.issues
    ).casefold()
    for draft in draft_cases:
        title_key = draft.title.strip().casefold()
        if title_key not in final_titles and title_key not in issue_text:
            final_cases.append(draft)
            final_titles.add(title_key)
    restored_points = _restore_missing_point_cases(final_cases, draft_cases)
    review_result = CaseReviewResult(
        summary=review_out.summary,
        issues=review_out.issues,
        dimension_scores=review_out.dimension_scores,
    )
    yield {
        "type": "review",
        "summary": review_result.summary,
        "issues": [i.model_dump() for i in review_result.issues],
        "dimension_scores": review_result.dimension_scores,
    }
    if restored_points:
        yield {
            "type": "log",
            "level": "warning",
            "message": f"评审后有 {restored_points} 个测试点失去用例，已按草稿补回",
        }
    log.info("用例检查 状态=完成 最终用例数=%d", len(final_cases))
    yield {
        "type": "log",
        "level": "success",
        "message": f"用例评审完成：发现 {len(review_result.issues)} 个问题，保留 {len(final_cases)} 条用例",
    }
    yield {"type": "phase", "phase": "review", "status": "done"}
    yield {
        "type": "review_done",
        "cases": final_cases,
        "review": review_result,
    }


def _iter_cases_and_review(
    *,
    context: str,
    analysis: RequirementAnalysisOut,
    test_points: list,
    artifacts: PipelineArtifacts,
    use_llm_model: str,
    llm_cfg: LlmRuntime,
    enable_case_review: bool = False,
    review_dimensions: list[ReviewDimensionConfig] | None = None,
    requirement_text: str | None = None,
) -> Iterator[dict[str, Any]]:
    log.info("分步生成流水线 阶段=用例生成 状态=开始 模型=%s", use_llm_model)
    yield {"type": "log", "level": "info", "message": "开始根据已确认测试点生成用例"}
    yield {"type": "phase", "phase": "cases", "status": "start"}
    total = len(test_points)
    draft_cases: list[GeneratedCase] = []
    uncovered: list = []
    offset = 0
    for batch in _point_batches(test_points):
        start = offset + 1
        end = offset + len(batch)
        offset = end
        yield {
            "type": "log",
            "level": "info",
            "message": f"正在生成第 {start}–{end} 个测试点的用例",
        }
        batch_cases = yield from _iter_cases_for_points(
            context=context,
            analysis=analysis,
            points=batch,
            use_llm_model=use_llm_model,
            llm_cfg=llm_cfg,
        )
        missing = _uncovered_points(batch, batch_cases)
        if missing:
            missing_ids = "、".join(_point_id(point) for point in missing)
            yield {
                "type": "log",
                "level": "warning",
                "message": f"有 {len(missing)} 个测试点没有对应用例（{missing_ids}），正在补生成…",
            }
            yield {"type": "status", "message": "正在补生成遗漏的测试点…"}
            retry_cases = yield from _iter_cases_for_points(
                context=context,
                analysis=analysis,
                points=missing,
                use_llm_model=use_llm_model,
                llm_cfg=llm_cfg,
            )
            batch_cases.extend(retry_cases)
            still_missing = _uncovered_points(batch, batch_cases)
            if still_missing:
                uncovered.extend(still_missing)
                still_ids = "、".join(_point_id(point) for point in still_missing)
                yield {
                    "type": "log",
                    "level": "warning",
                    "message": f"以下测试点未生成用例：{still_ids}",
                }
        draft_cases.extend(batch_cases)
        yield {
            "type": "cases_batch",
            "cases": [case.model_dump() for case in batch_cases],
            "count": len(draft_cases),
        }
    covered_count = total - len(uncovered)
    log.info(
        "分步生成流水线 阶段=用例生成 状态=完成 草稿数=%d 覆盖=%d/%d",
        len(draft_cases),
        covered_count,
        total,
    )
    yield {
        "type": "log",
        "level": "success",
        "message": f"用例草稿生成完成，共 {len(draft_cases)} 条，覆盖 {covered_count}/{total} 个测试点",
    }
    yield {"type": "phase", "phase": "cases", "status": "done"}

    dims = normalize_review_dims(review_dimensions, enable=enable_case_review)
    final_cases = draft_cases
    review_result: CaseReviewResult | None = None
    tp_json = json.dumps([point.model_dump() for point in test_points], ensure_ascii=False)
    for event in iter_case_review(
        draft_cases=draft_cases,
        dims=dims,
        use_llm_model=use_llm_model,
        llm_cfg=llm_cfg,
        test_points_json=tp_json,
        context=context,
        requirement_text=requirement_text,
    ):
        if event.get("type") == "review_done":
            final_cases = event["cases"]
            review_result = event.get("review")
            continue
        yield event

    if review_result is not None:
        artifacts.review = review_result

    assistant_message = format_agent_done_message(final_cases, review_result)
    yield {
        "type": "log",
        "level": "success",
        "message": f"生成流程完成，最终得到 {len(final_cases)} 条用例",
    }
    yield {
        "type": "done",
        "cases": [c.model_dump() for c in final_cases],
        "assistant_message": assistant_message,
        "artifacts": artifacts.model_dump(),
    }


def run_agent_pipeline_resume_cases(
    *,
    context: str,
    artifacts_payload: PipelineArtifacts | dict[str, Any],
    use_llm_model: str,
    llm_cfg: LlmRuntime,
    enable_case_review: bool = False,
    review_dimensions: list[ReviewDimensionConfig] | None = None,
    requirement_text: str | None = None,
) -> Iterator[dict[str, Any]]:
    analysis, test_points = _artifacts_from_resume_payload(artifacts_payload)
    if isinstance(artifacts_payload, PipelineArtifacts):
        artifacts = artifacts_payload
    else:
        artifacts = PipelineArtifacts.model_validate(artifacts_payload)
    yield from _iter_cases_and_review(
        context=context,
        analysis=analysis,
        test_points=test_points,
        artifacts=artifacts,
        use_llm_model=use_llm_model,
        llm_cfg=llm_cfg,
        enable_case_review=enable_case_review,
        review_dimensions=review_dimensions,
        requirement_text=requirement_text,
    )


def format_agent_done_message(
    cases: list[GeneratedCase],
    review: CaseReviewResult | None,
) -> str:
    if not cases:
        return "未生成用例，请调整描述后重试。"
    titles = "、".join(c.title for c in cases[:5])
    if len(cases) > 5:
        titles = f"{titles} 等{len(cases)}条"
    if review is not None:
        base = f"已生成 {len(cases)} 条用例（多维评审完成）：{titles}"
        if review.summary.strip():
            return f"{base}\n\n检查报告：{review.summary.strip()}"
        return base
    return f"已生成 {len(cases)} 条用例：{titles}"


def run_agent_pipeline(
    *,
    context: str,
    chat_messages: list[ChatMessage],
    use_llm_model: str,
    llm_cfg: LlmRuntime,
    images: list[tuple[str, bytes]] | None = None,
) -> Iterator[dict[str, Any]]:
    chat_text = _format_chat_history(chat_messages)
    artifacts = PipelineArtifacts()

    # Phase 1: requirement analysis
    log.info(
        "分步生成流水线 阶段=需求分析 状态=开始 模型=%s 附图=%d",
        use_llm_model,
        len(images or []),
    )
    yield {"type": "log", "level": "info", "message": "开始分析需求完整性"}
    yield {"type": "phase", "phase": "requirement_analysis", "status": "start"}
    yield {"type": "status", "message": "正在分析需求…"}
    analysis_user = (
        f"检索上下文：\n{context}\n\n"
        f"对话历史：\n{chat_text}\n\n"
        "请分析需求是否足够清晰以生成测试用例。"
    )
    analysis_messages = [
        {"role": "system", "content": _requirement_analysis_prompt()},
        {
            "role": "user",
            "content": content_with_images(analysis_user, images),
        },
    ]
    retry_events = []
    analysis = _json_complete_with_retry(
        analysis_messages,
        adapter=TypeAdapter(RequirementAnalysisOut),
        use_llm_model=use_llm_model,
        llm_cfg=llm_cfg,
        retry_user_hint="请仅输出合法 JSON，含 is_clear、summary、ambiguities、questions",
        phase="requirement_analysis",
        retry_events=retry_events,
    )
    yield from retry_events
    artifacts.requirement_analysis = analysis
    log.info("分步生成流水线 阶段=需求分析 状态=完成 需求清晰=%s", analysis.is_clear)
    yield {
        "type": "log",
        "level": "success" if analysis.is_clear else "warning",
        "message": (
            "需求分析完成，信息足够生成测试点"
            if analysis.is_clear
            else f"需求分析完成，仍有 {len(analysis.questions)} 个问题需要确认"
        ),
    }
    yield {"type": "phase", "phase": "requirement_analysis", "status": "done"}

    if not analysis.is_clear:
        assistant_message = format_clarification_message(analysis)
        yield {
            "type": "clarification",
            "analysis": analysis.model_dump(),
            "questions": analysis.questions,
            "assistant_message": assistant_message,
            "artifacts": artifacts.model_dump(),
        }
        return

    yield {
        "type": "analysis_done",
        "summary": analysis.summary,
        "artifacts": artifacts.model_dump(),
    }

    # Phase 2: test points
    log.info("分步生成流水线 阶段=测试点 状态=开始 模型=%s", use_llm_model)
    yield {"type": "log", "level": "info", "message": "开始生成覆盖矩阵测试点"}
    yield {"type": "phase", "phase": "test_points", "status": "start"}
    yield {"type": "status", "message": "正在生成测试点…"}
    tp_messages = [
        {"role": "system", "content": _test_points_prompt()},
        {
            "role": "user",
            "content": (
                f"检索上下文：\n{context}\n\n"
                f"需求摘要：\n{analysis.summary}\n\n"
                f"对话历史：\n{chat_text}\n\n"
                "请生成测试点列表。"
            ),
        },
    ]
    retry_events = []
    tp_resp = _json_complete_with_retry(
        tp_messages,
        adapter=TypeAdapter(TestPointsResponse),
        use_llm_model=use_llm_model,
        llm_cfg=llm_cfg,
        retry_user_hint=(
            '请仅输出合法 JSON 对象 {"test_points":[...]}，'
            "每条测试点必须包含非空 module"
        ),
        phase="test_points",
        retry_events=retry_events,
    )
    yield from retry_events
    test_points = tp_resp.test_points
    artifacts.test_points = test_points
    yield {
        "type": "test_points",
        "items": [tp.model_dump() for tp in test_points],
    }
    log.info("分步生成流水线 阶段=测试点 状态=完成 数量=%d", len(test_points))
    yield {
        "type": "log",
        "level": "success",
        "message": f"测试点生成完成，共 {len(test_points)} 条",
    }
    yield {"type": "phase", "phase": "test_points", "status": "done"}

    n = len(test_points)
    assistant_message = f"已生成 {n} 个测试点，请确认后继续生成用例。"
    yield {
        "type": "await_test_points_confirm",
        "items": [tp.model_dump() for tp in test_points],
        "assistant_message": assistant_message,
        "artifacts": artifacts.model_dump(),
    }
