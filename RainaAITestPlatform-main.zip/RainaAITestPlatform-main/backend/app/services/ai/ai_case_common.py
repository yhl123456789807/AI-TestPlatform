from __future__ import annotations

import base64
import json
from typing import Any

from pydantic import TypeAdapter

from app.errors import AppError
from app.schemas.ai.ai_gen import ChatMessage, GeneratedCase
from app.services.ai import llm
from app.services.ai.effective_ai_settings import LlmRuntime

MAX_CHAT_MESSAGES = 9


def trim_chat_messages(messages: list[ChatMessage]) -> list[ChatMessage]:
    if len(messages) <= MAX_CHAT_MESSAGES:
        return list(messages)
    omitted = len(messages) - MAX_CHAT_MESSAGES
    return [
        messages[0],
        ChatMessage(role="assistant", content=f"（已省略 {omitted} 条较早对话）"),
        *messages[-(MAX_CHAT_MESSAGES - 1) :],
    ]


def _json_case_items(raw: str) -> list[Any]:
    data = json.loads(raw)
    if isinstance(data, list):
        return data
    if isinstance(data, dict) and "cases" in data:
        payload = data["cases"]
        if not isinstance(payload, list):
            raise ValueError("cases must be an array")
        return payload
    raise ValueError("expected JSON array or object with key 'cases'")


def _draft_index(item: Any) -> int | None:
    if not isinstance(item, dict) or "draft_index" not in item:
        return None
    value = item.get("draft_index")
    if isinstance(value, bool) or value is None:
        return None
    if isinstance(value, int):
        return value if value >= 0 else None
    if isinstance(value, str) and value.strip().isdigit():
        return int(value.strip())
    return None


def parse_cases_with_draft_indexes(raw: str) -> tuple[list[GeneratedCase], list[int | None]]:
    payload = _json_case_items(raw)
    indexes = [_draft_index(item) for item in payload]
    cases = TypeAdapter(list[GeneratedCase]).validate_python(payload)
    return cases, indexes


def parse_cases(raw: str) -> list[GeneratedCase]:
    cases, _indexes = parse_cases_with_draft_indexes(raw)
    return cases


def cases_and_indexes_from_llm_raw(
    raw: str,
    messages: list[dict[str, Any]],
    *,
    use_llm_model: str,
    llm_cfg: LlmRuntime,
    keep_draft_index: bool = False,
) -> tuple[list[GeneratedCase], list[int | None]]:
    try:
        return parse_cases_with_draft_indexes(raw)
    except Exception as first_error:
        retry_hint = "每条用例保留 draft_index（原下标或 null）。" if keep_draft_index else ""
        retry_messages = list(messages)
        retry_messages.append({"role": "assistant", "content": raw})
        retry_messages.append(
            {
                "role": "user",
                "content": (
                    f"上次输出无法解析为合法 JSON（错误: {first_error}）。"
                    "请仅输出合法 JSON 对象，键为 cases。"
                    + retry_hint
                ),
            }
        )
        raw2 = llm.chat_complete(
            retry_messages,
            model=use_llm_model,
            db=None,
            cfg=llm_cfg,
            scene="用例生成",
        )
        try:
            return parse_cases_with_draft_indexes(raw2)
        except Exception as second_error:
            raise AppError(
                "unprocessable_entity",
                "LLM 返回内容无法解析为测试用例 JSON",
                detail=str(second_error),
                status_code=422,
            ) from second_error


def cases_from_llm_raw(
    raw: str,
    messages: list[dict[str, Any]],
    *,
    use_llm_model: str,
    llm_cfg: LlmRuntime,
) -> list[GeneratedCase]:
    cases, _indexes = cases_and_indexes_from_llm_raw(
        raw,
        messages,
        use_llm_model=use_llm_model,
        llm_cfg=llm_cfg,
    )
    return cases


def content_with_images(
    text: str, images: list[tuple[str, bytes]] | None
) -> str | list[dict[str, Any]]:
    if not images:
        return text
    parts: list[dict[str, Any]] = [{"type": "text", "text": text}]
    for mime, blob in images:
        encoded = base64.standard_b64encode(blob).decode("ascii")
        parts.append(
            {
                "type": "image_url",
                "image_url": {"url": f"data:{mime};base64,{encoded}"},
            }
        )
    return parts


def format_assistant_message(
    cases: list[GeneratedCase], *, revised: bool = False
) -> str:
    if not cases:
        return "未生成用例，请调整描述后重试。"
    titles = "、".join(case.title for case in cases[:5])
    if len(cases) > 5:
        titles = f"{titles} 等{len(cases)}条"
    verb = "已更新" if revised else "已生成"
    return f"{verb} {len(cases)} 条用例：{titles}"
