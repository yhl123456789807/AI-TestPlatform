"""LLM revise existing UiCase scripts; confirm writes back (no browser explore)."""

from __future__ import annotations

import logging
import uuid
from typing import Any

from sqlalchemy.orm import Session
from sqlalchemy.orm.attributes import flag_modified

from app.errors import AppError
from app.models.ui_automation.ui_automation import UiCase, UiCaseEditAgentSession
from app.services.ai.effective_ai_settings import LlmRuntime, get_llm_runtime
from app.services.api_automation.api_scenario_events import get_event_bus
from app.services.ui_automation.ui_node_script import is_runnable_ui_script
from app.services.ui_automation.ui_scenario_agent import revise_script_with_llm

log = logging.getLogger(__name__)

MAX_CASES = 10


def new_thread_id() -> str:
    return "uiedit-" + uuid.uuid4().hex


def _append_message(row: UiCaseEditAgentSession, role: str, content: str) -> None:
    msgs = list(row.messages_json) if isinstance(row.messages_json, list) else []
    msgs.append({"role": role, "content": content})
    row.messages_json = msgs
    flag_modified(row, "messages_json")


def _emit(row: UiCaseEditAgentSession, *, node: str, message: str, level: str = "info") -> None:
    get_event_bus().append(
        row.thread_id,
        {"type": "log", "node": node, "message": message, "level": level},
    )


def _persist_events(row: UiCaseEditAgentSession) -> None:
    row.events_json = get_event_bus().snapshot(row.thread_id)
    flag_modified(row, "events_json")


def session_title(prompt: str, case_ids: list[int]) -> str:
    text = (prompt or "").strip()
    if text:
        return text[:40] + ("…" if len(text) > 40 else "")
    n = len(case_ids)
    return f"批量修订 {n} 条用例" if n else "新修订会话"


def load_snapshots(db: Session, project_id: int, case_ids: list[int]) -> list[dict[str, Any]]:
    rows = (
        db.query(UiCase)
        .filter(UiCase.project_id == project_id, UiCase.id.in_(case_ids))
        .all()
    )
    by_id = {int(r.id): r for r in rows}
    missing = [c for c in case_ids if c not in by_id]
    if missing:
        raise AppError("bad_request", f"部分用例不属于当前项目: {missing}", status_code=400)
    out: list[dict[str, Any]] = []
    for cid in case_ids:
        row = by_id[cid]
        out.append(
            {
                "case_id": int(row.id),
                "name": row.name or "",
                "script": row.script or "",
            }
        )
    return out


def _current_scripts(row: UiCaseEditAgentSession) -> dict[int, str]:
    plan = row.plan_json if isinstance(row.plan_json, dict) else {}
    revisions = plan.get("revisions") if isinstance(plan.get("revisions"), list) else []
    out: dict[int, str] = {}
    for item in revisions:
        if not isinstance(item, dict):
            continue
        cid = int(item.get("case_id") or 0)
        if not cid:
            continue
        draft = str(item.get("draft_script") or "")
        if draft.strip():
            out[cid] = draft
    if out:
        return out
    snaps = row.base_snapshots_json if isinstance(row.base_snapshots_json, list) else []
    for s in snaps:
        if not isinstance(s, dict):
            continue
        cid = int(s.get("case_id") or 0)
        if cid:
            out[cid] = str(s.get("script") or "")
    return out


def _revise_all(
    *,
    snapshots: list[dict[str, Any]],
    scripts: dict[int, str],
    instruction: str,
    llm_cfg: LlmRuntime,
) -> dict[str, Any]:
    revisions: list[dict[str, Any]] = []
    warnings: list[str] = []
    for snap in snapshots:
        cid = int(snap["case_id"])
        name = str(snap.get("name") or "")
        base = scripts.get(cid, str(snap.get("script") or ""))
        if not is_runnable_ui_script(base):
            revisions.append(
                {
                    "case_id": cid,
                    "name": name,
                    "summary": "原脚本不可执行，已跳过",
                    "draft_script": base,
                    "skipped": True,
                    "skip_reason": "原脚本不是可执行 Playwright 脚本",
                }
            )
            continue
        try:
            revised = revise_script_with_llm(
                script=base,
                instruction=instruction,
                plan={"case_id": cid, "case_name": name},
                llm_cfg=llm_cfg,
            )
            if not is_runnable_ui_script(revised):
                raise ValueError("修订后脚本无效")
            changed = revised.strip() != base.strip()
            revisions.append(
                {
                    "case_id": cid,
                    "name": name,
                    "summary": "已按对话修订脚本" if changed else "脚本无实质变更",
                    "draft_script": revised,
                    "skipped": False,
                    "changed": changed,
                }
            )
        except Exception as ex:  # noqa: BLE001
            log.warning("ui case edit revise failed case_id=%s: %s", cid, ex)
            revisions.append(
                {
                    "case_id": cid,
                    "name": name,
                    "summary": f"修订失败：{ex}",
                    "draft_script": base,
                    "skipped": True,
                    "skip_reason": str(ex),
                }
            )
            warnings.append(f"#{cid} {name}: {ex}")
    usable = sum(1 for r in revisions if not r.get("skipped"))
    return {
        "title": "UI 脚本修订",
        "summary": f"已修订 {usable}/{len(revisions)} 条脚本草稿",
        "revisions": revisions,
        "warnings": warnings,
    }


def create_session(
    db: Session,
    *,
    project_id: int,
    user_id: int,
    case_ids: list[int],
    prompt: str,
    llm_cfg: LlmRuntime | None = None,
) -> UiCaseEditAgentSession:
    cfg = llm_cfg or get_llm_runtime(db)
    if not cfg.api_key.strip():
        raise AppError("bad_request", "未配置 LLM API Key", status_code=400)
    if len(case_ids) > MAX_CASES:
        raise AppError("bad_request", f"一次最多修订 {MAX_CASES} 条用例", status_code=400)

    text = (prompt or "").strip()
    if not text:
        raise AppError("bad_request", "请输入修改说明", status_code=400)

    snapshots = load_snapshots(db, project_id, case_ids)
    thread_id = new_thread_id()
    get_event_bus().replace(thread_id, [])
    row = UiCaseEditAgentSession(
        project_id=project_id,
        user_id=user_id,
        thread_id=thread_id,
        status="running",
        prompt=text,
        case_ids_json=case_ids,
        base_snapshots_json=snapshots,
        messages_json=[],
        plan_json=None,
        events_json=[],
        applied_case_ids_json=None,
        error_message="",
    )
    db.add(row)
    db.flush()

    _append_message(row, "user", text)
    _emit(row, node="revise", message=f"正在修订 {len(case_ids)} 条 UI 脚本…")
    db.commit()

    scripts = {int(s["case_id"]): str(s.get("script") or "") for s in snapshots}
    try:
        plan = _revise_all(snapshots=snapshots, scripts=scripts, instruction=text, llm_cfg=cfg)
        row.plan_json = plan
        flag_modified(row, "plan_json")
        usable = sum(1 for r in plan["revisions"] if not r.get("skipped"))
        if usable == 0:
            row.status = "error"
            row.error_message = "全部用例修订失败"
            _append_message(row, "assistant", row.error_message)
            get_event_bus().append(thread_id, {"type": "error", "message": row.error_message})
        else:
            row.status = "awaiting_confirm"
            row.error_message = ""
            _append_message(
                row,
                "assistant",
                f"已生成 {usable} 条脚本草稿。可继续对话修改，确认后才会写回用例。",
            )
            get_event_bus().append(thread_id, {"type": "plan", "plan": plan})
            get_event_bus().append(
                thread_id, {"type": "interrupted", "message": "等待确认写入 UI 用例"}
            )
    except Exception as ex:  # noqa: BLE001
        log.exception("ui case edit create failed")
        row.status = "error"
        row.error_message = str(ex) or "修订失败"
        _append_message(row, "assistant", f"修订失败：{row.error_message}")
        get_event_bus().append(thread_id, {"type": "error", "message": row.error_message})

    _persist_events(row)
    db.commit()
    db.refresh(row)
    return row


def apply_message(
    db: Session,
    row: UiCaseEditAgentSession,
    content: str,
    *,
    llm_cfg: LlmRuntime | None = None,
) -> UiCaseEditAgentSession:
    if row.status != "awaiting_confirm":
        raise AppError("bad_request", f"当前状态不可继续对话: {row.status}", status_code=400)
    text = content.strip()
    if not text:
        raise AppError("bad_request", "请输入修改说明", status_code=400)

    cfg = llm_cfg or get_llm_runtime(db)
    if not cfg.api_key.strip():
        raise AppError("bad_request", "未配置 LLM API Key", status_code=400)

    snapshots = row.base_snapshots_json if isinstance(row.base_snapshots_json, list) else []
    if not snapshots:
        raise AppError("bad_request", "会话缺少用例快照", status_code=400)

    _append_message(row, "user", text)
    row.status = "running"
    _emit(row, node="revise", message="正在根据对话修订脚本…")
    db.commit()

    scripts = _current_scripts(row)
    try:
        plan = _revise_all(
            snapshots=[s for s in snapshots if isinstance(s, dict)],
            scripts=scripts,
            instruction=text,
            llm_cfg=cfg,
        )
        row.plan_json = plan
        flag_modified(row, "plan_json")
        usable = sum(1 for r in plan["revisions"] if not r.get("skipped"))
        row.status = "awaiting_confirm"
        row.error_message = ""
        _append_message(
            row,
            "assistant",
            f"已按你的要求更新草稿（可用 {usable} 条）。可继续修改或确认写入。",
        )
        get_event_bus().append(row.thread_id, {"type": "plan", "plan": plan})
        get_event_bus().append(
            row.thread_id, {"type": "interrupted", "message": "等待确认写入 UI 用例"}
        )
    except Exception as ex:  # noqa: BLE001
        row.status = "awaiting_confirm"
        _append_message(row, "assistant", f"修订失败：{ex}。可换一种说法继续。")
        _emit(row, node="revise", message=str(ex), level="error")

    _persist_events(row)
    db.commit()
    db.refresh(row)
    return row


def confirm_session(
    db: Session,
    row: UiCaseEditAgentSession,
    *,
    action: str,
    case_ids: list[int] | None = None,
    drafts: list[dict[str, Any]] | None = None,
) -> UiCaseEditAgentSession:
    if row.status != "awaiting_confirm":
        raise AppError("bad_request", f"会话状态不可确认: {row.status}", status_code=400)

    if action == "cancel":
        row.status = "cancelled"
        row.applied_case_ids_json = []
        row.error_message = ""
        get_event_bus().append(
            row.thread_id, {"type": "done", "status": "cancelled", "applied_case_ids": []}
        )
        _persist_events(row)
        db.commit()
        db.refresh(row)
        return row

    plan = dict(row.plan_json) if isinstance(row.plan_json, dict) else None
    revisions = plan.get("revisions") if isinstance(plan, dict) else None
    if not isinstance(revisions, list) or not revisions:
        raise AppError("bad_request", "当前会话没有可应用的修订草稿", status_code=400)

    override_by_id: dict[int, str] = {}
    for item in drafts or []:
        if not isinstance(item, dict):
            continue
        cid = int(item.get("case_id") or 0)
        script = str(item.get("draft_script") or "")
        if not cid or not script.strip():
            continue
        if not is_runnable_ui_script(script):
            raise AppError(
                "bad_request",
                f"用例 #{cid} 手改草稿不是可执行脚本",
                status_code=400,
            )
        override_by_id[cid] = script if script.endswith("\n") else script + "\n"

    if override_by_id:
        for item in revisions:
            if not isinstance(item, dict):
                continue
            cid = int(item.get("case_id") or 0)
            if cid in override_by_id:
                item["draft_script"] = override_by_id[cid]
                item["skipped"] = False
                item["summary"] = str(item.get("summary") or "") or "已手动调整草稿"
        plan["revisions"] = revisions
        row.plan_json = plan
        flag_modified(row, "plan_json")

    want: set[int] | None = None
    if case_ids is not None:
        want = {int(x) for x in case_ids}
        if not want:
            raise AppError("bad_request", "请至少勾选一条要应用的修订", status_code=400)

    applied: list[int] = []
    for item in revisions:
        if not isinstance(item, dict) or item.get("skipped"):
            continue
        cid = int(item.get("case_id") or 0)
        if not cid:
            continue
        if want is not None and cid not in want:
            continue
        draft = str(item.get("draft_script") or "")
        if not is_runnable_ui_script(draft):
            continue
        case = (
            db.query(UiCase)
            .filter(UiCase.id == cid, UiCase.project_id == row.project_id)
            .first()
        )
        if case is None:
            continue
        case.script = draft if draft.endswith("\n") else draft + "\n"
        applied.append(cid)

    if want is not None and not applied:
        raise AppError("bad_request", "未写回任何用例，请确认已勾选有效修订", status_code=400)

    row.status = "confirmed"
    row.applied_case_ids_json = applied
    row.error_message = ""
    get_event_bus().append(
        row.thread_id,
        {"type": "done", "status": "confirmed", "applied_case_ids": applied},
    )
    _persist_events(row)
    db.commit()
    db.refresh(row)
    return row
