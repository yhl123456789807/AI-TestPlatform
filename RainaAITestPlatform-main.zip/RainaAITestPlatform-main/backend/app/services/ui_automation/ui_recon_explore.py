"""Read-only site reconnaissance before goal-driven LangGraph explore."""

from __future__ import annotations

import logging
import time
from collections import deque
from collections.abc import Callable
from typing import Any
from urllib.parse import urlparse

from app.config import settings
from app.services.ui_automation.playwright_cli_session import (
    PlaywrightCliSession,
    join_explore_url,
    unique_session_name,
)
from app.services.ui_automation.ui_cli_explorer import _snapshot_controls
from app.services.ui_automation.ui_page_knowledge import control_locator_expression

log = logging.getLogger(__name__)

_RECON_NAV_ROLES = frozenset({"link", "menuitem", "tab"})


def _hostname(url: str) -> str:
    return (urlparse(url).hostname or "").lower()


def _path_only(url: str, *, host: str) -> str:
    parsed = urlparse(url)
    if (parsed.hostname or "").lower() != host.lower():
        return ""
    return parsed.path or "/"


def _should_skip_path(path: str) -> bool:
    low = (path or "").lower()
    return any(frag in low for frag in ("/login", "/signin", "/register", "/logout"))


def _cli_current_url(cli: PlaywrightCliSession, fallback: str) -> str:
    page = cli.active_page()
    if page is not None:
        try:
            u = str(page.url or "").strip()
            if u.startswith("http"):
                return u
        except Exception:  # noqa: BLE001
            pass
    return fallback


def _extract_page_controls(cli: PlaywrightCliSession, snapshot: str) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    for row in _snapshot_controls(snapshot):
        if row.get("kind") != "control":
            continue
        role = str(row.get("role") or "").lower()
        name = str(row.get("name") or "").strip()
        ref = str(row.get("ref") or "")
        if not name:
            continue
        loc = ""
        if ref and role in _RECON_NAV_ROLES | {"button"}:
            try:
                loc = cli.generate_locator(ref) or control_locator_expression(role, name)
            except Exception:  # noqa: BLE001
                loc = control_locator_expression(role, name)
        entry: dict[str, Any] = {"role": role, "name": name, "ref": ref}
        if loc:
            entry["locator"] = loc
        out.append(entry)
    return out


def _nav_candidates(controls: list[dict[str, Any]]) -> list[dict[str, Any]]:
    seen: set[str] = set()
    candidates: list[dict[str, Any]] = []
    for c in controls:
        role = str(c.get("role") or "").lower()
        name = str(c.get("name") or "").strip()
        ref = str(c.get("ref") or "")
        if role not in _RECON_NAV_ROLES or not name or not ref:
            continue
        key = f"{role}|{name}"
        if key in seen:
            continue
        seen.add(key)
        candidates.append(c)
    return sorted(candidates, key=lambda x: (x.get("role", ""), x.get("name", "")))


def run_recon_explore(
    *,
    base_url: str,
    start_path: str,
    cli: PlaywrightCliSession | None = None,
    headed: bool = False,
    timeout_ms: int = 15000,
    max_pages: int | None = None,
    max_depth: int | None = None,
    should_cancel: Callable[[], bool] | None = None,
    on_log: Callable[[str], None] | None = None,
    storage_state: dict[str, Any] | str | None = None,
    extra_http_headers: dict[str, str] | None = None,
    local_storage: dict[str, str] | None = None,
) -> tuple[list[dict[str, Any]], PlaywrightCliSession]:
    """BFS same-site navigation; returns recon trace rows and the live CLI session."""
    own = cli is None
    session = cli or PlaywrightCliSession(
        headed=headed,
        session_name=unique_session_name("recon"),
        timeout_ms=timeout_ms,
        use_cdp=True,
        storage_state=storage_state,
        extra_http_headers=extra_http_headers,
        local_storage=local_storage,
    )
    limit_pages = max(1, int(max_pages if max_pages is not None else settings.ui_recon_max_pages))
    limit_depth = max(0, int(max_depth if max_depth is not None else settings.ui_recon_max_depth))
    start = start_path if str(start_path).startswith("/") else f"/{start_path or ''}"
    home = join_explore_url(base_url, start)
    host = _hostname(home)

    def _log(msg: str) -> None:
        if on_log:
            on_log(msg)
        log.info("recon: %s", msg)

    trace: list[dict[str, Any]] = []
    visited_paths: set[str] = set()
    queue: deque[tuple[str, int]] = deque([(start, 0)])

    try:
        if own:
            session.open(home)
        else:
            session.goto(home)
        time.sleep(0.35)

        while queue and len(visited_paths) < limit_pages:
            if should_cancel and should_cancel():
                _log("站点测绘已取消")
                break
            path, depth = queue.popleft()
            norm = path if path.startswith("/") else f"/{path}"
            if norm in visited_paths:
                continue
            target_url = join_explore_url(base_url, norm)
            session.goto(target_url)
            time.sleep(0.3)
            current = _cli_current_url(session, target_url)
            cur_path = _path_only(current, host=host) or norm
            if _should_skip_path(cur_path):
                continue
            visited_paths.add(cur_path)

            snapshot = session.snapshot_for_explore(stabilize_modal=False)
            controls = _extract_page_controls(session, snapshot)
            trace.append(
                {
                    "kind": "recon_visit",
                    "status": "ok",
                    "driver": "playwright",
                    "path": cur_path,
                    "url": current,
                    "depth": depth,
                    "title_hint": "",
                    "controls": controls,
                    "snapshot": snapshot[:6000],
                }
            )
            _log(f"测绘页面 {cur_path}（{len(controls)} 个控件，深度 {depth}）")

            if depth >= limit_depth:
                continue

            restore_url = current
            for cand in _nav_candidates(controls):
                if len(visited_paths) + len(queue) >= limit_pages:
                    break
                ref = str(cand.get("ref") or "")
                name = str(cand.get("name") or "")
                role = str(cand.get("role") or "link")
                try:
                    session.click(ref)
                    time.sleep(0.45)
                    after = _cli_current_url(session, restore_url)
                    new_path = _path_only(after, host=host)
                    if not new_path or _should_skip_path(new_path):
                        session.goto(restore_url)
                        time.sleep(0.25)
                        continue
                    trace.append(
                        {
                            "kind": "recon_nav",
                            "status": "ok",
                            "driver": "playwright",
                            "from_path": cur_path,
                            "to_path": new_path,
                            "via_role": role,
                            "via_name": name,
                            "via": f"{role}:{name}",
                        }
                    )
                    if new_path not in visited_paths and new_path not in {p for p, _ in queue}:
                        queue.append((new_path, depth + 1))
                    session.goto(restore_url)
                    time.sleep(0.25)
                except Exception as ex:  # noqa: BLE001
                    log.debug("recon click failed %s: %s", name, ex)
                    try:
                        session.goto(restore_url)
                    except Exception:  # noqa: BLE001
                        pass
    except Exception as ex:  # noqa: BLE001
        _log(f"站点测绘异常（将继续业务探索）: {ex}")
        trace.append({"kind": "recon_error", "status": "error", "error": str(ex)[:500]})

    _log(f"站点测绘完成：{len(visited_paths)} 页，{len(trace)} 条记录")
    return trace, session
