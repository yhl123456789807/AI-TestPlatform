"""Drive @playwright/cli named sessions for product UI explore (CDP + optional Midscene)."""

from __future__ import annotations

import json
import logging
import os
import re
import subprocess
import tempfile
import time
import uuid
from pathlib import Path
from typing import Any

log = logging.getLogger(__name__)

_RUNNER_DIR = Path(__file__).resolve().parents[4] / "ui-runner"


def running_in_container() -> bool:
    """True when the process is inside Docker/K8s (no display for headed Chromium)."""
    if os.environ.get("RAINIA_DOCKER", "").strip().lower() in {"1", "true", "yes"}:
        return True
    if Path("/.dockerenv").is_file():
        return True
    try:
        cgroup = Path("/proc/1/cgroup").read_text(encoding="utf-8", errors="ignore")
    except OSError:
        return False
    return "docker" in cgroup or "kubepods" in cgroup or "containerd" in cgroup


# Main-frame e12 and iframe/subtree f1e367 (Playwright accessibility snapshot refs).
SNAPSHOT_REF_TOKEN = r"(?:f\d+)?e\d+"
_REF = re.compile(rf"^(?:ref=)?({SNAPSHOT_REF_TOKEN})$", re.I)
_LOCATOR_REF = re.compile(
    rf"""^(?:page\.)?locator\(\s*['\"](?:ref=)?{SNAPSHOT_REF_TOKEN}['\"]\s*\)$""",
    re.I,
)
_LOCATOR_LINE = re.compile(
    r"(page\.(?:getBy(?:Role|Label|Placeholder|Text|TestId)|locator)\([^;\n]+\)(?:\.[a-zA-Z]+\([^)]*\))?)",
    re.I,
)
_SNAPSHOT_DIALOG_LINE = re.compile(r"^\s*-\s+dialog\b", re.I | re.M)


def _cli_playwright_core_pkg() -> Path | None:
    core = _RUNNER_DIR / "node_modules" / "@playwright" / "cli" / "node_modules" / "playwright-core"
    return core if core.is_dir() else None


def _cli_chromium_executable_path() -> str:
    """Resolve the Chromium binary path required by @playwright/cli's bundled playwright-core."""
    core = _cli_playwright_core_pkg()
    if core is None:
        return ""
    js = (
        f"const {{ chromium }} = require({json.dumps(str(core))}); "
        "process.stdout.write(chromium.executablePath());"
    )
    try:
        proc = subprocess.run(
            ["node", "-e", js],
            cwd=str(_RUNNER_DIR),
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=20,
            check=False,
        )
    except (OSError, subprocess.TimeoutExpired):
        return ""
    if proc.returncode != 0:
        return ""
    return (proc.stdout or "").strip()


def cli_ready() -> str | None:
    cli_pkg = _RUNNER_DIR / "node_modules" / "@playwright" / "cli"
    if not cli_pkg.is_dir():
        return (
            f"未安装 @playwright/cli（缺少 {cli_pkg}）。"
            f"请在 {_RUNNER_DIR} 目录执行：npm install"
        )
    exe = _cli_chromium_executable_path()
    if exe and not Path(exe).is_file():
        return (
            f"playwright-cli 所需的 Chromium 未安装（期望可执行文件：{exe}）。"
            f"请在 {_RUNNER_DIR} 目录执行："
            "npx --no-install playwright-cli install-browser chrome-for-testing"
            "（若失败可试 npx --no-install playwright-cli install）；"
            "另建议 npx playwright install chromium（CDP/Midscene 路径）。"
            "安装完成后重启 Celery Worker。"
        )
    return None


def is_element_ref(target: str | None) -> bool:
    return bool(target and _REF.match(str(target).strip()))


def is_snapshot_ref_locator(raw: str | None) -> bool:
    """True for live snapshot refs like e23 / f1e367 / page.locator("e23") — not stable in saved scripts."""
    s = (raw or "").strip().rstrip(";").strip()
    if not s:
        return False
    if is_element_ref(s):
        return True
    return bool(_LOCATOR_REF.match(s))


def normalize_ref(target: str) -> str:
    m = _REF.match(str(target).strip())
    if not m:
        raise ValueError(f"不是有效的 snapshot ref: {target!r}")
    return m.group(1).lower()


class PlaywrightCliSession:
    """One named playwright-cli browser session for a single explore job.

    Prefer CDP-backed Chromium so Midscene can attach to the same page for captcha aiQuery.
    """

    def __init__(
        self,
        *,
        headed: bool = False,
        session_name: str | None = None,
        timeout_ms: int = 15000,
        cwd: Path | None = None,
        use_cdp: bool = True,
        storage_state: dict[str, Any] | str | None = None,
        extra_http_headers: dict[str, str] | None = None,
        local_storage: dict[str, str] | None = None,
    ) -> None:
        missing = cli_ready()
        if missing:
            raise RuntimeError(missing)
        self.session_name = session_name or f"raina-{uuid.uuid4().hex[:10]}"
        if headed and running_in_container():
            log.warning(
                "容器内无显示器，已将 headed=True 降级为 headless（UI 场景 Agent / playwright-cli）"
            )
            headed = False
        self.headed = headed
        self.timeout_ms = max(3000, int(timeout_ms))
        self.cwd = Path(cwd or _RUNNER_DIR)
        self.use_cdp = use_cdp
        self.storage_state = storage_state
        self.extra_http_headers = extra_http_headers
        self.local_storage = local_storage
        self.cdp_endpoint: str | None = None
        self._opened = False
        self._pw = None
        self._browser = None
        self._context = None

    def _context_options(self) -> dict[str, Any]:
        opts: dict[str, Any] = {}
        if self.storage_state:
            opts["storage_state"] = self.storage_state
        if self.extra_http_headers:
            opts["extra_http_headers"] = dict(self.extra_http_headers)
        return opts

    def _argv(self, *parts: str) -> list[str]:
        return [
            "npx",
            "--no-install",
            "playwright-cli",
            f"-s={self.session_name}",
            "--raw",
            *parts,
        ]

    def run(self, *parts: str, check: bool = True) -> str:
        cmd = self._argv(*parts)
        log.debug("playwright-cli %s", " ".join(parts))
        try:
            proc = subprocess.run(
                cmd,
                cwd=str(self.cwd),
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
                timeout=max(30, self.timeout_ms // 1000 + 20),
            )
        except subprocess.TimeoutExpired as ex:
            raise RuntimeError(f"playwright-cli 超时: {' '.join(parts)}") from ex
        out = (proc.stdout or "").strip()
        err = (proc.stderr or "").strip()
        if check and proc.returncode != 0:
            raise RuntimeError(
                (err or out or f"playwright-cli exit {proc.returncode}")[-2000:]
            )
        return out

    def _open_via_cdp(self, url: str) -> None:
        from app.services.ui_automation.node_ui_runner import (
            cdp_endpoint_for_port,
            chromium_launch_args,
            free_cdp_port,
        )
        from playwright.sync_api import sync_playwright

        port = free_cdp_port()
        endpoint = cdp_endpoint_for_port(port)
        self._pw = sync_playwright().start()
        self._browser = self._pw.chromium.launch(
            headless=not self.headed,
            args=chromium_launch_args(cdp_port=port),
        )
        # Warm a page so Midscene / CLI have a target after attach.
        context = self._browser.new_context(**self._context_options())
        from app.services.ui_automation.ui_env_auth import local_storage_init_script

        init_js = local_storage_init_script(self.local_storage)
        if init_js:
            context.add_init_script(init_js)
        self._context = context
        page = context.new_page()
        page.goto("about:blank", wait_until="domcontentloaded", timeout=self.timeout_ms)
        self.cdp_endpoint = endpoint
        # Wait briefly for CDP HTTP to accept connections
        deadline = time.monotonic() + 8
        last_err = ""
        while time.monotonic() < deadline:
            try:
                self.run("attach", f"--cdp={endpoint}")
                last_err = ""
                break
            except Exception as ex:  # noqa: BLE001
                last_err = str(ex)
                time.sleep(0.25)
        if last_err:
            raise RuntimeError(f"playwright-cli attach CDP 失败: {last_err}") from None
        self.run("goto", url)
        self._opened = True

    def open(self, url: str) -> None:
        if self.use_cdp:
            try:
                self._open_via_cdp(url)
                return
            except Exception as ex:  # noqa: BLE001
                log.warning("CDP open failed, falling back to playwright-cli open: %s", ex)
                self._shutdown_cdp_browser()
                self.cdp_endpoint = None
        # @playwright/cli defaults to branded Chrome (/opt/google/chrome/chrome).
        # Docker / CI images only ship Playwright Chromium — force that channel.
        args = ["open", url, "--browser", "chromium"]
        if self.headed:
            args.append("--headed")
        self.run(*args)
        self._opened = True

    def goto(self, url: str) -> None:
        self.run("goto", url)

    def active_page(self) -> Any | None:
        if self._context is None:
            return None
        try:
            pages = list(self._context.pages)
            if pages:
                return pages[-1]
        except Exception:  # noqa: BLE001
            return None
        return None

    @staticmethod
    def snapshot_text_has_dialog(snapshot: str) -> bool:
        return bool(_SNAPSHOT_DIALOG_LINE.search(str(snapshot or "")))

    def dom_modal_visible(self) -> bool:
        """True when Ant Design modal wrap or [role=dialog] is visible (DOM ground truth)."""
        page = self.active_page()
        if page is None:
            return False
        try:
            return bool(
                page.evaluate(
                    """() => {
                      const visible = (el) => {
                        if (!el) return false;
                        const st = getComputedStyle(el);
                        if (st.display === 'none' || st.visibility === 'hidden') return false;
                        const op = parseFloat(st.opacity || '1');
                        if (Number.isFinite(op) && op < 0.02) return false;
                        const rect = el.getBoundingClientRect();
                        return rect.width > 0 && rect.height > 0;
                      };
                      const wraps = document.querySelectorAll('.ant-modal-wrap');
                      for (const wrap of wraps) {
                        if (visible(wrap)) return true;
                      }
                      const dialogs = document.querySelectorAll('[role="dialog"]');
                      for (const dlg of dialogs) {
                        if (visible(dlg)) return true;
                      }
                      return false;
                    }"""
                )
            )
        except Exception:  # noqa: BLE001
            log.debug("dom_modal_visible failed", exc_info=True)
            return False

    def dom_dialog_control_candidates(self) -> list[dict[str, str]]:
        """Named buttons/inputs inside the topmost visible dialog (for explore nudges)."""
        page = self.active_page()
        if page is None:
            return []
        try:
            raw = page.evaluate(
                """() => {
                  const visible = (el) => {
                    if (!el) return false;
                    const st = getComputedStyle(el);
                    if (st.display === 'none' || st.visibility === 'hidden') return false;
                    return true;
                  };
                  let root = null;
                  const dialogs = [...document.querySelectorAll('[role="dialog"]')].filter(visible);
                  if (dialogs.length) root = dialogs[dialogs.length - 1];
                  if (!root) {
                    const wrap = [...document.querySelectorAll('.ant-modal-wrap')].filter(visible).pop();
                    if (wrap) root = wrap.querySelector('.ant-modal') || wrap;
                  }
                  if (!root) return [];
                  const out = [];
                  const pushBtn = (el) => {
                    if (!(el instanceof HTMLElement) || !visible(el)) return;
                    const name = (el.innerText || el.getAttribute('aria-label') || '').trim().replace(/\\s+/g, ' ');
                    if (!name) return;
                    out.push({ role: 'button', name });
                  };
                  root.querySelectorAll('button, [role="button"]').forEach(pushBtn);
                  const inputs = root.querySelectorAll('input:not([type="hidden"]), textarea');
                  for (const el of inputs) {
                    if (!visible(el)) continue;
                    let label = el.getAttribute('aria-label') || el.getAttribute('placeholder') || '';
                    if (el.id) {
                      const lab = document.querySelector('label[for="' + CSS.escape(el.id) + '"]');
                      if (lab) label = (lab.innerText || '').trim() || label;
                    }
                    if (!label) {
                      const wrap = el.closest('.ant-form-item, [class*="form-item"]');
                      const lab = wrap && wrap.querySelector('label');
                      if (lab) label = (lab.innerText || '').trim();
                    }
                    const ariaRaw = el.getAttribute('aria-label') || '';
                    label = String(label || '').replace(/^\\s*[＊*]\\s*/, '').trim();
                    const role = el.tagName.toLowerCase() === 'textarea' ? 'textbox' : 'textbox';
                    const domId = el.id || '';
                    const ph = el.getAttribute('placeholder') || '';
                    if (label || domId) {
                      out.push({
                        role,
                        name: label || ph || domId,
                        dom_id: domId,
                        placeholder: ph,
                        accessible_name: ariaRaw || label,
                      });
                    }
                  }
                  return out.slice(0, 16);
                }"""
            )
        except Exception:  # noqa: BLE001
            log.debug("dom_dialog_control_candidates failed", exc_info=True)
            return []
        if not isinstance(raw, list):
            return []
        rows: list[dict[str, str]] = []
        for item in raw:
            if not isinstance(item, dict):
                continue
            role = str(item.get("role") or "").strip().lower() or "button"
            name = str(item.get("name") or "").strip()
            if not name:
                continue
            row = {"role": role, "name": name}
            dom_id = str(item.get("dom_id") or "").strip()
            if dom_id:
                row["dom_id"] = dom_id
            ph = str(item.get("placeholder") or "").strip()
            if ph:
                row["placeholder"] = ph
            acc = str(item.get("accessible_name") or "").strip()
            if acc:
                row["accessible_name"] = acc
            rows.append(row)
        return rows

    @staticmethod
    def role_name_candidates(name: str) -> list[str]:
        """Ant Design required fields often expose accessible name as «* 名称»."""
        raw = str(name or "").strip()
        if not raw:
            return []
        stripped = re.sub(r"^[\s*＊]+", "", raw).strip()
        out: list[str] = []
        for cand in (raw, stripped, f"* {stripped}" if stripped else "", f"＊ {stripped}" if stripped else ""):
            c = cand.strip()
            if c and c not in out:
                out.append(c)
        return out

    def _dialog_scope(self, page: Any) -> Any:
        try:
            dialog = page.get_by_role("dialog")
            count = dialog.count()
            if count > 0:
                last = dialog.nth(count - 1)
                if last.is_visible():
                    return last
        except Exception:  # noqa: BLE001
            pass
        return page

    def stabilize_modal(self, *, wait_ms: int = 300) -> None:
        page = self.active_page()
        if page is None:
            return
        try:
            page.wait_for_timeout(int(wait_ms))
            dialog = page.get_by_role("dialog")
            if dialog.count() > 0:
                dialog.nth(dialog.count() - 1).wait_for(state="visible", timeout=5000)
        except Exception:  # noqa: BLE001
            log.debug("stabilize_modal skipped", exc_info=True)

    def _resolve_unique_locator(
        self,
        root: Any,
        *,
        decision: dict[str, Any],
        target: str,
    ) -> tuple[Any | None, str]:
        """Resolve a unique Playwright locator + durable selector hint."""
        from app.services.ui_automation.ui_runner import resolve_page_locator

        blob = str(target or "").strip()
        role0 = str(decision.get("role") or "").strip().lower()
        if role0 == "input":
            role0 = "textbox"
        name0 = str(decision.get("name") or "").strip()
        placeholder0 = str(decision.get("placeholder") or "").strip()

        if blob.startswith("label="):
            label = blob.split("=", 1)[1].strip().strip("\"'")
            decision.setdefault("name", label)
            blob = f"label={label}"
        elif blob.startswith("placeholder="):
            ph = blob.split("=", 1)[1].strip().strip("\"'")
            decision.setdefault("placeholder", ph)
            blob = ph if not blob else blob

        attempts: list[str] = []
        if blob:
            attempts.append(blob)
        if placeholder0 and f"placeholder={placeholder0}" not in attempts:
            attempts.append(f"placeholder={placeholder0}")
        if role0 and name0:
            attempts.append(f"role={role0}[name=\"{name0}\"]")
        if role0 and name0:
            for cand in self.role_name_candidates(name0):
                attempts.append(f"role={role0}[name=\"{cand}\"]")

        seen: set[str] = set()
        for sel in attempts:
            if not sel or sel in seen:
                continue
            seen.add(sel)
            try:
                loc = resolve_page_locator(root, sel)
                if loc.count() == 1:
                    return loc, sel
            except Exception:  # noqa: BLE001
                continue

        if role0 and name0:
            for cand in self.role_name_candidates(name0):
                try:
                    scoped = root.get_by_role(role0, name=cand, exact=True)
                    if scoped.count() == 1:
                        decision["role"] = role0
                        decision["name"] = cand
                        return scoped, f"role={role0}[name=\"{cand}\"]"
                    scoped = root.get_by_role(role0, name=cand)
                    if scoped.count() == 1:
                        decision["role"] = role0
                        decision["name"] = cand
                        return scoped, f"role={role0}[name=\"{cand}\"]"
                except Exception:  # noqa: BLE001
                    continue
        return None, ""

    def cdp_fill(
        self,
        decision: dict[str, Any],
        target: str,
        text: str,
        *,
        timeout_ms: int | None = None,
    ) -> tuple[bool, str]:
        page = self.active_page()
        if page is None:
            return False, ""
        ms = int(timeout_ms or self.timeout_ms or 15000)
        root = self._dialog_scope(page)
        loc, hint = self._resolve_unique_locator(root, decision=decision, target=target)
        if loc is None:
            return False, ""
        try:
            loc.first.wait_for(state="visible", timeout=ms)
            loc.first.fill(str(text or ""), timeout=ms)
        except Exception as ex:  # noqa: BLE001
            log.debug("cdp_fill failed: %s", ex)
            return False, ""
        locator_expr = self._locator_expr_from_decision(decision, hint)
        return True, locator_expr

    def cdp_click(
        self,
        decision: dict[str, Any],
        target: str,
        *,
        timeout_ms: int | None = None,
    ) -> tuple[bool, str]:
        page = self.active_page()
        if page is None:
            return False, ""
        ms = int(timeout_ms or self.timeout_ms or 15000)
        root = self._dialog_scope(page)
        loc, hint = self._resolve_unique_locator(root, decision=decision, target=target)
        if loc is None:
            return False, ""
        try:
            loc.first.wait_for(state="visible", timeout=ms)
            loc.first.click(timeout=ms)
        except Exception as ex:  # noqa: BLE001
            log.debug("cdp_click failed: %s", ex)
            return False, ""
        return True, self._locator_expr_from_decision(decision, hint)

    def cdp_wait_for(
        self,
        decision: dict[str, Any],
        *,
        timeout_ms: int | None = None,
    ) -> bool:
        page = self.active_page()
        if page is None:
            return False
        ms = int(timeout_ms or self.timeout_ms or 15000)
        sel = str(decision.get("selector") or "").strip()
        state = str(decision.get("assert") or decision.get("value") or "visible").strip().lower()
        try:
            if state in ("networkidle", "load", "domcontentloaded"):
                page.wait_for_load_state(state, timeout=ms)
                return True
            if state == "url":
                expect = str(decision.get("value") or "")
                page.wait_for_url(f"**{expect}**", timeout=ms)
                return True
            if not sel:
                self.stabilize_modal()
                return True
            root = self._dialog_scope(page)
            from app.services.ui_automation.ui_runner import resolve_page_locator

            loc = resolve_page_locator(root, sel)
            loc.first.wait_for(
                state="hidden" if state == "hidden" else "visible",
                timeout=ms,
            )
            return True
        except Exception as ex:  # noqa: BLE001
            log.debug("cdp_wait_for failed: %s", ex)
            return False

    @staticmethod
    def _locator_expr_from_decision(decision: dict[str, Any], hint: str) -> str:
        import json as _json

        role = str(decision.get("role") or "").strip()
        name = str(decision.get("name") or "").strip()
        placeholder = str(decision.get("placeholder") or "").strip()
        if role and name:
            return (
                f"page.getByRole({_json.dumps(role, ensure_ascii=False)}, "
                f"{{ name: {_json.dumps(name, ensure_ascii=False)} }})"
            )
        if placeholder:
            return f"page.getByPlaceholder({_json.dumps(placeholder, ensure_ascii=False)})"
        hint = str(hint or "").strip()
        if hint.startswith("#") or hint.startswith("."):
            return f"page.locator({_json.dumps(hint, ensure_ascii=False)})"
        if hint.startswith("role="):
            return f"page.locator({_json.dumps(hint, ensure_ascii=False)})"
        return ""

    def snapshot(self, *, depth: int | None = 8) -> str:
        parts = ["snapshot"]
        if depth is not None:
            parts.append(f"--depth={int(depth)}")
        return self.run(*parts)

    def snapshot_for_explore(
        self,
        *,
        depth: int = 8,
        retry_depth: int = 16,
        stabilize_modal: bool = False,
    ) -> str:
        """Accessibility snapshot; deepen or annotate when DOM shows a modal but a11y lacks dialog."""
        if stabilize_modal and self.dom_modal_visible():
            self.stabilize_modal()
            snap = self.snapshot(depth=retry_depth)
            if self.snapshot_text_has_dialog(snap):
                return snap
        else:
            snap = self.snapshot(depth=depth)
        if not self.dom_modal_visible():
            return snap
        if self.snapshot_text_has_dialog(snap):
            return snap
        deeper = self.snapshot(depth=retry_depth)
        if self.snapshot_text_has_dialog(deeper):
            return deeper
        appendix = self._dom_dialog_snapshot_appendix()
        if appendix:
            return f"{snap.rstrip()}\n{appendix}"
        return snap

    def _dom_dialog_snapshot_appendix(self) -> str:
        """Synthetic dialog block so explore parsers scope candidates (refs are not actionable)."""
        rows = self.dom_dialog_control_candidates()
        if not rows:
            return ""
        lines = ['- dialog "（DOM 可见弹窗）"']
        for i, row in enumerate(rows):
            role = row.get("role") or "button"
            name = row.get("name") or ""
            if not name:
                continue
            dom_id = str(row.get("dom_id") or "").strip()
            suffix = f" 建议selector=#{dom_id}" if dom_id else ""
            lines.append(f'  - {role} "{name}" [ref=dom{i + 1}]{suffix}')
        return "\n".join(lines) if len(lines) > 1 else ""

    def screenshot(self) -> bytes:
        """PNG bytes of the current page. Prefer live CDP context; else playwright-cli."""
        page = None
        if self._context is not None:
            try:
                pages = list(self._context.pages)
                if pages:
                    page = pages[-1]
            except Exception:  # noqa: BLE001
                page = None
        if page is not None:
            try:
                data = page.screenshot(type="png", full_page=False)
                return bytes(data) if data else b""
            except Exception as ex:  # noqa: BLE001
                log.warning("context screenshot failed: %s", ex)
        tmp_path = ""
        try:
            with tempfile.NamedTemporaryFile(suffix=".png", prefix="explore-", delete=False) as tmp:
                tmp_path = tmp.name
            self.run("screenshot", tmp_path)
            data = Path(tmp_path).read_bytes()
            return data if data else b""
        except Exception as ex:  # noqa: BLE001
            log.warning("playwright-cli screenshot failed: %s", ex)
            return b""
        finally:
            if tmp_path:
                Path(tmp_path).unlink(missing_ok=True)

    def click(self, target: str) -> None:
        t = normalize_ref(target) if is_element_ref(target) else target
        self.run("click", t)

    def fill(self, target: str, text: str) -> None:
        t = normalize_ref(target) if is_element_ref(target) else target
        self.run("fill", t, text)

    def read_form_control_value(
        self,
        *,
        role: str = "",
        name: str = "",
        placeholder: str = "",
    ) -> str | None:
        """Read one grounded form control value through the attached CDP page.

        ``None`` means the control could not be identified uniquely. An empty
        string is a real observed value and therefore a failed non-empty fill.
        """
        page = None
        if self._context is not None:
            try:
                pages = list(self._context.pages)
                if pages:
                    page = pages[-1]
            except Exception:  # noqa: BLE001
                page = None
        if page is None:
            return None
        locator = None
        role0 = str(role or "").strip().lower()
        name0 = str(name or "").strip()
        placeholder0 = str(placeholder or "").strip()
        if role0 == "input":
            role0 = "textbox"
        try:
            if role0 and name0:
                names = [name0]
                normalized_name = re.sub(r"^[*\s]+", "", name0).strip()
                if normalized_name and normalized_name != name0:
                    names.append(normalized_name)
                for candidate in names:
                    exact = page.get_by_role(role0, name=candidate, exact=True)
                    if exact.count() == 1:
                        locator = exact
                        break
                    fuzzy = page.get_by_role(role0, name=candidate)
                    if fuzzy.count() == 1:
                        locator = fuzzy
                        break
            if locator is None and placeholder0:
                by_placeholder = page.get_by_placeholder(placeholder0, exact=True)
                if by_placeholder.count() == 1:
                    locator = by_placeholder
            if locator is None:
                return None
            return str(locator.input_value())
        except Exception:  # noqa: BLE001
            log.debug("read_form_control_value failed", exc_info=True)
            return None

    def press(self, key: str) -> None:
        self.run("press", key)

    def read_login_field_values(self) -> dict[str, str]:
        """Read username/password from the live page (accessible name / type / placeholder)."""
        page = None
        if self._context is not None:
            try:
                pages = list(self._context.pages)
                if pages:
                    page = pages[-1]
            except Exception:  # noqa: BLE001
                page = None
        if page is None:
            return {}
        try:
            raw = page.evaluate(
                """() => {
                  const userRe = /账号|用户名|username|user\\s*name|^user$/i;
                  const passRe = /密码|password|passwd|^pwd$/i;
                  const captchaRe = /验证码|captcha|verify|vcode|图中/i;
                  let username = '';
                  let password = '';
                  const nodes = Array.from(
                    document.querySelectorAll('input, textarea, [contenteditable="true"]')
                  );
                  for (const el of nodes) {
                    if (!(el instanceof HTMLElement)) continue;
                    const type = String(el.getAttribute('type') || '').toLowerCase();
                    if (type === 'hidden' || type === 'submit' || type === 'button') continue;
                    const labelBits = [
                      el.getAttribute('aria-label') || '',
                      el.getAttribute('placeholder') || '',
                      el.getAttribute('name') || '',
                      el.id || '',
                    ];
                    if (el.id) {
                      const lab = document.querySelector(`label[for="${CSS.escape(el.id)}"]`);
                      if (lab) labelBits.push(lab.textContent || '');
                    }
                    const blob = labelBits.join(' ');
                    if (captchaRe.test(blob)) continue;
                    const value =
                      el instanceof HTMLInputElement || el instanceof HTMLTextAreaElement
                        ? String(el.value || '')
                        : String(el.textContent || '');
                    if (!value.trim()) continue;
                    if (type === 'password' || passRe.test(blob)) {
                      if (!password) password = value;
                      continue;
                    }
                    if (userRe.test(blob) && !username) {
                      username = value;
                    }
                  }
                  return { username, password };
                }"""
            )
        except Exception:  # noqa: BLE001
            log.debug("read_login_field_values failed", exc_info=True)
            return {}
        if not isinstance(raw, dict):
            return {}
        out: dict[str, str] = {}
        user = str(raw.get("username") or "").strip()
        pwd = str(raw.get("password") or "").strip()
        if user:
            out["username"] = user
        if pwd:
            out["password"] = pwd
        return out

    def dump_storage_state(self) -> dict[str, Any] | None:
        if self._context is None:
            return None
        try:
            state = self._context.storage_state()
        except Exception:  # noqa: BLE001
            return None
        return state if isinstance(state, dict) else None

    def load_storage_state(self, state: dict[str, Any] | None) -> bool:
        """Merge cookies (and origins localStorage when possible) into the live CDP context."""
        if not state or not isinstance(state, dict) or self._context is None:
            return False
        ok = False
        cookies = state.get("cookies")
        if isinstance(cookies, list) and cookies:
            try:
                self._context.add_cookies(cookies)
                ok = True
            except Exception:  # noqa: BLE001
                log.debug("load_storage_state cookies failed", exc_info=True)
        origins = state.get("origins")
        if isinstance(origins, list) and origins:
            try:
                pages = list(self._context.pages)
                page = pages[-1] if pages else None
                if page is not None:
                    for origin in origins:
                        if not isinstance(origin, dict):
                            continue
                        origin_url = str(origin.get("origin") or "").strip()
                        items = origin.get("localStorage")
                        if not origin_url or not isinstance(items, list):
                            continue
                        pairs = [
                            (str(it.get("name") or ""), str(it.get("value") or ""))
                            for it in items
                            if isinstance(it, dict) and it.get("name") is not None
                        ]
                        if not pairs:
                            continue
                        page.evaluate(
                            """([originUrl, pairs]) => {
                              if (location.origin !== originUrl) return;
                              for (const [k, v] of pairs) localStorage.setItem(k, v);
                            }""",
                            [origin_url, pairs],
                        )
                        ok = True
            except Exception:  # noqa: BLE001
                log.debug("load_storage_state origins failed", exc_info=True)
        return ok

    def generate_locator(self, target: str) -> str:
        t = normalize_ref(target) if is_element_ref(target) else target
        raw = self.run("generate-locator", t)
        found = _LOCATOR_LINE.search(raw.replace("\n", " "))
        expr = found.group(1).strip() if found else (
            raw.strip().splitlines()[0].strip() if raw.strip() else ""
        )
        if is_snapshot_ref_locator(expr):
            return ""
        return expr

    def eval_on_ref(self, expression: str, target: str) -> str:
        """Run playwright-cli ``eval <expression> <ref>`` and return stdout."""
        t = normalize_ref(target) if is_element_ref(target) else target
        return self.run("eval", expression, t)

    def extract_locator_attrs(self, target: str) -> dict[str, str]:
        """Pull durable locator hints from the live DOM for a snapshot ref.

        Prefer testid / aria-label / placeholder / role+name; climb to a named
        button/link/textbox ancestor when the clicked node itself is nameless.
        """
        import json

        js = (
            "el => {"
            "  const roleOf = (node) => {"
            "    const explicit = (node.getAttribute('role') || '').toLowerCase();"
            "    if (explicit) return explicit;"
            "    const tag = (node.tagName || '').toLowerCase();"
            "    const type = (node.getAttribute('type') || '').toLowerCase();"
            "    if (tag === 'button' || (tag === 'input' && (type === 'button' || type === 'submit'))) return 'button';"
            "    if (tag === 'a') return 'link';"
            "    if (tag === 'input' || tag === 'textarea') return 'textbox';"
            "    if (tag === 'select') return 'combobox';"
            "    return 'generic';"
            "  };"
            "  const pick = (node) => {"
            "    if (!node || node.nodeType !== 1) return null;"
            "    const testid = node.getAttribute('data-testid') || node.getAttribute('data-test-id') || '';"
            "    const aria = (node.getAttribute('aria-label') || '').trim();"
            "    const title = (node.getAttribute('title') || '').trim();"
            "    const placeholder = (node.getAttribute('placeholder') || '').trim();"
            "    const labelledBy = node.getAttribute('aria-labelledby');"
            "    let labelled = '';"
            "    if (labelledBy) {"
            "      labelled = labelledBy.split(/\\s+/).map((id) => {"
            "        const n = document.getElementById(id);"
            "        return n ? (n.innerText || n.textContent || '').trim() : '';"
            "      }).filter(Boolean).join(' ').trim();"
            "    }"
            "    let text = (node.innerText || node.textContent || '').replace(/\\s+/g, ' ').trim();"
            "    if (text.length > 40) text = text.slice(0, 40);"
            "    const name = (aria || labelled || title || text || '').trim();"
            "    return {"
            "      testid, aria, title, placeholder,"
            "      role: roleOf(node), name,"
            "      tag: (node.tagName || '').toLowerCase()"
            "    };"
            "  };"
            "  const good = (p) => p && (p.testid || p.placeholder ||"
            "    (p.name && p.role && p.role !== 'generic'));"
            "  let cur = el;"
            "  let fallback = pick(el) || {};"
            "  for (let i = 0; i < 6 && cur; i++) {"
            "    const p = pick(cur);"
            "    if (good(p)) return JSON.stringify(p);"
            "    if (p && p.name && !fallback.name) fallback = p;"
            "    cur = cur.parentElement;"
            "  }"
            "  return JSON.stringify(fallback);"
            "}"
        )
        try:
            raw = self.eval_on_ref(js, target)
        except Exception as ex:  # noqa: BLE001
            log.info("extract_locator_attrs eval failed: %s", ex)
            return {}
        text = (raw or "").strip()
        start = text.find("{")
        end = text.rfind("}")
        if start < 0 or end <= start:
            return {}
        try:
            data = json.loads(text[start : end + 1])
        except json.JSONDecodeError:
            return {}
        if not isinstance(data, dict):
            return {}
        out: dict[str, str] = {}
        for key in ("testid", "aria", "title", "placeholder", "role", "name", "tag"):
            val = data.get(key)
            if val is None:
                continue
            s = str(val).strip()
            if s:
                out[key] = s
        return out

    def _shutdown_cdp_browser(self) -> None:
        if self._browser is not None:
            try:
                self._browser.close()
            except Exception:  # noqa: BLE001
                pass
            self._browser = None
        self._context = None
        if self._pw is not None:
            try:
                self._pw.stop()
            except Exception:  # noqa: BLE001
                pass
            self._pw = None

    def close(self) -> None:
        if self._opened:
            try:
                if self.cdp_endpoint:
                    self.run("detach", check=False)
                else:
                    self.run("close", check=False)
            except Exception:  # noqa: BLE001
                pass
            self._opened = False
        else:
            try:
                self.run("close", check=False)
            except Exception:  # noqa: BLE001
                pass
        self._shutdown_cdp_browser()
        self.cdp_endpoint = None
        try:
            self.run("delete-data", check=False)
        except Exception:  # noqa: BLE001
            pass


def join_explore_url(base_url: str, start_path: str) -> str:
    base = (base_url or "").rstrip("/")
    path = start_path if str(start_path).startswith("/") else f"/{start_path or ''}"
    if not path:
        path = "/"
    return f"{base}{path}"


def unique_session_name(prefix: str = "raina") -> str:
    return f"{prefix}-{int(time.time())}-{uuid.uuid4().hex[:6]}"
