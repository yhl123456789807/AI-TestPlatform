"""Shared Midscene usage policy for LLM prompts that generate/revise UI scripts."""

# Appended to review / revise / run-fix system prompts.
MIDSCENE_SCRIPT_POLICY = (
    "交互优先 Playwright（稳定性：getByTestId > getByRole+name > getByLabel > "
    "getByPlaceholder > getByText > locator）。"
    "非验证码步骤禁止新增 agent.aiTap / agent.aiInput / agent.aiKeyboardPress；"
    "若输入脚本已有此类调用且 explored_locators（或探索编译脚本）能提供等价 Playwright locator，"
    "必须改回 Playwright。"
    "仅当探索步明确无稳定 locator（含 generate-locator/DOM 恢复失败，或 canvas / 纯图片）"
    "且无 Playwright 等价写法时，才可保留 Midscene 视觉步（aiTap/aiInput）。"
    "验证码仅允许 agent.aiQuery 读图 + Playwright fill；禁止 aiInput 操作验证码，禁止写死验证码字符。"
    "禁止把笼统说法当点击目标，必须用页面 snapshot / 探索轨迹中的真实可访问名（role+name、placeholder、label）。"
)

# Shorter form for explore decide / task text (action JSON, not full scripts).
MIDSCENE_EXPLORE_POLICY = (
    "驱动默认 Playwright（snapshot 的 ref / role+name / label / placeholder / testid）。"
    "仅当 snapshot 无可用 ref/role/name，目标为 canvas / 纯图片验证码，"
    "或探索已操作但无法恢复稳定 locator 时，才设/保留 driver=midscene + prompt/locate。"
    "弹窗提交、侧栏链接、列表入口等有可见可访问名的控件必须用 Playwright，禁止 midscene。"
    "验证码：midscene 只读图；填框与点登录/提交用 Playwright；读图后勿重复读图。"
)
