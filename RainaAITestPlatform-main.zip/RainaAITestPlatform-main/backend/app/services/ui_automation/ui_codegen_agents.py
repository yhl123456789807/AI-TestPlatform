"""Grounded multi-agent code generation and verify/repair pipeline for UI explore."""

from __future__ import annotations

import json
import logging
import re
import tempfile
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any, Callable
from urllib.parse import urlparse

from app.services.ai.effective_ai_settings import LlmRuntime
from app.services.ai import llm as llm_client
from app.services.ui_automation.ui_node_script import (
    is_runnable_ui_script,
    script_has_assert,
)
from app.services.ui_automation.ui_script_midscene_policy import MIDSCENE_SCRIPT_POLICY
from app.config import settings

log = logging.getLogger(__name__)

_OBSERVE_ASSERT = "__OBSERVE_VALIDATION__"
_ERROR_TEXT = re.compile(
    r"必填|不能为空|格式.{0,8}(错误|不正确)|无效|校验|请输入|请选择|已存在|失败|error|required|invalid",
    re.I,
)
_NAVIGATION_TEXT = re.compile(
    r"进入|管理|列表|菜单|模块|项目|需求|工作台|首页|详情|"
    r"enter|manage|list|menu|module|project|requirement|dashboard|home|detail",
    re.I,
)
_MUTATION_TEXT = re.compile(
    r"新增|新建|创建|添加|编辑|修改|更新|删除|保存|提交|确认|"
    r"create|add|edit|update|delete|remove|save|submit|confirm",
    re.I,
)


def _strip_fence(raw: str) -> str:
    text = str(raw or "").strip()
    if text.startswith("```"):
        lines = text.splitlines()[1:]
        if lines and lines[-1].strip() == "```":
            lines.pop()
        text = "\n".join(lines).strip()
    return text + ("\n" if text and not text.endswith("\n") else "")


def _extract_json(raw: str) -> dict[str, Any]:
    text = _strip_fence(raw).strip()
    try:
        data = json.loads(text)
    except json.JSONDecodeError:
        start = text.find("{")
        end = text.rfind("}")
        if start < 0 or end <= start:
            raise
        data = json.loads(text[start : end + 1])
    if not isinstance(data, dict):
        raise ValueError("LLM 输出不是 JSON 对象")
    return data


def _chat(llm: LlmRuntime, messages: list[dict[str, str]], *, scene: str) -> str:
    return llm_client.chat_complete(
        messages,
        model=None,
        db=None,
        cfg=llm,
        json_mode=False,
        scene=scene,
    )


def _trace_summary(trace: list[dict[str, Any]]) -> list[dict[str, Any]]:
    from app.services.ui_automation.ui_explore_report import (
        _collapse_trace_for_bind,
        _trace_summary_for_derive,
    )

    return _trace_summary_for_derive(_collapse_trace_for_bind(trace))


def _observed_evidence(summary: list[dict[str, Any]]) -> tuple[set[str], set[str]]:
    texts: set[str] = set()
    urls: set[str] = set()
    for item in summary:
        observe = item.get("observe") if isinstance(item.get("observe"), dict) else {}
        url = str(observe.get("url_after") or "").strip()
        if url:
            urls.add(url)
        for text in observe.get("new_text") or []:
            value = str(text or "").strip()
            if value:
                texts.add(value)
    return texts, urls


def _ground_asserts(
    raw: Any,
    *,
    texts: set[str],
    urls: set[str],
) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    for item in raw if isinstance(raw, list) else []:
        if not isinstance(item, dict):
            continue
        action = str(item.get("action") or item.get("type") or "").strip()
        value = str(item.get("value") or item.get("text") or item.get("url") or "").strip()
        if action not in ("assert_text", "assert_visible", "assert_url") or not value:
            continue
        if action == "assert_url":
            grounded = any(value in url or url in value for url in urls)
        else:
            grounded = any(value in text or text in value for text in texts)
        if grounded:
            out.append(
                {
                    "action": action,
                    "target": value,
                    "value": value,
                    "driver": "playwright",
                    "ready": True,
                }
            )
    return out


def design_cases(
    *,
    prompt: str,
    goal: str,
    trace: list[dict[str, Any]],
    llm: LlmRuntime,
    start_path: str = "/",
    checklist: list[str] | None = None,
    case_name: str | None = None,
) -> list[dict[str, Any]]:
    """Design grounded cases using contiguous ranges over the explored trace."""
    from app.services.ui_automation.ui_explore_report import (
        MODAL_FRAGMENT_CASE_BAN,
        _apply_login_prefix_to_matrix,
        _collapse_trace_for_bind,
        _finalize_hydrated_row,
        filter_modal_fragment_matrix,
        _trace_summary_for_derive,
        _trace_item_to_step,
        test_design_actions,
    )

    collapsed = _collapse_trace_for_bind(trace)
    summary = _trace_summary_for_derive(collapsed)
    if not summary:
        return []
    texts, urls = _observed_evidence(summary)
    design_actions = test_design_actions(
        prompt=prompt,
        goal=goal,
        checklist=list(checklist or []),
    )
    messages = [
        {
            "role": "system",
            "content": (
                "你是 UI 测试用例设计 subagent。只输出 JSON 对象 {\"cases\": [...]}。"
                "每项包含 id、name、start_i、end_i、negative、variant、asserts。"
                "start_i/end_i 必须是 trace 中存在的索引，且表示连续区间；禁止平均切分或拼接不连续步骤。"
                "asserts 每项仅允许 action=assert_text|assert_visible|assert_url 和 value；"
                "文本或 URL 必须逐字来自 trace.observe，禁止把自然语言 expected 当页面文本。"
                "负向/字段校验用例设 negative=true、assert_pending=true，variant.field 和 "
                "variant.mode=empty|required|invalid；不要虚构错误文案。"
                "登录只作为必要前缀，不要重复设计多条登录用例。"
                "必须至少有 1 条 happy path：start_i～end_i 覆盖从进入业务模块到至少一次成功提交/保存的连续区间。"
                "case name 用业务语言（如「新增需求文档并在列表可见」），勿用技术步骤堆砌。"
                f"{MODAL_FRAGMENT_CASE_BAN}"
                "若 required_business_actions 非空：须为其中每个动作各至少 1 条 case，"
                "且 name 中须体现该动作；轨迹中无对应步骤时不要编造，勿用弹窗碎片凑数。"
            ),
        },
        {
            "role": "user",
            "content": json.dumps(
                {
                    "prompt": prompt[:1000],
                    "goal": goal,
                    "checklist": list(checklist or [])[:20],
                    "start_path": start_path,
                    "case_name": case_name,
                    "required_business_actions": design_actions,
                    "trace": summary,
                },
                ensure_ascii=False,
            )[:24000],
        },
    ]
    data = _extract_json(_chat(llm, messages, scene="UI Codegen CaseDesigner"))
    raw_cases = data.get("cases") or data.get("matrix") or []
    valid_indexes = [int(item["i"]) for item in summary if isinstance(item.get("i"), int)]
    low, high = min(valid_indexes), max(valid_indexes)
    rows: list[dict[str, Any]] = []
    for pos, raw in enumerate(raw_cases if isinstance(raw_cases, list) else [], start=1):
        if not isinstance(raw, dict):
            continue
        try:
            start_i = max(low, int(raw.get("start_i")))
            end_i = min(high, int(raw.get("end_i")))
        except (TypeError, ValueError):
            continue
        if end_i < start_i:
            continue
        steps = [
            step
            for i in range(start_i, end_i + 1)
            if i < len(collapsed) and (step := _trace_item_to_step(collapsed[i])) is not None
        ]
        if not steps:
            continue
        negative = bool(raw.get("negative"))
        variant = raw.get("variant") if isinstance(raw.get("variant"), dict) else {}
        field = str(variant.get("field") or "").strip()
        mode = str(variant.get("mode") or "").strip().lower()
        if negative and field:
            for step in steps:
                if str(step.get("action") or "") != "fill":
                    continue
                blob = " ".join(str(step.get(k) or "") for k in ("name", "placeholder", "locate", "target"))
                if field in blob:
                    step["value"] = "" if mode in ("empty", "required", "blank") else str(
                        variant.get("value") or "invalid"
                    )
                    break
        assertions = _ground_asserts(raw.get("asserts"), texts=texts, urls=urls)
        steps.extend(assertions)
        row = _finalize_hydrated_row(
            {
                "id": str(raw.get("id") or f"TC-{pos:02d}"),
                "name": str(raw.get("name") or case_name or goal or f"用例 {pos}")[:80],
                "start_url": str(raw.get("start_url") or start_path or "/"),
                "expected": "",
                "negative": negative,
                "assert_pending": negative and not assertions,
                "trace_range": [start_i, end_i],
            },
            steps,
        )
        # Pending negative assertions are completed by the observation run.
        if row.get("assert_pending"):
            row["ready"] = True
            row["has_assert"] = False
        rows.append(row)
    rows = filter_modal_fragment_matrix(rows)
    return _apply_login_prefix_to_matrix(rows)


def _trace_item_action(item: dict[str, Any]) -> str:
    kind = str(item.get("kind") or item.get("action") or "").strip().lower()
    if kind in ("tap", "ai_tap"):
        return "click"
    if kind in ("input", "ai_input"):
        return "fill"
    if kind == "fill_captcha":
        return "fill"
    return kind


def build_locator_catalog(
    trace_slice: list[dict[str, Any]],
    *,
    row_steps: list[dict[str, Any]] | None = None,
    navigation_prefix: list[dict[str, Any]] | None = None,
) -> list[dict[str, Any]]:
    """Structured locators + observe hints from explore trace for CaseCoder."""
    from app.services.ui_automation.playwright_cli_session import is_snapshot_ref_locator

    catalog: list[dict[str, Any]] = []
    idx = 0
    for item in [
        *(navigation_prefix or []),
        *(row_steps or []),
        *trace_slice,
    ]:
        if not isinstance(item, dict):
            continue
        if str(item.get("status") or "").lower() == "error":
            continue
        action = _trace_item_action(item)
        cli = str(item.get("cli_locator") or "").strip()
        if cli and is_snapshot_ref_locator(cli):
            cli = ""
        selector = str(item.get("selector") or "").strip()
        if selector and is_snapshot_ref_locator(selector):
            selector = ""
        observe = item.get("observe") if isinstance(item.get("observe"), dict) else {}
        observe_texts = [
            str(t).strip() for t in (observe.get("new_text") or []) if str(t or "").strip()
        ]
        url_after = str(observe.get("url_after") or "").strip()
        role = str(item.get("role") or "").strip()
        name = str(item.get("name") or "").strip()
        placeholder = str(item.get("placeholder") or "").strip()
        has_locator = bool(cli or placeholder or (role and name) or selector)
        if action == "goto" or has_locator or observe_texts:
            entry: dict[str, Any] = {
                "i": idx,
                "action": action,
                "cli_locator": cli,
                "role": role,
                "name": name,
                "placeholder": placeholder,
                "selector": selector,
                "observe_texts": observe_texts,
                "url_after": url_after,
            }
            if action in ("fill", "input"):
                entry["value"] = str(item.get("value") or "")
            if action == "goto":
                entry["path"] = _relative_path(
                    str(item.get("path") or item.get("value") or item.get("target") or "")
                )
            if action == "press":
                entry["key"] = str(item.get("value") or "Enter")
            catalog.append(entry)
            idx += 1
    return catalog


def catalog_has_actionable_locators(catalog: list[dict[str, Any]]) -> bool:
    for entry in catalog:
        if not isinstance(entry, dict):
            continue
        if str(entry.get("action") or "") == "goto" and str(entry.get("path") or "").strip():
            return True
        if str(entry.get("cli_locator") or "").strip():
            return True
        if str(entry.get("placeholder") or "").strip():
            return True
        if str(entry.get("role") or "").strip() and str(entry.get("name") or "").strip():
            return True
        if str(entry.get("selector") or "").strip():
            return True
    return False


def _locator_evidence(
    row: dict[str, Any],
    trace_slice: list[dict[str, Any]],
    *,
    catalog: list[dict[str, Any]] | None = None,
) -> str:
    if catalog:
        blob = json.dumps(catalog, ensure_ascii=False)
        if blob:
            return blob
    values: list[str] = []
    for item in [
        *(row.get("steps") or []),
        *(row.get("navigation_prefix") or []),
        *trace_slice,
    ]:
        if not isinstance(item, dict):
            continue
        for key in ("cli_locator", "selector", "role", "name", "placeholder", "locate", "target"):
            value = str(item.get(key) or "").strip()
            if value and value not in values:
                values.append(value)
    return "\n".join(values)


def _script_locator_literals(script: str) -> set[str]:
    """Extract selector/name evidence, excluding Playwright's standard ARIA role argument."""
    values: set[str] = set()
    for method, call in re.findall(
        r"(getBy(?:Role|Text|Label|Placeholder)|locator)\(([^\n;]+?)\)",
        script or "",
    ):
        literals = re.findall(r"['\"]([^'\"]+)['\"]", call)
        if method == "getByRole" and literals:
            literals = literals[1:]  # button/dialog/row/... are API roles, not invented evidence.
        values.update(literals)
    return values


def _business_action(row: dict[str, Any]) -> str:
    text = " ".join(
        str(row.get(key) or "") for key in ("id", "name", "expected")
    ).lower()
    if re.search(r"删除|delete|remove", text):
        return "delete"
    if re.search(r"编辑|修改|更新|edit|update", text):
        return "edit"
    if re.search(r"新增|新建|创建|添加|create|add", text):
        return "create"
    return ""


def _relative_path(value: str) -> str:
    text = str(value or "").strip()
    if not text:
        return ""
    parsed = urlparse(text)
    if parsed.scheme or parsed.netloc:
        path = parsed.path or "/"
        return path + (f"?{parsed.query}" if parsed.query else "")
    return text if text.startswith("/") else ""


def _is_navigation_trace_item(item: dict[str, Any]) -> bool:
    kind = str(item.get("kind") or item.get("action") or "").strip().lower()
    if kind == "goto":
        return True
    if kind not in ("click", "tap"):
        return False
    blob = " ".join(
        str(item.get(key) or "")
        for key in ("name", "locate", "selector", "cli_locator", "prompt", "reason")
    )
    role = str(item.get("role") or "").lower()
    if _MUTATION_TEXT.search(blob):
        return False
    return role in ("link", "menuitem", "tab") or bool(_NAVIGATION_TEXT.search(blob))


def _navigation_context(
    trace: list[dict[str, Any]],
    row: dict[str, Any],
) -> dict[str, Any]:
    """Ground an independent case with the route/menu steps observed before its first action."""
    cid = str(row.get("id") or "")
    cutoff: int | None = next(
        (
            i
            for i, item in enumerate(trace)
            if isinstance(item, dict) and cid and str(item.get("case_id") or "") == cid
        ),
        None,
    )
    if cutoff is None:
        span = row.get("trace_range")
        if isinstance(span, list) and len(span) == 2:
            try:
                cutoff = max(0, int(span[0]))
            except (TypeError, ValueError):
                cutoff = None
    before = trace[:cutoff] if cutoff is not None else []
    prefix = [
        dict(item)
        for item in before
        if isinstance(item, dict)
        and item.get("status") != "error"
        and _is_navigation_trace_item(item)
    ][-12:]
    path = ""
    for item in reversed(before):
        if not isinstance(item, dict):
            continue
        observe = item.get("observe") if isinstance(item.get("observe"), dict) else {}
        path = _relative_path(
            str(observe.get("url_after") or item.get("path") or item.get("value") or "")
        )
        if path and not re.search(r"/(?:login|signin|auth)(?:/|$)", path, re.I):
            break
        path = ""
    if path == "/":
        path = ""
    return {
        "start_path": path,
        "steps": prefix,
    }


def script_semantic_issues(script: str, row: dict[str, Any] | None = None) -> list[str]:
    """Detect false-positive patterns that a successful Playwright process cannot reveal."""
    code = script or ""
    meta = row or {}
    issues: list[str] = []
    if re.search(
        r"\.catch\s*\(\s*(?:\(\s*\)|[a-zA-Z_$][\w$]*)\s*=>\s*\{\s*\}\s*\)",
        code,
    ):
        issues.append("禁止用空 catch 吞掉关键步骤失败")
    if re.search(r"catch\s*\([^)]*\)\s*\{\s*\}", code):
        issues.append("禁止使用空 catch 块")

    action = _business_action(meta)
    if not action:
        return issues

    gotos = re.findall(r"page\.goto\(\s*['\"]([^'\"]+)['\"]", code)
    has_non_root_goto = any(_relative_path(path).rstrip("/") for path in gotos)
    nav_vars = re.findall(
        r"(?:const|let)\s+([a-zA-Z_$][\w$]*)\s*=\s*"
        r"page\.getByRole\(\s*['\"](?:link|menuitem|tab)['\"]",
        code,
        re.I,
    )
    has_module_navigation = any(
        re.search(rf"\b{re.escape(var)}(?:\.first\(\))?\.click\(\)", code)
        for var in nav_vars
    ) or bool(
        re.search(
            r"getByRole\(\s*['\"](?:link|menuitem|tab)['\"][^\n;]*\)"
            r"(?:\.first\(\))?\.click\(\)",
            code,
            re.I,
        )
        or re.search(
            r"getBy(?:Text|Role)\([^\n;]*(?:进入|管理|列表|项目|需求|模块)"
            r"[^\n;]*\)(?:\.first\(\))?\.click\(\)",
            code,
            re.I,
        )
    )
    if not has_non_root_goto and not has_module_navigation:
        issues.append("业务增删改用例缺少进入目标项目/模块的前置导航，禁止从 / 直接操作")

    # Mutation controls must be scoped to a target row/card/dialog, not the whole page's first match.
    global_mutation = re.search(
        r"page\.getByRole\(\s*['\"]button['\"]\s*,\s*\{[^}]*"
        r"name\s*:\s*['\"][^'\"]*(?:编辑|修改|删除|delete|edit)[^'\"]*['\"][^}]*\}"
        r"\s*\)(?:\.first\(\))?",
        code,
        re.I,
    )
    if global_mutation and action == "delete":
        issues.append("删除按钮必须限定在目标记录作用域内，禁止从 page 全局取 first")
    if global_mutation and action == "edit":
        heading_vars = re.findall(
            r"(?:const|let)\s+([a-zA-Z_$][\w$]*)\s*=\s*"
            r"page\.getByRole\(\s*['\"]heading['\"]",
            code,
        )
        selected_detail = any(
            re.search(rf"\b{re.escape(var)}(?:\.first\(\))?\.click\(\)", code)
            for var in heading_vars
        ) or bool(
            re.search(
                r"page\.getBy(?:Text|Role)\([^\n;]+\)(?:\.first\(\))?\.click\(\)",
                code,
            )
        )
        if not selected_detail:
            issues.append("编辑按钮位于列表页时必须先限定或进入目标记录，禁止直接取全局 first")
    if re.search(
        r"page\.getByRole\(\s*['\"]button['\"]\s*,\s*\{[^}]*"
        r"name\s*:\s*['\"]\s*(?:确\s*定|保存|提交)\s*['\"][^}]*\}\s*\)",
        code,
        re.I,
    ):
        issues.append("确认按钮必须限定在当前 dialog/form 作用域内")

    if action == "delete":
        if not re.search(
            r"(?:toHaveCount\(\s*0\s*\)|not\.toBeVisible\(|toBeHidden\()",
            code,
        ):
            issues.append("删除用例必须断言目标记录消失（toHaveCount(0)/not.toBeVisible/toBeHidden）")
        return issues

    # Create/edit must assert the exact value written by the case, not only a generic toast.
    fill_values = [
        value
        for value in re.findall(r"\.fill\(\s*['\"]([^'\"]{2,200})['\"]\s*\)", code)
        if value not in ("invalid", _OBSERVE_ASSERT)
    ]
    if fill_values:
        exact_assert = any(
            re.search(
                rf"getByText\(\s*['\"]{re.escape(value)}['\"]\s*,\s*\{{[^}}]*"
                r"exact\s*:\s*true",
                code,
            )
            for value in fill_values
        )
        if not exact_assert:
            issues.append(
                f"{'编辑' if action == 'edit' else '新增'}用例必须精确断言至少一个写入后的业务值"
            )
    else:
        issues.append(f"{'编辑' if action == 'edit' else '新增'}用例缺少可验证的写入值")
    return issues


def _codegen_guard_strict() -> bool:
    return str(settings.ui_codegen_guard or "off").strip().lower() == "strict"


def guard_script(
    script: str,
    *,
    draft: str,
    row: dict[str, Any],
    trace_slice: list[dict[str, Any]],
    credentials: list[str] | None = None,
    catalog: list[dict[str, Any]] | None = None,
    fallback_on_error: bool = True,
) -> tuple[str, list[str]]:
    """Reject structurally unsafe output; optionally return grounded template fallback."""
    errors: list[str] = []
    code = _strip_fence(script)
    if not is_runnable_ui_script(code):
        errors.append("缺少 async function run")
        if not fallback_on_error:
            return "", errors
        return draft if draft and is_runnable_ui_script(draft) else "", errors
    if not _codegen_guard_strict():
        return code, []
    if not script_has_assert(code) and _OBSERVE_ASSERT not in code:
        errors.append("缺少断言")
    errors.extend(script_semantic_issues(code, row))
    for secret in credentials or []:
        if secret and len(secret) >= 4 and secret in code:
            errors.append("包含明文凭据")
            break
    evidence = _locator_evidence(row, trace_slice, catalog=catalog)
    steps_blob = json.dumps(row.get("steps") or [], ensure_ascii=False)
    for value in _script_locator_literals(code):
        if not value or value == _OBSERVE_ASSERT:
            continue
        if value not in evidence and value not in steps_blob:
            errors.append(f"定位器无探索依据: {value[:80]}")
            break
    if errors:
        if not fallback_on_error:
            return "", errors
        fallback = draft
        if row.get("assert_pending") and fallback and _OBSERVE_ASSERT not in fallback:
            fallback = fallback.replace(
                "\n}",
                f"\n  await expect(page.getByText('{_OBSERVE_ASSERT}')).toBeVisible();\n}}",
                1,
            )
        return fallback, errors
    return code, []


def code_case(
    *,
    row: dict[str, Any],
    trace_slice: list[dict[str, Any]],
    draft: str,
    llm: LlmRuntime,
    credentials: list[str] | None = None,
    catalog: list[dict[str, Any]] | None = None,
    llm_primary: bool = False,
    fallback_on_error: bool | None = None,
) -> tuple[str, list[str]]:
    """Have one CaseCoder subagent write or refine a Playwright script from explore evidence."""
    if catalog is None:
        catalog = build_locator_catalog(
            trace_slice,
            row_steps=list(row.get("steps") or []),
            navigation_prefix=list(row.get("navigation_prefix") or []),
        )
    primary_rules = (
        "PRIMARY 模式：禁止照抄 matrix steps 里的空 assert；"
        "只能使用 locator_catalog 中的 cli_locator 或 role/name/placeholder；"
        "不得输出 getByText('assert_visible') 或用例标题当断言。"
        if llm_primary
        else ""
    )
    draft_note = (
        "template_draft 仅作结构参考，可全部重写。"
        if llm_primary
        else "可在 template_draft 基础上润色。"
    )
    messages = [
        {
            "role": "system",
            "content": (
                "你是 UI 自动化 CaseCoder subagent。输出完整 Node.js Playwright 脚本，不要 Markdown。"
                "必须定义 async function run(page, agent)，不要 import。goto 只能用相对路径。"
                "账号密码只从 env.username/env.password 等环境变量读取。"
                "只能使用输入给出的 locator_catalog / locator_candidates，不得编造定位器；优先 Playwright，"
                "只有候选为空时才可用 agent.aiTap/aiInput。补充必要的 URL、弹窗、可见性等待。"
                "每条脚本必须可独立执行：优先 goto navigation.start_path；若为空或不稳定，"
                "必须在业务操作前按 navigation.steps 重放进入项目和目标模块的菜单步骤。"
                "禁止只 goto('/') 就直接执行新增、编辑或删除。"
                "禁止任何空 catch、.catch(() => {}) 或把关键等待失败吞掉。"
                "编辑/删除按钮必须限定在目标行或卡片内，确认按钮必须限定在 dialog/form 内。"
                "新增必须精确断言新增值出现；编辑必须精确断言新值出现；"
                "删除必须断言目标记录 toHaveCount(0)、not.toBeVisible 或 toBeHidden。"
                "断言只能来自 observe_texts 或本用例实际写入的值。negative 且 assert_pending 时保留"
                f" getByText('{_OBSERVE_ASSERT}') 占位断言，供观察跑替换。"
                f"{primary_rules}{draft_note}"
                f"{MIDSCENE_SCRIPT_POLICY}"
            ),
        },
        {
            "role": "user",
            "content": json.dumps(
                {
                    "case": row,
                    "trace": trace_slice,
                    "navigation": {
                        "start_path": row.get("navigation_start_path") or "",
                        "steps": row.get("navigation_prefix") or [],
                    },
                    "locator_catalog": catalog,
                    "locator_candidates": _locator_evidence(
                        row, trace_slice, catalog=catalog
                    ),
                    **(
                        {}
                        if llm_primary
                        else {"template_draft": draft}
                    ),
                    "llm_primary": llm_primary,
                },
                ensure_ascii=False,
            )[:28000],
        },
    ]
    raw = _chat(llm, messages, scene="UI Codegen CaseCoder")
    if fallback_on_error is None:
        fallback_on_error = not llm_primary
    return guard_script(
        raw,
        draft=draft,
        row=row,
        trace_slice=trace_slice,
        credentials=credentials,
        catalog=catalog,
        fallback_on_error=fallback_on_error,
    )


def _failed_step(rows: list[dict[str, Any]]) -> dict[str, Any] | None:
    return next(
        (
            item
            for item in reversed(rows)
            if isinstance(item, dict) and str(item.get("status") or "") in ("failed", "error")
        ),
        None,
    )


def _validation_text(snapshot: str) -> str:
    for raw in (snapshot or "").splitlines():
        line = re.sub(r"^\\s*-?\\s*(?:text|alert|status)?\\s*[:=]?\\s*", "", raw).strip(" '\"")
        if 1 < len(line) <= 120 and _ERROR_TEXT.search(line):
            return line
    return ""


def _repair_script(
    *,
    script: str,
    row: dict[str, Any],
    failure: dict[str, Any],
    llm: LlmRuntime,
) -> str:
    snapshot = str(
        failure.get("failure_snapshot")
        or (failure.get("detail_json") or {}).get("failure_snapshot")
        or ""
    )
    if _OBSERVE_ASSERT in script:
        text = _validation_text(snapshot)
        if text:
            return script.replace(_OBSERVE_ASSERT, text.replace("'", "\\'"), 1)
    messages = [
        {
            "role": "system",
            "content": (
                "你是 UI 脚本 Repairer subagent。只输出 JSON 对象 "
                '{"patches":[{"old":"脚本中的原文","new":"替换文本","rationale":"原因"}]}。'
                "做最小替换；old 必须逐字存在；不得编造 failure_snapshot 中没有的页面文本或 locator。"
            ),
        },
        {
            "role": "user",
            "content": json.dumps(
                {"case": row, "script": script, "failure": failure},
                ensure_ascii=False,
            )[:24000],
        },
    ]
    data = _extract_json(_chat(llm, messages, scene="UI Codegen Repairer"))
    patches = [p for p in (data.get("patches") or []) if isinstance(p, dict)]
    if not patches:
        return script
    # Local import avoids ui_scenario_agent → engines → codegen → ui_run_fix cycle.
    from app.services.ui_automation.ui_run_fix import apply_script_patches

    return apply_script_patches(script, patches)


def _unsafe_repair_issues(
    candidate: str,
    *,
    baseline: str,
    row: dict[str, Any],
    failure: dict[str, Any],
    credentials: list[str] | None = None,
) -> list[str]:
    """Reject repairs that break the script, leak secrets, or invent ungrounded locators."""
    issues: list[str] = []
    if not is_runnable_ui_script(candidate):
        issues.append("修复结果不是可执行的 Node UI 脚本")
    for secret in credentials or []:
        if secret and len(secret) >= 4 and secret in candidate:
            issues.append("修复结果包含明文凭据")
            break
    original_locators = _script_locator_literals(baseline)
    evidence = json.dumps(row, ensure_ascii=False) + str(failure.get("failure_snapshot") or "")
    invented = [
        value
        for value in _script_locator_literals(candidate) - original_locators
        if value and value not in evidence
    ]
    if invented:
        issues.append(f"修复结果包含无失败现场依据的新定位器: {invented[0][:80]}")
    return issues


def repair_trial_script(
    *,
    script: str,
    row: dict[str, Any],
    failure: dict[str, Any],
    llm: LlmRuntime,
    credentials: list[str] | None = None,
) -> tuple[str, list[str]]:
    """Repair one failed manual trial and reject unsafe patches (trial skips semantic lint)."""
    try:
        repaired = _repair_script(script=script, row=row, failure=failure, llm=llm)
    except Exception as ex:  # noqa: BLE001
        return script, [f"AI 修复失败: {ex}"]
    if repaired == script:
        return script, ["AI 未生成可应用的脚本补丁"]
    def validate(candidate: str, baseline: str) -> list[str]:
        return _unsafe_repair_issues(
            candidate,
            baseline=baseline,
            row=row,
            failure=failure,
            credentials=credentials,
        )

    issues = validate(repaired, script)
    if not issues:
        return repaired, []

    # Give Repairer one validation-feedback refinement inside the user-confirmed repair round.
    retry_failure = {
        **failure,
        "error_message": (
            str(failure.get("error_message") or "")
            + "\n上一次修复未通过静态校验："
            + "；".join(issues)
            + "。请一次性修复全部问题。"
        )[:4000],
    }
    try:
        refined = _repair_script(script=repaired, row=row, failure=retry_failure, llm=llm)
    except Exception as ex:  # noqa: BLE001
        return script, [*issues, f"二次校正失败: {ex}"]
    refined_issues = validate(refined, script)
    return (script, refined_issues) if refined_issues else (refined, [])


def verify_and_repair(
    *,
    row: dict[str, Any],
    script: str,
    llm: LlmRuntime,
    runner_kwargs: dict[str, Any],
    max_repair: int = 2,
    should_cancel: Callable[[], bool] | None = None,
    execute: Callable[..., list[dict[str, Any]]] | None = None,
    credentials: list[str] | None = None,
) -> dict[str, Any]:
    from app.services.ui_automation.ui_runner import execute_ui_script

    run = execute or execute_ui_script
    current = script
    last_error = ""
    for attempt in range(max(0, int(max_repair)) + 1):
        if should_cancel and should_cancel():
            return {
                "code": current,
                "ready": False,
                "verify_status": "skipped",
                "verify_error": "已取消",
                "attempts": attempt,
            }
        semantic_issues = script_semantic_issues(current, row)
        if semantic_issues:
            failure = {
                "status": "failed",
                "error_message": "脚本语义校验未通过：" + "；".join(semantic_issues),
                "failure_snapshot": "",
            }
        else:
            steps = run(script=current, **runner_kwargs)
            failure = _failed_step(steps)
        if failure is None:
            return {
                "code": current,
                "ready": True,
                "verify_status": "passed",
                "verify_error": "",
                "attempts": attempt + 1,
            }
        last_error = str(failure.get("error_message") or failure.get("status") or "试跑失败")
        if attempt >= max_repair:
            break
        repaired = _repair_script(script=current, row=row, failure=failure, llm=llm)
        if repaired == current:
            break
        unsafe = _unsafe_repair_issues(
            repaired,
            baseline=current,
            row=row,
            failure=failure,
            credentials=credentials,
        )
        if unsafe:
            last_error = f"{last_error}\n修复补丁被拒绝：" + "；".join(unsafe)
            break
        current = repaired
    return {
        "code": current,
        "ready": False,
        "verify_status": "failed",
        "verify_error": last_error[:2000],
        "attempts": min(max_repair + 1, attempt + 1),
    }


def _case_trace(trace: list[dict[str, Any]], row: dict[str, Any]) -> list[dict[str, Any]]:
    cid = str(row.get("id") or "")
    tagged = [item for item in trace if isinstance(item, dict) and str(item.get("case_id") or "") == cid]
    if tagged:
        return tagged
    span = row.get("trace_range")
    if isinstance(span, list) and len(span) == 2:
        try:
            return trace[max(0, int(span[0])) : int(span[1]) + 1]
        except (TypeError, ValueError):
            pass
    return list(trace)


def run_codegen_pipeline(
    *,
    matrix: list[dict[str, Any]],
    trace: list[dict[str, Any]],
    llm: LlmRuntime,
    base_url: str,
    ctx: dict[str, str],
    browser_name: str = "chromium",
    viewport: dict[str, int] | None = None,
    timeout_ms: int = 15000,
    storage_state_path: str | None = None,
    extra_http_headers: dict[str, str] | None = None,
    local_storage: dict[str, str] | None = None,
    verify: bool = True,
    max_repair: int = 2,
    max_seconds: int = 360,
    on_log: Callable[[str], None] | None = None,
    should_cancel: Callable[[], bool] | None = None,
    execute: Callable[..., list[dict[str, Any]]] | None = None,
) -> tuple[list[dict[str, Any]], str | None]:
    """Generate cases in parallel, then verify login first and business cases concurrently."""
    deadline = time.monotonic() + max(30, int(max_seconds))
    rows = [dict(row) for row in matrix if isinstance(row, dict)]
    credentials = [str(ctx.get(k) or "") for k in ("username", "password", "user", "passwd")]

    def generate(row: dict[str, Any]) -> dict[str, Any]:
        nav = _navigation_context(trace, row)
        grounded_row = {
            **row,
            "navigation_start_path": nav["start_path"],
            "navigation_prefix": nav["steps"],
        }
        if nav["start_path"]:
            grounded_row["start_url"] = nav["start_path"]
            grounded_steps = [
                dict(step) if isinstance(step, dict) else step
                for step in (grounded_row.get("steps") or [])
            ]
            replaced = False
            for step in grounded_steps:
                if isinstance(step, dict) and str(step.get("action") or "") == "goto":
                    step["target"] = nav["start_path"]
                    step["value"] = nav["start_path"]
                    replaced = True
                    break
            if not replaced:
                grounded_steps.insert(
                    0,
                    {
                        "action": "goto",
                        "target": nav["start_path"],
                        "value": nav["start_path"],
                        "driver": "playwright",
                        "ready": True,
                    },
                )
            grounded_row["steps"] = grounded_steps
        trace_slice = _case_trace(trace, grounded_row)
        catalog = build_locator_catalog(
            trace_slice,
            row_steps=list(grounded_row.get("steps") or []),
            navigation_prefix=list(nav["steps"] or []),
        )
        if (
            _codegen_guard_strict()
            and not catalog_has_actionable_locators(catalog)
        ):
            code, guard_errors = "", ["探索缺少稳定 locator，无法 LLM 生成脚本"]
        else:
            try:
                code, guard_errors = code_case(
                    row=grounded_row,
                    trace_slice=trace_slice,
                    draft="",
                    llm=llm,
                    credentials=credentials,
                    catalog=catalog,
                    llm_primary=True,
                    fallback_on_error=False,
                )
            except Exception as ex:  # noqa: BLE001
                log.warning("CaseCoder failed for %s: %s", row.get("id"), ex)
                code, guard_errors = "", [f"CaseCoder 失败: {ex}"]
        if _codegen_guard_strict():
            deliverable = bool(code) and not guard_errors
        else:
            deliverable = bool(str(code or "").strip())
        return {
            "id": str(grounded_row.get("id") or "TC"),
            "name": str(
                grounded_row.get("name") or grounded_row.get("id") or "UI 用例"
            ),
            "start_url": str(grounded_row.get("start_url") or "/"),
            "needs_auth": bool(grounded_row.get("needs_auth")),
            "is_login": bool(
                re.search(
                    r"登录|login|sign\s*in",
                    str(grounded_row.get("name") or ""),
                    re.I,
                )
            ),
            "code": code,
            "ready": deliverable and not verify,
            "verify_status": "skipped" if not verify else "pending",
            "verify_error": "",
            "attempts": 0,
            "guard_errors": guard_errors,
            "navigation_start_path": nav["start_path"],
            "navigation_prefix": nav["steps"],
            "_row": grounded_row,
        }

    generated: list[dict[str, Any]] = []
    with ThreadPoolExecutor(max_workers=min(4, max(1, len(rows)))) as pool:
        futures = {pool.submit(generate, row): i for i, row in enumerate(rows)}
        ordered: dict[int, dict[str, Any]] = {}
        for future in as_completed(futures):
            ordered[futures[future]] = future.result()
        generated = [ordered[i] for i in sorted(ordered)]
    if on_log:
        on_log(f"CaseCoder 完成：生成 {len(generated)} 条脚本")
    if not verify:
        for item in generated:
            item.pop("_row", None)
        return generated, storage_state_path

    auth_path = storage_state_path
    login = next((item for item in generated if item["is_login"]), None)
    base_kwargs = {
        "base_url": base_url,
        "ctx": ctx,
        "viewport": viewport or {"width": 1280, "height": 720},
        "headless": True,
        "browser_name": browser_name,
        "default_timeout_ms": timeout_ms,
        "extra_http_headers": extra_http_headers,
        "local_storage": local_storage,
    }

    def verify_one(item: dict[str, Any], *, state_path: str | None = None, save_path: str | None = None) -> dict[str, Any]:
        if time.monotonic() >= deadline:
            return {**item, "ready": False, "verify_status": "skipped", "verify_error": "超过代码生成总时限"}
        kwargs = dict(base_kwargs)
        if state_path:
            kwargs["storage_state_path"] = state_path
        if save_path:
            kwargs["save_storage_state_path"] = save_path
        result = verify_and_repair(
            row=item["_row"],
            script=str(item.get("code") or ""),
            llm=llm,
            runner_kwargs=kwargs,
            max_repair=max_repair,
            should_cancel=should_cancel,
            execute=execute,
            credentials=credentials,
        )
        return {**item, **result}

    if login:
        if not auth_path:
            auth_path = str(Path(tempfile.gettempdir()) / f"raina-ui-codegen-{time.time_ns()}.json")
        checked = verify_one(login, save_path=auth_path)
        generated[generated.index(login)] = checked
        if not checked.get("ready"):
            auth_path = None
        if on_log:
            on_log(f"登录用例试跑：{checked.get('verify_status')}")

    pending = [item for item in generated if item is not login]
    with ThreadPoolExecutor(max_workers=min(2, max(1, len(pending)))) as pool:
        future_map = {
            pool.submit(
                verify_one,
                item,
                state_path=auth_path if item.get("needs_auth") else storage_state_path,
            ): i
            for i, item in enumerate(pending)
        }
        checked_by_id: dict[str, dict[str, Any]] = {}
        for future in as_completed(future_map):
            checked = future.result()
            checked_by_id[str(checked.get("id"))] = checked
        generated = [
            checked_by_id.get(str(item.get("id")), item) if item is not login else generated[generated.index(login)]
            for item in generated
        ]
    for item in generated:
        item.pop("_row", None)
    if on_log:
        passed = sum(1 for item in generated if item.get("verify_status") == "passed")
        repaired = sum(1 for item in generated if int(item.get("attempts") or 0) > 1)
        on_log(f"自动试跑完成：通过 {passed}/{len(generated)}，修复 {repaired} 条")
    return generated, auth_path
