"""Shared UI-automation label lexicon (login / auth fields / captcha).

Keep Chinese + English vocabulary in one place so explore, report, and codegen
do not drift.
"""

from __future__ import annotations

import re

USER_FIELD = re.compile(r"账号|用户名|username|user\s*name", re.I)
PASS_FIELD = re.compile(r"密码|password|passwd", re.I)
CAPTCHA = re.compile(r"验证码|captcha|verify[\s_-]?code|vcode", re.I)
CAPTCHA_REFRESH = re.compile(
    r"换一张|刷新验证码|刷新|reload.*captcha|refresh.*captcha",
    re.I,
)
# Match after whitespace collapse so「登 录」/「sign in」still work.
LOGIN_BTN = re.compile(r"登录|login|signin", re.I)
AUTH_PATH_SEG = frozenset({"login", "signin", "sign-in", "auth", "sso"})

CAPTCHA_QUERY_PROMPT = (
    "只读取验证码图片中的字符；忽略输入框已有文字与背景噪点；"
    "只输出字符本身，不要引号空格或解释"
)


def norm_ws(value: str) -> str:
    """Collapse whitespace for label compares (Ant Design『登 录』etc.)."""
    return re.sub(r"\s+", "", value or "")


def path_is_auth(path: str) -> bool:
    raw = str(path or "").strip().split("?")[0].split("#")[0]
    if not raw:
        return False
    if not raw.startswith("/"):
        raw = "/" + raw
    parts = [p for p in raw.split("/") if p]
    if not parts:
        return False
    return parts[0].lower() in AUTH_PATH_SEG
