"""Triage a failed UI run, then patch or re-explore (human confirm before write)."""

from __future__ import annotations

import json
import logging
import uuid
from typing import Any

from sqlalchemy.orm import Session
from sqlalchemy.orm.attributes import flag_modified

from app.errors import AppError
from app.models.functional.testcase import TestCase, TestCaseStep
from app.models.ui_automation.ui_automation import (
    UiCase,
    UiEnvironment,
    UiRun,
    UiRunFixSession,
    UiRunStep,
    UiScenarioAgentSession,
)
from app.services.ai.effective_ai_settings import LlmRuntime, get_llm_runtime
from app.services.api_automation.api_scenario_events import get_event_bus
from app.services.api_automation.api_scenario_llm import llm_json
from app.services.ui_automation.ui_node_script import is_node_ui_script, is_runnable_ui_script
from app.services.ui_automation.ui_scenario_agent import _strip_code_fence, new_thread_id, resolve_env, stop_session
from app.services.ui_automation.ui_script_midscene_policy import MIDSCENE_SCRIPT_POLICY
from app.user_messages import UI_CASE_NOT_FOUND

log = logging.getLogger(__name__)

_CATEGORY_ACTIONS: dict[str, tuple[str, str]] = {
    "locator_drift": ("patch_script", "patch"),
    "timing_wait": ("patch_script", "patch"),
    "assertion_mismatch": ("patch_script", "patch"),
    "auth_env": ("fix_env", "none"),
    "product_bug": ("file_bug", "none"),
    "flake_infra": ("rerun_only", "none"),
    "nav_flow": ("explore_repair", "replace"),
}

_PATCH_CATEGORIES = frozenset({"locator_drift", "timing_wait", "assertion_mismatch"})
_ADVICE_ACTIONS = frozenset({"fix_env", "file_bug", "rerun_only"})

_LOCATOR_HINTS = (
    "getByRole",
    "getByText",
    "getByLabel",
    "getByPlaceholder",
    "getByTestId",
    "locator(",
)


def new_fix_id() -> str:
    return "uifix-" + uuid.uuid4().hex


def _row_to_meta(row: UiRunFixSession, *, events: list[dict[str, Any]] | None = None) -> dict[str, Any]:
    return {
        "id": row.id,
        "run_id": row.run_id,
        "case_id": row.case_id,
        "project_id": row.project_id,
        "status": row.status,
        "plan": row.plan_json if isinstance(row.plan_json, dict) else None,
        "triage": row.triage_json if isinstance(row.triage_json, dict) else None,
        "current_script": row.current_script or "",
        "error_message": row.error_message or "",
        "patch_message": row.patch_message or "",
        "rerun_id": row.rerun_id,
        "explore_session_id": row.explore_session_id,
        "failure_screenshot_key": row.failure_screenshot_key,
        "failure_step_id": row.failure_step_id,
        "events": events if events is not None else [],
    }


def get_fix(db: Session, fix_id: str) -> dict[str, Any] | None:
    row = db.get(UiRunFixSession, str(fix_id))
    if row is None:
        return None
    return _row_to_meta(row)


def put_fix(db: Session, meta: dict[str, Any]) -> dict[str, Any]:
    fix_id = str(meta["id"])
    row = db.get(UiRunFixSession, fix_id)
    if row is None:
        row = UiRunFixSession(
            id=fix_id,
            project_id=int(meta["project_id"]),
            run_id=int(meta["run_id"]),
            case_id=meta.get("case_id"),
            current_script=str(meta.get("current_script") or ""),
            created_by=meta.get("created_by"),
        )
        db.add(row)
    row.status = str(meta.get("status") or "analyzing")
    row.case_id = meta.get("case_id")
    row.plan_json = meta.get("plan") if isinstance(meta.get("plan"), dict) else None
    row.triage_json = meta.get("triage") if isinstance(meta.get("triage"), dict) else None
    row.current_script = str(meta.get("current_script") or "")
    row.error_message = str(meta.get("error_message") or "")
    row.patch_message = str(meta.get("patch_message") or "")
    row.rerun_id = meta.get("rerun_id")
    row.explore_session_id = meta.get("explore_session_id")
    row.failure_screenshot_key = meta.get("failure_screenshot_key")
    row.failure_step_id = meta.get("failure_step_id")
    db.commit()
    db.refresh(row)
    return _row_to_meta(row, events=meta.get("events") if isinstance(meta.get("events"), list) else [])


def _string_list(value: Any) -> list[str]:
    if not isinstance(value, list):
        return []
    out: list[str] = []
    for item in value:
        text = str(item or "").strip()
        if text:
            out.append(text)
    return out


def _normalize_suggested_script(raw: str, *, original: str, require_same_type: bool = True) -> str:
    code = _strip_code_fence(str(raw or "").strip())
    if not is_runnable_ui_script(code):
        raise ValueError("修订结果不是可执行脚本")
    if require_same_type and original and is_node_ui_script(original) != is_node_ui_script(code):
        raise ValueError("修订结果脚本类型与当前脚本不一致")
    if not code.endswith("\n"):
        code += "\n"
    return code


def _keeps_explore_locators(explored: str, suggested: str) -> bool:
    if not any(hint in explored for hint in _LOCATOR_HINTS):
        return True
    return any(hint in suggested for hint in _LOCATOR_HINTS)


def _session_events(session: UiScenarioAgentSession) -> list[dict[str, Any]]:
    db_events = session.events_json if isinstance(session.events_json, list) else []
    live = get_event_bus().snapshot(session.thread_id)
    return live if len(live) >= len(db_events) else list(db_events)


def _failed_step(db: Session, run: UiRun) -> UiRunStep | None:
    rows = (
        db.query(UiRunStep)
        .filter(UiRunStep.run_id == run.id, UiRunStep.project_id == run.project_id)
        .order_by(UiRunStep.order, UiRunStep.id)
        .all()
    )
    for row in rows:
        if row.status in ("failed", "error"):
            return row
    return rows[0] if rows else None


def resolve_fix_case(db: Session, run: UiRun, step: UiRunStep | None) -> UiCase:
    case_id = int(step.case_id) if step is not None and step.case_id else None
    if case_id is None and run.trigger_type == "case":
        case_id = int(run.target_id)
    if case_id is None:
        raise AppError("bad_request", "没有可修复的用例脚本", status_code=400)
    case = (
        db.query(UiCase)
        .filter(UiCase.id == case_id, UiCase.project_id == run.project_id)
        .first()
    )
    if case is None:
        raise AppError("not_found", UI_CASE_NOT_FOUND, status_code=404)
    if not is_runnable_ui_script(case.script or ""):
        raise AppError("bad_request", "没有可修复的用例脚本", status_code=400)
    return case


def _manual_case_context(db: Session, case: UiCase) -> dict[str, Any]:
    if not case.manual_case_id:
        return {}
    tc = (
        db.query(TestCase)
        .filter(TestCase.id == case.manual_case_id, TestCase.project_id == case.project_id)
        .first()
    )
    if tc is None:
        return {}
    steps = (
        db.query(TestCaseStep)
        .filter(TestCaseStep.case_id == tc.id)
        .order_by(TestCaseStep.order, TestCaseStep.id)
        .all()
    )
    from app.services.functional.test_data_vars import as_str_dict, case_test_data_text

    return {
        "title": tc.title,
        "precondition": tc.precondition or "",
        "test_data": case_test_data_text(variables=tc.variables_json, test_data=tc.test_data),
        "variables": as_str_dict(tc.variables_json),
        "overall_expected": tc.overall_expected or "",
        "steps": [{"action": s.action, "expected": s.expected} for s in steps],
    }


def _session_for_run(db: Session, run: UiRun) -> UiScenarioAgentSession | None:
    found = (
        db.query(UiScenarioAgentSession)
        .filter(
            UiScenarioAgentSession.project_id == run.project_id,
            UiScenarioAgentSession.run_id == run.id,
        )
        .first()
    )
    if found is not None:
        return found
    case_id = run.target_id if run.trigger_type == "case" else None
    if case_id is None:
        return None
    return (
        db.query(UiScenarioAgentSession)
        .filter(
            UiScenarioAgentSession.project_id == run.project_id,
            UiScenarioAgentSession.saved_ui_case_id == case_id,
        )
        .order_by(UiScenarioAgentSession.id.desc())
        .first()
    )


def _neighbor_steps(db: Session, run: UiRun, step: UiRunStep) -> list[dict[str, Any]]:
    rows = (
        db.query(UiRunStep)
        .filter(UiRunStep.run_id == run.id, UiRunStep.project_id == run.project_id)
        .order_by(UiRunStep.order, UiRunStep.id)
        .all()
    )
    out: list[dict[str, Any]] = []
    for row in rows:
        out.append(
            {
                "id": row.id,
                "order": row.order,
                "action": row.action or "",
                "status": row.status,
                "selector": (row.selector or "")[:300],
                "error_message": (row.error_message or "")[:500],
                "is_failed": row.id == step.id,
            }
        )
    return out


def _truncate_json(value: Any, *, limit: int = 3000) -> Any:
    if value is None:
        return None
    try:
        text = json.dumps(value, ensure_ascii=False)
    except (TypeError, ValueError):
        text = str(value)
    if len(text) <= limit:
        return value
    return {"_truncated": text[:limit]}


def build_fix_context(db: Session, run: UiRun, step: UiRunStep, case: UiCase) -> dict[str, Any]:
    session = _session_for_run(db, run)
    plan = session.plan_json if session is not None and isinstance(session.plan_json, dict) else {}
    report = plan.get("explore_report") if isinstance(plan.get("explore_report"), dict) else {}
    last_url = ""
    if isinstance(report, dict):
        last_url = str(report.get("last_url") or report.get("url") or "")
        if not last_url:
            steps = report.get("steps")
            if isinstance(steps, list) and steps:
                last = steps[-1]
                if isinstance(last, dict):
                    last_url = str(last.get("page_url") or last.get("url") or "")
    env = None
    if run.env_id is not None:
        env = (
            db.query(UiEnvironment)
            .filter(UiEnvironment.id == run.env_id, UiEnvironment.project_id == run.project_id)
            .first()
        )
    has_storage = bool(env and (env.auth_states_encrypted or "").strip())
    summary = run.summary_json if isinstance(run.summary_json, dict) else {}
    log_lines = summary.get("log_lines") if isinstance(summary.get("log_lines"), list) else []
    log_tail = [str(x)[:500] for x in log_lines[-30:]]
    detail = step.detail_json if isinstance(step.detail_json, dict) else step.detail_json
    return {
        "run_id": run.id,
        "run_status": run.status,
        "error_message": (step.error_message or "")[:4000],
        "step_status": step.status,
        "step_action": step.action or "",
        "step_selector": (step.selector or "")[:1024],
        "step_screenshot_key": step.screenshot_key or "",
        "step_detail": _truncate_json(detail),
        "neighbor_steps": _neighbor_steps(db, run, step),
        "log_tail": log_tail,
        "current_script": (case.script or "")[:12000],
        "manual_case": _manual_case_context(db, case),
        "explore": {
            "last_url": last_url[:500],
            "auth_mode": str(plan.get("_auth_mode") or ""),
            "account_name": str(plan.get("_account_name") or run.account_name or ""),
            "goal": str(plan.get("goal") or ""),
            "start_path": str(plan.get("start_path") or ""),
        },
        "env": {
            "has_storage_state": has_storage,
            "token_inject": getattr(env, "token_inject", None) or "none",
            "account_name": run.account_name or "",
        },
    }


def _normalize_category(raw: Any, *, evidence_sufficient: bool | None) -> str:
    category = str(raw or "").strip().lower()
    if category not in _CATEGORY_ACTIONS:
        return "nav_flow"
    if category in _PATCH_CATEGORIES and evidence_sufficient is False:
        return "nav_flow"
    return category


def _action_for_category(category: str) -> tuple[str, str]:
    return _CATEGORY_ACTIONS.get(category, ("explore_repair", "replace"))


def _triage_failure(db: Session, ctx: dict[str, Any]) -> dict[str, Any]:
    fallback = {
        "category": "nav_flow",
        "recommended_action": "explore_repair",
        "apply_mode": "replace",
        "summary": "证据不足，将重新探索页面生成脚本。",
        "likely_causes": [],
        "warnings": [],
        "evidence_sufficient": False,
    }
    messages = [
        {
            "role": "system",
            "content": (
                "你是 UI 自动化失败归因助手。根据失败现场（报错、selector、步骤、脚本、环境），"
                "只输出 JSON："
                '{"category":"locator_drift|timing_wait|assertion_mismatch|auth_env|product_bug|flake_infra|nav_flow",'
                '"summary":"...","likely_causes":["..."],"warnings":["..."],'
                '"evidence_sufficient":true|false}。'
                "category 含义："
                "locator_drift=控件/文案变了可局部改 locator；"
                "timing_wait=缺等待/竞态；"
                "assertion_mismatch=断言过时；"
                "auth_env=登录态/账号/环境问题，不应改脚本；"
                "product_bug=产品本身错误，不应改脚本；"
                "flake_infra=超时/基础设施抖动，宜重跑；"
                "nav_flow=流程/入口变了或证据不足需重探。"
                "证据不足以给出可靠局部修补时，evidence_sufficient=false 且 category 用 nav_flow。"
                "不要编造未提供的页面信息。只输出 JSON。"
            ),
        },
        {
            "role": "user",
            "content": "失败现场：\n" + json.dumps(ctx, ensure_ascii=False)[:14000],
        },
    ]
    try:
        cfg = get_llm_runtime(db)
        if not cfg.api_key.strip():
            return fallback
        raw = llm_json(messages, cfg=cfg, scene="UI 失败归因")
    except Exception:  # noqa: BLE001
        log.exception("ui run fix triage failed")
        return fallback
    evidence = raw.get("evidence_sufficient")
    evidence_sufficient = None if evidence is None else bool(evidence)
    category = _normalize_category(raw.get("category"), evidence_sufficient=evidence_sufficient)
    action, apply_mode = _action_for_category(category)
    return {
        "category": category,
        "recommended_action": action,
        "apply_mode": apply_mode,
        "summary": str(raw.get("summary") or fallback["summary"]).strip() or fallback["summary"],
        "likely_causes": _string_list(raw.get("likely_causes")),
        "warnings": _string_list(raw.get("warnings")),
        "evidence_sufficient": bool(evidence_sufficient) if evidence_sufficient is not None else category in _PATCH_CATEGORIES,
    }


def _parse_patches(raw: Any) -> list[dict[str, str]]:
    if not isinstance(raw, list):
        return []
    out: list[dict[str, str]] = []
    for item in raw:
        if not isinstance(item, dict):
            continue
        old = str(item.get("old") or "")
        new = str(item.get("new") or "")
        if not old:
            continue
        out.append(
            {
                "kind": "replace",
                "old": old,
                "new": new,
                "rationale": str(item.get("rationale") or "").strip(),
            }
        )
    return out


def apply_script_patches(script: str, patches: list[dict[str, str]]) -> str:
    result = script
    for patch in patches:
        old = patch.get("old") or ""
        if not old or old not in result:
            raise ValueError(f"patch old 未命中脚本: {old[:80]}")
        result = result.replace(old, patch.get("new") or "", 1)
    return result


def _synthesize_patches(db: Session, ctx: dict[str, Any], triage: dict[str, Any]) -> dict[str, Any] | None:
    script = str(ctx.get("current_script") or "")
    messages = [
        {
            "role": "system",
            "content": (
                "你是 UI 自动化脚本修补助手。根据归因结果，对当前脚本做最小精确子串替换。"
                "只输出 JSON："
                '{"changes":["..."],"suggested_patches":[{"kind":"replace","old":"脚本中必须原样存在的片段",'
                '"new":"替换后的片段","rationale":"..."}],"warnings":[]}。'
                "old 必须是 current_script 中的连续原文；不要输出整份脚本；不要编造 locator。"
                "若无法给出可靠 old/new，输出 suggested_patches=[]。"
                "只输出 JSON。"
            ),
        },
        {
            "role": "user",
            "content": json.dumps(
                {"triage": triage, "failure_context": ctx},
                ensure_ascii=False,
            )[:14000],
        },
    ]
    try:
        cfg = get_llm_runtime(db)
        if not cfg.api_key.strip():
            return None
        raw = llm_json(messages, cfg=cfg, scene="UI 失败修补")
    except Exception:  # noqa: BLE001
        log.exception("ui run fix synthesize patches failed")
        return None
    patches = _parse_patches(raw.get("suggested_patches"))
    if not patches:
        return None
    try:
        suggested = apply_script_patches(script, patches)
        suggested = _normalize_suggested_script(suggested, original=script)
    except ValueError:
        return None
    return {
        "category": triage["category"],
        "recommended_action": "patch_script",
        "apply_mode": "patch",
        "summary": triage.get("summary") or "已生成局部脚本修补。",
        "likely_causes": list(triage.get("likely_causes") or []),
        "changes": _string_list(raw.get("changes"))
        or [p.get("rationale") or "局部替换" for p in patches],
        "warnings": _string_list(raw.get("warnings")) + list(triage.get("warnings") or []),
        "suggested_patches": patches,
        "suggested_script": suggested,
    }


def _advice_plan(triage: dict[str, Any], current_script: str) -> dict[str, Any]:
    action = str(triage.get("recommended_action") or "fix_env")
    apply_mode = "none"
    return {
        "category": triage.get("category") or "auth_env",
        "recommended_action": action if action in _ADVICE_ACTIONS else "fix_env",
        "apply_mode": apply_mode,
        "summary": triage.get("summary") or "该失败不宜通过改脚本修复。",
        "likely_causes": list(triage.get("likely_causes") or []),
        "changes": [],
        "warnings": list(triage.get("warnings") or []),
        "suggested_patches": [],
        "suggested_script": current_script,
    }


def _repair_prompt(step: UiRunStep, case: UiCase, *, triage: dict[str, Any] | None = None) -> str:
    error = (step.error_message or "").strip()[:1500]
    script = (case.script or "").strip()[:4000]
    selector = (step.selector or "").strip()[:300]
    category = str((triage or {}).get("category") or "nav_flow")
    summary = str((triage or {}).get("summary") or "").strip()[:400]
    return (
        "试跑失败，请重新探索当前流程并基于真实页面生成可执行脚本，不要凭空改脚本。\n"
        "请锚定失败步骤附近页面，不要整站漫游。\n"
        f"归因分类：{category}\n"
        f"归因摘要：{summary or '（无）'}\n"
        f"失败 selector：{selector or '（无）'}\n"
        f"失败信息：{error or '（无详细报错）'}\n"
        f"当前脚本：\n{script}"
    )


def start_run_fix(
    db: Session,
    run: UiRun,
    *,
    user_id: int,
    llm_cfg: LlmRuntime,
) -> dict[str, Any]:
    _ = llm_cfg
    if run.status not in ("failed", "error"):
        raise AppError("bad_request", "仅支持对失败/错误执行记录做修复", status_code=400)
    step = _failed_step(db, run)
    if step is None:
        raise AppError("bad_request", "执行记录没有失败步骤", status_code=400)
    case = resolve_fix_case(db, run, step)
    fix_id = new_fix_id()
    meta: dict[str, Any] = {
        "id": fix_id,
        "run_id": run.id,
        "case_id": case.id,
        "project_id": run.project_id,
        "status": "analyzing",
        "plan": None,
        "triage": None,
        "current_script": case.script or "",
        "error_message": "",
        "patch_message": "",
        "rerun_id": None,
        "explore_session_id": None,
        "failure_screenshot_key": step.screenshot_key,
        "failure_step_id": step.id,
        "created_by": user_id,
        "events": [],
    }
    meta = put_fix(db, meta)

    ctx = build_fix_context(db, run, step, case)
    triage = _triage_failure(db, ctx)
    meta["triage"] = triage

    action = str(triage.get("recommended_action") or "explore_repair")
    if action in _ADVICE_ACTIONS:
        meta["plan"] = _advice_plan(triage, case.script or "")
        meta["status"] = "awaiting_confirm"
        return put_fix(db, meta)

    if action == "patch_script":
        patched = _synthesize_patches(db, ctx, triage)
        if patched is not None:
            meta["plan"] = patched
            meta["status"] = "awaiting_confirm"
            return put_fix(db, meta)
        triage = {
            **triage,
            "category": "nav_flow",
            "recommended_action": "explore_repair",
            "apply_mode": "replace",
            "warnings": list(triage.get("warnings") or []) + ["局部修补未命中脚本，改为重新探索"],
        }
        meta["triage"] = triage

    return _begin_repair_explore(db, run, case, step, meta, triage=triage, user_id=user_id)


def start_repair_explore(
    db: Session,
    run: UiRun,
    *,
    user_id: int,
    llm_cfg: LlmRuntime,
) -> dict[str, Any]:
    """Backward-compatible entry: triage-first then branch."""
    return start_run_fix(db, run, user_id=user_id, llm_cfg=llm_cfg)


def _begin_repair_explore(
    db: Session,
    run: UiRun,
    case: UiCase,
    step: UiRunStep,
    meta: dict[str, Any],
    *,
    triage: dict[str, Any],
    user_id: int,
) -> dict[str, Any]:
    origin = _session_for_run(db, run)
    origin_plan = origin.plan_json if origin is not None and isinstance(origin.plan_json, dict) else {}
    raw_auth = origin_plan.get("_auth_mode")
    if raw_auth in ("none", "account", "token"):
        auth_mode: str | None = str(raw_auth)
    elif run.account_name:
        auth_mode = "account"
    else:
        auth_mode = None
    account_name = (
        str(origin_plan.get("_account_name") or run.account_name or "").strip() or None
        if auth_mode == "account"
        else None
    )
    testcase_id = origin.testcase_id if origin is not None else case.manual_case_id
    creds = origin.credentials_json if origin is not None and isinstance(origin.credentials_json, dict) else None
    env = resolve_env(db, run.project_id, run.env_id or (origin.env_id if origin is not None else None))
    prompt = _repair_prompt(step, case, triage=triage)
    thread_id = new_thread_id()
    get_event_bus().replace(thread_id, [])
    fix_id = str(meta["id"])
    repair_plan: dict[str, Any] = {
        "_max_steps": 15,
        "_headed": True,
        "engine": "midscene",
        "_auth_mode": auth_mode,
        "_account_name": account_name,
        "_repair_run_id": run.id,
        "_repair_case_id": case.id,
        "_repair_fix_id": fix_id,
        "_repair_category": triage.get("category") or "nav_flow",
        "_single_case": True,
    }
    for key in ("goal", "start_path", "checklist", "case_name"):
        if origin_plan.get(key):
            repair_plan[key] = origin_plan[key]
    row = UiScenarioAgentSession(
        project_id=run.project_id,
        user_id=user_id,
        thread_id=thread_id,
        status="running",
        prompt=prompt,
        testcase_id=testcase_id,
        env_id=env.id,
        browser=run.browser or env.browser or "chromium",
        messages_json=[{"role": "user", "content": prompt}],
        plan_json=repair_plan,
        credentials_json=creds,
        events_json=[],
        playwright_code="",
        dry_run_error="",
        error_message="",
    )
    db.add(row)
    db.commit()
    db.refresh(row)
    meta["explore_session_id"] = row.id
    meta["status"] = "exploring"
    meta["plan"] = None
    meta["error_message"] = ""
    meta = put_fix(db, meta)

    from app.api.ui_automation.ui_scenario_agent import _start_explore

    _start_explore(db, row, env.queue_name or "ui")
    db.refresh(row)
    return hydrate_fix(db, meta)


def hydrate_fix(db: Session, meta: dict[str, Any]) -> dict[str, Any]:
    sid = meta.get("explore_session_id")
    if not sid:
        return meta
    session = db.get(UiScenarioAgentSession, int(sid))
    if session is None:
        return meta
    meta["events"] = _session_events(session)
    if meta.get("status") == "exploring":
        complete_repair_from_explore(db, session)
        fresh = get_fix(db, str(meta["id"]))
        if fresh is not None:
            fresh["events"] = _session_events(session)
            return fresh
    return put_fix(db, meta)


def _short_explore_fail_message(detail: str = "") -> str:
    text = str(detail or "").strip()
    if not text or text == "探索失败":
        return "探索失败"
    if text.startswith("探索失败"):
        return text
    first = text.splitlines()[0].strip()
    if len(first) > 80:
        first = first[:77] + "…"
    return f"探索失败：{first}"


def _case_scripts_none_ready(plan: dict[str, Any]) -> bool:
    scripts = plan.get("case_scripts")
    if not isinstance(scripts, list) or not scripts:
        return False
    return not any(
        isinstance(c, dict) and c.get("ready") and str(c.get("code") or "").strip() for c in scripts
    )


def _fail_repair_explore(db: Session, meta: dict[str, Any], *, detail: str = "") -> dict[str, Any]:
    meta["status"] = "error"
    meta["error_message"] = _short_explore_fail_message(detail)
    meta["plan"] = None
    return put_fix(db, meta)


def complete_repair_from_explore(db: Session, session: UiScenarioAgentSession) -> dict[str, Any] | None:
    plan = session.plan_json if isinstance(session.plan_json, dict) else {}
    fix_id = str(plan.get("_repair_fix_id") or "")
    if not fix_id:
        return None
    meta = get_fix(db, fix_id)
    if meta is None or meta.get("status") != "exploring":
        return meta
    meta["events"] = _session_events(session)
    meta["explore_session_id"] = session.id

    if session.status in ("running", "awaiting_human", "pending"):
        return put_fix(db, meta)
    if session.status == "cancelled":
        meta["status"] = "cancelled"
        meta["patch_message"] = "已取消"
        meta["error_message"] = session.error_message or ""
        return put_fix(db, meta)
    if session.status == "error":
        return _fail_repair_explore(db, meta, detail=session.error_message or "探索失败")

    explored = session.playwright_code or ""
    if not is_runnable_ui_script(explored):
        return _fail_repair_explore(
            db, meta, detail=session.error_message or "重新探索未产生可执行脚本"
        )
    if session.error_message:
        return _fail_repair_explore(db, meta, detail=session.error_message)
    if _case_scripts_none_ready(plan):
        return _fail_repair_explore(db, meta, detail="未生成可用用例脚本")

    explored = _normalize_suggested_script(explored, original=explored, require_same_type=False)
    suggestion = _suggest_from_explore(db, meta, session, explored)
    meta["plan"] = suggestion
    meta["status"] = "awaiting_confirm"
    meta["error_message"] = ""
    session.status = "done"
    session.playwright_code = suggestion["suggested_script"]
    db.commit()
    return put_fix(db, meta)


def _suggest_from_explore(
    db: Session,
    meta: dict[str, Any],
    session: UiScenarioAgentSession,
    explored: str,
) -> dict[str, Any]:
    triage = meta.get("triage") if isinstance(meta.get("triage"), dict) else {}
    category = str(
        triage.get("category")
        or (session.plan_json or {}).get("_repair_category")
        or "nav_flow"
    )
    fallback = {
        "category": category if category in _CATEGORY_ACTIONS else "nav_flow",
        "recommended_action": "explore_repair",
        "apply_mode": "replace",
        "summary": "已根据重新探索的页面生成脚本，请确认后写入原用例。",
        "likely_causes": list(triage.get("likely_causes") or []),
        "changes": ["用本次探索得到的 locator 与等待替换当前脚本"],
        "warnings": list(triage.get("warnings") or []),
        "suggested_patches": [],
        "suggested_script": explored,
    }
    run = db.get(UiRun, int(meta["run_id"]))
    case = db.get(UiCase, int(meta["case_id"])) if meta.get("case_id") else None
    if run is None or case is None:
        return fallback
    step = _failed_step(db, run)
    ctx = build_fix_context(db, run, step, case) if step is not None else {}
    plan = session.plan_json if isinstance(session.plan_json, dict) else {}
    ctx["explored_script"] = explored[:12000]
    ctx["explore_report"] = plan.get("explore_report") if isinstance(plan.get("explore_report"), dict) else {}
    ctx["triage"] = triage
    node = is_node_ui_script(explored)
    script_kind = (
        "Node.js Playwright（必须定义 async function run(page, agent)，不要写 import）"
        if node
        else "Python Playwright 同步脚本（必须定义 def run(page)，不要写 import）"
    )
    messages = [
        {
            "role": "system",
            "content": (
                "你是 UI 自动化失败修复助手。已经重新探索了真实页面。"
                "suggested_script 必须以这次探索编译出的脚本为准，最多微调断言以贴合功能用例期望，"
                "不得丢掉探索得到的 locator，不得凭报错编 locator。"
                "输出 JSON："
                '{"summary":"...","likely_causes":["..."],"changes":["..."],'
                '"warnings":["..."],"suggested_script":"完整可运行脚本"}。'
                f"suggested_script 必须是{script_kind}。"
                "page.goto 的参数必须是以 / 开头的相对路径。"
                f"{MIDSCENE_SCRIPT_POLICY}"
                "探索脚本里非验证码的 agent.aiTap/aiInput 若有 Playwright 等价 locator，必须改回 Playwright。"
                "修脚本解决不了的环境/账号问题放入 warnings。"
                "只输出 JSON，不要 Markdown。"
            ),
        },
        {
            "role": "user",
            "content": "失败上下文与探索结果：\n" + json.dumps(ctx, ensure_ascii=False),
        },
    ]
    try:
        cfg = get_llm_runtime(db)
        if not cfg.api_key.strip():
            return fallback
        raw_plan = llm_json(messages, cfg=cfg, scene="UI 失败修复")
    except Exception:  # noqa: BLE001
        log.exception("ui run fix suggest after explore failed")
        return fallback
    suggested = explored
    raw_script = str(raw_plan.get("suggested_script") or "")
    if raw_script.strip():
        try:
            candidate = _normalize_suggested_script(raw_script, original=explored)
            if _keeps_explore_locators(explored, candidate):
                suggested = candidate
        except ValueError:
            suggested = explored
    return {
        "category": fallback["category"],
        "recommended_action": "explore_repair",
        "apply_mode": "replace",
        "summary": str(raw_plan.get("summary") or fallback["summary"]).strip() or fallback["summary"],
        "likely_causes": _string_list(raw_plan.get("likely_causes")) or fallback["likely_causes"],
        "changes": _string_list(raw_plan.get("changes")) or fallback["changes"],
        "warnings": _string_list(raw_plan.get("warnings")) or fallback["warnings"],
        "suggested_patches": [],
        "suggested_script": suggested,
    }


def _sync_session_script(db: Session, run: UiRun, old_script: str, new_script: str) -> None:
    session = _session_for_run(db, run)
    if session is None:
        return
    session.playwright_code = new_script
    if not isinstance(session.plan_json, dict):
        return
    plan = dict(session.plan_json)
    scripts = plan.get("case_scripts")
    if not isinstance(scripts, list):
        return
    updated = False
    for item in scripts:
        if isinstance(item, dict) and str(item.get("code") or "") == old_script:
            item["code"] = new_script
            updated = True
            break
    if not updated:
        for item in scripts:
            if isinstance(item, dict) and item.get("ready"):
                item["code"] = new_script
                break
    plan["case_scripts"] = scripts
    session.plan_json = plan
    flag_modified(session, "plan_json")


def _enqueue_rerun(db: Session, meta: dict[str, Any], run: UiRun, case: UiCase, *, user_id: int | None) -> dict[str, Any]:
    from app.tasks.ui_automation.run_ui_case import enqueue_run_ui_case

    env = None
    if run.env_id is not None:
        env = db.get(UiEnvironment, run.env_id)
    queue = (env.queue_name if env else run.queue_name) or "ui"
    new_run = UiRun(
        project_id=run.project_id,
        trigger_type="case",
        target_id=case.id,
        env_id=run.env_id,
        browser=run.browser or "chromium",
        headless=bool(run.headless),
        account_name=run.account_name,
        queue_name=queue,
        status="pending",
        triggered_by=user_id or run.triggered_by,
    )
    db.add(new_run)
    db.commit()
    db.refresh(new_run)
    enqueue_run_ui_case(new_run.id, queue=queue)
    session = _session_for_run(db, run)
    if session is not None:
        session.run_id = new_run.id
        db.commit()
    meta["rerun_id"] = new_run.id
    return meta


def confirm_fix(
    db: Session,
    meta: dict[str, Any],
    *,
    action: str,
    apply_patch: bool,
    rerun: bool,
    user_id: int | None,
) -> dict[str, Any]:
    if action == "cancel":
        sid = meta.get("explore_session_id")
        if sid and meta.get("status") == "exploring":
            session = db.get(UiScenarioAgentSession, int(sid))
            if session is not None and session.status in ("running", "awaiting_human"):
                try:
                    stop_session(db, session)
                except AppError:
                    pass
        meta["status"] = "cancelled"
        meta["patch_message"] = "已取消"
        return put_fix(db, meta)

    plan = meta.get("plan") if isinstance(meta.get("plan"), dict) else {}
    apply_mode = str(plan.get("apply_mode") or "replace")
    run = db.get(UiRun, int(meta["run_id"]))
    case_id = meta.get("case_id")
    case = db.query(UiCase).filter(UiCase.id == case_id).first() if case_id else None

    if apply_mode == "none":
        if apply_patch:
            meta["status"] = "confirmed"
            meta["patch_message"] = "此归因分类不修改脚本。已确认建议；如需验证可勾选再试跑。"
            if rerun and run is not None and case is not None:
                meta = _enqueue_rerun(db, meta, run, case, user_id=user_id)
                meta["patch_message"] = f"此归因分类不修改脚本，已触发试跑 #{meta['rerun_id']}。"
            return put_fix(db, meta)
        meta["status"] = "confirmed"
        meta["patch_message"] = "已确认，未修改用例。"
        if rerun and run is not None and case is not None:
            meta = _enqueue_rerun(db, meta, run, case, user_id=user_id)
            meta["patch_message"] = f"已确认（未改脚本），并触发试跑 #{meta['rerun_id']}。"
        return put_fix(db, meta)

    if not apply_patch:
        meta["status"] = "confirmed"
        meta["patch_message"] = "已确认，未修改用例。勾选「确认时写入修补」后再点确认，才会把建议写回去。"
        return put_fix(db, meta)

    suggested = str(plan.get("suggested_script") or "").strip()
    if case is None:
        meta["status"] = "error"
        meta["error_message"] = UI_CASE_NOT_FOUND
        return put_fix(db, meta)
    try:
        new_script = _normalize_suggested_script(suggested, original=case.script or "")
    except ValueError as e:
        meta["status"] = "error"
        meta["error_message"] = str(e)
        return put_fix(db, meta)

    old_script = case.script or ""
    case.script = new_script
    if run is not None:
        _sync_session_script(db, run, old_script, new_script)
    db.commit()
    meta["status"] = "confirmed"
    meta["patch_message"] = f"已写入 UI 用例 #{case.id} 脚本。"
    meta["current_script"] = new_script

    if rerun and run is not None:
        meta = _enqueue_rerun(db, meta, run, case, user_id=user_id)
        meta["patch_message"] = f"已写入 UI 用例 #{case.id} 脚本，并触发试跑 #{meta['rerun_id']}。"

    return put_fix(db, meta)
