"""Conversational UI scenario agent: plan → explore → revise → confirm UiCase."""

from __future__ import annotations

import json
import logging
import re
import time
import uuid
from pathlib import Path
from typing import Any, Callable

from sqlalchemy.orm import Session, joinedload

from app.errors import AppError
from app.models.functional.testcase import TestCase
from app.models.ui_automation.ui_automation import UiCase, UiEnvironment, UiScenarioAgentSession, UiSuite
from app.services.api_automation.api_scenario_events import emit_log, get_event_bus
from app.services.ai.effective_ai_settings import LlmRuntime, get_llm_runtime, get_midscene_runtime
from app.services.ai import llm
from app.services.functional.testcase_run_finalize import (
    execution_mode_of,
    finalize_agent_once,
    judge_agent_once_result,
)
from app.services.ui_automation.ui_ai_explorer import (
    DEFAULT_MAX_STEPS,
    _extract_json,
    build_plan_from_testcase,
    run_explore_loop,
    steps_to_script,
    trace_to_explore_script,
    trace_to_ui_steps,
)
from app.services.ui_automation.ui_explore_engines import (
    run_midscene_engine,
    run_playwright_cli_engine,
)
from app.services.ui_automation.ui_explore_report import (
    annotate_steps,
    build_explore_report,
    ensure_plan_matrix,
    test_design_actions,
    warn_if_login_stuck,
)
from app.services.ui_automation.ui_node_script import (
    _is_login_case_name,
    is_node_ui_script,
    is_runnable_ui_script,
)
from app.services.ui_automation.ui_script_midscene_policy import MIDSCENE_SCRIPT_POLICY
from app.services.ui_automation.ui_env_auth import (
    BrowserAuth,
    browser_auth_satisfies_business,
    env_has_inject_config,
    normalize_auth_mode,
    resolve_browser_auth,
)
from app.services.functional.test_data_vars import as_str_dict, case_test_data_text
from app.services.ui_automation.ui_run_executor import _build_ctx, _load_env
from app.core.datetime_json import now_beijing, to_beijing_iso
from app.user_messages import (
    TEST_CASE_NOT_FOUND,
    UI_ENV_BASE_URL_REQUIRED,
    UI_ENV_NOT_FOUND,
    UI_ENV_TOKEN_REQUIRED,
)

log = logging.getLogger(__name__)

MANUAL_STOP_MESSAGE = "已手动停止探索"
TRIAL_REPAIR_MAX = 2

_COMBO_CREDS = [
    # 账号密码：admin admin123  /  账号密码 admin admin123
    re.compile(
        r"(?:账号密码|用户名密码|username\s*/?\s*password|user\s*/?\s*pass(?:word)?)"
        r"\s*[:=：]?\s*([^\s,，；;]+)\s+([^\s,，；;]+)",
        re.I,
    ),
    # 用户名 admin 与密码 admin123 / 输入用户名 admin 和密码 admin123
    re.compile(
        r"(?:账号|用户名|username|user(?:name)?)\s*[:=：]?\s*([^\s,，；;与和]+)"
        r"\s*(?:与|和|/|,|，)\s*(?:密码|password|passwd|pwd)\s*[:=：]?\s*([^\s,，；;]+)",
        re.I,
    ),
    # 登录系统 admin admin123 / 登录 admin admin123（需空白分隔的两段 token）
    re.compile(
        r"登录(?:系统)?\s+([^\s,，；;]+)\s+([^\s,，；;]+)",
        re.I,
    ),
]
_USER_PATTERNS = [
    re.compile(r"(?:账号|用户名|username|user(?:name)?)\s*[:=：]\s*([^\s,，；;]+)", re.I),
    re.compile(r"(?:账号|用户名)\s+([^\s,，；;与和]+)", re.I),
]
_PASS_PATTERNS = [
    re.compile(r"(?:密码|password|passwd|pwd)\s*[:=：]\s*([^\s,，；;]+)", re.I),
    re.compile(r"(?:密码)\s+([^\s,，；;]+)", re.I),
]
_REEXPLORE_HINT = re.compile(r"重新探索|重跑探索|再探索|重新生成步骤|re-?explore", re.I)
# Outcome / step-index tokens must never become username/password via regex scrape.
_BAD_CRED_VALUE = re.compile(
    r"^(?:"
    r"登录成功|登录失败|成功|失败|通过|离开|正确|错误|无效|"
    r"密码|账号|用户名|username|password|passwd|pwd|"
    r"\d+\.?"
    r")$",
    re.I,
)


def new_thread_id() -> str:
    return uuid.uuid4().hex


def plan_auth_mode(plan: dict[str, Any] | None) -> str | None:
    """Return explicit plan auth_mode, or None to follow env inject."""
    if not isinstance(plan, dict):
        return None
    return normalize_auth_mode(str(plan.get("_auth_mode") or "") or None)


def resolve_plan_browser_auth(env: Any, plan: dict[str, Any] | None) -> BrowserAuth:
    """Honor plan ``_auth_mode=none`` (login); otherwise follow env inject KV."""
    mode = plan_auth_mode(plan)
    if mode == "none":
        return resolve_browser_auth(env, auth_mode="none")
    if mode in ("account", "token"):
        name = None
        if isinstance(plan, dict):
            raw = str(plan.get("_account_name") or "").strip()
            name = raw or None
        return resolve_browser_auth(env, auth_mode=mode, account_name=name)
    return resolve_browser_auth(env, apply_env_defaults=True)


def is_plausible_credential_value(value: str, *, kind: str = "") -> bool:
    """True when a scraped/bound credential token looks usable (not outcome copy)."""
    text = str(value or "").strip().strip("\"'")
    if not text or len(text) > 64:
        return False
    if _BAD_CRED_VALUE.match(text):
        return False
    if kind == "username" and re.match(r"^密码", text):
        return False
    return True


def extract_credentials_from_text(text: str) -> dict[str, str]:
    """Pull username/password from free-form chat/step text. Never logs secrets.

    Rejects outcome phrases (e.g. 登录成功) and step indexes so case titles
    like 「用户名密码登录成功」+「1. …」 cannot poison ctx.
    """
    out: dict[str, str] = {}
    raw = text or ""
    for pat in _COMBO_CREDS:
        for m in pat.finditer(raw):
            user = m.group(1).strip().strip("\"'")
            pwd = m.group(2).strip().strip("\"'")
            if is_plausible_credential_value(user, kind="username") and is_plausible_credential_value(
                pwd, kind="password"
            ):
                return {"username": user, "password": pwd}
    for pat in _USER_PATTERNS:
        for m in pat.finditer(raw):
            user = m.group(1).strip().strip("\"'")
            if is_plausible_credential_value(user, kind="username"):
                out["username"] = user
                break
        if out.get("username"):
            break
    for pat in _PASS_PATTERNS:
        for m in pat.finditer(raw):
            pwd = m.group(1).strip().strip("\"'")
            if is_plausible_credential_value(pwd, kind="password"):
                out["password"] = pwd
                break
        if out.get("password"):
            break
    return out


def merge_credentials(*parts: dict[str, str] | None) -> dict[str, str]:
    merged: dict[str, str] = {}
    for p in parts:
        if not p:
            continue
        for k, v in p.items():
            if v:
                merged[str(k)] = str(v)
    return merged


def credentials_to_ctx(creds: dict[str, str]) -> dict[str, str]:
    """Map credentials into script env. Always include username/password as strings."""
    ctx: dict[str, str] = {}
    user = str(creds.get("username") or creds.get("user") or "")
    pwd = str(creds.get("password") or creds.get("passwd") or "")
    ctx["username"] = user
    ctx["user"] = user
    ctx["LOGIN_USERNAME"] = user
    ctx["password"] = pwd
    ctx["passwd"] = pwd
    ctx["LOGIN_PASSWORD"] = pwd
    for k, v in creds.items():
        if k not in ctx and v is not None:
            ctx[str(k)] = str(v)
    return ctx


def script_env_from_ctx(ctx: dict[str, str] | None) -> dict[str, str]:
    """Env dict for Node dry-run: always string username/password so fill() never gets undefined."""
    base = {str(k): str(v) for k, v in (ctx or {}).items() if v is not None}
    base.setdefault("username", "")
    base.setdefault("password", "")
    base.setdefault("user", base["username"])
    base.setdefault("passwd", base["password"])
    base.setdefault("LOGIN_USERNAME", base["username"])
    base.setdefault("LOGIN_PASSWORD", base["password"])
    return base


def _append_message(session: UiScenarioAgentSession, role: str, content: str) -> None:
    msgs = list(session.messages_json) if isinstance(session.messages_json, list) else []
    msgs.append({"role": role, "content": content})
    session.messages_json = msgs


def _persist_event(session: UiScenarioAgentSession, ev: dict[str, Any]) -> None:
    events = list(session.events_json) if isinstance(session.events_json, list) else []
    events.append(ev)
    session.events_json = events


def _emit(
    session: UiScenarioAgentSession,
    *,
    node: str,
    message: str,
    level: str = "info",
    data: dict[str, Any] | None = None,
) -> None:
    def persist(ev: dict[str, Any]) -> None:
        _persist_event(session, ev)

    emit_log(session.thread_id, node=node, message=message, level=level, data=data, persist=persist)


def _emit_commit(
    db: Session,
    session: UiScenarioAgentSession,
    *,
    node: str,
    message: str,
    level: str = "info",
    data: dict[str, Any] | None = None,
) -> None:
    _emit(session, node=node, message=message, level=level, data=data)
    db.commit()


def session_headed(session: UiScenarioAgentSession) -> bool:
    plan = session.plan_json if isinstance(session.plan_json, dict) else {}
    return bool(plan.get("_headed"))


def _attach_explore_report(
    session: UiScenarioAgentSession,
    *,
    plan: dict[str, Any],
    steps: list[dict[str, Any]] | None,
    script: str = "",
    engine: str = "",
) -> dict[str, Any]:
    """Annotate steps, build explore report, persist into plan_json."""
    case_scripts = plan.get("case_scripts") if isinstance(plan.get("case_scripts"), list) else []
    bound_matrix = plan.get("matrix") if isinstance(plan.get("matrix"), list) else None
    bound_cases = bool(plan.get("_bound_functional_cases"))
    plan = ensure_plan_matrix(plan, synthesize_if_empty=bound_cases)
    if bound_matrix:
        plan["matrix"] = bound_matrix
    if case_scripts:
        plan["case_scripts"] = case_scripts
    # Prefer matrix already bound by explore engine (structured steps + ready flags).
    annotated = annotate_steps(steps, matrix=plan.get("matrix") if isinstance(plan.get("matrix"), list) else [])
    report = build_explore_report(
        plan=plan,
        steps=annotated,
        script=script,
        engine=engine,
        synthesize_matrix=bound_cases,
    )
    if isinstance(plan.get("matrix"), list) and plan["matrix"]:
        report["matrix"] = plan["matrix"]
    plan["explore_report"] = report
    plan["matrix"] = report.get("matrix") or plan.get("matrix")
    session.plan_json = plan
    session.result_steps_json = annotated
    return report


def _emit_matrix_summary(db: Session, session: UiScenarioAgentSession, plan: dict[str, Any]) -> None:
    matrix = plan.get("matrix") if isinstance(plan.get("matrix"), list) else []
    if not matrix:
        return
    lines = [f"{r.get('id')}: {r.get('name')}" for r in matrix if isinstance(r, dict)]
    preview = "；".join(lines[:8])
    if len(lines) > 8:
        preview += f"…（共 {len(lines)} 条）"
    _emit_commit(db, session, node="plan", message=f"用例（{len(lines)}）：{preview}")
    get_event_bus().append(session.thread_id, {"type": "matrix", "matrix": matrix})


def _normalize_explore_plan(data: dict[str, Any], *, fallback_goal: str) -> dict[str, Any]:
    start = str(data.get("start_path") or "/").strip() or "/"
    if not start.startswith("/"):
        start = "/" + start
    checklist = data.get("checklist") if isinstance(data.get("checklist"), list) else []
    out: dict[str, Any] = {
        "goal": str(data.get("goal") or fallback_goal or "UI 探索"),
        "start_path": start,
        "checklist": [str(x) for x in checklist][:20],
        "case_name": str(data.get("case_name") or "").strip() or None,
        "matrix": [],
        "case_scripts": [],
    }
    # LLM-extracted credentials (validated); consumed into session.credentials_json later.
    user = str(data.get("username") or data.get("user") or "").strip().strip("\"'")
    pwd = str(data.get("password") or data.get("passwd") or "").strip().strip("\"'")
    if is_plausible_credential_value(user, kind="username") and is_plausible_credential_value(
        pwd, kind="password"
    ):
        out["_extracted_username"] = user
        out["_extracted_password"] = pwd
    test_data = str(data.get("test_data") or "").strip()
    if test_data:
        out["test_data"] = test_data[:2000]
    from app.services.ui_automation.ui_explore_report import apply_sequential_explore_matrix

    if out.get("checklist"):
        out = apply_sequential_explore_matrix(out)
    return out


def credentials_from_plan(plan: dict[str, Any] | None) -> dict[str, str]:
    """Pull validated credentials staged on the plan by build_plan_from_prompt."""
    if not isinstance(plan, dict):
        return {}
    user = str(plan.pop("_extracted_username", "") or "").strip()
    pwd = str(plan.pop("_extracted_password", "") or "").strip()
    out: dict[str, str] = {}
    if is_plausible_credential_value(user, kind="username"):
        out["username"] = user
    if is_plausible_credential_value(pwd, kind="password"):
        out["password"] = pwd
    return out


def _fallback_plan_from_prompt(prompt: str) -> dict[str, Any]:
    text = (prompt or "").strip() or "UI 探索"
    # Heuristic checklist from numbered / arrow-separated lines
    parts = re.split(r"[\n；;]+|(?<=\d)[、.．]\s*", text)
    checklist = [p.strip(" \t-•→") for p in parts if len(p.strip(" \t-•→")) >= 2][:12]
    if not checklist:
        checklist = [text[:80]]
    # Prefer "/" ; regex scrape may still find creds. Avoid hardcoding product login path.
    start = "/"
    scraped = extract_credentials_from_text(text)
    out = {
        "goal": text[:500],
        "start_path": start,
        "checklist": checklist,
        "case_name": None,
        "matrix": [],
        "case_scripts": [],
    }
    if checklist:
        from app.services.ui_automation.ui_explore_report import apply_sequential_explore_matrix

        out = apply_sequential_explore_matrix(out)
    if scraped.get("username") and scraped.get("password"):
        out["_extracted_username"] = scraped["username"]
        out["_extracted_password"] = scraped["password"]
    return out


def _planner_system_prompt() -> str:
    """Domain-agnostic planner rules; matrix is built server-side from checklist."""
    return (
        "你是 Web UI 自动化探索规划助手。根据用户自然语言写出探索目标与检查点。"
        "只输出 JSON 对象，键："
        "goal(string 一次探索要覆盖的业务目标), "
        "start_path(string, 以/开头的相对路径), "
        "checklist(array of string 探索时要覆盖的功能点，按顺序), "
        "case_name(string 建议场景名), "
        "username(string 可选，用户明文给出的登录账号), "
        "password(string 可选，用户明文给出的登录密码)。"
        "不要输出 matrix；服务端会按 checklist 顺序生成探索用例矩阵，探索后编译脚本。"
        "checklist 规则：每条仅一个可独立 done 的业务结果；"
        "禁止在同一条中用「并/然后/→/以及」串联多个业务动作。"
        "若用户需求含多种业务操作（如增删改查），须拆成多条 checklist，顺序与用户流程一致，"
        "每条名称用用户描述中的业务对象与动词，不要臆造未出现的模块名。"
        "不要写成单步 UI 操作（填某字段、点某按钮、点确定）。"
        "禁止把「弹窗能否打开/关闭」单独写成 checklist 项。"
        "可选 test_data(string)：探索 fill 用的样例数据；优先 JSON 对象字符串，"
        "键名与用户需求中的实体/字段语义一致（英文 snake_case），或「键: 值」分行文案。"
        "若用户在需求中写了账号与密码，填入 username/password；未给出则两键省略或空字符串。"
        "禁止一次输出多个 JSON 或数组；只输出一个 JSON 对象。"
        "字符串内的双引号必须转义为 \\\"。不要输出 Markdown。"
    )


def _planner_user_prompt(*, base_url: str, prompt: str) -> str:
    text = prompt or "(无描述，打开首页并做基本冒烟)"
    actions = test_design_actions(prompt=text, goal=text, checklist=[])
    lines = [
        f"被测 base_url: {base_url}",
        f"用户需求:\n{text}",
    ]
    if actions:
        lines.append(
            "规划提示：从需求中识别到业务操作类型 "
            + "、".join(actions)
            + "。请为每种需要的操作各写至少一条 checklist（可验收的业务结果），"
            "顺序与用户在需求中描述的流程一致；示例结构仅为「动词+对象+结果」，"
            "须使用需求里出现的业务名词，勿套用其它产品示例。"
        )
    return "\n".join(lines) + "\n"


def build_plan_from_prompt(
    *,
    prompt: str,
    base_url: str,
    llm_cfg: LlmRuntime,
    model: str | None = None,
) -> dict[str, Any]:
    """Plan: goal + checklist; server applies sequential matrix before explore."""
    messages: list[dict[str, str]] = [
        {"role": "system", "content": _planner_system_prompt()},
        {"role": "user", "content": _planner_user_prompt(base_url=base_url, prompt=prompt)},
    ]
    raw = llm.chat_complete(
        messages, model=model, db=None, cfg=llm_cfg, json_mode=True, scene="UI 场景规划"
    )
    try:
        data = _extract_json(raw)
        if not isinstance(data, dict):
            raise ValueError("计划不是 JSON 对象")
        return _normalize_explore_plan(data, fallback_goal=prompt or "UI 探索")
    except (json.JSONDecodeError, ValueError, TypeError) as ex1:
        log.warning("UI 场景规划 JSON 解析失败，重试: %s", ex1)
        retry = list(messages)
        retry.append({"role": "assistant", "content": (raw or "")[:4000]})
        retry.append(
            {
                "role": "user",
                "content": (
                    f"上一份输出不是合法 JSON（{ex1}）。请只重新输出一个合法 JSON 对象，"
                    "键 goal/start_path/checklist/case_name，可选 username/password/test_data；不要 Markdown。"
                ),
            }
        )
        raw2 = llm.chat_complete(
            retry, model=model, db=None, cfg=llm_cfg, json_mode=True, scene="UI 场景规划"
        )
        try:
            data2 = _extract_json(raw2)
            if not isinstance(data2, dict):
                raise ValueError("计划不是 JSON 对象")
            return _normalize_explore_plan(data2, fallback_goal=prompt or "UI 探索")
        except (json.JSONDecodeError, ValueError, TypeError) as ex2:
            log.warning("UI 场景规划 JSON 重试仍失败，使用降级计划: %s", ex2)
            return _fallback_plan_from_prompt(prompt)


def _strip_code_fence(raw: str) -> str:
    text = (raw or "").strip()
    if not text.startswith("```"):
        return text
    lines = text.splitlines()
    if lines and lines[0].startswith("```"):
        lines = lines[1:]
    if lines and lines[-1].strip() == "```":
        lines = lines[:-1]
    return "\n".join(lines).strip()


def _pick_revise_script(
    session: UiScenarioAgentSession,
    plan: dict[str, Any],
    *,
    case_id: str = "",
) -> tuple[str, str | None, int | None]:
    """Return (script, case_id or None, index in case_scripts or None)."""
    wanted = (case_id or "").strip()
    case_scripts = plan.get("case_scripts") if isinstance(plan.get("case_scripts"), list) else []
    rows = [c for c in case_scripts if isinstance(c, dict)]
    if wanted:
        for i, row in enumerate(rows):
            if str(row.get("id") or "").strip() == wanted:
                code = str(row.get("code") or "").strip() or (session.playwright_code or "")
                return code, wanted, i
    for i, row in enumerate(rows):
        code = str(row.get("code") or "").strip()
        if row.get("ready") and code:
            return code, str(row.get("id") or "").strip() or None, i
    if rows:
        code = str(rows[0].get("code") or "").strip() or (session.playwright_code or "")
        return code, str(rows[0].get("id") or "").strip() or None, 0
    return session.playwright_code or "", None, None


def revise_script_with_llm(
    *,
    script: str,
    instruction: str,
    plan: dict[str, Any] | None,
    llm_cfg: LlmRuntime,
    model: str | None = None,
) -> str:
    node = is_node_ui_script(script)
    if node:
        system = (
            "你是 UI 自动化脚本编辑助手。根据用户指令修改 Node.js Playwright 脚本。"
            "脚本必须定义 async function run(page, agent)。不要写 import。"
            "可使用 page、agent、env。page 是 Playwright；agent 仅用于验证码 aiQuery 等极少视觉步。"
            "page.goto 的参数必须是以 / 开头的相对路径。"
            f"{MIDSCENE_SCRIPT_POLICY}"
            "只输出 JavaScript，不要 Markdown。"
        )
    else:
        system = (
            "你是 UI 自动化脚本编辑助手。根据用户指令修改 Python Playwright 同步脚本。"
            "脚本必须定义 def run(page):，不要写 import。"
            "可使用已注入的 page、expect、env、re。"
            "page.goto 的参数必须是以 / 开头的相对路径。"
            "只输出 Python 代码，不要 Markdown。"
        )
    messages = [
        {"role": "system", "content": system},
        {
            "role": "user",
            "content": json.dumps(
                {
                    "plan": plan or {},
                    "current_script": script,
                    "instruction": instruction,
                },
                ensure_ascii=False,
            ),
        },
    ]
    raw = llm.chat_complete(
        messages,
        model=model,
        db=None,
        cfg=llm_cfg,
        json_mode=False,
        scene="UI 场景修订",
    )
    code = _strip_code_fence(raw)
    if node:
        if "async function run" not in code:
            raise ValueError("修订结果不是可执行脚本")
    elif "def run" not in code:
        raise ValueError("修订结果不是可执行脚本")
    if not code.endswith("\n"):
        code += "\n"
    return code


def resolve_env(db: Session, project_id: int, env_id: int | None) -> UiEnvironment:
    env = _load_env(db, project_id, env_id)
    if env is None:
        raise AppError("not_found", UI_ENV_NOT_FOUND, status_code=404)
    return env


def _explore_with_engine(
    db: Session,
    session: UiScenarioAgentSession,
    *,
    engine: str,
    env: UiEnvironment,
    plan: dict[str, Any],
    ctx: dict[str, str],
    llm_cfg: LlmRuntime,
    base_url: str,
    browser_name: str,
    headed: bool,
    timeout_ms: int,
    max_steps: int,
    title: str,
    browser_factory: Callable[[], Any] | None,
    browser_auth: BrowserAuth | None = None,
) -> None:
    del title, browser_factory
    username = ctx.get("username") or ""
    password = ctx.get("password") or ""
    auth = browser_auth or BrowserAuth()
    vp = env.viewport_json if isinstance(env.viewport_json, dict) else {"width": 1280, "height": 720}
    viewport = {"width": int(vp.get("width") or 1280), "height": int(vp.get("height") or 720)}
    def _engine_log(message: str, data: dict[str, Any] | None = None) -> None:
        _emit_commit(db, session, node="explore", message=str(message or "")[:2000], data=data)

    def _on_screenshot(png: bytes, meta: dict[str, Any]) -> str | None:
        from app.services.file_storage import save_ui_explore_screenshot

        n = int(meta.get("step") or 0)
        action = str(meta.get("action") or "step").strip() or "step"
        fname = f"{n:03d}_{action}.png"
        try:
            key, _ = save_ui_explore_screenshot(session.project_id, session.id, fname, png)
        except Exception as ex:  # noqa: BLE001
            _engine_log(f"截图保存失败: {ex}")
            return None
        _engine_log(f"已截图 step={n} action={action}", data={"screenshot_key": key})
        return key

    session_id = session.id
    human_wait_sec = 15 * 60

    def _should_cancel() -> bool:
        from app.deps import SessionLocal

        sdb = SessionLocal()
        try:
            row = sdb.get(UiScenarioAgentSession, session_id)
            if row is None:
                return True
            return row.status not in ("running", "awaiting_human")
        finally:
            sdb.close()

    def _wait_human_reply(reason: str) -> str | None:
        from app.deps import SessionLocal

        hint = (reason or "需要人工协助（例如验证码）").strip()[:500]
        sdb = SessionLocal()
        try:
            row = sdb.get(UiScenarioAgentSession, session_id)
            if row is None:
                return None
            if row.status not in ("running", "awaiting_human"):
                return None
            plan_obj = dict(row.plan_json) if isinstance(row.plan_json, dict) else {}
            plan_obj.pop("_human_reply", None)
            row.plan_json = plan_obj
            row.status = "awaiting_human"
            row.error_message = ""
            _emit(row, node="explore", message=hint, level="warn")
            get_event_bus().append(
                row.thread_id,
                {"type": "need_human", "message": hint, "node": "explore"},
            )
            _append_message(
                row,
                "assistant",
                f"{hint}\n浏览器保持打开。请在页面上手动操作，或在此输入验证码/说明后发送；也可发送「继续」。",
            )
            sdb.commit()
        finally:
            sdb.close()

        deadline = time.monotonic() + human_wait_sec
        while time.monotonic() < deadline:
            if _should_cancel():
                return None
            sdb = SessionLocal()
            try:
                row = sdb.get(UiScenarioAgentSession, session_id)
                if row is None:
                    return None
                if row.status == "error":
                    return None
                plan_obj = dict(row.plan_json) if isinstance(row.plan_json, dict) else {}
                if "_human_reply" in plan_obj:
                    reply = str(plan_obj.pop("_human_reply") or "")
                    row.plan_json = plan_obj
                    row.status = "running"
                    _emit(row, node="explore", message="已收到人工协助，继续探索…")
                    sdb.commit()
                    return reply
            finally:
                sdb.close()
            time.sleep(0.5)
        return None

    try:
        if engine == "playwright":
            if _should_cancel():
                raise RuntimeError(MANUAL_STOP_MESSAGE)
            trace, code = run_playwright_cli_engine(
                base_url=base_url,
                start_path=str(plan.get("start_path") or "/"),
                goal=str(plan.get("goal") or session.prompt or ""),
                username=username,
                password=password,
                ctx=ctx,
                llm=llm_cfg,
                headed=headed,
                timeout_ms=timeout_ms,
                max_steps=max_steps,
                plan=plan,
                on_log=_engine_log,
                should_cancel=_should_cancel,
                on_need_human=_wait_human_reply if headed else None,
                on_screenshot=_on_screenshot,
                storage_state=auth.storage_state,
                extra_http_headers=auth.extra_http_headers,
                local_storage=auth.local_storage,
                skip_login=auth.skip_login,
            )
        else:
            # midscene label: same CLI explore; Midscene only in generated complex steps
            midscene = get_midscene_runtime(db)
            if _should_cancel():
                raise RuntimeError(MANUAL_STOP_MESSAGE)
            trace, code = run_midscene_engine(
                base_url=base_url,
                start_path=str(plan.get("start_path") or "/"),
                goal=str(plan.get("goal") or session.prompt or ""),
                username=username,
                password=password,
                ctx=ctx,
                midscene=midscene,
                browser=browser_name,
                headed=headed,
                viewport=viewport,
                timeout_ms=timeout_ms,
                on_log=_engine_log,
                should_cancel=_should_cancel,
                on_need_human=_wait_human_reply if headed else None,
                on_screenshot=_on_screenshot,
                llm=llm_cfg,
                max_steps=max_steps,
                plan=plan,
                prefer_cli=True,
                storage_state=auth.storage_state,
                extra_http_headers=auth.extra_http_headers,
                local_storage=auth.local_storage,
                skip_login=auth.skip_login,
            )
    except AppError as ex:
        _settle_explore_failure(db, session, ex.message)
        return
    except Exception as ex:  # noqa: BLE001
        stopped = MANUAL_STOP_MESSAGE in str(ex)
        if not stopped:
            log.exception("ui engine explore failed id=%s engine=%s", session.id, engine)
        db.refresh(session)
        _settle_explore_failure(
            db, session, MANUAL_STOP_MESSAGE if stopped else str(ex), stopped=stopped
        )
        return

    # Human-assist path mutates the row via a separate SessionLocal; reload before write-back.
    db.refresh(session)
    # Stop may have landed while the engine was finishing / codegen — do not overwrite.
    if session.status not in ("running", "awaiting_human") or _should_cancel():
        if session.status != "error":
            _settle_explore_failure(
                db, session, MANUAL_STOP_MESSAGE, stopped=True, node="explore"
            )
        return
    # Drop any captured storageState — auth is env inject KV, not per-account storage.
    if isinstance(plan, dict):
        plan.pop("_captured_storage_state", None)
    if isinstance(session.plan_json, dict) and "_captured_storage_state" in session.plan_json:
        # JSON column is not mutation-tracked; reassign a new dict so the change is flushed.
        session.plan_json = {
            k: v for k, v in session.plan_json.items() if k != "_captured_storage_state"
        }
    _complete_explore(
        db,
        session,
        plan=plan,
        trace=trace,
        code=code,
        engine=engine,
        script_kind="node",
    )


def _screenshot_keys_from_events(session: UiScenarioAgentSession) -> list[str]:
    events = session.events_json if isinstance(session.events_json, list) else []
    keys: list[str] = []
    for ev in events:
        if not isinstance(ev, dict):
            continue
        data = ev.get("data") if isinstance(ev.get("data"), dict) else {}
        key = str(data.get("screenshot_key") or "").strip()
        if key and key not in keys:
            keys.append(key)
    return keys


def _finalize_agent_once_on_failure(
    db: Session,
    session: UiScenarioAgentSession,
    *,
    status: str,
    error_message: str,
) -> None:
    plan = session.plan_json if isinstance(session.plan_json, dict) else {}
    if execution_mode_of(plan) != "agent_once":
        return
    run = finalize_agent_once(
        db,
        session,
        status=status,
        error_message=error_message,
        summary=error_message or f"Agent 直跑{status}",
        actual_result=error_message,
        screenshot_keys=_screenshot_keys_from_events(session),
    )
    if run is not None:
        get_event_bus().append(
            session.thread_id,
            {
                "type": "done",
                "status": status,
                "case_run_id": run.id,
                "case_run_status": run.status,
            },
        )


def _settle_explore_failure(
    db: Session,
    session: UiScenarioAgentSession,
    message: str,
    *,
    stopped: bool = False,
    node: str = "error",
) -> None:
    """Park the session in error (manual stop included, so the user can keep chatting)."""
    session.status = "error"
    session.error_message = message
    _emit_commit(db, session, node=node, message=message, level="warn" if stopped else "error")
    get_event_bus().append(session.thread_id, {"type": "error", "message": message})
    _finalize_agent_once_on_failure(
        db,
        session,
        status="cancelled" if stopped else "error",
        error_message=message,
    )
    db.commit()


def _complete_explore(
    db: Session,
    session: UiScenarioAgentSession,
    *,
    plan: dict[str, Any],
    trace: list[Any],
    code: str,
    engine: str,
    script_kind: str = "node",
) -> None:
    """Finish explore: either codegen → awaiting_confirm, or agent_once → TestCaseRun."""
    mode = execution_mode_of(plan if isinstance(plan, dict) else session.plan_json)
    session.trace_json = trace
    steps = trace if isinstance(trace, list) else []

    if mode == "agent_once":
        session.playwright_code = ""
        report = _attach_explore_report(
            session, plan=plan, steps=steps, script="", engine=engine
        )
        mid_n = int((report.get("summary") or {}).get("midscene_steps") or 0)
        pw_n = int((report.get("summary") or {}).get("playwright_steps") or 0)
        result, err = judge_agent_once_result(trace if isinstance(trace, list) else [])
        _emit_commit(
            db,
            session,
            node="explore",
            message=(
                f"Agent 直跑完成：Playwright {pw_n} 步 / Midscene {mid_n} 步；结果 {result}"
                + (f"（{err}）" if err else "")
            ),
            level="error" if result != "passed" else "info",
        )
        get_event_bus().append(session.thread_id, {"type": "explore_report", "report": report})
        run = finalize_agent_once(
            db,
            session,
            status=result,
            error_message=err,
            summary="Agent 直跑通过" if result == "passed" else (err or "Agent 直跑失败"),
            actual_result=err or ("已按用例完成探索断言" if result == "passed" else ""),
            screenshot_keys=_screenshot_keys_from_events(session),
        )
        assistant = (
            f"Agent 直跑已结束：{'通过' if result == 'passed' else '失败'}。"
            + (f" {err}" if err else "")
            + (f" 执行记录 #{run.id}。" if run is not None else "")
        )
        _append_message(session, "assistant", assistant)
        session.status = "done" if result == "passed" else ("failed" if result == "failed" else session.status)
        # Normalize: use done for both pass/fail so clients poll until settled
        if session.status not in ("error", "cancelled"):
            session.status = "done"
        if not session.error_message and result != "passed":
            session.error_message = err or "Agent 直跑失败"
        get_event_bus().append(
            session.thread_id,
            {
                "type": "done",
                "status": "done",
                "case_run_id": run.id if run else None,
                "case_run_status": result,
            },
        )
        get_event_bus().append(session.thread_id, {"type": "plan", "plan": session.plan_json})
        db.commit()
        return

    session.playwright_code = code
    # Prefer first ready script from explore codegen.
    case_scripts = plan.get("case_scripts") if isinstance(plan.get("case_scripts"), list) else []
    verified_codes = [
        str(c.get("code") or "")
        for c in case_scripts
        if isinstance(c, dict)
        and c.get("verify_status") == "passed"
        and str(c.get("code") or "").strip()
    ]
    ready_codes = [
        str(c.get("code") or "")
        for c in case_scripts
        if isinstance(c, dict) and c.get("ready") and str(c.get("code") or "").strip()
    ]
    preferred_codes = verified_codes or ready_codes
    if preferred_codes:
        code = preferred_codes[0]
        session.playwright_code = code
        plan["case_scripts"] = case_scripts
        session.plan_json = plan

    report = _attach_explore_report(
        session, plan=plan, steps=steps, script=code, engine=engine
    )
    mid_n = int((report.get("summary") or {}).get("midscene_steps") or 0)
    pw_n = int((report.get("summary") or {}).get("playwright_steps") or 0)
    _emit_commit(
        db,
        session,
        node="explore",
        message=f"探索完成：Playwright {pw_n} 步 / Midscene {mid_n} 步；已生成 explore report 与脚本",
    )
    get_event_bus().append(session.thread_id, {"type": "explore_report", "report": report})
    if not (code or "").strip():
        session.error_message = "探索未产生可执行脚本"
    stuck = warn_if_login_stuck(
        steps if isinstance(steps, list) else [],
        matrix=plan.get("matrix") if isinstance(plan.get("matrix"), list) else [],
        single_case=bool(plan.get("_single_case")),
    )
    if stuck:
        _emit_commit(db, session, node="explore", message=stuck, level="warn")
    if script_kind == "python":
        assistant = (
            "已生成探索报告与 Python 脚本（snapshot 探索）。"
            "左侧可查看用例 / driver 与脚本；确认后才会写入 UI 用例。"
        )
    else:
        generated_n = len([c for c in case_scripts if isinstance(c, dict)])
        ready_n = len(
            [
                c
                for c in case_scripts
                if isinstance(c, dict)
                and c.get("ready")
                and str(c.get("code") or "").strip()
            ]
        )
        from app.config import settings

        guard_note = (
            "（LLM 直出，未做自动校验，请试跑确认）"
            if str(settings.ui_codegen_guard or "off").strip().lower() != "strict"
            else "（已通过自动校验）"
        )
        assistant = (
            "已生成探索报告与 Node 脚本（稳定步用 Playwright，动态步用 Midscene）。"
            f"共 {generated_n} 条用例，LLM 脚本 {ready_n} 条{guard_note}。"
            "左侧可查看用例动作与脚本，可先试跑再确认写入 UI 用例。"
        )
    if stuck:
        assistant = f"{assistant}\n\n{stuck}"
    _append_message(session, "assistant", assistant)
    session.status = "awaiting_confirm"
    get_event_bus().append(
        session.thread_id,
        {"type": "interrupted", "message": "等待确认写入 UI 用例"},
    )
    get_event_bus().append(session.thread_id, {"type": "plan", "plan": session.plan_json})
    db.commit()


def execute_session_explore(
    db: Session,
    session_id: int,
    *,
    llm_cfg: LlmRuntime | None = None,
    browser_factory: Callable[[], Any] | None = None,
) -> None:
    """Plan + browser explore; ends in awaiting_confirm, done (agent_once), or error."""
    session = db.get(UiScenarioAgentSession, session_id)
    if session is None:
        log.warning("ui scenario session %s not found", session_id)
        return
    # Manual stop parks status=error so the user can chat / re-explore; never restart settled sessions.
    if session.status in ("cancelled", "confirmed", "done", "awaiting_confirm", "error"):
        return

    session.status = "running"
    session.error_message = ""
    db.commit()

    get_event_bus().replace(session.thread_id, list(session.events_json or []))
    cfg = llm_cfg or get_llm_runtime(db)

    try:
        env = resolve_env(db, session.project_id, session.env_id)
        base_url = (env.base_url or "").strip()
        if not base_url:
            raise AppError("bad_request", UI_ENV_BASE_URL_REQUIRED, status_code=400)

        prior_plan = session.plan_json if isinstance(session.plan_json, dict) else {}
        creds = merge_credentials(
            session.credentials_json if isinstance(session.credentials_json, dict) else None
        )
        ctx = _build_ctx(env, None)
        if not ctx.get("username") and ctx.get("user"):
            ctx["username"] = str(ctx["user"])
        ctx.update(credentials_to_ctx(creds))
        browser_auth = resolve_plan_browser_auth(env, prior_plan)
        if (
            plan_auth_mode(prior_plan) != "none"
            and env_has_inject_config(env)
            and not (browser_auth.extra_http_headers or browser_auth.local_storage)
        ):
            raise AppError("bad_request", UI_ENV_TOKEN_REQUIRED, status_code=400)

        _emit_commit(db, session, node="plan", message="正在生成探索计划…")

        extra_prompt = (session.prompt or "").strip()
        title = extra_prompt or "UI 探索"
        prior_ids = prior_plan.get("_testcase_ids") if isinstance(prior_plan.get("_testcase_ids"), list) else []
        testcase_ids: list[int] = []
        for x in prior_ids:
            try:
                testcase_ids.append(int(x))
            except (TypeError, ValueError):
                continue
        if not testcase_ids and session.testcase_id is not None:
            testcase_ids = [int(session.testcase_id)]

        if testcase_ids:
            from app.services.ui_automation.ui_explore_report import matrix_rows_from_testcases

            rows_tc = (
                db.query(TestCase)
                .options(joinedload(TestCase.steps))
                .filter(TestCase.id.in_(testcase_ids), TestCase.project_id == session.project_id)
                .all()
            )
            by_id = {int(tc.id): tc for tc in rows_tc}
            missing = [i for i in testcase_ids if i not in by_id]
            if missing:
                raise AppError("not_found", TEST_CASE_NOT_FOUND, status_code=404)
            case_payloads: list[dict[str, Any]] = []
            checklist: list[str] = []
            goal_parts: list[str] = []
            for tid in testcase_ids:
                tc = by_id[tid]
                td_text = case_test_data_text(variables=tc.variables_json, test_data=tc.test_data)
                case_vars = as_str_dict(tc.variables_json)
                if case_vars:
                    ctx.update(case_vars)
                steps = [{"action": s.action, "expected": s.expected} for s in (tc.steps or [])]
                case_payloads.append(
                    {
                        "id": tid,
                        "title": tc.title,
                        "steps": steps,
                        "test_data": td_text,
                        "overall_expected": tc.overall_expected or "",
                        "precondition": tc.precondition or "",
                    }
                )
                goal_parts.append(tc.title)
                for s in steps:
                    act = (s.get("action") or "").strip()
                    if act:
                        checklist.append(f"[{tc.title}] {act}")
            title = "；".join(goal_parts) if len(goal_parts) <= 3 else f"{goal_parts[0]} 等 {len(goal_parts)} 条用例"
            # Planning LLM for start_path/goal; matrix comes from selected cases (no正反扩展).
            plan = build_plan_from_testcase(
                title=title,
                steps=[{"action": c, "expected": ""} for c in checklist[:20]],
                base_url=base_url,
                llm_cfg=cfg,
                test_data=None,
                overall_expected=None,
                precondition=None,
                extra_prompt=extra_prompt,
                skip_login=browser_auth.skip_login,
            )
            start = str(plan.get("start_path") or "/").strip() or "/"
            plan["matrix"] = matrix_rows_from_testcases(case_payloads, default_start=start)
            plan["case_name"] = title
            plan["checklist"] = checklist[:20] or list(plan.get("checklist") or [])
            plan["goal"] = (
                f"按所选 {len(case_payloads)} 条功能用例完成探索并生成脚本："
                + "；".join(goal_parts[:5])
            )
            plan["_bound_functional_cases"] = True
            plan["_testcase_ids"] = testcase_ids
            plan["_single_case"] = False
        else:
            plan = build_plan_from_prompt(prompt=session.prompt, base_url=base_url, llm_cfg=cfg)
            plan["_bound_functional_cases"] = False
            plan["_testcase_ids"] = []
            plan["_single_case"] = False

        # Prefer LLM-extracted creds from plan; regex scrape remains a fallback.
        plan_creds = credentials_from_plan(plan)
        scrape_creds = extract_credentials_from_text(
            f"{session.prompt or ''}\n{extra_prompt or title}"
        )
        creds = merge_credentials(
            session.credentials_json if isinstance(session.credentials_json, dict) else None,
            plan_creds,
            scrape_creds,
            creds,
        )
        if creds:
            session.credentials_json = creds
            ctx.update(credentials_to_ctx(creds))

        max_steps = DEFAULT_MAX_STEPS
        headed = False
        engine = "midscene"
        if isinstance(prior_plan.get("_max_steps"), int):
            max_steps = max(1, min(50, int(prior_plan["_max_steps"])))
        headed = bool(prior_plan.get("_headed"))
        raw_engine = str(prior_plan.get("engine") or "midscene")
        if raw_engine in ("midscene", "playwright"):
            engine = raw_engine
        plan["_max_steps"] = max_steps
        plan["_headed"] = headed
        plan["engine"] = engine
        # Preserve session auth (none = login / skip inject); default follow-env.
        preserved_auth = plan_auth_mode(prior_plan)
        plan["_auth_mode"] = preserved_auth
        plan["_account_name"] = (
            str(prior_plan.get("_account_name") or "").strip() or None
            if preserved_auth == "account"
            else None
        )
        plan["_execution_mode"] = execution_mode_of(prior_plan)
        if prior_plan.get("_case_run_id") is not None:
            plan["_case_run_id"] = prior_plan.get("_case_run_id")
        plan["user_prompt"] = extra_prompt or title
        for key, value in prior_plan.items():
            if str(key).startswith("_repair_"):
                plan[key] = value
        plan.setdefault("_testcase_ids", testcase_ids)
        plan["_bound_functional_cases"] = bool(testcase_ids) or bool(
            plan.get("_bound_functional_cases")
        )
        # Selected cases / free-text expansion always multi-script path (not single E2E layout).
        plan["_single_case"] = False
        if not plan.get("matrix") and plan.get("checklist"):
            from app.services.ui_automation.ui_explore_report import apply_sequential_explore_matrix

            plan = apply_sequential_explore_matrix(plan)
        if isinstance(plan.get("matrix"), list) and plan["matrix"]:
            plan = ensure_plan_matrix(plan, synthesize_if_empty=False)
        else:
            plan = dict(plan)
            plan.setdefault("matrix", [])
            plan.setdefault("case_scripts", [])
        if plan.get("_sequential_matrix") and isinstance(plan.get("matrix"), list):
            n = len(plan["matrix"])
            if n > 1:
                max_steps = min(50, max(max_steps, 8 + 6 * n))
                plan["_max_steps"] = max_steps
        session.plan_json = plan
        _emit_commit(db, session, node="plan", message=f"目标：{plan.get('goal') or title}")
        exec_mode = execution_mode_of(plan)
        if exec_mode == "agent_once":
            checks = plan.get("checklist") if isinstance(plan.get("checklist"), list) else []
            hint = f"；检查点 {len(checks)} 项" if checks else ""
            _emit_commit(
                db,
                session,
                node="plan",
                message=f"Agent 直跑：按功能用例执行{hint}，不生成脚本",
            )
        elif testcase_ids:
            n = len(testcase_ids)
            checks = plan.get("checklist") if isinstance(plan.get("checklist"), list) else []
            hint = f"；检查点 {len(checks)} 项" if checks else ""
            _emit_commit(
                db,
                session,
                node="plan",
                message=f"按所选 {n} 条功能用例探索{hint}，每条生成一条 UI 脚本",
            )
            if isinstance(plan.get("matrix"), list) and plan["matrix"]:
                _emit_matrix_summary(db, session, plan)
        elif isinstance(plan.get("matrix"), list) and plan["matrix"]:
            _emit_matrix_summary(db, session, plan)
        else:
            checks = plan.get("checklist") if isinstance(plan.get("checklist"), list) else []
            hint = f"；检查点 {len(checks)} 项" if checks else ""
            _emit_commit(
                db,
                session,
                node="plan",
                message=f"先探索界面{hint}，完成后按测试设计扩展多条脚本",
            )

        timeout_ms = int(getattr(env, "default_timeout_ms", None) or 15000)
        browser_name = session.browser or env.browser or "chromium"
        mode = "有头" if headed else "无头"
        engine_label = {
            "playwright": "playwright",
            "midscene": "playwright+midscene",
        }.get(engine, engine)
        _emit_commit(
            db,
            session,
            node="explore",
            message=f"开始浏览器探索（{engine_label} · {browser_name} · {mode}）…",
        )
        # Default path: playwright-cli. browser_factory keeps in-process Playwright for tests.
        if engine in ("midscene", "playwright") and browser_factory is None:
            _explore_with_engine(
                db,
                session,
                engine=engine,
                env=env,
                plan=plan,
                ctx=ctx,
                llm_cfg=cfg,
                base_url=base_url,
                browser_name=browser_name,
                headed=headed,
                timeout_ms=timeout_ms,
                max_steps=max_steps,
                title=title,
                browser_factory=browser_factory,
                browser_auth=browser_auth,
            )
            return

        def _cancelled() -> bool:
            db.refresh(session)
            return session.status not in ("running", "awaiting_human")

        def _on_step(item: dict[str, Any]) -> None:
            act = item.get("action")
            st = item.get("status")
            sel = item.get("selector") or ""
            val = item.get("value")
            err = item.get("error")
            extra = ""
            if sel:
                extra += f" sel={sel}"
            if val is not None and act in ("goto", "fill", "press", "select_option"):
                extra += f" value={val}"
            if err:
                extra += f" err={err}"
            _emit_commit(
                db,
                session,
                node="explore",
                message=f"{act} → {st}{extra}",
                level="error" if st == "error" else "info",
            )

        cdp_endpoint: str | None = None
        mid_cfg: dict[str, str] | None = None
        try:
            mid_cfg = get_midscene_runtime(db).as_model_config()
        except Exception:  # noqa: BLE001
            mid_cfg = None

        if browser_factory is not None:
            page = browser_factory()
            trace = run_explore_loop(
                page=page,
                base_url=base_url,
                plan=plan,
                ctx=ctx,
                llm_cfg=cfg,
                max_steps=max_steps,
                timeout_ms=timeout_ms,
                should_cancel=_cancelled,
                on_step=_on_step,
                cdp_endpoint=None,
                model_config=mid_cfg,
            )
        else:
            from playwright.sync_api import sync_playwright

            from app.services.ui_automation.node_ui_runner import (
                cdp_endpoint_for_port,
                chromium_launch_args,
                free_cdp_port,
            )

            with sync_playwright() as p:
                use_name = browser_name if browser_name in ("chromium", "firefox", "webkit") else "chromium"
                launcher = getattr(p, use_name)
                launch_kwargs: dict[str, Any] = {"headless": not headed}
                if use_name == "chromium":
                    cdp_port = free_cdp_port()
                    launch_kwargs["args"] = chromium_launch_args(cdp_port=cdp_port)
                    cdp_endpoint = cdp_endpoint_for_port(cdp_port)
                browser = launcher.launch(**launch_kwargs)
                try:
                    vp = env.viewport_json if isinstance(env.viewport_json, dict) else {"width": 1280, "height": 720}
                    page = browser.new_page(
                        viewport={
                            "width": int(vp.get("width") or 1280),
                            "height": int(vp.get("height") or 720),
                        }
                    )
                    page.set_default_timeout(timeout_ms)
                    trace = run_explore_loop(
                        page=page,
                        base_url=base_url,
                        plan=plan,
                        ctx=ctx,
                        llm_cfg=cfg,
                        max_steps=max_steps,
                        timeout_ms=timeout_ms,
                        should_cancel=_cancelled,
                        on_step=_on_step,
                        cdp_endpoint=cdp_endpoint,
                        model_config=mid_cfg,
                    )
                finally:
                    browser.close()

        if _cancelled():
            session.trace_json = trace
            _settle_explore_failure(
                db, session, MANUAL_STOP_MESSAGE, stopped=True, node="explore"
            )
            get_event_bus().append(session.thread_id, {"type": "done", "status": "error"})
            return

        steps = trace_to_ui_steps(trace)
        # Preserve locator hints from explore loop for driver inference
        for i, step in enumerate(steps):
            if i < len(trace) and isinstance(trace[i], dict):
                for key in ("locate", "placeholder", "role", "name", "reason", "driver", "prompt", "kind"):
                    if trace[i].get(key) and key not in step:
                        step[key] = trace[i].get(key)
        code = ""
        if execution_mode_of(plan) != "agent_once":
            code = trace_to_explore_script(
                title=title,
                base_url=base_url,
                trace=trace,
                start_path=str(plan.get("start_path") or "/"),
                username=str(ctx.get("username") or ""),
                password=str(ctx.get("password") or ""),
            )
        _complete_explore(
            db,
            session,
            plan=plan,
            trace=steps,
            code=code,
            engine="playwright",
            script_kind="python",
        )
    except AppError as ex:
        _settle_explore_failure(db, session, ex.message)
    except Exception as ex:  # noqa: BLE001
        log.exception("ui scenario explore failed id=%s", session_id)
        _settle_explore_failure(db, session, str(ex))
    finally:
        try:
            db.refresh(session)
            _maybe_complete_repair_explore(db, session)
        except Exception:  # noqa: BLE001
            log.exception("ui repair explore complete failed id=%s", session_id)


def _maybe_complete_repair_explore(db: Session, session: UiScenarioAgentSession) -> None:
    plan = session.plan_json if isinstance(session.plan_json, dict) else {}
    if not plan.get("_repair_fix_id"):
        return
    from app.services.ui_automation.ui_run_fix import complete_repair_from_explore

    complete_repair_from_explore(db, session)


def _apply_explore_tune(
    db: Session,
    session: UiScenarioAgentSession,
    tune: dict[str, Any],
) -> None:
    """Apply optional retune fields before re-explore (env / headed / auth / layout / case)."""
    if not tune:
        return
    plan = dict(session.plan_json) if isinstance(session.plan_json, dict) else {}
    if "env_id" in tune and tune["env_id"] is not None:
        env = resolve_env(db, session.project_id, int(tune["env_id"]))
        session.env_id = env.id
    if "browser" in tune:
        browser = (str(tune["browser"] or "")).strip()
        if browser:
            session.browser = browser
    if "testcase_ids" in tune or "testcase_id" in tune:
        ids: list[int] = []
        raw_ids = tune.get("testcase_ids")
        if isinstance(raw_ids, list):
            for x in raw_ids:
                try:
                    ids.append(int(x))
                except (TypeError, ValueError):
                    continue
        elif "testcase_id" in tune:
            tid = tune["testcase_id"]
            if tid is not None:
                try:
                    ids = [int(tid)]
                except (TypeError, ValueError):
                    ids = []
        # Dedupe
        seen: set[int] = set()
        merged: list[int] = []
        for i in ids:
            if i not in seen:
                seen.add(i)
                merged.append(i)
        plan["_testcase_ids"] = merged
        plan["_bound_functional_cases"] = bool(merged)
        plan["_single_case"] = False
        session.testcase_id = merged[0] if merged else None
    if "headed" in tune and tune["headed"] is not None:
        plan["_headed"] = bool(tune["headed"])
    if "auth_mode" in tune:
        plan["_auth_mode"] = normalize_auth_mode(
            str(tune["auth_mode"]) if tune["auth_mode"] is not None else None
        )
    if "account_name" in tune:
        name = str(tune.get("account_name") or "").strip()
        plan["_account_name"] = name or None
    if plan.get("_auth_mode") != "account":
        plan["_account_name"] = None
    session.plan_json = plan


def apply_user_message(
    db: Session,
    session: UiScenarioAgentSession,
    content: str,
    *,
    case_id: str = "",
    llm_cfg: LlmRuntime | None = None,
    browser_factory: Callable[[], Any] | None = None,
    enqueue_explore: Callable[[int, str], str | None] | None = None,
    explore_tune: dict[str, Any] | None = None,
) -> UiScenarioAgentSession:
    if session.status not in ("awaiting_confirm", "error", "awaiting_human"):
        raise AppError("bad_request", f"当前状态不可继续对话: {session.status}", status_code=400)

    text = content.strip()
    _append_message(session, "user", text)

    new_creds = extract_credentials_from_text(text)
    if new_creds:
        session.credentials_json = merge_credentials(
            session.credentials_json if isinstance(session.credentials_json, dict) else None,
            new_creds,
        )
        _emit(session, node="credentials", message="已从对话更新账号信息（密码不回显）")

    if session.status == "awaiting_human":
        plan = dict(session.plan_json) if isinstance(session.plan_json, dict) else {}
        plan["_human_reply"] = text
        session.plan_json = plan
        _append_message(session, "assistant", "已收到，浏览器中继续探索…")
        _emit(session, node="explore", message="已收到人工协助回复")
        db.commit()
        db.refresh(session)
        return session

    cfg = llm_cfg or get_llm_runtime(db)
    from_error = session.status == "error"
    want_reexplore = from_error or bool(_REEXPLORE_HINT.search(text))

    if want_reexplore:
        if explore_tune:
            _apply_explore_tune(db, session, explore_tune)
        if from_error and text:
            prev = (session.prompt or "").strip()
            session.prompt = f"{prev}\n{text}".strip() if prev else text
        session.status = "running"
        session.dry_run_status = None
        session.dry_run_error = ""
        session.error_message = ""
        _append_message(session, "assistant", "好的，将按最新对话重新探索页面…")
        db.commit()
        if enqueue_explore is not None:
            env = resolve_env(db, session.project_id, session.env_id)
            task_id = enqueue_explore(session.id, env.queue_name or "ui")
            if task_id:
                session.celery_task_id = task_id
                db.commit()
        else:
            execute_session_explore(db, session.id, llm_cfg=cfg, browser_factory=browser_factory)
        db.refresh(session)
        return session

    plan = dict(session.plan_json) if isinstance(session.plan_json, dict) else {}
    current_script, resolved_case_id, case_idx = _pick_revise_script(
        session, plan, case_id=case_id
    )
    label = resolved_case_id or "当前脚本"
    _emit(session, node="revise", message=f"正在根据对话修订 {label}…")
    db.commit()
    try:
        revised = revise_script_with_llm(
            script=current_script,
            instruction=text,
            plan=plan,
            llm_cfg=cfg,
        )
        if not is_runnable_ui_script(revised):
            raise ValueError("修订后脚本无效")
        case_scripts = plan.get("case_scripts") if isinstance(plan.get("case_scripts"), list) else []
        if isinstance(case_scripts, list) and case_idx is not None and 0 <= case_idx < len(case_scripts):
            row = dict(case_scripts[case_idx]) if isinstance(case_scripts[case_idx], dict) else {}
            row["code"] = revised
            row["ready"] = True
            case_scripts[case_idx] = row
            plan["case_scripts"] = case_scripts
            session.plan_json = plan
        session.playwright_code = revised
        _append_message(
            session,
            "assistant",
            f"已按你的要求改好 {label}。可继续修改或确认写入。",
        )
        session.status = "awaiting_confirm"
        db.commit()
    except Exception as ex:  # noqa: BLE001
        _append_message(session, "assistant", f"修订失败：{ex}。可换一种说法，或说「重新探索」。")
        session.status = "awaiting_confirm"
        _emit(session, node="revise", message=str(ex), level="error")
        db.commit()
    db.refresh(session)
    return session


def stop_session(db: Session, session: UiScenarioAgentSession) -> UiScenarioAgentSession:
    """Abort a running explore; leave session in error so the user can continue chatting."""
    if session.status not in ("running", "awaiting_human"):
        if session.status == "error" and (session.error_message or "").startswith(MANUAL_STOP_MESSAGE):
            db.refresh(session)
            return session
        raise AppError("bad_request", f"当前状态不可停止: {session.status}", status_code=400)

    plan = dict(session.plan_json) if isinstance(session.plan_json, dict) else {}
    plan.pop("_human_reply", None)
    session.plan_json = plan
    session.status = "error"
    session.error_message = MANUAL_STOP_MESSAGE
    _append_message(session, "assistant", f"{MANUAL_STOP_MESSAGE}，可继续描述后重试。")
    _emit(session, node="explore", message=MANUAL_STOP_MESSAGE, level="warn")
    get_event_bus().append(session.thread_id, {"type": "error", "message": MANUAL_STOP_MESSAGE})
    get_event_bus().append(session.thread_id, {"type": "done", "status": "error"})
    _finalize_agent_once_on_failure(
        db, session, status="cancelled", error_message=MANUAL_STOP_MESSAGE
    )
    db.commit()

    task_id = (session.celery_task_id or "").strip()
    if task_id:
        try:
            from app.tasks.celery_app import celery_app

            # Soft revoke only: terminate=True with --pool=solo can kill the worker process.
            # Cooperative cancel polls DB status via should_cancel / _should_cancel.
            celery_app.control.revoke(task_id, terminate=False)
        except Exception:  # noqa: BLE001
            log.warning("revoke ui scenario task failed task_id=%s", task_id, exc_info=True)

    db.refresh(session)
    return session


def _manual_case_id_for_script(
    case_meta: dict[str, Any],
    fallback: int | None,
) -> int | None:
    mid = case_meta.get("manual_case_id")
    if mid is None:
        return fallback
    try:
        return int(mid)
    except (TypeError, ValueError):
        return fallback


def _default_suite_name(
    plan: dict[str, Any],
    *,
    session_id: int,
    override: str | None,
) -> str:
    if override and str(override).strip():
        return str(override).strip()[:512]
    case_name = str(plan.get("case_name") or "").strip()
    if case_name:
        return case_name[:512]
    goal = str(plan.get("goal") or "").strip()
    if goal:
        return goal[:512]
    return f"UI Agent 会话 #{session_id}"


def confirm_session(
    db: Session,
    session: UiScenarioAgentSession,
    *,
    action: str,
    name: str | None = None,
    script: str | None = None,
    case_status: str = "ready",
    user_id: int | None = None,
    case_ids: list[str] | None = None,
    case_overrides: list[dict[str, Any]] | None = None,
    create_suite: bool = True,
    suite_name: str | None = None,
    suite_description: str | None = None,
    suite_env_id: int | None = None,
    suite_browsers: list[str] | None = None,
    suite_stop_on_fail: bool | None = None,
) -> UiScenarioAgentSession:
    plan = session.plan_json if isinstance(session.plan_json, dict) else {}
    if execution_mode_of(plan) == "agent_once":
        raise AppError(
            "bad_request",
            "Agent 直跑模式不会写入 UI 用例，请查看功能用例执行记录",
            status_code=400,
        )
    if plan.get("_repair_fix_id"):
        raise AppError(
            "bad_request",
            "修复探索请在失败记录中确认建议，不会单独写入新用例",
            status_code=400,
        )
    if session.status not in ("awaiting_confirm", "error"):
        raise AppError("bad_request", f"会话状态不可确认: {session.status}", status_code=400)

    if action == "cancel":
        raise AppError(
            "bad_request",
            "不支持取消会话，请保留草稿或直接导入 UI 用例",
            status_code=400,
        )

    plan = session.plan_json if isinstance(session.plan_json, dict) else {}
    case_scripts = plan.get("case_scripts") if isinstance(plan.get("case_scripts"), list) else []
    override_map: dict[str, str] = {}
    for item in case_overrides or []:
        if not isinstance(item, dict):
            continue
        cid = str(item.get("id") or "").strip()
        code = str(item.get("code") or "").strip()
        if cid and code:
            override_map[cid] = code

    merged_rows: list[dict[str, Any]] = []
    for raw in case_scripts:
        if not isinstance(raw, dict):
            continue
        row = dict(raw)
        cid = str(row.get("id") or "").strip()
        if cid in override_map:
            row["code"] = override_map[cid]
        merged_rows.append(row)

    ready_cases = [
        c
        for c in merged_rows
        if is_runnable_ui_script(str(c.get("code") or ""))
    ]
    if case_ids is not None:
        want = {str(x).strip() for x in case_ids if str(x).strip()}
        ready_cases = [c for c in ready_cases if str(c.get("id") or "").strip() in want]

    chosen = (script or "").strip() or (session.playwright_code or "").strip()
    if not ready_cases:
        if not merged_rows:
            if not chosen:
                legacy = list(session.result_steps_json) if isinstance(session.result_steps_json, list) else []
                chosen = steps_to_script(legacy).strip()
            if not is_runnable_ui_script(chosen):
                raise AppError("bad_request", "没有可写入的脚本", status_code=400)
            ready_cases = [
                {
                    "id": "TC-001",
                    "name": (
                        (name or "").strip()
                        or (str(plan.get("case_name") or "").strip() if plan else "")
                        or (str(plan.get("goal") or "").strip() if plan else "")
                        or f"UI Agent #{session.id}"
                    ),
                    "code": chosen,
                    "ready": True,
                }
            ]
        else:
            raise AppError("bad_request", "没有可写入的脚本", status_code=400)
    session.playwright_code = str(ready_cases[0].get("code") or chosen)

    def _normalize_case_steps(raw: list[Any] | None) -> list[dict[str, Any]] | None:
        out: list[dict[str, Any]] = []
        for item in raw or []:
            if not isinstance(item, dict):
                continue
            action = str(item.get("action") or "").strip()
            if not action or action == "done":
                continue
            step = dict(item)
            step.pop("screenshot_key", None)
            step.pop("screenshot", None)
            out.append(step)
        return out or None

    def _steps_for_case(case_meta: dict[str, Any]) -> list[dict[str, Any]] | None:
        raw = case_meta.get("steps") if isinstance(case_meta.get("steps"), list) else None
        if not raw:
            matrix = plan.get("matrix") if isinstance(plan.get("matrix"), list) else []
            cid = str(case_meta.get("id") or "")
            for row in matrix:
                if isinstance(row, dict) and str(row.get("id") or "") == cid:
                    if isinstance(row.get("steps"), list):
                        raw = row["steps"]
                    break
        if not raw:
            raw = session.result_steps_json if isinstance(session.result_steps_json, list) else None
        return _normalize_case_steps(raw if isinstance(raw, list) else None)

    saved_ids: list[int] = []
    for c in ready_cases:
        code = str(c.get("code") or "").strip()
        if not is_runnable_ui_script(code):
            continue
        title = f"{c.get('id') or 'UC'}: {c.get('name') or 'UI 用例'}".strip(": ")
        if name and len(ready_cases) == 1:
            title = (name or "").strip() or title
        case = UiCase(
            project_id=session.project_id,
            name=title[:512],
            description=f"由 UI 自动化 Agent 会话 #{session.id} 生成",
            script=code,
            steps_json=_steps_for_case(c),
            # Do not invent case variables; user may set them later on the case form.
            variables_json=None,
            auth_mode=plan_auth_mode(plan if isinstance(plan, dict) else None),
            manual_case_id=_manual_case_id_for_script(c, session.testcase_id),
            status=case_status if case_status in ("draft", "ready") else "ready",
            creator_id=user_id or session.user_id,
        )
        db.add(case)
        db.flush()
        saved_ids.append(int(case.id))
    if not saved_ids:
        raise AppError("bad_request", "没有可写入的脚本", status_code=400)

    saved_suite_id: int | None = None
    if create_suite and saved_ids:
        desc_override = (suite_description or "").strip()
        suite_desc = (
            desc_override
            if desc_override
            else f"由 UI 自动化 Agent 会话 #{session.id} 生成"
        )
        suite_env = suite_env_id if suite_env_id is not None else session.env_id
        suite_stop = True if suite_stop_on_fail is None else bool(suite_stop_on_fail)
        suite_browser_list = list(suite_browsers) if suite_browsers else []
        suite_row = UiSuite(
            project_id=session.project_id,
            name=_default_suite_name(plan, session_id=int(session.id), override=suite_name),
            description=suite_desc[:65535],
            case_ids_json=list(saved_ids),
            stop_on_fail=suite_stop,
            env_id=suite_env,
            browsers_json=suite_browser_list,
            creator_id=user_id or session.user_id,
        )
        db.add(suite_row)
        db.flush()
        saved_suite_id = int(suite_row.id)
        session.saved_ui_suite_id = saved_suite_id

    db.commit()

    session.saved_ui_case_id = saved_ids[0]
    plan_patch: dict[str, Any] = {"saved_ui_case_ids": saved_ids}
    if saved_suite_id is not None:
        plan_patch["saved_ui_suite_id"] = saved_suite_id
    if isinstance(session.plan_json, dict):
        session.plan_json = {**session.plan_json, **plan_patch}
    elif saved_suite_id is not None or saved_ids:
        session.plan_json = plan_patch
    session.status = "confirmed"
    ids_text = "、".join(f"#{i}" for i in saved_ids)
    msg = f"已确认并写入 {len(saved_ids)} 条 UI 用例：{ids_text}。"
    if saved_suite_id is not None:
        msg += f" 已创建 UI 套件 #{saved_suite_id}。"
    _append_message(session, "assistant", msg)
    done_event: dict[str, Any] = {
        "type": "done",
        "status": "confirmed",
        "saved_ui_case_id": saved_ids[0],
        "saved_ui_case_ids": saved_ids,
    }
    if saved_suite_id is not None:
        done_event["saved_ui_suite_id"] = saved_suite_id
    get_event_bus().append(session.thread_id, done_event)
    db.commit()

    db.refresh(session)
    return session


def session_has_script_draft(session: UiScenarioAgentSession) -> bool:
    plan = session.plan_json if isinstance(session.plan_json, dict) else {}
    case_scripts = plan.get("case_scripts") if isinstance(plan.get("case_scripts"), list) else []
    for c in case_scripts:
        if isinstance(c, dict) and str(c.get("code") or "").strip():
            return True
    return bool((session.playwright_code or "").strip())


_REOPEN_DRAFT_STATUSES = frozenset({"cancelled", "confirmed", "done", "error"})


def reopen_session(db: Session, session: UiScenarioAgentSession) -> UiScenarioAgentSession:
    """Restore archived sessions to awaiting_confirm when scripts still exist."""
    if session.status not in _REOPEN_DRAFT_STATUSES:
        raise AppError("bad_request", f"当前状态不可恢复草稿: {session.status}", status_code=400)
    if not session_has_script_draft(session):
        raise AppError("bad_request", "没有可恢复的脚本草稿", status_code=400)
    session.status = "awaiting_confirm"
    _append_message(session, "assistant", "已恢复为草稿，可试跑或导入 UI 用例。")
    get_event_bus().append(
        session.thread_id,
        {"type": "interrupted", "message": "等待确认写入 UI 用例"},
    )
    db.commit()
    db.refresh(session)
    return session


def _trial_case_is_login(meta: dict[str, Any] | None) -> bool:
    if not isinstance(meta, dict):
        return False
    if bool(meta.get("is_login")):
        return True
    return _is_login_case_name(str(meta.get("name") or ""))


def _trial_case_needs_auth(meta: dict[str, Any] | None, plan: dict[str, Any]) -> bool:
    """Business matrix rows need storageState; login / ad-hoc single scripts do not."""
    if not isinstance(meta, dict) or _trial_case_is_login(meta):
        return False
    if "needs_auth" in meta:
        return bool(meta.get("needs_auth"))
    case_scripts = plan.get("case_scripts") if isinstance(plan.get("case_scripts"), list) else []
    has_login = any(_trial_case_is_login(c) for c in case_scripts if isinstance(c, dict))
    return bool(has_login and len(case_scripts) > 1)


def _trial_auth_file_path(session: UiScenarioAgentSession) -> Path:
    from app.config import settings

    dest = (
        Path(settings.upload_dir).resolve()
        / str(session.project_id)
        / "ui-explore"
        / str(session.id)
    )
    dest.mkdir(parents=True, exist_ok=True)
    return dest / "trial_auth.json"


def _trial_auth_path_from_plan(plan: dict[str, Any]) -> str | None:
    raw = plan.get("_trial_auth") if isinstance(plan.get("_trial_auth"), dict) else {}
    path = str(raw.get("path") or "").strip()
    if path and Path(path).is_file():
        return path
    return None


def _find_login_case_script(plan: dict[str, Any]) -> dict[str, Any] | None:
    case_scripts = plan.get("case_scripts") if isinstance(plan.get("case_scripts"), list) else []
    for row in case_scripts:
        if not isinstance(row, dict):
            continue
        if not _trial_case_is_login(row):
            continue
        code = str(row.get("code") or "").strip()
        if is_runnable_ui_script(code):
            return row
    return None


def _resolve_trial_script(
    session: UiScenarioAgentSession,
    *,
    case_id: str,
    script: str | None = None,
) -> tuple[str, str, dict[str, Any]]:
    """Return (case_id, code, case_meta) for trial run.

    ``case_meta`` includes ``needs_auth`` / ``is_login`` when known.
    """
    override = (script or "").strip()
    plan = session.plan_json if isinstance(session.plan_json, dict) else {}
    case_scripts = plan.get("case_scripts") if isinstance(plan.get("case_scripts"), list) else []
    wanted = (case_id or "").strip()
    chosen: dict[str, Any] | None = None
    if wanted:
        for row in case_scripts:
            if isinstance(row, dict) and str(row.get("id") or "").strip() == wanted:
                chosen = row
                break
    if chosen is None and case_scripts:
        for row in case_scripts:
            if isinstance(row, dict) and row.get("ready") and str(row.get("code") or "").strip():
                chosen = row
                break
    if chosen is None:
        code = override or (session.playwright_code or "").strip()
        if not is_runnable_ui_script(code):
            raise AppError("bad_request", "没有可试跑的脚本", status_code=400)
        meta = {"id": wanted or "script", "name": "当前脚本", "code": code, "is_login": False, "needs_auth": False}
        return wanted or "script", code, meta

    cid = str(chosen.get("id") or "").strip() or wanted or "TC"
    code = override or str(chosen.get("code") or "").strip()
    if not is_runnable_ui_script(code):
        raise AppError("bad_request", f"用例 {cid} 没有可执行脚本", status_code=400)
    meta = dict(chosen)
    meta["is_login"] = _trial_case_is_login(meta)
    meta["needs_auth"] = _trial_case_needs_auth(meta, plan if isinstance(plan, dict) else {})
    return cid, code, meta


def enqueue_session_trial_run(
    db: Session,
    session: UiScenarioAgentSession,
    *,
    case_id: str = "",
    headed: bool = True,
    script: str | None = None,
    enqueue: Callable[[int, str], str | None] | None = None,
) -> UiScenarioAgentSession:
    """Mark session dry_run running and enqueue Celery trial task."""
    if session.status not in ("awaiting_confirm", "confirmed", "done", "error"):
        raise AppError(
            "bad_request",
            f"当前状态不可试跑: {session.status}",
            status_code=400,
        )
    if session.dry_run_status == "running":
        raise AppError("bad_request", "试跑进行中，请稍候", status_code=400)

    cid, code, meta = _resolve_trial_script(session, case_id=case_id, script=script)
    plan = dict(session.plan_json) if isinstance(session.plan_json, dict) else {}
    prev_trial = plan.get("_trial") if isinstance(plan.get("_trial"), dict) else {}
    prev_cid = str(prev_trial.get("case_id") or "").strip()
    repair_attempts = (
        int(prev_trial.get("repair_attempts") or 0) if prev_cid and prev_cid == cid else 0
    )
    is_login = bool(meta.get("is_login"))
    needs_auth = bool(meta.get("needs_auth"))
    plan["_trial"] = {
        "case_id": cid,
        "case_name": str(meta.get("name") or cid),
        "headed": bool(headed),
        "script": code,
        "is_login": is_login,
        "needs_auth": needs_auth,
        "failure": None,
        "repair_attempts": repair_attempts,
        "repair_status": None,
        "repair_requested": False,
        "repair_preview": None,
        "step_results": [],
    }
    session.plan_json = plan
    session.dry_run_status = "running"
    session.dry_run_error = ""
    mode = "有头" if headed else "无头"
    hint = ""
    if is_login:
        hint = "，将保存登录态"
    elif needs_auth:
        hint = "，将复用登录态"
    _emit(
        session,
        node="trial",
        message=f"开始试跑 {cid}（{mode}）{hint}…",
    )
    trial_start = {
        "type": "trial_start",
        "case_id": cid,
        "headed": bool(headed),
    }
    _persist_event(session, trial_start)
    get_event_bus().append(session.thread_id, trial_start)
    db.commit()

    env = resolve_env(db, session.project_id, session.env_id)
    queue = env.queue_name or "ui"
    if enqueue is not None:
        task_id = enqueue(session.id, queue)
    else:
        from app.tasks.ui_automation.run_ui_scenario_agent import enqueue_ui_scenario_agent_trial

        task_id = enqueue_ui_scenario_agent_trial(session.id, queue=queue)
    if task_id:
        session.celery_task_id = task_id
        db.commit()
    db.refresh(session)
    return session


def _trial_repair_case_meta(plan: dict[str, Any], cid: str, trial: dict[str, Any], script: str) -> dict[str, Any]:
    scripts = plan.get("case_scripts") if isinstance(plan.get("case_scripts"), list) else []
    for item in scripts:
        if isinstance(item, dict) and str(item.get("id") or "") == cid:
            meta = dict(item)
            meta["is_login"] = _trial_case_is_login(meta)
            meta["needs_auth"] = _trial_case_needs_auth(meta, plan)
            return meta
    return {
        "id": cid,
        "name": str(trial.get("case_name") or cid),
        "code": script,
        "is_login": bool(trial.get("is_login")),
        "needs_auth": bool(trial.get("needs_auth")),
    }


def _assert_trial_repair_eligible(session: UiScenarioAgentSession) -> tuple[dict[str, Any], dict[str, Any], str]:
    if session.dry_run_status not in ("failed", "error"):
        raise AppError("bad_request", "只有试跑失败后才能触发 AI 修复", status_code=400)
    plan = dict(session.plan_json) if isinstance(session.plan_json, dict) else {}
    trial = dict(plan.get("_trial")) if isinstance(plan.get("_trial"), dict) else {}
    if not isinstance(trial.get("failure"), dict):
        raise AppError("bad_request", "缺少试跑失败现场，无法进行 AI 修复", status_code=400)
    attempts = int(trial.get("repair_attempts") or 0)
    if attempts >= TRIAL_REPAIR_MAX:
        raise AppError(
            "bad_request",
            f"AI 修复已达到 {TRIAL_REPAIR_MAX} 轮上限",
            status_code=400,
        )
    script = str(trial.get("script") or "").strip()
    if not is_runnable_ui_script(script):
        raise AppError("bad_request", "当前没有可修复的试跑脚本", status_code=400)
    return plan, trial, script


def _commit_trial_case_script(session: UiScenarioAgentSession, cid: str, repaired: str) -> dict[str, Any]:
    plan = dict(session.plan_json) if isinstance(session.plan_json, dict) else {}
    scripts = plan.get("case_scripts") if isinstance(plan.get("case_scripts"), list) else []
    updated: list[Any] = []
    matched = False
    for item in scripts:
        if isinstance(item, dict) and str(item.get("id") or "") == cid:
            updated.append({**item, "code": repaired})
            matched = True
        else:
            updated.append(item)
    if matched:
        plan["case_scripts"] = updated
    session.playwright_code = repaired
    session.plan_json = plan
    return plan


def preview_session_trial_repair(db: Session, session: UiScenarioAgentSession) -> UiScenarioAgentSession:
    """Sync LLM repair; store diff preview on plan._trial (does not write case_scripts)."""
    from app.services.ui_automation.ui_codegen_agents import repair_trial_script

    plan, trial, script = _assert_trial_repair_eligible(session)
    cid = str(trial.get("case_id") or "").strip() or "script"
    failure = trial.get("failure") if isinstance(trial.get("failure"), dict) else {}
    case_meta = _trial_repair_case_meta(plan, cid, trial, script)
    creds = merge_credentials(
        session.credentials_json if isinstance(session.credentials_json, dict) else None
    )
    repaired, repair_issues = repair_trial_script(
        script=script,
        row=case_meta,
        failure=failure,
        llm=get_llm_runtime(db),
        credentials=list(creds.values()),
    )
    attempts = int(trial.get("repair_attempts") or 0)
    trial["repair_preview"] = {
        "before": script,
        "after": repaired,
        "issues": list(repair_issues),
        "status": "pending",
        "created_at": to_beijing_iso(now_beijing()),
    }
    trial["repair_status"] = "preview"
    plan["_trial"] = trial
    session.plan_json = plan
    _emit(
        session,
        node="trial",
        message=f"已生成第 {attempts + 1} 轮 AI 修复预览，请确认 diff 后应用"
        + ("（修复建议可能不完整）" if repair_issues else ""),
    )
    event = {
        "type": "trial_repair_preview",
        "case_id": cid,
        "attempt": attempts + 1,
        "has_issues": bool(repair_issues),
    }
    _persist_event(session, event)
    get_event_bus().append(session.thread_id, event)
    db.commit()
    db.refresh(session)
    return session


def apply_session_trial_repair(
    db: Session,
    session: UiScenarioAgentSession,
    *,
    script: str,
) -> UiScenarioAgentSession:
    """Apply user-confirmed script; increment repair_attempts; clear preview."""
    plan, trial, _ = _assert_trial_repair_eligible(session)
    cid = str(trial.get("case_id") or "").strip() or "script"
    cleaned = str(script or "").strip()
    if not is_runnable_ui_script(cleaned):
        raise AppError("bad_request", "脚本缺少可执行的 run 函数", status_code=400)
    attempts = int(trial.get("repair_attempts") or 0)
    _commit_trial_case_script(session, cid, cleaned)
    plan = dict(session.plan_json) if isinstance(session.plan_json, dict) else plan
    trial = dict(plan.get("_trial")) if isinstance(plan.get("_trial"), dict) else trial
    trial["script"] = cleaned
    trial["repair_attempts"] = attempts + 1
    trial["repair_preview"] = None
    trial["repair_status"] = "applied"
    trial["repair_requested"] = False
    plan["_trial"] = trial
    session.plan_json = plan
    _emit(session, node="trial", message=f"已应用第 {attempts + 1} 轮 AI 修复脚本到用例 {cid}")
    event = {
        "type": "trial_repair_applied",
        "case_id": cid,
        "attempt": attempts + 1,
    }
    _persist_event(session, event)
    get_event_bus().append(session.thread_id, event)
    db.commit()
    db.refresh(session)
    return session


def discard_session_trial_repair_preview(db: Session, session: UiScenarioAgentSession) -> UiScenarioAgentSession:
    plan = dict(session.plan_json) if isinstance(session.plan_json, dict) else {}
    trial = dict(plan.get("_trial")) if isinstance(plan.get("_trial"), dict) else {}
    if not isinstance(trial.get("repair_preview"), dict):
        raise AppError("bad_request", "当前没有可丢弃的修复预览", status_code=400)
    cid = str(trial.get("case_id") or "")
    trial["repair_preview"] = None
    trial["repair_status"] = None
    plan["_trial"] = trial
    session.plan_json = plan
    _emit(session, node="trial", message="已放弃 AI 修复预览")
    event = {"type": "trial_repair_discarded", "case_id": cid}
    _persist_event(session, event)
    get_event_bus().append(session.thread_id, event)
    db.commit()
    db.refresh(session)
    return session


def enqueue_session_trial_repair(
    db: Session,
    session: UiScenarioAgentSession,
    *,
    enqueue: Callable[[int, str], str | None] | None = None,
) -> UiScenarioAgentSession:
    """Deprecated: one-shot repair+rerun. Prefer preview → apply → trial-run."""
    raise AppError(
        "bad_request",
        "请使用 trial-repair/preview 与 apply 确认修复后再试跑",
        status_code=400,
    )


def _trial_failure_context(row: dict[str, Any] | None, error: str = "") -> dict[str, Any]:
    item = row if isinstance(row, dict) else {}
    detail = item.get("detail_json") if isinstance(item.get("detail_json"), dict) else {}
    return {
        "error_message": str(item.get("error_message") or error or "")[:2000],
        "selector": str(item.get("selector") or "")[:1000],
        "failure_url": str(
            item.get("failure_url") or detail.get("failure_url") or detail.get("url") or ""
        )[:2000],
        "failure_snapshot": str(
            item.get("failure_snapshot") or detail.get("failure_snapshot") or ""
        )[:8000],
    }


def execute_session_trial_run(db: Session, session_id: int) -> None:
    """Run one case script from plan._trial via execute_ui_script; update dry_run_*.

    Login cases save Playwright storageState to ``plan["_trial_auth"]``.
    ``needs_auth`` cases load that state (or env account storage); if missing,
    auto-run the login case first, then the business script.
    """
    from app.services.ui_automation.ui_runner import execute_ui_script

    session = db.get(UiScenarioAgentSession, session_id)
    if session is None:
        log.warning("ui scenario trial session %s not found", session_id)
        return
    plan = dict(session.plan_json) if isinstance(session.plan_json, dict) else {}
    trial = plan.get("_trial") if isinstance(plan.get("_trial"), dict) else {}
    cid = str(trial.get("case_id") or "").strip() or "script"
    headed = bool(trial.get("headed"))
    code = str(trial.get("script") or "").strip()
    case_meta: dict[str, Any] = {}
    if not code:
        try:
            cid, code, case_meta = _resolve_trial_script(session, case_id=cid)
        except AppError as ex:
            session.dry_run_status = "error"
            session.dry_run_error = ex.message
            _emit(session, node="trial", message=ex.message, level="error")
            get_event_bus().append(
                session.thread_id,
                {"type": "trial_done", "status": "error", "case_id": cid, "error": ex.message},
            )
            db.commit()
            return
    else:
        try:
            _, _, case_meta = _resolve_trial_script(session, case_id=cid, script=code)
        except AppError:
            case_meta = {
                "id": cid,
                "name": str(trial.get("case_name") or cid),
                "is_login": bool(trial.get("is_login")),
                "needs_auth": bool(trial.get("needs_auth")),
            }

    is_login = bool(trial.get("is_login")) if "is_login" in trial else _trial_case_is_login(case_meta)
    needs_auth = (
        bool(trial.get("needs_auth"))
        if "needs_auth" in trial
        else _trial_case_needs_auth(case_meta, plan)
    )

    get_event_bus().replace(session.thread_id, list(session.events_json or []))
    trial_steps: list[dict[str, Any]] = []
    trial_phase = {"value": "login" if is_login else "business"}

    def _compact_trial_step(row: dict[str, Any], *, phase: str) -> dict[str, Any]:
        detail = row.get("detail_json") if isinstance(row.get("detail_json"), dict) else {}
        url = str(detail.get("url") or row.get("failure_url") or "").strip()
        return {
            "phase": phase,
            "order": int(row.get("order") or 0),
            "action": str(row.get("action") or "script")[:100],
            "selector": str(row.get("selector") or "")[:1000],
            "status": str(row.get("status") or "error")[:20],
            "duration_ms": row.get("duration_ms"),
            "error_message": str(row.get("error_message") or "")[:2000],
            "screenshot_key": str(row.get("screenshot_key") or "")[:1024],
            "url": url[:2000],
        }

    def _finish_trial(
        *,
        status: str,
        error: str = "",
        steps: int = 0,
        level: str = "info",
        assistant: str = "",
        failure: dict[str, Any] | None = None,
    ) -> None:
        recorded_steps = len(trial_steps) if trial_steps else steps
        session.dry_run_status = status
        session.dry_run_error = error
        plan["_trial"] = {
            **trial,
            "status": status,
            "error": error,
            "steps": recorded_steps,
            "is_login": is_login,
            "needs_auth": needs_auth,
            "failure": failure or None,
            "repair_requested": False,
            "step_results": list(trial_steps),
            "repair_status": "passed" if status == "passed" and trial.get("repair_requested") else (
                "failed" if trial.get("repair_requested") and status in ("failed", "error") else trial.get("repair_status")
            ),
        }
        session.plan_json = plan
        msg = assistant or (
            f"试跑 {cid} {status}" + (f"：{error}" if error else "")
        )
        _emit(session, node="trial", message=msg[:2000], level=level)
        done_ev = {
            "type": "trial_done",
            "status": status,
            "case_id": cid,
            "steps": recorded_steps,
            **({"error": error} if error else {}),
        }
        _persist_event(session, done_ev)
        get_event_bus().append(session.thread_id, done_ev)
        db.commit()

    def _failed_steps(step_rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
        bad: list[dict[str, Any]] = []
        for index, row in enumerate(step_rows):
            if not isinstance(row, dict):
                bad.append(
                    {
                        "action": "script",
                        "status": "error",
                        "error_message": f"试跑返回了无效步骤（index={index}）",
                    }
                )
                continue
            if str(row.get("status") or "").strip().lower() != "passed":
                bad.append(row)
        return bad

    try:
        env = resolve_env(db, session.project_id, session.env_id)
        base_url = (env.base_url or "").strip()
        if not base_url:
            raise AppError("bad_request", UI_ENV_BASE_URL_REQUIRED, status_code=400)

        creds = merge_credentials(
            session.credentials_json if isinstance(session.credentials_json, dict) else None
        )
        ctx = _build_ctx(env, None)
        if not ctx.get("username") and ctx.get("user"):
            ctx["username"] = str(ctx["user"])
        ctx.update(credentials_to_ctx(creds))
        ctx = script_env_from_ctx(ctx)

        browser_auth = resolve_plan_browser_auth(env, plan)

        timeout_ms = int(getattr(env, "default_timeout_ms", None) or 15000)
        browser_name = session.browser or env.browser or "chromium"
        vp = env.viewport_json if isinstance(env.viewport_json, dict) else {"width": 1280, "height": 720}
        viewport = {"width": int(vp.get("width") or 1280), "height": int(vp.get("height") or 720)}

        def _on_log(message: str) -> None:
            text = str(message or "").strip()
            if not text:
                return
            _emit_commit(db, session, node="trial", message=text[:2000])

        def _save_trial_screenshot(data: bytes, filename: str) -> str:
            from app.services.file_storage import save_ui_explore_screenshot

            phase = trial_phase["value"]
            stored_name = f"trial_{cid}_{phase}_{filename}"
            key, _ = save_ui_explore_screenshot(
                session.project_id,
                session.id,
                stored_name,
                data,
            )
            return key

        def _on_trial_step(row: dict[str, Any]) -> None:
            compact = _compact_trial_step(row, phase=trial_phase["value"])
            trial_steps.append(compact)
            event = {
                "type": "trial_step",
                "case_id": cid,
                **compact,
                "data": (
                    {"screenshot_key": compact["screenshot_key"]}
                    if compact["screenshot_key"]
                    else {}
                ),
            }
            _persist_event(session, event)
            get_event_bus().append(session.thread_id, event)
            db.commit()

        run_kwargs: dict[str, Any] = {
            "base_url": base_url,
            "ctx": ctx,
            "viewport": viewport,
            "headless": not headed,
            "browser_name": browser_name,
            "default_timeout_ms": timeout_ms,
            "extra_http_headers": browser_auth.extra_http_headers,
            "local_storage": browser_auth.local_storage,
            "on_log": _on_log,
            "screenshot_saver": _save_trial_screenshot,
            "on_step": _on_trial_step,
        }

        storage_state_path: str | None = None
        save_storage_state_path: str | None = None
        auth_path = _trial_auth_file_path(session)

        if is_login:
            save_storage_state_path = str(auth_path)
        elif needs_auth:
            storage_state_path = _trial_auth_path_from_plan(plan)
            if not storage_state_path:
                storage_state_path = browser_auth.materialize_storage_path()
            if browser_auth.mode == "account" and browser_auth.account_name:
                plan["_auth_mode"] = "account"
                plan["_account_name"] = browser_auth.account_name
                session.plan_json = plan
            injected_auth = browser_auth_satisfies_business(browser_auth)
            if (
                not storage_state_path
                and not injected_auth
                and browser_auth.account_selection_required
            ):
                names = "、".join(browser_auth.available_accounts)
                raise AppError(
                    "bad_request",
                    f"环境中有多个已采集登录态的账号（{names}），请先选择本次试跑使用的账号",
                    status_code=400,
                )
            explicit_account = plan_auth_mode(plan) == "account"
            if (
                not storage_state_path
                and not injected_auth
                and explicit_account
                and str(plan.get("_account_name") or "").strip()
            ):
                raise AppError(
                    "bad_request",
                    f"账号「{plan.get('_account_name')}」尚未采集 storageState，请在 UI 环境中重新采集登录态",
                    status_code=400,
                )
            if not storage_state_path and not injected_auth:
                login_row = _find_login_case_script(plan)
                if login_row is None:
                    raise AppError(
                        "bad_request",
                        (
                            "业务用例需要登录态，但环境没有可用的 Token 注入或账号 storageState，"
                            "且当前结果中没有可执行的登录用例"
                        ),
                        status_code=400,
                    )
                login_cid = str(login_row.get("id") or "TC-01")
                login_code = str(login_row.get("code") or "").strip()
                _emit_commit(
                    db,
                    session,
                    node="trial",
                    message=f"业务用例需要登录态，先试跑 {login_cid}…",
                )
                trial_phase["value"] = "login"
                login_steps = execute_ui_script(
                    script=login_code,
                    storage_state_path=None,
                    save_storage_state_path=str(auth_path),
                    **run_kwargs,
                )
                login_bad = _failed_steps(login_steps)
                if login_bad:
                    last = login_bad[-1]
                    err = str(last.get("error_message") or last.get("status") or "登录试跑失败")
                    status = "failed" if str(last.get("status")) == "failed" else "error"
                    _finish_trial(
                        status=status,
                        error=err,
                        steps=len(login_steps),
                        level="error",
                        assistant=f"先跑登录 {login_cid} 未通过：{err}",
                        failure=_trial_failure_context(last, err),
                    )
                    return
                if not auth_path.is_file():
                    raise AppError(
                        "bad_request",
                        f"登录用例 {login_cid} 未写出 storageState，无法试跑业务用例",
                        status_code=400,
                    )
                plan["_trial_auth"] = {"path": str(auth_path), "from_case": login_cid}
                session.plan_json = plan
                db.commit()
                storage_state_path = str(auth_path)

        trial_phase["value"] = "login" if is_login else "business"
        step_rows = execute_ui_script(
            script=code,
            storage_state_path=storage_state_path,
            save_storage_state_path=save_storage_state_path,
            **run_kwargs,
        )
        if not step_rows:
            err = "试跑未返回任何执行步骤，不能判定为通过"
            _finish_trial(
                status="error",
                error=err,
                level="error",
                assistant=f"试跑 {cid} 未通过：{err}",
                failure=_trial_failure_context(None, err),
            )
            return
        bad = _failed_steps(step_rows)
        if bad:
            last = bad[-1]
            raw_status = str(last.get("status") or "").strip().lower()
            err = str(
                last.get("error_message")
                or (f"步骤状态异常：{raw_status}" if raw_status else "步骤缺少执行状态")
            )
            status = "failed" if raw_status in ("fail", "failure", "failed") else "error"
            _finish_trial(
                status=status,
                error=err,
                steps=len(step_rows),
                level="error",
                assistant=f"试跑 {cid} 未通过：{err}",
                failure=_trial_failure_context(last, err),
            )
        else:
            if is_login and auth_path.is_file():
                plan["_trial_auth"] = {"path": str(auth_path), "from_case": cid}
            _finish_trial(
                status="passed",
                steps=len(step_rows),
                assistant=f"试跑 {cid} 通过。",
            )
    except AppError as ex:
        _finish_trial(
            status="error",
            error=ex.message,
            level="error",
            assistant=f"试跑失败：{ex.message}",
            failure=_trial_failure_context(None, ex.message),
        )
    except Exception as ex:  # noqa: BLE001
        log.exception("ui scenario trial failed id=%s", session_id)
        _finish_trial(
            status="error",
            error=str(ex),
            level="error",
            assistant=f"试跑出错：{ex}",
            failure=_trial_failure_context(None, str(ex)),
        )

