"""Structured site map from recon trace (pages, controls, navigation edges)."""

from __future__ import annotations

import json
import re
from typing import Any
from urllib.parse import urlparse

_NAV_ROLES = frozenset({"link", "menuitem", "tab"})
_FIELD_ROLES = frozenset({"textbox", "searchbox", "combobox", "input"})
_SKIP_PATH_FRAGMENTS = ("/login", "/signin", "/register")
_RECORD_ROLES = _NAV_ROLES | _FIELD_ROLES | frozenset({"button", "checkbox"})
_MAX_CONTROLS_PER_PAGE = 40


def _js(s: str) -> str:
    return json.dumps(s, ensure_ascii=False)


def control_locator_expression(role: str, name: str) -> str:
    role0 = str(role or "generic").strip().lower()
    name0 = str(name or "").strip()
    if not name0:
        return ""
    return f"page.getByRole({_js(role0)}, {{ name: {_js(name0)} }})"


def _path_from_url(url: str, *, base_hostname: str = "") -> str:
    try:
        parsed = urlparse(str(url or "").strip())
    except Exception:  # noqa: BLE001
        return "/"
    if base_hostname and (parsed.hostname or "").lower() != base_hostname.lower():
        return ""
    path = parsed.path or "/"
    if parsed.query:
        path = f"{path}?{parsed.query}"
    return path


def _title_hint_from_snapshot(snapshot: str) -> str:
    for line in str(snapshot or "").splitlines():
        m = re.search(r"heading\s+\"([^\"]+)\"", line, re.I)
        if m:
            return m.group(1).strip()[:120]
    return ""


def _control_key(role: str, name: str) -> str:
    return f"{role.lower()}|{name.strip()}"


def _refresh_knowledge_summary(knowledge: dict[str, Any]) -> None:
    pages = [p for p in (knowledge.get("pages") or []) if isinstance(p, dict)]
    edges = [e for e in (knowledge.get("edges") or []) if isinstance(e, dict)]
    knowledge["preconditions"] = ["探索中增量记录页面控件"]
    if len(pages) > 1:
        knowledge["preconditions"].append(f"已记录 {len(pages)} 个页面路径")
    knowledge["summary"] = {
        "pages_visited": len(pages),
        "control_count": sum(len(p.get("controls") or []) for p in pages),
        "edge_count": len(edges),
    }


def _ensure_page(knowledge: dict[str, Any], path: str) -> dict[str, Any]:
    pages = knowledge.setdefault("pages", [])
    page = next((x for x in pages if isinstance(x, dict) and x.get("path") == path), None)
    if page is None:
        page = {"path": path, "title_hint": "", "controls": [], "forms": []}
        pages.append(page)
    return page


def _append_control(page: dict[str, Any], *, role: str, name: str, locator: str = "") -> bool:
    controls = page.setdefault("controls", [])
    if len(controls) >= _MAX_CONTROLS_PER_PAGE:
        return False
    key = _control_key(role, name)
    keys = {_control_key(str(c.get("role") or ""), str(c.get("name") or "")) for c in controls}
    if key in keys:
        return False
    loc = locator or control_locator_expression(role, name)
    entry: dict[str, Any] = {"role": role, "name": name}
    if loc:
        entry["locator"] = loc
    if role in _FIELD_ROLES:
        entry["interaction"] = "fill"
    elif role in _NAV_ROLES | {"button"}:
        entry["interaction"] = "click"
    controls.append(entry)
    fields = [{"role": c["role"], "name": c["name"]} for c in controls if c.get("role") in _FIELD_ROLES]
    if fields:
        page["forms"] = [{"fields": fields[:20]}]
    return True


def record_navigation_edge(
    knowledge: dict[str, Any],
    *,
    from_path: str,
    to_path: str,
    via: str = "",
) -> None:
    fp = str(from_path or "").strip()
    tp = str(to_path or "").strip()
    if not fp or not tp or fp == tp:
        return
    edges = knowledge.setdefault("edges", [])
    seen = {f"{e.get('from')}|{e.get('to')}|{e.get('via')}" for e in edges if isinstance(e, dict)}
    edge_key = f"{fp}|{tp}|{via}"
    if edge_key in seen:
        return
    edges.append({"from": fp, "to": tp, "via": via or "navigate"})


def merge_snapshot_into_knowledge(
    knowledge: dict[str, Any],
    *,
    path: str,
    snapshot: str,
    url: str = "",
    prev_path: str = "",
    via: str = "",
) -> dict[str, Any]:
    """Merge accessibility snapshot lines into page_knowledge for one URL path."""
    from app.services.ui_automation.ui_cli_explorer import _snapshot_controls

    if not isinstance(knowledge, dict):
        knowledge = build_page_knowledge([])
    norm = str(path or _path_from_url(url) or "/").strip() or "/"
    page = _ensure_page(knowledge, norm)
    if not page.get("title_hint"):
        page["title_hint"] = _title_hint_from_snapshot(snapshot)
    for row in _snapshot_controls(str(snapshot or "")):
        if row.get("kind") != "control":
            continue
        role = str(row.get("role") or "").strip().lower()
        name = str(row.get("name") or "").strip()
        if not name or role not in _RECORD_ROLES:
            continue
        _append_control(page, role=role, name=name)
    if prev_path and prev_path != norm:
        record_navigation_edge(knowledge, from_path=prev_path, to_path=norm, via=via)
    knowledge["_last_path"] = norm
    _refresh_knowledge_summary(knowledge)
    return knowledge


def increment_plan_page_knowledge(
    plan: dict[str, Any],
    *,
    url: str,
    snapshot: str,
    trace: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    """Update plan.page_knowledge from current explore snapshot (+ optional last trace step)."""
    pk = plan.get("page_knowledge") if isinstance(plan.get("page_knowledge"), dict) else build_page_knowledge([])
    path = _path_from_url(url) or str(plan.get("start_path") or "/")
    prev = str(pk.get("_last_path") or "")
    via = ""
    if trace:
        last = trace[-1] if trace else {}
        if isinstance(last, dict) and last.get("status") == "ok":
            kind = str(last.get("kind") or last.get("action") or "")
            if kind == "goto":
                via = f"goto:{last.get('path') or last.get('value') or ''}"
            elif kind == "click":
                role = str(last.get("role") or "button")
                name = str(last.get("name") or last.get("selector") or "")
                via = f"{role}:{name}"
    pk = merge_snapshot_into_knowledge(
        pk,
        path=path,
        snapshot=snapshot,
        url=url,
        prev_path=prev,
        via=via,
    )
    if trace:
        pk = merge_trace_into_knowledge(pk, trace[-5:])
    plan = dict(plan)
    plan["page_knowledge"] = pk
    return plan


def build_page_knowledge(recon_trace: list[dict[str, Any]] | None) -> dict[str, Any]:
    """Aggregate recon_visit / recon_nav rows into page_knowledge."""
    pages_by_path: dict[str, dict[str, Any]] = {}
    edges: list[dict[str, str]] = []
    seen_edges: set[str] = set()

    for item in recon_trace or []:
        if not isinstance(item, dict):
            continue
        kind = str(item.get("kind") or "")
        if kind == "recon_visit":
            path = str(item.get("path") or "/").strip() or "/"
            row = pages_by_path.setdefault(
                path,
                {
                    "path": path,
                    "title_hint": "",
                    "controls": [],
                    "forms": [],
                },
            )
            hint = str(item.get("title_hint") or "").strip()
            if hint and not row.get("title_hint"):
                row["title_hint"] = hint
            elif not row.get("title_hint"):
                row["title_hint"] = _title_hint_from_snapshot(str(item.get("snapshot") or ""))
            existing = {_control_key(c.get("role", ""), c.get("name", "")) for c in row["controls"]}
            for c in item.get("controls") or []:
                if not isinstance(c, dict):
                    continue
                role = str(c.get("role") or "").strip().lower()
                name = str(c.get("name") or "").strip()
                if not name or role == "generic":
                    continue
                key = _control_key(role, name)
                if key in existing:
                    continue
                existing.add(key)
                loc = str(c.get("locator") or "").strip() or control_locator_expression(role, name)
                control: dict[str, Any] = {"role": role, "name": name}
                if loc:
                    control["locator"] = loc
                if role in _FIELD_ROLES:
                    control["interaction"] = "fill"
                elif role in {"button", "link", "menuitem", "tab"}:
                    control["interaction"] = "click"
                row["controls"].append(control)
            fields = [
                {"role": c["role"], "name": c["name"]}
                for c in row["controls"]
                if c.get("role") in _FIELD_ROLES
            ]
            if fields:
                row["forms"] = [{"fields": fields}]
        elif kind == "recon_nav":
            fp = str(item.get("from_path") or "").strip()
            tp = str(item.get("to_path") or "").strip()
            via = str(item.get("via") or item.get("via_name") or "").strip()
            if not fp or not tp:
                continue
            edge_key = f"{fp}|{tp}|{via}"
            if edge_key in seen_edges:
                continue
            seen_edges.add(edge_key)
            edges.append({"from": fp, "to": tp, "via": via or f"{item.get('via_role', 'link')}:{item.get('via_name', '')}"})

    pages = sorted(pages_by_path.values(), key=lambda p: p.get("path") or "")
    preconditions = ["已登录"] if pages else []
    if len(pages) > 1:
        preconditions.append(f"已测绘 {len(pages)} 个页面路径")
    return {
        "pages": pages,
        "edges": edges,
        "preconditions": preconditions,
        "summary": {
            "pages_visited": len(pages),
            "control_count": sum(len(p.get("controls") or []) for p in pages),
            "edge_count": len(edges),
        },
    }


def summarize_page_knowledge_for_decide(
    knowledge: dict[str, Any] | None,
    *,
    max_bytes: int = 8000,
) -> dict[str, Any]:
    """Compact page_knowledge for decide_next_action user JSON."""
    if not isinstance(knowledge, dict):
        return {}
    out: dict[str, Any] = {
        "preconditions": knowledge.get("preconditions") or [],
        "edges": (knowledge.get("edges") or [])[:40],
        "pages": [],
    }
    for page in knowledge.get("pages") or []:
        if not isinstance(page, dict):
            continue
        links = [
            {"role": c.get("role"), "name": c.get("name")}
            for c in (page.get("controls") or [])
            if isinstance(c, dict)
            and c.get("role") in _NAV_ROLES | {"button"}
            and c.get("name")
        ][:24]
        buttons = [
            c.get("name")
            for c in (page.get("controls") or [])
            if isinstance(c, dict) and c.get("role") == "button" and c.get("name")
        ][:12]
        out["pages"].append(
            {
                "path": page.get("path"),
                "title_hint": page.get("title_hint"),
                "links": links,
                "buttons": buttons,
            }
        )
    raw = json.dumps(out, ensure_ascii=False)
    while len(raw.encode("utf-8")) > max_bytes and out["pages"]:
        out["pages"].pop()
        raw = json.dumps(out, ensure_ascii=False)
    if len(raw.encode("utf-8")) > max_bytes:
        out["pages"] = out["pages"][:3]
    return out


def _tokens(text: str) -> set[str]:
    parts = re.findall(r"[\u4e00-\u9fff]{2,}|[a-zA-Z]{3,}", str(text or ""))
    return {p.lower() for p in parts if p}


def validate_matrix_against_knowledge(
    matrix: list[dict[str, Any]] | None,
    knowledge: dict[str, Any] | None,
) -> list[str]:
    """Heuristic warnings when matrix titles mention modules absent from recon links."""
    if not matrix or not knowledge:
        return []
    link_names: set[str] = set()
    for page in knowledge.get("pages") or []:
        if not isinstance(page, dict):
            continue
        for c in page.get("controls") or []:
            if not isinstance(c, dict):
                continue
            if c.get("role") in _NAV_ROLES | {"button", "link"}:
                name = str(c.get("name") or "").strip()
                if name:
                    link_names.add(name)
                    link_names.update(_tokens(name))
    warnings: list[str] = []
    for row in matrix:
        if not isinstance(row, dict):
            continue
        title = str(row.get("name") or row.get("title") or row.get("id") or "")
        if not title:
            continue
        if title.strip().startswith("成功"):
            continue
        tokens = _tokens(title)
        if not tokens:
            continue
        if any(t in link_names or any(t in ln for ln in link_names) for t in tokens):
            continue
        # Only warn when title looks like a module noun (2+ CJK tokens)
        cjk = [t for t in tokens if re.search(r"[\u4e00-\u9fff]", t)]
        if len(cjk) >= 1 and link_names:
            warnings.append(
                f"矩阵「{title}」在已记录页面知识中未找到同名导航/按钮（{len(link_names)} 个已知入口）"
            )
    return warnings[:12]


def merge_trace_into_knowledge(
    knowledge: dict[str, Any],
    business_trace: list[dict[str, Any]] | None,
) -> dict[str, Any]:
    """Incrementally add controls seen during case explore (e.g. modal fields)."""
    if not isinstance(knowledge, dict):
        knowledge = build_page_knowledge([])
    path = "/"
    for item in business_trace or []:
        if not isinstance(item, dict):
            continue
        observe = item.get("observe") if isinstance(item.get("observe"), dict) else {}
        url = str(observe.get("url_after") or item.get("page_url") or "")
        p = _path_from_url(url)
        if p:
            path = p
        role = str(item.get("role") or "").strip().lower()
        name = str(item.get("name") or "").strip()
        if not name:
            continue
        if role not in _FIELD_ROLES | {"button", "link"}:
            kind = str(item.get("kind") or item.get("action") or "")
            if kind not in ("click", "fill"):
                continue
            role = "button" if kind == "click" else "textbox"
        pages = knowledge.setdefault("pages", [])
        page = next((x for x in pages if isinstance(x, dict) and x.get("path") == path), None)
        if page is None:
            page = {"path": path, "title_hint": "", "controls": [], "forms": []}
            pages.append(page)
        keys = {_control_key(c.get("role", ""), c.get("name", "")) for c in page.get("controls") or []}
        key = _control_key(role, name)
        if key in keys:
            continue
        loc = str(item.get("cli_locator") or "").strip() or control_locator_expression(role, name)
        _append_control(page, role=role, name=name, locator=loc)
    _refresh_knowledge_summary(knowledge)
    return knowledge
