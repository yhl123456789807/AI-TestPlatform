"""Explore report + case matrix helpers (handoff contract before codegen)."""

from __future__ import annotations

import json
import re
from typing import Any

from app.services.ui_automation.ui_lexicon import (
    AUTH_PATH_SEG as _AUTH_PATH_SEG,
    CAPTCHA as _CAPTCHA,
    CAPTCHA_QUERY_PROMPT as _CAPTCHA_QUERY_HINT,
    CAPTCHA_REFRESH as _CAPTCHA_REFRESH,
    LOGIN_BTN as _LOGIN_BTN,
    PASS_FIELD as _PASS_FIELD,
    USER_FIELD as _USER_FIELD,
    norm_ws as _norm_ws,
    path_is_auth as _path_is_auth,
)

_HASH_CLASS = re.compile(r"\.(?:css|sc|jsx|emotion)-[a-zA-Z0-9_-]+")
_DEEP_XPATH = re.compile(r"xpath=", re.I)
_CANVAS = re.compile(r"canvas|webgl|图表|chart", re.I)
_SHADOW = re.compile(r"shadow|iframe", re.I)
_TESTID = re.compile(r"data-testid|getByTestId|\[data-testid", re.I)
_ROLE = re.compile(r"getByRole|role=", re.I)
_PLACEHOLDER = re.compile(r"getByPlaceholder|placeholder", re.I)
_LOCATOR_NAME = re.compile(
    r"""name\s*[:=]\s*['"]([^'"]+)['"]|name\s*=\s*"([^"]+)"|name\s*=\s*'([^']+)'""",
    re.I,
)


def _str(value: Any, default: str = "") -> str:
    if value is None:
        return default
    return str(value).strip()


def _skeleton_steps_for_row(*, start: str, expected: str) -> list[dict[str, Any]]:
    steps: list[dict[str, Any]] = [
        {
            "action": "goto",
            "target": start or "/",
            "value": start or "/",
            "driver": "playwright",
            "ready": True,
        }
    ]
    exp = (expected or "").strip()
    if exp:
        if re.search(r"url|路径|跳转|/|首页", exp, re.I):
            steps.append(
                {
                    "action": "assert_url",
                    "target": exp,
                    "value": exp,
                    "driver": "playwright",
                    "ready": True,
                }
            )
        else:
            steps.append(
                {
                    "action": "assert_text",
                    "target": exp,
                    "value": exp,
                    "driver": "playwright",
                    "ready": True,
                }
            )
    return steps


def skeletonize_matrix_row(row: dict[str, Any]) -> dict[str, Any]:
    """Keep id/name/start_url/expected; drop prose steps until explore hydrates."""
    out = dict(row)
    start = _str(out.get("start_url") or "/") or "/"
    expected = _str(out.get("expected"))
    out["steps"] = _skeleton_steps_for_row(start=start, expected=expected)
    out["ready"] = False
    out["has_assert"] = any(_str(s.get("action")).startswith("assert") for s in out["steps"])
    action = _str(out.get("business_action"))
    if action:
        out["business_action"] = action
    return out


def skeletonize_plan_matrix(plan: dict[str, Any]) -> dict[str, Any]:
    out = dict(plan)
    matrix = out.get("matrix") if isinstance(out.get("matrix"), list) else []
    out["matrix"] = [skeletonize_matrix_row(r) for r in matrix if isinstance(r, dict)]
    out["case_scripts"] = []
    return out


def matrix_from_checklist(
    *,
    goal: str,
    start_path: str,
    checklist: list[str],
    case_name: str | None = None,
) -> list[dict[str, Any]]:
    """Synthesize a minimal matrix when the LLM omitted one."""
    name = (case_name or goal or "UI 探索").strip() or "UI 探索"
    row = normalize_matrix_row(
        {
            "id": "UC-001",
            "name": name,
            "start_url": start_path or "/",
            "preconditions": "已配置环境与账号（如需）",
            "steps": [],
            "data": "",
            "expected": "目标步骤完成且关键断言通过",
        },
        index=1,
        default_start=start_path or "/",
    )
    return [skeletonize_matrix_row(row)] if row else []


def _parse_test_data_blob(test_data: str) -> dict[str, Any]:
    text = _str(test_data)
    if not text:
        return {}
    if text.startswith("{"):
        try:
            data = json.loads(text)
            return data if isinstance(data, dict) else {}
        except json.JSONDecodeError:
            pass
    out: dict[str, Any] = {}
    for line in re.split(r"[\n;；]+", text):
        part = line.strip()
        if ":" in part or "：" in part:
            chunks = re.split(r"[:：]", part, maxsplit=1)
            if len(chunks) != 2:
                continue
            key, val = chunks[0], chunks[1]
            key = _slug_token(key)
            val = _str(val)
            if key and val:
                out[key] = val
    return out


def _slug_token(text: str) -> str:
    t = re.sub(r"\s+", "_", _str(text).lower())
    t = re.sub(r"[^\w]+", "_", t).strip("_")
    return t[:48] or "field"


def infer_business_action(name: str) -> str:
    """Rough CRUD/nav label for explore constraints."""
    blob = _str(name)
    if not blob:
        return "nav"
    if re.search(r"删除|remove|delete", blob, re.I):
        return "delete"
    if re.search(r"编辑|修改|更新|edit|update", blob, re.I):
        return "edit"
    if re.search(r"查询|列表|检索|搜索|可见|query|list|search", blob, re.I):
        return "query"
    if re.search(r"新增|新建|创建|添加|create|add", blob, re.I):
        return "create"
    if re.search(r"登录|login|sign\s*in", blob, re.I):
        return "nav"
    return "nav"


def _checklist_case_id(name: str, index: int) -> str:
    slug = _slug_token(name)
    if not slug or slug == "field":
        return f"uc_{index + 1:03d}"
    return slug[:56]


def expected_for_matrix_item(
    *,
    name: str,
    business_action: str,
    test_data: str = "",
) -> str:
    data = _parse_test_data_blob(test_data)
    if business_action == "edit":
        for key in ("requirement_title_edited", "title_edited", "edited_title"):
            if data.get(key):
                return _str(data[key])
    if business_action in ("create", "query"):
        for key in (
            "requirement_title",
            "title",
            "requirement_name",
            "name",
        ):
            if data.get(key):
                return _str(data[key])
    if business_action == "delete":
        for key in ("requirement_title", "title", "requirement_title_edited"):
            if data.get(key):
                return _str(data[key])
    if re.search(r"项目", name) and data.get("project_name"):
        return _str(data["project_name"])
    short = _norm_ws(name)
    return short[:120] if short else "关键业务结果可见"


def matrix_from_sequential_checklist(
    *,
    goal: str,
    start_path: str,
    checklist: list[str],
    case_name: str | None = None,
    test_data: str = "",
) -> list[dict[str, Any]]:
    """One matrix row per checklist item for sequential LangGraph explore."""
    items = [_str(x) for x in (checklist or []) if _str(x)]
    if len(items) < 2:
        return []
    start = start_path or "/"
    rows: list[dict[str, Any]] = []
    for index, name in enumerate(items):
        action = infer_business_action(name)
        cid = _checklist_case_id(name, index)
        expected = expected_for_matrix_item(
            name=name,
            business_action=action,
            test_data=test_data,
        )
        row = normalize_matrix_row(
            {
                "id": cid,
                "name": name,
                "start_url": start if index == 0 else start,
                "preconditions": (
                    "已登录并处在业务页面"
                    if index > 0
                    else "已配置环境与账号（如需）"
                ),
                "steps": [],
                "data": _str(test_data)[:500],
                "expected": expected,
                "business_action": action,
            },
            index=index + 1,
            default_start=start,
        )
        if row:
            rows.append(skeletonize_matrix_row(row))
    return rows[:30]


def split_oversized_checklist(checklist: list[str]) -> list[str]:
    """Split merged checklist lines so each maps to one matrix row (根治：一检查点一用例)."""
    out: list[str] = []
    split_re = re.compile(r"[→\->]+|然后|接着|再然后")
    dual_re = re.compile(r"(创建|新建).*(项目).*(需求|文档)", re.I)
    for raw in checklist or []:
        text = _str(raw)
        if not text:
            continue
        parts = [p.strip() for p in split_re.split(text) if len(_str(p)) >= 4]
        if len(parts) > 1:
            out.extend(parts[:12])
            continue
        if dual_re.search(text):
            for sep in ("并", "和", "，再", "后再", "；"):
                if sep in text:
                    chunks = [c.strip(" ，,.") for c in text.split(sep) if len(c.strip()) >= 4]
                    if len(chunks) >= 2:
                        out.extend(chunks[:8])
                        break
            else:
                out.append(text)
            continue
        out.append(text)
    return out[:24]


def expand_checklist_for_crud(
    *,
    goal: str,
    prompt: str,
    checklist: list[str],
) -> list[str]:
    """Ensure multiple checklist rows when user asked for CRUD but planner merged lines."""
    items = split_oversized_checklist(checklist)
    required = test_design_actions(prompt=prompt, goal=goal, checklist=items)
    if len(required) < 2:
        return items
    if len(items) >= 2:
        return items
    blob = " ".join(items)
    for label in required:
        if label not in blob and not any(label in _str(x) for x in items):
            items.append(f"{label}业务验收点")
    return items


def case_done_allowed(
    plan: dict[str, Any],
    snapshot: str,
    trace: list[dict[str, Any]],
    case_id: str,
) -> tuple[bool, str]:
    """Done gate: active_case.expected must appear in snapshot or recent case trace."""
    active = plan.get("_active_case") if isinstance(plan.get("_active_case"), dict) else {}
    exp = _str(active.get("expected"))
    if not exp or len(exp) < 2 or len(exp) > 120:
        return True, ""
    snap = snapshot or ""
    if exp in snap or _norm_ws(exp) in snap:
        return True, ""
    for item in reversed(trace[-30:]):
        if not isinstance(item, dict):
            continue
        if str(item.get("case_id") or "").strip() not in ("", case_id):
            continue
        if str(item.get("action") or "") in ("assert_text", "assert_visible"):
            blob = str(item.get("value") or item.get("assert") or "")
            if exp in blob or blob in exp:
                return True, ""
        observe = item.get("observe") if isinstance(item.get("observe"), dict) else {}
        for text in observe.get("new_text") or []:
            if exp in str(text):
                return True, ""
    return False, f"用例尚未达到预期「{exp[:60]}」，请先 assert 或完成操作后再 done"


def apply_sequential_explore_matrix(plan: dict[str, Any]) -> dict[str, Any]:
    """Build skeleton matrix from checklist; enable per-case explore."""
    out = dict(plan)
    raw_list = out.get("checklist") if isinstance(out.get("checklist"), list) else []
    user_prompt = _str(out.get("user_prompt"))
    goal = _str(out.get("goal"))
    checklist = expand_checklist_for_crud(
        goal=goal,
        prompt=user_prompt or goal,
        checklist=[_str(x) for x in raw_list],
    )
    out["checklist"] = checklist
    matrix = matrix_from_sequential_checklist(
        goal=goal,
        start_path=_str(out.get("start_path")) or "/",
        checklist=checklist,
        case_name=_str(out.get("case_name")) or None,
        test_data=_str(out.get("test_data")),
    )
    if not matrix:
        return out
    out["matrix"] = matrix
    out["_sequential_matrix"] = True
    out["case_scripts"] = []
    return out


_MATRIX_ACTIONS = ("goto", "fill", "click", "press", "assert_text", "assert_url", "assert_visible")


def _infer_action_from_text(text: str, *, default_start: str = "/") -> dict[str, Any]:
    """Best-effort convert a prose step into a structured matrix action."""
    t = (text or "").strip()
    low = t.lower()
    if re.search(r"打开|进入|goto|导航|访问", t) and ("/" in t or "页" in t or "url" in low):
        path = default_start
        m = re.search(r"(/[^\s，,；;]+)", t)
        if m:
            path = m.group(1)
        return {"action": "goto", "target": path, "value": path, "driver": "playwright", "ready": False}
    if re.search(r"断言|应|可见|出现|跳转|expected|assert", t, re.I):
        if re.search(r"url|路径|地址|跳转", t, re.I):
            return {"action": "assert_url", "target": "", "value": t, "driver": "playwright", "ready": False}
        return {"action": "assert_text", "target": t, "value": t, "driver": "playwright", "ready": False}
    if re.search(r"点击|单击|点|click|tap", t, re.I):
        return {"action": "click", "target": t, "value": "", "driver": "playwright", "ready": False}
    if re.search(r"输入|填写|填|fill|input", t, re.I):
        driver = "midscene" if _CAPTCHA.search(t) and re.search(r"读|识别|图片|图中", t) else "playwright"
        return {"action": "fill", "target": t, "value": "", "driver": driver, "ready": False}
    if re.search(r"按|press|回车|enter", t, re.I):
        return {"action": "press", "target": "", "value": "Enter", "driver": "playwright", "ready": False}
    return {"action": "click", "target": t, "value": "", "driver": "playwright", "ready": False}


def normalize_matrix_step(raw: Any, *, default_start: str = "/") -> dict[str, Any] | None:
    if isinstance(raw, str) and raw.strip():
        return _infer_action_from_text(raw.strip(), default_start=default_start)
    if not isinstance(raw, dict):
        return None
    action = _str(raw.get("action") or raw.get("kind") or raw.get("操作")).lower()
    if action not in _MATRIX_ACTIONS:
        prose = _str(raw.get("target") or raw.get("name") or raw.get("locate") or raw.get("prompt") or raw.get("text"))
        if prose:
            return _infer_action_from_text(prose, default_start=default_start)
        return None
    target = _str(raw.get("target") or raw.get("locate") or raw.get("prompt") or raw.get("selector") or raw.get("name"))
    value = raw.get("value")
    if value is None:
        value = raw.get("assert") or raw.get("text") or ""
    value = _str(value) if not isinstance(value, (int, float, bool)) else value
    driver = _str(raw.get("driver") or "playwright").lower() or "playwright"
    if driver not in ("playwright", "midscene"):
        driver = "playwright"
    if action == "goto" and not target:
        target = _str(value) or default_start
    step: dict[str, Any] = {
        "action": action,
        "target": target,
        "value": value,
        "driver": driver,
        "ready": bool(raw.get("ready")),
    }
    for key in ("placeholder", "role", "name", "selector", "cli_locator", "prompt", "locate", "captcha"):
        if raw.get(key) is not None and _str(raw.get(key)):
            step[key] = raw[key]
    return step


def normalize_matrix_row(raw: Any, *, index: int, default_start: str = "/") -> dict[str, Any] | None:
    if not isinstance(raw, dict):
        return None
    name = _str(raw.get("name") or raw.get("title") or raw.get("用例名称"))
    if not name:
        return None
    cid = _str(raw.get("id") or raw.get("ID")) or f"UC-{index:03d}"
    steps_raw = raw.get("steps") or raw.get("操作步骤") or raw.get("操作")
    steps: list[dict[str, Any]] = []
    if isinstance(steps_raw, list):
        for item in steps_raw:
            step = normalize_matrix_step(item, default_start=default_start)
            if step:
                steps.append(step)
    elif isinstance(steps_raw, str) and steps_raw.strip():
        for part in re.split(r"[\n;；]", steps_raw):
            step = normalize_matrix_step(part.strip(), default_start=default_start)
            if step:
                steps.append(step)
    start = _str(raw.get("start_url") or raw.get("start_path") or raw.get("起始URL") or default_start) or "/"
    if not start.startswith("/") and not start.startswith("http"):
        start = "/" + start
    expected = _str(raw.get("expected") or raw.get("预期结果") or raw.get("预期"))
    if expected and not any(s.get("action", "").startswith("assert") for s in steps):
        if re.search(r"url|路径|跳转|/|首页", expected, re.I):
            steps.append(
                {
                    "action": "assert_url",
                    "target": expected,
                    "value": expected,
                    "driver": "playwright",
                    "ready": False,
                }
            )
        else:
            steps.append(
                {
                    "action": "assert_text",
                    "target": expected,
                    "value": expected,
                    "driver": "playwright",
                    "ready": False,
                }
            )
    if not any(s.get("action") == "goto" for s in steps):
        steps.insert(
            0,
            {
                "action": "goto",
                "target": start,
                "value": start,
                "driver": "playwright",
                "ready": True,
            },
        )
    ready = bool(raw.get("ready")) if "ready" in raw else all(
        s.get("ready") or s.get("action", "").startswith("assert") or s.get("action") == "goto"
        for s in steps
    )
    row_out: dict[str, Any] = {
        "id": cid,
        "name": name,
        "start_url": start,
        "preconditions": _str(raw.get("preconditions") or raw.get("前置条件") or raw.get("前置")),
        "steps": steps[:24],
        "data": _str(raw.get("data") or raw.get("测试数据") or raw.get("数据")),
        "expected": expected,
        "ready": ready,
    }
    biz = _str(raw.get("business_action"))
    if biz:
        row_out["business_action"] = biz
    return row_out


def normalize_matrix(
    raw: Any,
    *,
    goal: str = "",
    start_path: str = "/",
    checklist: list[str] | None = None,
    case_name: str | None = None,
) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    if isinstance(raw, list):
        for i, item in enumerate(raw, start=1):
            row = normalize_matrix_row(item, index=i, default_start=start_path)
            if row:
                rows.append(row)
    if rows:
        return rows[:30]
    return matrix_from_checklist(
        goal=goal,
        start_path=start_path,
        checklist=list(checklist or []),
        case_name=case_name,
    )


def ensure_plan_matrix(plan: dict[str, Any], *, synthesize_if_empty: bool = True) -> dict[str, Any]:
    """Normalize matrix rows. Explore-first plans pass synthesize_if_empty=False."""
    out = dict(plan)
    goal = _str(out.get("goal"))
    start = _str(out.get("start_path")) or "/"
    checklist = out.get("checklist") if isinstance(out.get("checklist"), list) else []
    case_name = _str(out.get("case_name")) or None
    raw = out.get("matrix")
    if isinstance(raw, list) and not raw and not synthesize_if_empty:
        out["matrix"] = []
        return out
    if raw is None and not synthesize_if_empty:
        out["matrix"] = []
        return out
    out["matrix"] = normalize_matrix(
        raw,
        goal=goal,
        start_path=start,
        checklist=[_str(x) for x in checklist],
        case_name=case_name,
    )
    if not out.get("case_name") and out["matrix"]:
        out["case_name"] = out["matrix"][0].get("name")
    return out


def _selector_blob(step: dict[str, Any]) -> str:
    parts = [
        step.get("selector"),
        step.get("locate"),
        step.get("placeholder"),
        step.get("name"),
        step.get("role"),
        step.get("prompt"),
        step.get("reason"),
        step.get("value"),
        step.get("action"),
        step.get("kind"),
    ]
    return " ".join(_str(p) for p in parts if p is not None)


def infer_driver(step: dict[str, Any]) -> tuple[str, str | None, str | None]:
    """Return (driver, reason, prompt). Playwright-first; Midscene only when unstable."""
    explicit = _str(step.get("driver")).lower()
    if explicit in ("playwright", "midscene"):
        reason = _str(step.get("reason")) or None
        prompt = _str(step.get("prompt") or step.get("locate")) or None
        return explicit, reason, prompt

    kind = _str(step.get("kind") or step.get("action")).lower()
    blob = _selector_blob(step)
    captcha = bool(step.get("captcha")) or bool(_CAPTCHA.search(blob))

    if kind in ("ai_act", "ai_tap", "ai_input", "ai_assert", "ai_query", "fill_captcha"):
        if captcha or kind == "fill_captcha":
            return (
                "midscene",
                "captcha-image: not machine-readable via locator",
                _str(step.get("prompt") or step.get("locate")) or "验证码图片中的字符",
            )
        return (
            "midscene",
            _str(step.get("reason")) or "unstable-dom: midscene action",
            _str(step.get("prompt") or step.get("locate")) or None,
        )

    if captcha and kind in ("fill", "input"):
        # Input box itself stays Playwright when we have a locator; read-image is midscene.
        if step.get("placeholder") or _TESTID.search(blob) or _ROLE.search(blob):
            return "playwright", None, None
        return (
            "midscene",
            "captcha-image: not machine-readable via locator",
            _str(step.get("locate")) or "验证码输入框",
        )

    if _CANVAS.search(blob):
        return "midscene", "canvas: target not in a11y tree", _str(step.get("locate")) or None
    if _SHADOW.search(blob) and not (_TESTID.search(blob) or _ROLE.search(blob)):
        return "midscene", "closed-shadow-or-iframe", _str(step.get("locate")) or None

    selector = _str(step.get("selector"))
    if selector and _HASH_CLASS.search(selector) and not (_TESTID.search(selector) or _ROLE.search(selector)):
        return "midscene", "unstable-dom: hash-class/xpath-only", _str(step.get("locate")) or selector
    if selector.startswith("xpath=") or (selector and _DEEP_XPATH.search(selector) and selector.count("/") > 6):
        if not (_TESTID.search(blob) or _ROLE.search(blob) or step.get("placeholder")):
            return "midscene", "unstable-dom: hash-class/xpath-only", _str(step.get("locate")) or selector

    if kind in ("goto", "press", "wait_for", "assert_visible", "assert_text", "assert_url", "done", "screenshot"):
        return "playwright", None, None

    if (
        step.get("placeholder")
        or step.get("role")
        or _TESTID.search(blob)
        or _ROLE.search(blob)
        or _PLACEHOLDER.search(blob)
        or (selector and not _HASH_CLASS.search(selector))
    ):
        return "playwright", None, None

    locate = _str(step.get("locate") or step.get("prompt"))
    if locate and not selector and not step.get("placeholder") and not step.get("role"):
        return "midscene", "snapshot: no usable semantic locator", locate

    return "playwright", None, None


def annotate_step(step: dict[str, Any], *, case_id: str = "UC-001", index: int = 1) -> dict[str, Any]:
    out = dict(step)
    driver, reason, prompt = infer_driver(out)
    out["driver"] = driver
    if reason:
        out["reason"] = reason
    elif "reason" in out and not _str(out.get("reason")):
        out.pop("reason", None)
    if prompt:
        out["prompt"] = prompt
    out.setdefault("case_id", case_id)
    out.setdefault("index", index)
    intent = _str(out.get("intent") or out.get("action") or out.get("kind"))
    if intent:
        out["intent"] = intent
    return out


def annotate_steps(
    steps: list[dict[str, Any]] | None,
    *,
    matrix: list[dict[str, Any]] | None = None,
) -> list[dict[str, Any]]:
    case_id = "UC-001"
    if matrix and isinstance(matrix[0], dict) and matrix[0].get("id"):
        case_id = str(matrix[0]["id"])
    out: list[dict[str, Any]] = []
    for i, raw in enumerate(steps or [], start=1):
        if not isinstance(raw, dict):
            continue
        out.append(annotate_step(raw, case_id=case_id, index=i))
    return out


def _locator_tier(step: dict[str, Any]) -> int | None:
    blob = _selector_blob(step)
    if _TESTID.search(blob):
        return 1
    if _ROLE.search(blob) or step.get("role"):
        return 2
    selector = _str(step.get("selector"))
    if selector.startswith("#") or re.search(r"\[id=", selector):
        return 3
    if step.get("placeholder") or _PLACEHOLDER.search(blob) or (selector and not selector.startswith("xpath=")):
        return 4
    if selector.startswith("xpath=") or "xpath=" in selector.lower():
        return 5
    return None


def build_explore_report(
    *,
    plan: dict[str, Any],
    steps: list[dict[str, Any]] | None,
    script: str = "",
    engine: str = "",
    synthesize_matrix: bool = True,
) -> dict[str, Any]:
    """Build the explore handoff report (matrix + per-step driver)."""
    plan = ensure_plan_matrix(plan, synthesize_if_empty=synthesize_matrix)
    matrix = plan.get("matrix") if isinstance(plan.get("matrix"), list) else []
    annotated = annotate_steps(steps, matrix=matrix)
    midscene_items = [
        {
            "index": s.get("index"),
            "intent": s.get("intent") or s.get("action"),
            "reason": s.get("reason"),
            "prompt": s.get("prompt") or s.get("locate"),
        }
        for s in annotated
        if s.get("driver") == "midscene"
    ]
    report_steps: list[dict[str, Any]] = []
    for s in annotated:
        entry: dict[str, Any] = {
            "case_id": s.get("case_id"),
            "index": s.get("index"),
            "intent": s.get("intent") or s.get("action") or s.get("kind"),
            "driver": s.get("driver") or "playwright",
            "action": s.get("action") or s.get("kind"),
            "selector": s.get("selector") or s.get("placeholder") or "",
            "value": s.get("value"),
            "assert": s.get("assert"),
            "status": s.get("status"),
        }
        tier = _locator_tier(s)
        if tier is not None and entry["driver"] == "playwright":
            entry["locator_tier"] = tier
        if s.get("reason"):
            entry["reason"] = s["reason"]
        if s.get("prompt"):
            entry["prompt"] = s["prompt"]
        if s.get("captcha"):
            entry["captcha"] = True
        report_steps.append(entry)

    mapping = [{"id": r.get("id"), "title": r.get("name")} for r in matrix if isinstance(r, dict)]
    captcha_steps = [s for s in annotated if s.get("captcha") or _CAPTCHA.search(_selector_blob(s))]
    captcha_meta = None
    if captcha_steps:
        captcha_meta = {
            "image_how": "未知（探索未探测到专用验证码图 locator）",
            "length": None,
            "charset": None,
            "refresh": "未知",
            "fail_text": "未知",
            "success_url": "未知",
            "note": "位数/字符集/失败文案以实际页面为准；生成代码时用 aiQuery 读图 + Playwright fill",
        }

    page_knowledge = plan.get("page_knowledge") if isinstance(plan.get("page_knowledge"), dict) else None
    pk_summary = (
        page_knowledge.get("summary")
        if isinstance(page_knowledge, dict) and isinstance(page_knowledge.get("summary"), dict)
        else {}
    )
    recon_warnings = plan.get("_recon_warnings") if isinstance(plan.get("_recon_warnings"), list) else []

    return {
        "case_name": _str(plan.get("case_name")) or (matrix[0].get("name") if matrix else "UI 探索"),
        "goal": _str(plan.get("goal")),
        "start_path": _str(plan.get("start_path")) or "/",
        "engine": engine or _str(plan.get("engine")),
        "matrix": matrix,
        "mapping": mapping,
        "steps": report_steps,
        "midscene_checklist": midscene_items,
        "captcha": captcha_meta,
        "blockers": [],
        "testid_suggestions": [],
        "has_script": bool((script or "").strip()),
        "page_knowledge": page_knowledge,
        "recon_warnings": recon_warnings,
        "summary": {
            "total_steps": len(report_steps),
            "playwright_steps": sum(1 for s in report_steps if s.get("driver") == "playwright"),
            "midscene_steps": len(midscene_items),
            "pages_visited": int(pk_summary.get("pages_visited") or 0),
            "recon_controls": int(pk_summary.get("control_count") or 0),
        },
    }


def _trace_label_blob(item: dict[str, Any]) -> str:
    return " ".join(
        _str(item.get(k))
        for k in ("name", "locate", "placeholder", "prompt", "selector", "cli_locator", "reason", "target")
    )


def _is_captcha_refresh_click(item: dict[str, Any]) -> bool:
    if _str(item.get("reason")) == "captcha_retry_refresh":
        return True
    kind = _str(item.get("kind") or item.get("action"))
    if kind not in ("click", "tap"):
        return False
    return bool(_CAPTCHA_REFRESH.search(_trace_label_blob(item)))


def _control_visible_names(item: dict[str, Any]) -> list[str]:
    """Control identity labels only — never reason/prompt prose."""
    names: list[str] = []
    for key in ("name",):
        val = _str(item.get(key))
        if val:
            names.append(val)
    for key in ("cli_locator", "selector"):
        loc = _str(item.get(key))
        if not loc:
            continue
        m = _LOCATOR_NAME.search(loc)
        if m:
            picked = next((g for g in m.groups() if g), "")
            if picked:
                names.append(picked)
    return names


def _is_login_click(item: dict[str, Any]) -> bool:
    kind = _str(item.get("kind") or item.get("action"))
    if kind not in ("click", "tap"):
        return False
    if _is_captcha_refresh_click(item):
        return False
    for name in _control_visible_names(item):
        if _LOGIN_BTN.search(_norm_ws(name)):
            return True
    return False


def _is_captcha_fill_item(item: dict[str, Any]) -> bool:
    kind = _str(item.get("kind") or item.get("action"))
    if item.get("captcha") or kind == "fill_captcha" or item.get("explore_captcha_read"):
        return True
    if kind in ("fill", "input", "ai_input", "ai_query"):
        return bool(_CAPTCHA.search(_trace_label_blob(item)))
    return False


def _is_auth_credential_fill(item: dict[str, Any]) -> bool:
    """Username / password / captcha fills used to infer login boundary."""
    if _is_captcha_fill_item(item):
        return True
    kind = _str(item.get("kind") or item.get("action"))
    if kind not in ("fill", "input", "ai_input", "fill_captcha"):
        return False
    blob = _trace_label_blob(item)
    return bool(_USER_FIELD.search(blob) or _PASS_FIELD.search(blob))


def _boundary_by_path_leave(collapsed: list[dict[str, Any]], *, after: int = -1) -> int:
    """Inclusive end of auth segment: index before first non-auth path after auth path."""
    saw_auth_path = False
    for i, it in enumerate(collapsed):
        path = _str(it.get("path"))
        if not path:
            continue
        if _path_is_auth(path):
            saw_auth_path = True
            continue
        if saw_auth_path and i > after and i > 0:
            return i - 1
    return -1


def _login_boundary_index(collapsed: list[dict[str, Any]]) -> int:
    """Inclusive end index of the auth/login segment, or -1 if none / no post-login tail.

    Prefer the first explicit login control click; else path leaving auth; else
    last credential/captcha fill when non-auth steps follow.
    """
    if not collapsed:
        return -1
    for i, it in enumerate(collapsed):
        if _is_login_click(it) and i < len(collapsed) - 1:
            return i

    last_auth = max(
        (i for i, it in enumerate(collapsed) if _is_auth_credential_fill(it)),
        default=-1,
    )
    leave = _boundary_by_path_leave(collapsed, after=last_auth)
    if leave >= 0 and leave < len(collapsed) - 1:
        return leave

    if last_auth < 0 or last_auth >= len(collapsed) - 1:
        return -1
    for j in range(last_auth + 1, len(collapsed)):
        if not _is_auth_credential_fill(collapsed[j]) and not _is_login_click(collapsed[j]):
            return last_auth
    return -1


def _fill_field_key(item: dict[str, Any]) -> str:
    if _is_captcha_fill_item(item):
        return "captcha"
    blob = _trace_label_blob(item)
    if _USER_FIELD.search(blob):
        return "username"
    if _PASS_FIELD.search(blob):
        return "password"
    return (
        "fill:"
        + (
            _str(item.get("placeholder"))
            or _str(item.get("name"))
            or _str(item.get("locate"))
            or _str(item.get("selector"))
            or _str(item.get("cli_locator"))
            or "field"
        )
    )


def _collapse_trace_for_bind(trace: list[dict[str, Any]] | None) -> list[dict[str, Any]]:
    """Collapse explore noise into a codegen-friendly path.

    Drops captcha-refresh retries, repeated midscene noops, duplicate field fills
    (last wins), and repeated login clicks (keep first auth-segment login).
    """
    filtered: list[dict[str, Any]] = []
    seen_mid: set[str] = set()
    for raw in trace or []:
        if not isinstance(raw, dict):
            continue
        if raw.get("status") == "error":
            continue
        kind = _str(raw.get("kind") or raw.get("action"))
        if kind in ("", "done"):
            continue
        if _is_captcha_refresh_click(raw):
            continue
        driver = _str(raw.get("driver") or "playwright").lower()
        if driver == "midscene" and not raw.get("explore_captcha_read") and not _is_captcha_fill_item(raw):
            prompt = _str(raw.get("prompt") or raw.get("locate") or raw.get("selector"))
            key = f"mid::{prompt}"
            if key in seen_mid:
                continue
            seen_mid.add(key)
        filtered.append(raw)

    if not filtered:
        return []

    first_login = next((i for i, it in enumerate(filtered) if _is_login_click(it)), -1)
    last_captcha = max((i for i, it in enumerate(filtered) if _is_captcha_fill_item(it)), default=-1)
    auth_end = max(first_login, last_captcha)

    head: list[dict[str, Any]] = []
    fills: dict[str, dict[str, Any]] = {}
    fill_order: list[str] = []
    captcha_item: dict[str, Any] | None = None
    login_item: dict[str, Any] | None = None
    other_auth: list[dict[str, Any]] = []
    tail: list[dict[str, Any]] = []
    saw_goto = False

    for i, item in enumerate(filtered):
        kind = _trace_action_kind(item)
        if auth_end >= 0 and i > auth_end:
            if _is_login_click(item) or _is_captcha_fill_item(item) or _is_captcha_refresh_click(item):
                continue
            tail.append(item)
            continue
        if kind == "goto":
            if not saw_goto:
                head.append(item)
                saw_goto = True
            continue
        if _is_captcha_fill_item(item):
            # Prefer fill_captcha / captcha fill over bare ai_query for codegen
            if item.get("explore_captcha_read") and kind == "ai_query" and captcha_item:
                continue
            captcha_item = item
            continue
        if _is_login_click(item):
            # Keep the first login control in the auth segment only.
            if login_item is None:
                login_item = item
            continue
        if kind in ("fill", "input"):
            key = _fill_field_key(item)
            if key not in fills:
                fill_order.append(key)
            fills[key] = item
            continue
        other_auth.append(item)

    out: list[dict[str, Any]] = []
    out.extend(head)
    for key in fill_order:
        if key == "captcha":
            continue
        out.append(fills[key])
    if captcha_item is not None:
        out.append(captcha_item)
    out.extend(other_auth)
    if login_item is not None:
        out.append(login_item)
    out.extend(tail)
    return out


def _trace_action_kind(item: dict[str, Any]) -> str:
    kind = _str(item.get("kind") or item.get("action"))
    if kind == "fill_captcha":
        return "fill"
    if kind in ("tap", "ai_tap"):
        return "click"
    if kind in ("input", "ai_input"):
        return "fill"
    return kind


def _is_durable_step_locator(step: dict[str, Any], *, kind: str = "") -> bool:
    """True when the step has a non-snapshot-ref locator (or midscene/goto/captcha)."""
    from app.services.ui_automation.playwright_cli_session import is_snapshot_ref_locator

    action = kind or _str(step.get("action"))
    if action == "goto" or action.startswith("assert"):
        return True
    if step.get("captcha") or action == "fill_captcha":
        return True
    driver = _str(step.get("driver")).lower() or "playwright"
    if driver == "midscene" and (step.get("prompt") or step.get("locate")):
        return True
    cli = _str(step.get("cli_locator"))
    if cli and not is_snapshot_ref_locator(cli):
        return True
    if step.get("placeholder") or step.get("name"):
        return True
    if step.get("role") and step.get("name"):
        return True
    sel = _str(step.get("selector"))
    if not sel or sel.startswith("xpath="):
        return False
    if is_snapshot_ref_locator(sel):
        return False
    return True


def _apply_trace_to_step(step: dict[str, Any], item: dict[str, Any]) -> dict[str, Any]:
    out = dict(step)
    kind = _trace_action_kind(item)
    if kind:
        out["action"] = kind if kind != "fill_captcha" else "fill"
    if item.get("driver"):
        out["driver"] = _str(item.get("driver")).lower() or out.get("driver") or "playwright"
    for key in (
        "placeholder",
        "role",
        "name",
        "selector",
        "cli_locator",
        "prompt",
        "locate",
        "captcha",
        "value",
        "path",
    ):
        if item.get(key) is not None and _str(item.get(key)):
            out[key] = item[key]
    # Never keep a live snapshot ref as the saved selector when we recovered fields
    from app.services.ui_automation.playwright_cli_session import is_snapshot_ref_locator

    if is_snapshot_ref_locator(_str(out.get("selector"))) and (
        out.get("cli_locator") or out.get("role") or out.get("placeholder") or out.get("name")
    ):
        if out.get("cli_locator"):
            out["selector"] = out["cli_locator"]
        elif out.get("placeholder"):
            out["selector"] = f"placeholder={out['placeholder']}"
        elif out.get("role") and out.get("name"):
            out["selector"] = f"role={out['role']}[name=\"{out['name']}\"]"
    target = (
        _str(item.get("cli_locator"))
        or (
            _str(out.get("selector"))
            if not is_snapshot_ref_locator(_str(out.get("selector")))
            else ""
        )
        or _str(item.get("placeholder"))
        or _str(item.get("locate"))
        or _str(item.get("prompt"))
        or _str(item.get("name"))
        or _str(out.get("target"))
    )
    if kind == "goto":
        target = _str(item.get("path") or item.get("value") or target)
        out["value"] = target
    if target:
        out["target"] = target
    if kind == "fill" and item.get("value") is not None and not out.get("value"):
        out["value"] = item.get("value")
    if item.get("captcha") or kind == "fill_captcha":
        out["captcha"] = True
    out["ready"] = _is_durable_step_locator(out, kind=kind or _str(out.get("action")))
    return out


def _trace_item_to_step(item: dict[str, Any]) -> dict[str, Any] | None:
    """Convert one explore trace row into a ready matrix step for codegen."""
    kind = _trace_action_kind(item)
    if kind in ("", "done", "ai_query"):
        # ai_query is folded into fill_captcha
        if item.get("explore_captcha_read") and not item.get("captcha"):
            return {
                "action": "fill",
                "driver": "midscene",
                "prompt": _str(item.get("prompt") or _CAPTCHA_QUERY_HINT),
                "locate": _str(item.get("locate") or item.get("prompt")),
                "captcha": True,
                "ready": True,
                "target": _str(item.get("prompt") or "验证码图片"),
            }
        if kind == "ai_query":
            return None
        return None
    step: dict[str, Any] = {
        "action": "fill" if kind == "fill_captcha" else kind,
        "driver": _str(item.get("driver") or "playwright").lower() or "playwright",
    }
    if kind == "fill_captcha" or item.get("captcha"):
        step["action"] = "fill"
        step["captcha"] = True
        step["kind"] = "fill_captcha"
    for key in (
        "placeholder",
        "role",
        "name",
        "selector",
        "cli_locator",
        "prompt",
        "locate",
        "value",
        "path",
    ):
        if item.get(key) is not None and _str(item.get(key)):
            step[key] = item[key]
    from app.services.ui_automation.playwright_cli_session import is_snapshot_ref_locator

    if is_snapshot_ref_locator(_str(step.get("selector"))) and (
        step.get("cli_locator") or step.get("role") or step.get("placeholder") or step.get("name")
    ):
        if step.get("cli_locator"):
            step["selector"] = step["cli_locator"]
        elif step.get("placeholder"):
            step["selector"] = f"placeholder={step['placeholder']}"
        elif step.get("role") and step.get("name"):
            step["selector"] = f"role={step['role']}[name=\"{step['name']}\"]"
    if kind == "goto":
        path = _str(item.get("path") or item.get("value") or "/")
        step["target"] = path
        step["value"] = path
    else:
        sel = _str(step.get("selector"))
        step["target"] = (
            _str(item.get("cli_locator"))
            or (sel if sel and not is_snapshot_ref_locator(sel) else "")
            or _str(item.get("placeholder"))
            or _str(item.get("locate"))
            or _str(item.get("name"))
            or _str(item.get("prompt"))
            or kind
        )
    if item.get("value") is not None and kind in ("fill", "fill_captcha", "press"):
        step["value"] = item.get("value")
    step["ready"] = _is_durable_step_locator(step, kind=kind)
    return step


def _collapsed_to_steps(collapsed: list[dict[str, Any]]) -> list[dict[str, Any]]:
    steps: list[dict[str, Any]] = []
    for item in collapsed:
        if item.get("explore_captcha_read") and item.get("kind") == "ai_query":
            continue
        step = _trace_item_to_step(item)
        if step:
            steps.append(step)
    return steps


def _finalize_hydrated_row(raw: dict[str, Any], steps: list[dict[str, Any]]) -> dict[str, Any]:
    row = dict(raw)
    expected = _str(row.get("expected"))
    out_steps = list(steps)
    if expected and not any(_str(s.get("action")).startswith("assert") for s in out_steps):
        out_steps.extend(_skeleton_steps_for_row(start="", expected=expected)[1:])
    for s in out_steps:
        # Preserve False from bind; recompute when unset
        if s.get("ready") is not False:
            s["ready"] = _is_durable_step_locator(s)
    row["steps"] = out_steps[:40]
    interactive = [
        s
        for s in out_steps
        if _str(s.get("action")) not in ("",)
        and not _str(s.get("action")).startswith("assert")
    ]
    row["ready"] = bool(interactive) and all(bool(s.get("ready")) for s in interactive)
    row["has_assert"] = any(_str(s.get("action")).startswith("assert") for s in out_steps)
    return row


def _row_needs_login_prefix(row: dict[str, Any], index: int) -> bool:
    """Non-login cases need login steps prepended for independent dry-run.

    Skeleton matrices often copy plan start_path (/login) onto every row, so do not
    use start_url alone to skip the prefix — rely on case name / index.
    """
    if index <= 0:
        return False
    name = _str(row.get("name"))
    # Dedicated login cases are self-contained
    if re.search(r"登录|login|sign\s*in", name, re.I):
        return False
    return True


def _login_prefix_steps(collapsed: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Auth segment through the login boundary (inclusive)."""
    if not collapsed:
        return []
    boundary = _login_boundary_index(collapsed)
    if boundary < 0:
        # Username/password fills without a detected post-login tail
        fills = [
            it
            for it in collapsed
            if _trace_action_kind(it) in ("fill", "fill_captcha", "input", "goto")
            or _is_captcha_fill_item(it)
        ]
        return _collapsed_to_steps(fills[:6]) if fills else []
    return _collapsed_to_steps(collapsed[: boundary + 1])


def _merge_login_prefix(login_steps: list[dict[str, Any]], case_steps: list[dict[str, Any]]) -> list[dict[str, Any]]:
    if not login_steps:
        return case_steps
    # Drop leading goto from case if login already navigates
    rest = list(case_steps)
    while rest and _str(rest[0].get("action")) == "goto":
        rest = rest[1:]
    return list(login_steps) + rest


def _path_first_segment(path: str) -> str:
    """First non-empty path segment for business-area cuts (empty for auth paths)."""
    raw = _str(path).split("?")[0].split("#")[0]
    if not raw:
        return ""
    if not raw.startswith("/"):
        raw = "/" + raw
    parts = [p for p in raw.split("/") if p]
    if not parts:
        return ""
    if parts[0].lower() in _AUTH_PATH_SEG:
        return ""
    return parts[0].lower()


def _segment_label_from_path(
    chunk: list[dict[str, Any]],
    *,
    fallback: str = "后续操作",
) -> str:
    """Name a segment from path first-segment — never raw control labels."""
    for item in chunk:
        seg = _path_first_segment(_str(item.get("path")))
        if seg:
            return seg[:80]
    return fallback


def _chunk_interactive_count(chunk: list[dict[str, Any]]) -> int:
    n = 0
    for item in chunk:
        kind = _trace_action_kind(item)
        if kind in ("", "done", "goto"):
            continue
        n += 1
    return n


def _merge_tiny_segments(
    segments: list[tuple[str, list[dict[str, Any]]]],
    *,
    min_interactive: int = 2,
) -> list[tuple[str, list[dict[str, Any]]]]:
    """Merge segments with too few interactive steps into the previous one."""
    if not segments:
        return []
    out: list[tuple[str, list[dict[str, Any]]]] = [segments[0]]
    for label, chunk in segments[1:]:
        if _chunk_interactive_count(chunk) < min_interactive and out:
            prev_label, prev_chunk = out[-1]
            out[-1] = (prev_label, list(prev_chunk) + list(chunk))
        else:
            out.append((label, chunk))
    if len(out) >= 2 and _chunk_interactive_count(out[0][1]) < min_interactive:
        (_, c0), (l1, c1) = out[0], out[1]
        out = [(l1, list(c0) + list(c1))] + out[2:]
    return out


def _cap_segments(
    segments: list[tuple[str, list[dict[str, Any]]]],
    *,
    max_n: int = 5,
    fallback: str = "后续操作",
) -> list[tuple[str, list[dict[str, Any]]]]:
    """Keep at most max_n segments; merge overflow into the last (never collapse to 1)."""
    if len(segments) <= max_n:
        return segments
    head = list(segments[: max_n - 1])
    merged_items: list[dict[str, Any]] = []
    for _, chunk in segments[max_n - 1 :]:
        merged_items.extend(chunk)
    head.append((_segment_label_from_path(merged_items, fallback=fallback), merged_items))
    return head


def _split_tail_segments(
    tail: list[dict[str, Any]],
    labels: list[str] | None = None,
    *,
    fallback_name: str = "登录后业务流",
) -> list[tuple[str, list[dict[str, Any]]]]:
    """Split post-login trace by first-path-segment changes only (no CRUD keyword cuts).

    ``labels`` ignored (no checklist 1:1). SPA with no path change → one segment.
    """
    if not tail:
        return []
    del labels  # checklist must not drive even splits

    cut_idxs = [0]
    last_seg = _path_first_segment(_str(tail[0].get("path")))
    for i, item in enumerate(tail):
        if i == 0:
            continue
        path = _str(item.get("path"))
        seg = _path_first_segment(path)
        if seg and seg != last_seg:
            if i - cut_idxs[-1] >= 1:
                cut_idxs.append(i)
            last_seg = seg
        elif seg:
            last_seg = seg

    cut_idxs = sorted(set(cut_idxs))
    segments: list[tuple[str, list[dict[str, Any]]]] = []
    for j, start in enumerate(cut_idxs):
        end = cut_idxs[j + 1] if j + 1 < len(cut_idxs) else len(tail)
        chunk = tail[start:end]
        if chunk:
            segments.append(
                (_segment_label_from_path(chunk, fallback=fallback_name), chunk)
            )
    segments = _cap_segments(segments, max_n=5, fallback=fallback_name)
    segments = _merge_tiny_segments(segments)
    if len(segments) >= 2:
        return segments
    if segments:
        return [(fallback_name, list(segments[0][1]))]
    return [(fallback_name, list(tail))]


def _trace_summary_for_derive(collapsed: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Compact indexed actions for post-explore LLM case splitting."""
    out: list[dict[str, Any]] = []
    for i, item in enumerate(collapsed):
        kind = _trace_action_kind(item)
        if kind in ("", "done"):
            continue
        row: dict[str, Any] = {"i": i, "kind": kind}
        for key in ("path", "placeholder", "role", "name", "locate", "selector", "cli_locator", "prompt", "value"):
            if item.get(key) is not None and _str(item.get(key)):
                val = item.get(key)
                if key == "value" and len(_str(val)) > 40:
                    val = _str(val)[:40]
                row[key] = val
        if item.get("captcha") or item.get("explore_captcha_read"):
            row["captcha"] = True
        observe = item.get("observe")
        if isinstance(observe, dict):
            row["observe"] = {
                "url_after": _str(observe.get("url_after"))[:500],
                "new_text": [
                    _str(text)[:240]
                    for text in (observe.get("new_text") or [])[:15]
                    if _str(text)
                ],
                "dialog_open": bool(observe.get("dialog_open")),
            }
        out.append(row)
    return out[:80]


def _is_mega_single_case(rows: list[dict[str, Any]], collapsed: list[dict[str, Any]]) -> bool:
    """True when a single LLM case looks broken (covers most of the trace with <3 acts)."""
    if len(rows) != 1 or not collapsed:
        return False
    steps = rows[0].get("steps") if isinstance(rows[0].get("steps"), list) else []
    n_steps = len([s for s in steps if isinstance(s, dict) and _str(s.get("action"))])
    n_collapsed = len(collapsed)
    if n_collapsed <= 1:
        return False
    # Short-step blob covering most of the explore — force fallback
    if n_steps >= 3:
        return False
    return n_steps >= max(1, int(n_collapsed * 0.8))


def _post_login_collapsed(collapsed: list[dict[str, Any]]) -> list[dict[str, Any]]:
    boundary = _login_boundary_index(collapsed)
    if boundary < 0 or boundary >= len(collapsed) - 1:
        return list(collapsed)
    return list(collapsed[boundary + 1 :])


def _distinct_path_segments(items: list[dict[str, Any]]) -> set[str]:
    out: set[str] = set()
    for it in items:
        seg = _path_first_segment(_str(it.get("path")))
        if seg:
            out.add(seg)
    return out


def _row_looks_like_login(row: dict[str, Any]) -> bool:
    name = _norm_ws(_str(row.get("name")))
    return bool(_LOGIN_BTN.search(name))


def _row_interactive_count(row: dict[str, Any]) -> int:
    steps = row.get("steps") if isinstance(row.get("steps"), list) else []
    n = 0
    for s in steps:
        if not isinstance(s, dict):
            continue
        action = _str(s.get("action"))
        if not action or action == "goto" or action.startswith("assert"):
            continue
        n += 1
    return n


def _row_name_is_control_label(row: dict[str, Any]) -> bool:
    """True when case name equals a step control name/placeholder (over-split smell)."""
    name = _norm_ws(_str(row.get("name"))).lower()
    if not name:
        return False
    for s in row.get("steps") or []:
        if not isinstance(s, dict):
            continue
        for key in ("name", "placeholder"):
            label = _norm_ws(_str(s.get(key))).lower()
            if label and label == name:
                return True
    return False


def _is_under_split_matrix(rows: list[dict[str, Any]], collapsed: list[dict[str, Any]]) -> bool:
    """True when LLM kept too few cases while post-login trace spans multiple path modules."""
    if not rows or not collapsed:
        return False
    n = len(rows)
    if n > 2:
        return False
    if n == 2 and not _row_looks_like_login(rows[0]):
        return False
    tail = _post_login_collapsed(collapsed)
    if not tail:
        return False
    return len(_distinct_path_segments(tail)) >= 2


def _is_over_split_matrix(rows: list[dict[str, Any]], collapsed: list[dict[str, Any]]) -> bool:
    """True when LLM produced tiny / control-named cases (structural over-split)."""
    if not rows or len(rows) < 2:
        return False
    biz_rows = [r for r in rows if isinstance(r, dict) and not _row_looks_like_login(r)]
    if not biz_rows:
        return False
    short = 0
    for r in biz_rows:
        n_int = _row_interactive_count(r)
        if n_int < 2:
            return True
        if _row_name_is_control_label(r):
            return True
        if n_int < 3:
            short += 1
    tail = _post_login_collapsed(collapsed)
    path_n = max(1, len(_distinct_path_segments(tail)))
    if len(biz_rows) > path_n * 2 and short >= max(1, len(biz_rows) // 2):
        return True
    return False


def _fallback_matrix_from_trace(
    *,
    trace: list[dict[str, Any]] | None,
    goal: str = "",
    start_path: str = "/",
    case_name: str | None = None,
    checklist: list[str] | None = None,
) -> list[dict[str, Any]]:
    """No LLM / LLM fail: login + path-module business segments (coarse, no CRUD cuts)."""
    collapsed = _collapse_trace_for_bind(trace)
    if not collapsed:
        return []
    steps_all = _collapsed_to_steps(collapsed)
    name0 = _str(case_name) or _str(goal) or "探索脚本"
    del checklist  # never 1:1 checklist → matrix
    boundary = _login_boundary_index(collapsed)

    def _single() -> list[dict[str, Any]]:
        return [
            _finalize_hydrated_row(
                {
                    "id": "TC-001",
                    "name": name0[:80],
                    "start_url": start_path or "/",
                    "expected": "",
                },
                steps_all,
            )
        ]

    def _rows_from_segments(
        segments: list[tuple[str, list[dict[str, Any]]]],
        *,
        start_idx: int = 1,
        needs_auth: bool = False,
    ) -> list[dict[str, Any]]:
        out: list[dict[str, Any]] = []
        for offset, (label, chunk) in enumerate(segments):
            steps = _collapsed_to_steps(chunk)
            if not steps:
                continue
            idx = start_idx + offset
            row = _finalize_hydrated_row(
                {
                    "id": f"TC-{idx:02d}",
                    "name": _str(label)[:80] or f"用例{idx}",
                    "start_url": start_path or "/",
                    "expected": "",
                },
                steps,
            )
            if needs_auth:
                row["needs_auth"] = True
            out.append(row)
        return out

    if boundary < 0 or boundary >= len(collapsed) - 1:
        # No clear login boundary: optional path-module cuts, else one E2E case
        if len(collapsed) >= 4:
            segments = _split_tail_segments(
                collapsed, None, fallback_name=name0[:80] or "探索脚本"
            )
            rows = _rows_from_segments(segments, start_idx=1, needs_auth=False)
            if rows:
                return rows
        return _single()

    head = collapsed[: boundary + 1]
    tail = collapsed[boundary + 1 :]
    login_steps = _collapsed_to_steps(head)
    rows: list[dict[str, Any]] = [
        _finalize_hydrated_row(
            {
                "id": "TC-01",
                "name": "登录成功",
                "start_url": start_path or "/",
                "expected": "",
            },
            login_steps,
        )
    ]

    # Hollow guard: do not invent a goal-named business case from a 0–1 step tail.
    if _chunk_interactive_count(tail) < 2:
        if login_steps and _chunk_interactive_count(head) >= 1:
            return rows
        return _single()

    biz_label = (
        _str(case_name)
        or _str(goal)
        or "登录后业务流"
    )[:80]
    # Path-module cuts only; SPA → one business E2E named from case/goal.
    segments = _split_tail_segments(tail, None, fallback_name=biz_label)
    if not segments and tail:
        segments = [(biz_label, list(tail))]
    elif len(segments) == 1:
        segments = [(biz_label or segments[0][0], segments[0][1])]

    rows.extend(_rows_from_segments(segments, start_idx=2, needs_auth=True))
    return rows if len(rows) >= 2 else (_single() if not rows else rows)


def _apply_login_prefix_to_matrix(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Mark business cases as needs_auth; do not prepend login steps (reuse storageState)."""
    out: list[dict[str, Any]] = []
    for i, raw in enumerate(rows):
        row = dict(raw)
        if _row_needs_login_prefix(row, i):
            row["needs_auth"] = True
        out.append(row)
    return out


def warn_if_login_stuck(
    trace: list[dict[str, Any]] | None,
    *,
    matrix: list[dict[str, Any]] | None = None,
    single_case: bool = False,
) -> str | None:
    """User-facing hint when explore barely left auth / produced only a login case."""
    if single_case:
        return None
    collapsed = _collapse_trace_for_bind(trace)
    if not collapsed:
        return None
    boundary = _login_boundary_index(collapsed)
    thin_tail = False
    if boundary >= 0 and boundary < len(collapsed) - 1:
        thin_tail = _chunk_interactive_count(collapsed[boundary + 1 :]) < 2
    elif boundary >= 0:
        thin_tail = True
    rows = [r for r in (matrix or []) if isinstance(r, dict)]
    only_login = bool(rows) and all(_row_looks_like_login(r) for r in rows)
    if not thin_tail and not only_login:
        return None
    return (
        "提示：探索似乎未进入业务页（登录后有效操作很少，或仅生成了登录用例）。"
        "请确认账号密码与验证码是否正确后重试；也可写成「账号密码 user pass」。"
    )


def matrix_rows_from_testcases(
    cases: list[dict[str, Any]] | None,
    *,
    default_start: str = "/",
) -> list[dict[str, Any]]:
    """Preset matrix: one row per selected functional case (no正反扩展)."""
    rows: list[dict[str, Any]] = []
    start0 = default_start or "/"
    for idx, raw in enumerate(cases or [], start=1):
        if not isinstance(raw, dict):
            continue
        title = _str(raw.get("title") or raw.get("name"))
        if not title:
            continue
        tc_id = raw.get("id") or raw.get("testcase_id")
        steps_in = raw.get("steps") if isinstance(raw.get("steps"), list) else []
        expected = _str(raw.get("overall_expected") or raw.get("expected"))
        data = _str(raw.get("test_data") or raw.get("data"))
        pre = _str(raw.get("precondition") or raw.get("preconditions"))
        prose_steps: list[Any] = []
        for s in steps_in:
            if isinstance(s, dict):
                action = _str(s.get("action"))
                exp = _str(s.get("expected"))
                if action:
                    prose_steps.append(action if not exp or exp in ("—", "-") else f"{action}；期望：{exp}")
            elif isinstance(s, str) and s.strip():
                prose_steps.append(s.strip())
        row = normalize_matrix_row(
            {
                "id": f"TC-{idx:02d}",
                "name": title[:80],
                "start_url": start0,
                "preconditions": pre,
                "steps": prose_steps,
                "data": data,
                "expected": expected,
                "manual_case_id": int(tc_id) if tc_id is not None else None,
            },
            index=idx,
            default_start=start0,
        )
        if row:
            if tc_id is not None:
                try:
                    row["manual_case_id"] = int(tc_id)
                except (TypeError, ValueError):
                    pass
            rows.append(row)
    return rows


def _fill_fields_from_trace(collapsed: list[dict[str, Any]]) -> list[dict[str, str]]:
    """Unique fill targets seen in explore (for per-field validation design)."""
    fields: list[dict[str, str]] = []
    seen: set[str] = set()
    for item in collapsed:
        kind = _trace_action_kind(item)
        if kind not in ("fill", "fill_captcha", "ai_input"):
            continue
        cli_locator = _str(item.get("cli_locator"))
        name = _str(
            item.get("name")
            or item.get("placeholder")
            or item.get("locate")
            or item.get("prompt")
        )
        if not name and cli_locator:
            name_match = _LOCATOR_NAME.search(cli_locator)
            if name_match:
                name = next((g for g in name_match.groups() if g), "")
            if not name:
                direct = re.search(
                    r"""getBy(?:Label|Placeholder)\(\s*['"]([^'"]+)['"]""",
                    cli_locator,
                    re.I,
                )
                if direct:
                    name = direct.group(1)
        if not name or name in seen:
            continue
        if re.fullmatch(r"(?:f\d+)?e\d+", name, re.I):
            continue
        seen.add(name)
        fields.append(
            {
                "name": name[:40],
                "role": _str(item.get("role") or "textbox"),
                "sample_value": _str(item.get("value"))[:40],
                "cli_locator": cli_locator,
                "selector": _str(item.get("selector")),
            }
        )
    return fields[:20]


_CRUD_DESIGN_ACTIONS: tuple[tuple[str, tuple[str, ...]], ...] = (
    ("新增", ("新增", "新建", "创建", "添加")),
    ("查询", ("查询", "搜索", "筛选", "检索")),
    ("编辑", ("编辑", "修改", "更新")),
    ("删除", ("删除", "移除")),
)

MODAL_FRAGMENT_CASE_BAN = (
    "禁止把下列模式拆成独立用例（除非用户明确要求 UI 交互测试）："
    "仅打开/关闭/取消/再打开某弹窗、Esc 关遮罩、重复点同一「新建」入口、弹窗往返。"
)

_MODAL_FRAGMENT_CASE_NAME = re.compile(
    r"取消.*(?:重新)?打开|再打开.*弹窗|打开.*关闭|关闭.*再打开|"
    r"弹窗.*往返|往返.*弹窗|重复点.*新建|Esc.*遮罩|关.*遮罩后",
    re.I,
)


def test_design_actions(
    *,
    prompt: str,
    goal: str,
    checklist: list[str] | None,
) -> list[str]:
    """Business actions explicitly requested (public alias for expand/design)."""
    return _test_design_actions(prompt=prompt, goal=goal, checklist=checklist)


def case_name_is_modal_fragment(name: str) -> bool:
    text = _str(name)
    if not text:
        return False
    if _MODAL_FRAGMENT_CASE_NAME.search(text):
        return True
    if re.search(r"弹窗", text) and re.search(r"打开|关闭|取消", text) and not re.search(
        r"提交|保存|创建成功|新增.*文档|填写",
        text,
    ):
        return True
    return False


def filter_modal_fragment_matrix(rows: list[dict[str, Any]] | None) -> list[dict[str, Any]]:
    if not rows:
        return []
    return [r for r in rows if isinstance(r, dict) and not case_name_is_modal_fragment(_str(r.get("name")))]


def matrix_missing_crud_actions(
    rows: list[dict[str, Any]] | None,
    design_actions: list[str] | None,
) -> list[str]:
    """CRUD labels from intent that do not appear in any case name."""
    if not design_actions:
        return []
    missing: list[str] = []
    for action in design_actions:
        label = _str(action)
        if not label:
            continue
        if not any(label in _str(r.get("name")) for r in (rows or []) if isinstance(r, dict)):
            missing.append(label)
    return missing


def _test_design_actions(
    *,
    prompt: str,
    goal: str,
    checklist: list[str] | None,
) -> list[str]:
    """Business actions explicitly requested by free-text goal/checklist."""
    blob = " ".join([prompt or "", goal or "", *(str(x) for x in (checklist or []))])
    out: list[str] = []
    for label, tokens in _CRUD_DESIGN_ACTIONS:
        if any(token in blob for token in tokens):
            out.append(label)
    if re.search(r"\bcrud\b|增删改查", blob, re.I):
        for label in ("新增", "查询", "编辑", "删除"):
            if label not in out:
                out.append(label)
    return out


def count_test_design_fields(trace: list[dict[str, Any]] | None) -> int:
    """Count unique explored input fields for expansion diagnostics."""
    return len(_fill_fields_from_trace(_collapse_trace_for_bind(trace)))


def expand_cases_from_test_design(
    *,
    prompt: str = "",
    goal: str = "",
    trace: list[dict[str, Any]] | None,
    llm: Any = None,
    start_path: str = "/",
    checklist: list[str] | None = None,
    case_name: str | None = None,
    model: str | None = None,
) -> list[dict[str, Any]]:
    """After one explore: expand into test-design cases (happy path + per-field checks)."""
    collapsed = _collapse_trace_for_bind(trace)
    if not collapsed:
        return []

    summary = _trace_summary_for_derive(collapsed)
    fields = _fill_fields_from_trace(collapsed)
    design_actions = _test_design_actions(
        prompt=prompt,
        goal=goal,
        checklist=checklist,
    )
    steps_all = [_trace_item_to_step(x) for x in collapsed]
    steps_all = [s for s in steps_all if s]
    rows: list[dict[str, Any]] = []

    if llm is not None and summary:
        try:
            from app.services.ui_automation.ui_ai_explorer import _extract_json

            messages = [
                {
                    "role": "system",
                    "content": (
                        "你是测试设计专家。根据一次 UI 探索轨迹与已识别输入字段，按用例设计扩展多条可独立执行的用例。"
                        "只输出 JSON 对象 {\"matrix\": [...]}。"
                        "每项：id(如 TC-01)、name、expected、"
                        "step_indexes(array of int，对应 trace 摘要里的 i；主路径用例用)、"
                        "variant(object 可选：field=字段名, mode=empty|invalid|required, value=覆盖填值)。"
                        "规则："
                        "1) 必须有一条主成功路径（happy path），覆盖探索中的关键业务步骤；"
                        "2) 若意图含新增/创建/查询/编辑/删除/CRUD，禁止只输出一条；"
                        "   须按用户明确要求的每个业务动作各输出至少一条独立用例；"
                        "3) fields 非空时，对每个字段至少 1 条校验用例（空值/必填/格式异常等），"
                        "   校验用例可复用主路径 step_indexes，用 variant 改该字段填值并写清 expected；"
                        "4) fields 为空时仍须按业务动作拆分，不能退化成一个超长端到端用例；"
                        "5) 每条用例须可独立理解；索引必须来自输入；不要臆造未出现的控件；"
                        "6) 登录相关操作归到主路径前缀即可，不要单独拆成「仅登录」以外的空用例。"
                        f"7) {MODAL_FRAGMENT_CASE_BAN}"
                        "8) 未在 trace 中出现的 CRUD 动作禁止编造步骤；不要输出只有 name 的空占位用例。"
                    ),
                },
                {
                    "role": "user",
                    "content": json.dumps(
                        {
                            "user_prompt": (prompt or "")[:800],
                            "goal": goal or "",
                            "checklist": list(checklist or [])[:20],
                            "start_path": start_path or "/",
                            "fields": fields,
                            "required_business_actions": design_actions,
                            "trace": summary,
                        },
                        ensure_ascii=False,
                    ),
                },
            ]
            raw = llm.chat_complete(
                messages, model=model, db=None, cfg=llm, scene="UI 测试设计扩展用例"
            )
            data = _extract_json(raw)
            matrix_raw = []
            if isinstance(data, dict):
                matrix_raw = data.get("matrix") or data.get("cases") or []
            if isinstance(matrix_raw, list):
                for idx, item in enumerate(matrix_raw, start=1):
                    if not isinstance(item, dict):
                        continue
                    name = _str(item.get("name") or item.get("title"))
                    if not name:
                        continue
                    cid = _str(item.get("id")) or f"TC-{idx:02d}"
                    indexes = item.get("step_indexes") or item.get("steps") or []
                    picked: list[dict[str, Any]] = []
                    if isinstance(indexes, list) and indexes and all(isinstance(x, int) for x in indexes):
                        for i in indexes:
                            if 0 <= i < len(collapsed):
                                step = _trace_item_to_step(collapsed[i])
                                if step:
                                    picked.append(dict(step))
                    elif isinstance(indexes, list):
                        for part in indexes:
                            if isinstance(part, int) and 0 <= part < len(collapsed):
                                step = _trace_item_to_step(collapsed[part])
                                if step:
                                    picked.append(dict(step))
                            elif isinstance(part, dict):
                                if isinstance(part.get("i"), int) and 0 <= int(part["i"]) < len(collapsed):
                                    step = _trace_item_to_step(collapsed[int(part["i"])])
                                    if step:
                                        picked.append(dict(step))
                                else:
                                    step = normalize_matrix_step(part, default_start=start_path or "/")
                                    if step:
                                        step["ready"] = True
                                        picked.append(step)
                    if not picked and steps_all:
                        picked = [dict(s) for s in steps_all]
                    if not picked:
                        continue
                    variant = item.get("variant") if isinstance(item.get("variant"), dict) else {}
                    field = _str(variant.get("field"))
                    mode = _str(variant.get("mode")).lower()
                    override = variant.get("value")
                    if field:
                        for s in picked:
                            if _str(s.get("action")) not in ("fill", "ai_input"):
                                continue
                            blob = " ".join(
                                _str(s.get(k))
                                for k in ("name", "placeholder", "locate", "target", "prompt")
                            )
                            if field not in blob and _norm_ws(field) not in _norm_ws(blob):
                                continue
                            if mode in ("empty", "required", "blank"):
                                s["value"] = ""
                            elif override is not None:
                                s["value"] = _str(override)
                            elif mode == "invalid":
                                s["value"] = str(override or "invalid")
                            break
                    expected = _str(item.get("expected"))
                    rows.append(
                        _finalize_hydrated_row(
                            {
                                "id": cid,
                                "name": name[:80],
                                "start_url": _str(item.get("start_url") or start_path) or "/",
                                "expected": expected,
                                "preconditions": _str(item.get("preconditions")),
                            },
                            picked,
                        )
                    )
        except Exception:  # noqa: BLE001
            rows = []

    # A mega single case is not a valid test-design result for explicit CRUD intent.
    if rows and _is_mega_single_case(rows, collapsed) and design_actions:
        rows = []

    # Guarantee a happy path when the LLM failed or returned an unusable mega case.
    if not rows and steps_all:
        rows = [
            _finalize_hydrated_row(
                {
                    "id": "TC-01",
                    "name": (_str(case_name) or _str(goal) or "主成功路径")[:80],
                    "start_url": start_path or "/",
                    "expected": "",
                },
                [dict(s) for s in steps_all],
            )
        ]

    # Guarantee one independent case per explicitly requested CRUD business action.
    # The explored steps are reused as a grounded skeleton; later locator/code readiness
    # remains visible per row instead of collapsing back to one synthetic case.
    if rows and design_actions:
        for action_index, action_name in enumerate(design_actions, start=1):
            if any(action_name in _str(r.get("name")) for r in rows):
                continue
            base_steps = [
                dict(s)
                for s in (rows[0].get("steps") or steps_all)
                if isinstance(s, dict)
            ]
            if not base_steps:
                continue
            rows.append(
                _finalize_hydrated_row(
                    {
                        "id": f"TC-B{action_index:02d}",
                        "name": f"{action_name}流程验证",
                        "start_url": start_path or "/",
                        "expected": "",
                    },
                    base_steps,
                )
            )

    if fields and rows:
        existing_names = {_str(r.get("name")) for r in rows}
        for fi, field in enumerate(fields, start=1):
            fname = field.get("name") or f"字段{fi}"
            case_name_f = f"{fname}为空校验"
            if case_name_f in existing_names:
                continue
            # Skip if LLM already produced a variant for this field
            if any(fname in _str(r.get("name")) and ("空" in _str(r.get("name")) or "校验" in _str(r.get("name"))) for r in rows):
                continue
            base_steps = [dict(s) for s in (rows[0].get("steps") or steps_all) if isinstance(s, dict)]
            if not base_steps:
                continue
            for s in base_steps:
                if _str(s.get("action")) not in ("fill", "ai_input"):
                    continue
                blob = " ".join(
                    _str(s.get(k)) for k in ("name", "placeholder", "locate", "target", "prompt")
                )
                if fname in blob or _norm_ws(fname) in _norm_ws(blob):
                    s["value"] = ""
                    break
            rows.append(
                _finalize_hydrated_row(
                    {
                        "id": f"TC-F{fi:02d}",
                        "name": case_name_f[:80],
                        "start_url": start_path or "/",
                        "expected": f"{fname}为空时应提示校验或阻止提交",
                    },
                    base_steps,
                )
            )

    if not rows:
        rows = _fallback_matrix_from_trace(
            trace=trace,
            goal=goal,
            start_path=start_path or "/",
            case_name=case_name,
            checklist=list(checklist or []),
        )
    return _apply_login_prefix_to_matrix(rows)


def derive_matrix_from_explore(
    *,
    prompt: str = "",
    goal: str = "",
    trace: list[dict[str, Any]] | None,
    llm: Any = None,
    start_path: str = "/",
    checklist: list[str] | None = None,
    case_name: str | None = None,
    model: str | None = None,
) -> list[dict[str, Any]]:
    """After one explore: split collapsed trace into multiple ready matrix rows."""
    collapsed = _collapse_trace_for_bind(trace)
    if not collapsed:
        return []

    summary = _trace_summary_for_derive(collapsed)
    rows: list[dict[str, Any]] = []

    if llm is not None and summary:
        try:
            from app.services.ui_automation.ui_ai_explorer import _extract_json

            messages = [
                {
                    "role": "system",
                    "content": (
                        "你是 UI 测试用例拆分助手。根据一次界面探索的操作轨迹，拆成可独立执行的端到端用例。"
                        "只输出 JSON 对象，键 matrix(array)。每项："
                        "id(string 如 TC-01), name(string), expected(string 可断言终态), "
                        "step_indexes(array of int，对应输入 trace 摘要里的 i)。"
                        "规则："
                        "checklist 只是探索检查点，禁止一项 checklist 对应一条 matrix；"
                        "每条（登录除外）须为可独立理解的完整业务闭环，交互 step_indexes 建议 ≥2；"
                        "禁止单步用例、禁止仅填一个字段、禁止仅点确认/提交成案；"
                        "登录相关操作归 TC-01；后续用例不要重复登录步（系统会自动补登录）；"
                        "按轨迹中真实出现的导航/路径模块划分业务区，不要臆造模块名；"
                        "名称用业务结果语义，不要用控件裸文案（如字段 placeholder、确定按钮）；"
                        "索引必须来自输入，优先连续索引。"
                    ),
                },
                {
                    "role": "user",
                    "content": json.dumps(
                        {
                            "user_prompt": (prompt or "")[:800],
                            "goal": goal or "",
                            "checklist": list(checklist or [])[:20],
                            "start_path": start_path or "/",
                            "trace": summary,
                        },
                        ensure_ascii=False,
                    ),
                },
            ]
            raw = llm.chat_complete(messages, model=model, db=None, cfg=llm, scene="UI 探索后拆用例")
            data = _extract_json(raw)
            matrix_raw = []
            if isinstance(data, dict):
                matrix_raw = data.get("matrix") or data.get("cases") or []
            if isinstance(matrix_raw, list):
                for idx, item in enumerate(matrix_raw, start=1):
                    if not isinstance(item, dict):
                        continue
                    name = _str(item.get("name") or item.get("title"))
                    if not name:
                        continue
                    cid = _str(item.get("id")) or f"TC-{idx:02d}"
                    indexes = item.get("step_indexes") or item.get("steps") or []
                    picked: list[dict[str, Any]] = []
                    if isinstance(indexes, list) and indexes and all(isinstance(x, int) for x in indexes):
                        for i in indexes:
                            if 0 <= i < len(collapsed):
                                step = _trace_item_to_step(collapsed[i])
                                if step:
                                    picked.append(step)
                    elif isinstance(indexes, list):
                        for part in indexes:
                            if isinstance(part, int) and 0 <= part < len(collapsed):
                                step = _trace_item_to_step(collapsed[part])
                                if step:
                                    picked.append(step)
                            elif isinstance(part, dict):
                                # Allow {i: n} or full step dict
                                if isinstance(part.get("i"), int) and 0 <= int(part["i"]) < len(collapsed):
                                    step = _trace_item_to_step(collapsed[int(part["i"])])
                                    if step:
                                        picked.append(step)
                                else:
                                    step = normalize_matrix_step(part, default_start=start_path or "/")
                                    if step:
                                        step["ready"] = True
                                        picked.append(step)
                    if not picked:
                        continue
                    expected = _str(item.get("expected"))
                    rows.append(
                        _finalize_hydrated_row(
                            {
                                "id": cid,
                                "name": name[:80],
                                "start_url": _str(item.get("start_url") or start_path) or "/",
                                "expected": expected,
                                "preconditions": _str(item.get("preconditions")),
                            },
                            picked,
                        )
                    )
        except Exception:  # noqa: BLE001
            rows = []

    if rows and (
        _is_mega_single_case(rows, collapsed)
        or _is_under_split_matrix(rows, collapsed)
        or _is_over_split_matrix(rows, collapsed)
    ):
        rows = []

    if not rows:
        rows = _fallback_matrix_from_trace(
            trace=trace,
            goal=goal,
            start_path=start_path or "/",
            case_name=case_name,
            checklist=list(checklist or []),
        )
    return _apply_login_prefix_to_matrix(rows)


def hydrate_matrix_from_trace(
    matrix: list[dict[str, Any]] | None,
    trace: list[dict[str, Any]] | None,
) -> list[dict[str, Any]]:
    """After explore: hydrate each matrix row from case_id-tagged (or split) trace."""
    rows_in = [r for r in (matrix or []) if isinstance(r, dict)]
    if not rows_in:
        return []

    by_case: dict[str, list[dict[str, Any]]] = {}
    for raw in trace or []:
        if not isinstance(raw, dict):
            continue
        cid = _str(raw.get("case_id"))
        if not cid:
            continue
        by_case.setdefault(cid, []).append(raw)

    if by_case:
        out: list[dict[str, Any]] = []
        for i, raw in enumerate(rows_in):
            cid = _str(raw.get("id"))
            items = by_case.get(cid) or []
            if not items:
                out.append(skeletonize_matrix_row(raw))
                continue
            steps = _collapsed_to_steps(_collapse_trace_for_bind(items))
            if not steps:
                out.append(skeletonize_matrix_row(raw))
                continue
            row = _finalize_hydrated_row(raw, steps)
            if _row_needs_login_prefix(raw, i):
                row["needs_auth"] = True
            out.append(row)
        return out

    # No case_id tags: single row gets full trace; multi-row splits at login then distributes tail.
    collapsed = _collapse_trace_for_bind(trace)
    if not collapsed:
        return [skeletonize_matrix_row(r) for r in rows_in]

    if len(rows_in) == 1:
        return [_finalize_hydrated_row(rows_in[0], _collapsed_to_steps(collapsed))]

    last_login = max((i for i, it in enumerate(collapsed) if _is_login_click(it)), default=-1)
    if last_login < 0:
        chunks = [chunk for _, chunk in _split_tail_segments(collapsed)]
        return [
            (
                _finalize_hydrated_row(raw, _collapsed_to_steps(chunks[i]))
                if i < len(chunks) and chunks[i]
                else skeletonize_matrix_row(raw)
            )
            for i, raw in enumerate(rows_in)
        ]

    head = collapsed[: last_login + 1]
    tail = collapsed[last_login + 1 :]
    login_steps = _collapsed_to_steps(head)
    out = [_finalize_hydrated_row(rows_in[0], login_steps)]
    rest = rows_in[1:]
    if not rest:
        return out
    if not tail:
        out.extend(skeletonize_matrix_row(r) for r in rest)
        return out
    tail_chunks = [chunk for _, chunk in _split_tail_segments(tail)]
    for i, raw in enumerate(rest, start=1):
        chunk = tail_chunks[i - 1] if i - 1 < len(tail_chunks) else []
        steps = _collapsed_to_steps(chunk)
        if not steps:
            out.append(skeletonize_matrix_row(raw))
            continue
        row = _finalize_hydrated_row(raw, steps)
        if _row_needs_login_prefix(raw, i):
            row["needs_auth"] = True
        out.append(row)
    return out


def bind_trace_to_matrix(
    matrix: list[dict[str, Any]] | None,
    trace: list[dict[str, Any]] | None,
) -> list[dict[str, Any]]:
    """Fill matrix step targets from explore trace (deduped). Marks row.ready.

    Prefer hydrate_matrix_from_trace for post-explore codegen (skeleton → code).
    """
    # If matrix rows look like skeletons (only goto/assert), hydrate from full trace.
    rows_in = [r for r in (matrix or []) if isinstance(r, dict)]
    if rows_in:
        interactive = 0
        for r in rows_in:
            for s in r.get("steps") or []:
                if isinstance(s, dict):
                    a = _str(s.get("action"))
                    if a and a not in ("goto",) and not a.startswith("assert"):
                        interactive += 1
        if interactive <= 1:
            return hydrate_matrix_from_trace(matrix, trace)
    collapsed = _collapse_trace_for_bind(trace)
    rows: list[dict[str, Any]] = []
    cursor = 0
    for raw in matrix or []:
        if not isinstance(raw, dict):
            continue
        row = dict(raw)
        steps_out: list[dict[str, Any]] = []
        for step in row.get("steps") or []:
            if not isinstance(step, dict):
                continue
            action = _str(step.get("action"))
            if action.startswith("assert") or action == "goto":
                bound = dict(step)
                if action == "goto":
                    bound["ready"] = True
                    if not bound.get("target"):
                        bound["target"] = bound.get("value") or row.get("start_url") or "/"
                else:
                    # Asserts are codegen-ready from plan text; no locator bind required.
                    bound["ready"] = True
                steps_out.append(bound)
                continue
            if cursor < len(collapsed):
                item = collapsed[cursor]
                # Prefer matching action kinds; otherwise take next interactive step.
                while cursor < len(collapsed):
                    item = collapsed[cursor]
                    tkind = _trace_action_kind(item)
                    if tkind == action or (
                        action in ("fill", "click", "press") and tkind in ("fill", "click", "press", "goto")
                    ):
                        if tkind == "goto" and action != "goto":
                            cursor += 1
                            continue
                        steps_out.append(_apply_trace_to_step(step, item))
                        cursor += 1
                        break
                    cursor += 1
                else:
                    unbound = dict(step)
                    unbound["ready"] = False
                    steps_out.append(unbound)
            else:
                unbound = dict(step)
                unbound["ready"] = False
                steps_out.append(unbound)
        row["steps"] = steps_out
        interactive = [s for s in steps_out if _str(s.get("action")) not in ("goto",) and not _str(s.get("action")).startswith("assert")]
        row["ready"] = bool(steps_out) and all(
            s.get("ready") for s in steps_out if not _str(s.get("action")).startswith("assert")
        ) and (
            not interactive or any(s.get("ready") for s in interactive)
        )
        # Require at least one assert per case for dry-run gate
        row["has_assert"] = any(_str(s.get("action")).startswith("assert") for s in steps_out)
        rows.append(row)
    return rows


def matrix_bind_issues(matrix: list[dict[str, Any]] | None) -> list[str]:
    """Human-readable reasons the matrix cannot drive a passing dry-run.

    Requires at least one ready case with asserts (typically the primary path).
    Unbound secondary cases are skipped by codegen and do not alone fail the gate.
    """
    issues: list[str] = []
    rows = [r for r in (matrix or []) if isinstance(r, dict)]
    if not rows:
        return ["用例矩阵为空"]
    ready_rows = [r for r in rows if r.get("ready")]
    if not ready_rows:
        first = rows[0]
        cid = _str(first.get("id") or first.get("name") or "UC-001")
        unbound = []
        for step in first.get("steps") or []:
            if not isinstance(step, dict):
                continue
            action = _str(step.get("action"))
            if action.startswith("assert") or action == "goto":
                continue
            if not step.get("ready"):
                unbound.append(f"{action} {step.get('target') or ''}".strip())
        if unbound:
            issues.append(f"{cid}: 步骤未绑定 locator（{unbound[0]}）")
        else:
            issues.append(f"{cid}: 用例未就绪")
        return issues
    for row in ready_rows:
        cid = _str(row.get("id") or row.get("name") or "?")
        steps = row.get("steps") or []
        has_assert = any(
            _str(s.get("action")).startswith("assert") for s in steps if isinstance(s, dict)
        )
        if not has_assert:
            issues.append(f"{cid}: 缺少 assert_text/assert_url")
    return issues[:12]
