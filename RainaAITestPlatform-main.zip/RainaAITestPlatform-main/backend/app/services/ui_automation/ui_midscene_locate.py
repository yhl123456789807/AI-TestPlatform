"""Short Midscene locate/prompt hints for aiTap/aiInput (never long explore reasons)."""

from __future__ import annotations

import re
from typing import Any

from app.services.ui_automation.playwright_cli_session import SNAPSHOT_REF_TOKEN

_MAX_HINT_LEN = 40
_SNAPSHOT_REF_HINT = re.compile(rf"(?:ref=)?{SNAPSHOT_REF_TOKEN}$", re.I)

# Generic Ant Design spaced labels only (not product-specific control names).
_ANT_SPACED = frozenset({"确 定", "创 建"})

_DEFAULT_HINTS = frozenset({"目标按钮", "目标输入框", "按钮", "输入框"})

_OPEN_Q = r"「『\"“‘'"
_CLOSE_Q = r"」』\"”’'"
_QUOTED = re.compile(rf"[{_OPEN_Q}]([^{_CLOSE_Q}]{{1,40}})[{_CLOSE_Q}]")
# Allow one internal space for Ant Design labels like 「确 定」
_CLICK_BTN = re.compile(
    rf"(?:点击|点|选择|按下)\s*"
    rf"[{_OPEN_Q}]?"
    rf"([^\s{_CLOSE_Q}，,。；;]{{1,20}}(?:\s+[^\s{_CLOSE_Q}，,。；;]{{1,12}})?)"
    rf"[{_CLOSE_Q}]?"
    rf"(?:按钮|提交|保存)?"
)
# Narrative explore reasons mistaken for locate/prompt
_REASON_LIKE = re.compile(r"已识别|已填写|已出现|已选择|已创建|弹窗|点击|提交|完成删除|继续")
_LEADING_QUOTE = re.compile(rf"^[{_OPEN_Q}]")
# Single-char scraps that are almost always truncated quotes (「确 定」→ 确)
_SCRAP_CHARS = frozenset("确取删编创登保提查搜返取")


def _is_bad_hint(text: str) -> bool:
    s = (text or "").strip()
    if not s:
        return True
    if len(s) > _MAX_HINT_LEN:
        return True
    if s.startswith("page.") or s.startswith("locator(") or s.startswith("getBy"):
        return True
    if _LEADING_QUOTE.match(s) or any(ch in s for ch in "「」『』\"“”‘’"):
        return True
    # snapshot refs (e12 / f1e367)
    if _SNAPSHOT_REF_HINT.fullmatch(s):
        return True
    # Truncated 1-char scraps (e.g. 确 from 「确 定」)
    if len(s) == 1 and s in _SCRAP_CHARS:
        return True
    return False


def _normalize_confirm(cand: str, context: str = "") -> str:
    """Map 确 / 确定 scraps to Ant Design 「确 定」 or 确定 when context supports it."""
    s = (cand or "").strip()
    blob = f"{context} {s}"
    if s in ("确 定", "确定"):
        return s
    if s == "确" or s.endswith("确"):
        if "确 定" in blob or re.search(r"确\s+定", blob):
            return "确 定"
        if "确定" in blob:
            return "确定"
        # Bare 确 after 点击 in dialogs → prefer spaced Ant label
        if "点击" in blob or "弹窗" in blob or "确认" in blob:
            return "确 定"
    return s


def _normalize_create(cand: str, context: str = "") -> str:
    """Map 创 / 创建 scraps to Ant Design 「创 建」 or 创建 when context supports it."""
    s = (cand or "").strip()
    blob = f"{context} {s}"
    if s in ("创 建", "创建"):
        return s
    if s == "创" or (s.endswith("创") and s != "创建"):
        if "创 建" in blob or re.search(r"创\s+建", blob):
            return "创 建"
        if "创建" in blob:
            return "创建"
        if "点击" in blob or "弹窗" in blob:
            return "创 建"
    return s


def _normalize_ant_label(cand: str, context: str = "") -> str:
    """Normalize Ant Design spaced confirm/create labels."""
    s = _normalize_confirm(cand, context)
    return _normalize_create(s, context)


def is_named_control_hint(hint: str, *, action: str = "click") -> bool:
    """True when hint is a stable accessible name (codegen → getByRole, not aiTap)."""
    s = (hint or "").strip()
    if not s or s in _DEFAULT_HINTS or _is_bad_hint(s):
        return False
    if s.startswith("目标"):
        return False
    if _REASON_LIKE.search(s) and len(s) > 16:
        return False
    # Short visible labels from explore (menu item, button name, …) — no product allowlist.
    return 1 < len(s) <= 24


def _hint_from_reason(reason: str) -> str:
    text = (reason or "").strip()
    if not text:
        return ""
    # Quoted UI labels — prefer the last short quote (often the confirm button)
    quotes = [m.group(1).strip() for m in _QUOTED.finditer(text) if m.group(1).strip()]
    for q in reversed(quotes):
        q = _normalize_ant_label(q, text)
        if _is_bad_hint(q):
            continue
        if "？" in q or "?" in q or len(q) > 16:
            if q in _ANT_SPACED or len(q) <= 8:
                return q
            continue
        return q
    # "点击X" capture — use the captured label itself (no product token table)
    m = _CLICK_BTN.search(text)
    if m:
        cand = (m.group(1) or "").strip()
        # Drop trailing verb/noise: 「创建提交新建项目」→「创建」
        cand = re.sub(r"(?:按钮|提交|保存).*$", "", cand).strip() or cand
        cand = _normalize_ant_label(cand, text)
        if cand and not _is_bad_hint(cand) and 1 < len(cand) <= 24:
            return cand
    return ""


def agent_locate_hint(
    decision: dict[str, Any] | None,
    *,
    action: str = "click",
) -> str:
    """Build a short NL target for Midscene aiTap/aiInput.

    Prefer locate/prompt/name; extract button labels from reason; never return
    the full explore reason paragraph.
    """
    d = decision if isinstance(decision, dict) else {}
    action = (action or "click").strip().lower()
    default = "目标按钮" if action in ("click", "tap", "ai_tap") else "目标输入框"

    for key in ("locate", "prompt", "name"):
        raw = str(d.get(key) or "").strip()
        if not raw or _is_bad_hint(raw):
            continue
        # Short locate that is actually a narrative reason → extract control name
        if _REASON_LIKE.search(raw) and (len(raw) > 10 or "点击" in raw):
            extracted = _hint_from_reason(raw)
            if extracted and not _is_bad_hint(extracted):
                return extracted
            continue
        normalized = _normalize_ant_label(raw, raw)
        if not _is_bad_hint(normalized):
            return normalized

    from_reason = _hint_from_reason(str(d.get("reason") or ""))
    if from_reason and not _is_bad_hint(from_reason):
        return from_reason

    # Last resort: extract from locate/prompt/reason; never ship narrative blobs
    for key in ("locate", "prompt", "name", "reason"):
        raw = str(d.get(key) or "").strip()
        if not raw or raw.startswith("page.") or _SNAPSHOT_REF_HINT.fullmatch(raw):
            continue
        extracted = _hint_from_reason(raw)
        if extracted and not _is_bad_hint(extracted):
            return extracted
        if key != "reason" and not _REASON_LIKE.search(raw) and len(raw) <= _MAX_HINT_LEN:
            normalized = _normalize_ant_label(raw, raw)
            if not _is_bad_hint(normalized):
                return normalized

    return default


def midscene_locate_hint(
    decision: dict[str, Any] | None,
    *,
    action: str = "click",
) -> str:
    """Alias for agent_locate_hint (Midscene codegen / explore)."""
    return agent_locate_hint(decision, action=action)
