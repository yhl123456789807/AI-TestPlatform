"""Explore engines: playwright-cli (default) and optional Midscene aiAct legacy."""

from __future__ import annotations

from collections.abc import Callable
import logging
from typing import Any

from app.config import settings
from app.services.ai.effective_ai_settings import LlmRuntime, MidsceneRuntime
from app.services.ui_automation.node_ui_runner import explore_with_midscene
from app.services.ui_automation.ui_cli_explorer import (
    REPEATED_MIDSCENE_NOOP,
    run_cli_explore_loop,
)
from app.services.ui_automation.ui_explore_report import (
    _skeleton_steps_for_row,
    apply_sequential_explore_matrix,
    bind_trace_to_matrix,
    count_test_design_fields,
    ensure_plan_matrix,
    expand_cases_from_test_design,
    filter_modal_fragment_matrix,
    matrix_missing_crud_actions,
    test_design_actions,
    hydrate_matrix_from_trace,
)
from app.services.ui_automation.ui_codegen_agents import design_cases, run_codegen_pipeline
from app.services.ui_automation.ui_page_knowledge import (
    build_page_knowledge,
    merge_trace_into_knowledge,
    validate_matrix_against_knowledge,
)
from app.services.ui_automation.ui_recon_explore import run_recon_explore
from app.services.ui_automation.ui_script_midscene_policy import MIDSCENE_EXPLORE_POLICY
from app.services.ui_automation.ui_node_script import (
    actions_to_node_script,
    matrix_to_case_scripts,
)

ENGINES = ("playwright", "midscene")
log = logging.getLogger(__name__)


def merge_explore_ctx(
    ctx: dict[str, str] | None = None,
    *,
    username: str = "",
    password: str = "",
) -> dict[str, str]:
    """Non-empty explore/codegen variables. username/password kwargs remain for callers."""
    out: dict[str, str] = {}
    for k, v in (ctx or {}).items():
        key = str(k).strip()
        val = str(v or "").strip()
        if key and val:
            out[key] = val
    user = str(username or "").strip()
    pwd = str(password or "").strip()
    if user:
        out.setdefault("username", user)
    if pwd:
        out.setdefault("password", pwd)
    return out


def explore_task_text(
    *,
    goal: str,
    ctx: dict[str, str] | None = None,
    username: str = "",
    password: str = "",
    engine: str = "midscene",
) -> str:
    env = merge_explore_ctx(ctx, username=username, password=password)
    var_bits = "".join(
        f"若页面有与键「{k}」语义匹配的输入框，fill 的 value 用 {{{{{k}}}}}。" for k in env
    )
    policy = MIDSCENE_EXPLORE_POLICY
    captcha = (
        "若有图片验证码：Midscene 只读图，再用 Playwright 填入对应验证码输入框，"
        "然后立刻点击页面上的登录/提交按钮；禁止对验证码图片或刷新按钮做 Input；不要反复空转同一框。"
        "若提交失败或验证码图已刷新，可点击刷新类控件后重新读图填写。"
    )
    return (
        f"目标：{goal or '完成用户要求的界面操作'}。"
        f"{var_bits}"
        "按当前页面可见控件操作：优先用 accessibility snapshot 中的 ref / role+name（Playwright）。"
        f"{policy}"
        f"{captcha}"
        "不要在同一页面无限重复同一操作。"
        "只有离开当前表单页面，或出现明确的成功、失败提示时才结束。"
    )


def _trace_from_actions(
    actions: list[dict[str, Any]],
    *,
    ctx: dict[str, str] | None = None,
    password: str = "",
    username: str = "",
) -> list[dict[str, Any]]:
    from app.services.ui_automation.ui_explore_report import annotate_steps

    env = merge_explore_ctx(ctx, username=username, password=password)
    # Longer values first so we don't partially mis-map
    value_to_key = sorted(
        ((str(v), k) for k, v in env.items()),
        key=lambda kv: -len(kv[0]),
    )
    trace: list[dict[str, Any]] = []
    for raw in actions:
        if not isinstance(raw, dict):
            continue
        kind = str(raw.get("kind") or "")
        value = raw.get("value")
        if value is not None:
            text = str(value)
            for val, key in value_to_key:
                if val and text == val:
                    value = "{{" + key + "}}"
                    break
        item: dict[str, Any] = {
            "action": "fill" if kind in ("fill", "fill_captcha") else kind,
            "kind": kind,
            "status": "ok",
            "selector": raw.get("selector") or "",
            "locate": raw.get("locate") or "",
            "placeholder": raw.get("placeholder") or "",
            "role": raw.get("role") or "",
            "name": raw.get("name") or "",
        }
        # Prefer stable locator text for display when selector empty
        if not item["selector"]:
            item["selector"] = raw.get("cli_locator") or raw.get("placeholder") or raw.get("locate") or ""
        if value is not None and kind in ("fill", "fill_captcha", "goto", "press"):
            item["value"] = value
        if kind == "fill_captcha":
            item["captcha"] = True
        if kind == "goto":
            item["value"] = raw.get("path") or value or "/"
        for key in ("driver", "reason", "prompt", "cli_locator", "captcha"):
            if raw.get(key) is not None and key not in item:
                item[key] = raw.get(key)
        trace.append(item)
    return annotate_steps(trace)


def run_playwright_cli_engine(
    *,
    base_url: str,
    start_path: str,
    goal: str,
    username: str = "",
    password: str = "",
    llm: LlmRuntime,
    headed: bool,
    timeout_ms: int,
    max_steps: int = 25,
    plan: dict[str, Any] | None = None,
    ctx: dict[str, str] | None = None,
    on_log: Callable[[str], None] | None = None,
    should_cancel: Callable[[], bool] | None = None,
    on_step: Callable[[dict[str, Any]], None] | None = None,
    on_need_human: Callable[[str], str | None] | None = None,
    on_screenshot: Callable[[bytes, dict[str, Any]], str | None] | None = None,
    midscene_model_config: dict[str, str] | None = None,
    storage_state: dict[str, Any] | str | None = None,
    extra_http_headers: dict[str, str] | None = None,
    local_storage: dict[str, str] | None = None,
    skip_login: bool = False,
) -> tuple[list[dict[str, Any]], str]:
    """Explore with playwright-cli; captcha via Midscene aiQuery then CLI fill.

    Bound functional cases: preset matrix → explore → hydrate → one script per case.
    Free text: explore by goal/checklist, then expand_cases_from_test_design.
    """
    explore_ctx = merge_explore_ctx(ctx, username=username, password=password)
    incoming = dict(plan or {})
    single_case = bool(incoming.get("_single_case"))
    if not single_case and not incoming.get("_bound_functional_cases"):
        cl = incoming.get("checklist") if isinstance(incoming.get("checklist"), list) else []
        if cl and not (isinstance(incoming.get("matrix"), list) and incoming["matrix"]):
            incoming = apply_sequential_explore_matrix(incoming)
    has_preset_matrix = (
        isinstance(incoming.get("matrix"), list) and bool(incoming["matrix"])
    )
    plan_obj = ensure_plan_matrix(incoming, synthesize_if_empty=has_preset_matrix)
    if not has_preset_matrix:
        plan_obj["matrix"] = []
    plan_obj["_single_case"] = single_case
    plan_obj.setdefault("goal", goal or "完成用户要求的界面操作")
    plan_obj.setdefault("start_path", start_path or "/")
    explore_goal = str(plan_obj.get("goal") or "")
    if explore_ctx and not skip_login:
        plan_obj["goal"] = explore_task_text(
            goal=explore_goal, ctx=explore_ctx, engine="midscene"
        )
    mid_cfg = midscene_model_config
    if mid_cfg is None:
        try:
            from app.deps import SessionLocal
            from app.services.ai.effective_ai_settings import get_midscene_runtime

            db = SessionLocal()
            try:
                mid_cfg = get_midscene_runtime(db).as_model_config()
            finally:
                db.close()
        except Exception:  # noqa: BLE001
            mid_cfg = None
    bound_cases = bool(incoming.get("_bound_functional_cases")) or has_preset_matrix
    sequential = bool(incoming.get("_sequential_matrix"))
    if on_log is not None:
        if single_case:
            mode = "单脚本"
        elif sequential and has_preset_matrix:
            n = len(plan_obj.get("matrix") or [])
            mode = f"按检查点矩阵顺序探索（{n} 条）"
        elif bound_cases:
            mode = "按功能用例生成"
        else:
            mode = "探索后按测试设计扩展"
        on_log(
            f"开始 LangGraph + Playwright CLI 探索（{mode}）"
            + (
                "；复杂控件可用 Midscene（含验证码读图）…"
                if mid_cfg
                else "；未配置 Midscene，视觉步将跳过…"
            )
        )
    recon_session = None
    recon_trace: list[dict[str, Any]] = []
    run_recon = (
        bool(settings.ui_recon_enabled)
        and not single_case
        and (sequential or has_preset_matrix or bool(plan_obj.get("_recon_force")))
    )
    if run_recon:
        if on_log is not None:
            on_log("站点测绘：只读导航 BFS（同域链接）…")
        try:
            recon_trace, recon_session = run_recon_explore(
                base_url=base_url,
                start_path=str(plan_obj.get("start_path") or start_path or "/"),
                headed=headed,
                timeout_ms=timeout_ms,
                should_cancel=should_cancel,
                on_log=on_log,
                storage_state=storage_state,
                extra_http_headers=extra_http_headers,
                local_storage=local_storage,
            )
            plan_obj["recon_trace"] = recon_trace
            plan_obj["page_knowledge"] = build_page_knowledge(recon_trace)
            matrix_in = plan_obj.get("matrix") if isinstance(plan_obj.get("matrix"), list) else []
            warns = validate_matrix_against_knowledge(matrix_in, plan_obj["page_knowledge"])
            if warns:
                plan_obj["_recon_warnings"] = warns
                if on_log is not None:
                    on_log("测绘校验：" + "；".join(warns[:3]))
        except Exception as ex:  # noqa: BLE001
            log.warning("recon explore failed: %s", ex)
            if on_log is not None:
                on_log(f"站点测绘失败，跳过测绘继续探索：{ex}")
    elif not single_case and (sequential or has_preset_matrix):
        plan_obj["page_knowledge"] = build_page_knowledge([])
        if on_log is not None:
            on_log("结构化页面知识：探索中增量记录（未启用 BFS 测绘）")
    try:
        trace = run_cli_explore_loop(
            base_url=base_url,
            plan=plan_obj,
            ctx=explore_ctx,
            llm_cfg=llm,
            headed=headed,
            max_steps=max_steps,
            timeout_ms=timeout_ms,
            should_cancel=should_cancel,
            on_step=on_step,
            on_log=on_log,
            on_need_human=on_need_human,
            on_screenshot=on_screenshot,
            session=recon_session,
            midscene_model_config=mid_cfg,
            agent_driver="midscene",
            storage_state=storage_state,
            extra_http_headers=extra_http_headers,
            local_storage=local_storage,
        )
    finally:
        if recon_session is not None:
            try:
                recon_session.close()
            except Exception:  # noqa: BLE001
                log.debug("recon session close failed", exc_info=True)
    if isinstance(plan_obj.get("page_knowledge"), dict):
        plan_obj["page_knowledge"] = merge_trace_into_knowledge(plan_obj["page_knowledge"], trace)
    matrix_post = plan_obj.get("matrix") if isinstance(plan_obj.get("matrix"), list) else []
    if matrix_post and isinstance(plan_obj.get("page_knowledge"), dict):
        post_warns = validate_matrix_against_knowledge(matrix_post, plan_obj["page_knowledge"])
        if post_warns:
            plan_obj["_recon_warnings"] = post_warns
            if on_log is not None:
                on_log("页面知识校验：" + "；".join(post_warns[:3]))
    finish_reason = str(plan_obj.get("_explore_finish_reason") or "")
    if isinstance(plan, dict):
        if finish_reason:
            plan["_explore_finish_reason"] = finish_reason

    raw_matrix = plan_obj.get("matrix") if isinstance(plan_obj.get("matrix"), list) else []
    if single_case:
        case_name = str(plan_obj.get("case_name") or goal or "UI 用例").strip() or "UI 用例"
        start = start_path or str(plan_obj.get("start_path") or "/")
        expected = str(plan_obj.get("expected") or (plan or {}).get("expected") or "")
        raw_row = {
            "id": "TC-001",
            "name": case_name,
            "start_url": start,
            "data": str(plan_obj.get("test_data") or (plan or {}).get("test_data") or ""),
            "expected": expected,
            "steps": _skeleton_steps_for_row(start=start, expected=expected),
            "ready": bool(trace),
        }
        matrix = bind_trace_to_matrix([raw_row], trace) if trace else [raw_row]
        case_scripts = matrix_to_case_scripts(
            matrix,
            ctx=explore_ctx,
            username=username,
            password=password,
            start_path=start_path or "/",
        )
    elif not bound_cases:
        if sequential and isinstance(plan_obj.get("matrix"), list) and plan_obj["matrix"]:
            if on_log is not None:
                on_log("探索完成，正在按矩阵用例绑定轨迹…")
            matrix = hydrate_matrix_from_trace(plan_obj["matrix"], trace)
            if trace and not any(isinstance(r, dict) and r.get("ready") for r in matrix):
                matrix = bind_trace_to_matrix(plan_obj["matrix"], trace)
            case_scripts = matrix_to_case_scripts(
                matrix,
                ctx=explore_ctx,
                username=username,
                password=password,
                start_path=start_path or "/",
            )
            if on_log is not None:
                ready_count = sum(
                    1 for item in case_scripts if item.get("ready") and item.get("code")
                )
                on_log(f"矩阵绑定完成：{len(matrix)} 条用例，可执行脚本 {ready_count} 条")
        elif plan_obj.get("_sequential_matrix"):
            if on_log is not None:
                on_log("顺序矩阵未绑定到轨迹，跳过事后 LLM 切 case")
            matrix = plan_obj.get("matrix") if isinstance(plan_obj.get("matrix"), list) else []
            case_scripts = matrix_to_case_scripts(
                matrix,
                ctx=explore_ctx,
                username=username,
                password=password,
                start_path=start_path or "/",
            )
        else:
            if on_log is not None:
                on_log("探索完成，正在按测试设计扩展多条用例脚本…")
            checklist = plan_obj.get("checklist") if isinstance(plan_obj.get("checklist"), list) else []
            user_prompt = str((plan or {}).get("user_prompt") or explore_goal or goal or "")
            explore_goal_text = explore_goal or goal or ""
            required_actions = test_design_actions(
                prompt=user_prompt,
                goal=explore_goal_text,
                checklist=[str(x) for x in checklist],
            )
            matrix = []
            if isinstance(llm, LlmRuntime):
                try:
                    matrix = design_cases(
                        prompt=user_prompt,
                        goal=explore_goal_text,
                        trace=trace,
                        llm=llm,
                        start_path=start_path or str(plan_obj.get("start_path") or "/"),
                        checklist=[str(x) for x in checklist],
                        case_name=str(plan_obj.get("case_name") or "") or None,
                    )
                except Exception as ex:  # noqa: BLE001
                    log.warning("CaseDesigner failed, using legacy design: %s", ex)
            if matrix:
                matrix = filter_modal_fragment_matrix(matrix)
            if matrix and required_actions and matrix_missing_crud_actions(matrix, required_actions):
                log.info(
                    "CaseDesigner missing CRUD actions %s; falling back to expand_cases_from_test_design",
                    matrix_missing_crud_actions(matrix, required_actions),
                )
                matrix = []
            if not matrix:
                matrix = expand_cases_from_test_design(
                    prompt=user_prompt,
                    goal=explore_goal_text,
                    trace=trace,
                    llm=llm if isinstance(llm, LlmRuntime) else None,
                    start_path=start_path or str(plan_obj.get("start_path") or "/"),
                    checklist=[str(x) for x in checklist],
                    case_name=str(plan_obj.get("case_name") or "") or None,
                )
                if matrix:
                    matrix = filter_modal_fragment_matrix(matrix)
            case_scripts = matrix_to_case_scripts(
                matrix,
                ctx=explore_ctx,
                username=username,
                password=password,
                start_path=start_path or "/",
            )
            if on_log is not None:
                ready_count = sum(
                    1 for item in case_scripts if item.get("ready") and item.get("code")
                )
                on_log(
                    "测试设计扩展完成："
                    f"识别字段 {count_test_design_fields(trace)} 个，"
                    f"生成用例 {len(matrix)} 条，可执行脚本 {ready_count} 条"
                )
    else:
        matrix = hydrate_matrix_from_trace(raw_matrix, trace)
        # Fallback to step-wise bind when hydrate left nothing ready but trace exists
        if trace and not any(isinstance(r, dict) and r.get("ready") for r in matrix):
            matrix = bind_trace_to_matrix(raw_matrix, trace)
        case_scripts = matrix_to_case_scripts(
            matrix,
            ctx=explore_ctx,
            username=username,
            password=password,
            start_path=start_path or "/",
        )
    if not isinstance(llm, LlmRuntime) and on_log is not None:
        on_log("未配置 LLM，无法由 CaseCoder 生成脚本")
    if isinstance(llm, LlmRuntime):
        try:
            # Headless trial/repair only when UI_CODEGEN_VERIFY=true; default is user session trial.
            case_scripts, generated_auth_path = run_codegen_pipeline(
                matrix=matrix,
                trace=trace,
                llm=llm,
                base_url=base_url,
                ctx=explore_ctx,
                browser_name="chromium",
                timeout_ms=timeout_ms,
                storage_state_path=storage_state if isinstance(storage_state, str) else None,
                extra_http_headers=extra_http_headers,
                local_storage=local_storage,
                verify=bool(settings.ui_codegen_verify),
                max_repair=int(settings.ui_codegen_max_repair),
                on_log=on_log,
                should_cancel=should_cancel,
            )
            if generated_auth_path and isinstance(plan, dict):
                plan["_trial_auth"] = {"path": generated_auth_path, "from_case": "codegen"}
        except Exception as ex:  # noqa: BLE001
            log.exception("UI codegen pipeline failed: %s", ex)
            if on_log is not None:
                on_log(f"CaseCoder 流水线失败，未交付脚本：{ex}")
    if on_log is not None and not settings.ui_codegen_verify:
        on_log("脚本已生成；可在左侧勾选批量试跑，或点「查看脚本」单条试跑（探索任务不自动试跑）")
    plan_obj["matrix"] = matrix
    plan_obj["case_scripts"] = case_scripts
    if isinstance(plan, dict):
        plan["matrix"] = matrix
        plan["case_scripts"] = case_scripts
        plan["_single_case"] = single_case
        plan["_bound_functional_cases"] = bound_cases
        plan["_explore_finish_reason"] = finish_reason or plan.get("_explore_finish_reason") or ""
        if plan_obj.get("page_knowledge"):
            plan["page_knowledge"] = plan_obj["page_knowledge"]
        if plan_obj.get("recon_trace"):
            plan["recon_trace"] = plan_obj["recon_trace"]
        if plan_obj.get("_recon_warnings"):
            plan["_recon_warnings"] = plan_obj["_recon_warnings"]

    ready_codes = [c.get("code") or "" for c in case_scripts if c.get("ready") and (c.get("code") or "").strip()]
    script = ready_codes[0] if ready_codes else ""
    if not (script or "").strip() and on_log is not None:
        on_log("探索未产出可执行 LLM 脚本（需配置 LLM 且 CaseCoder/guard 通过）")
    raw_actions: list[dict[str, Any]] = []
    for item in trace:
        if not isinstance(item, dict) or item.get("status") == "error":
            continue
        kind = str(item.get("kind") or item.get("action") or "").strip()
        if kind in ("", "done"):
            continue
        row = {
            **item,
            "kind": kind if kind != "fill_captcha" else "fill_captcha",
        }
        raw_actions.append(row)
    annotated = _trace_from_actions(raw_actions, ctx=explore_ctx)
    if on_log is not None:
        n_ready = sum(1 for c in case_scripts if c.get("ready") and c.get("code"))
        mid_dup = "；已拦截重复 midscene 空转" if finish_reason == REPEATED_MIDSCENE_NOOP else ""
        split_hint = ""
        if single_case:
            split_hint = "（单脚本）"
        elif bound_cases:
            split_hint = "（按功能用例）"
        elif n_ready:
            split_hint = "（测试设计扩展）"
        on_log(
            f"Playwright CLI 探索完成，{len(annotated)} 步；"
            f"已生成 {n_ready}/{len(case_scripts) or n_ready} 条用例脚本"
            f"{split_hint}"
            f"{mid_dup}"
        )
    return annotated, script


def run_midscene_engine(
    *,
    base_url: str,
    start_path: str,
    goal: str,
    username: str = "",
    password: str = "",
    midscene: MidsceneRuntime,
    browser: str,
    headed: bool,
    viewport: dict[str, int] | None,
    timeout_ms: int,
    on_log: Callable[[str], None] | None = None,
    should_cancel: Callable[[], bool] | None = None,
    on_need_human: Callable[[str], str | None] | None = None,
    on_screenshot: Callable[[bytes, dict[str, Any]], str | None] | None = None,
    llm: LlmRuntime | None = None,
    max_steps: int = 25,
    plan: dict[str, Any] | None = None,
    ctx: dict[str, str] | None = None,
    prefer_cli: bool = True,
    storage_state: dict[str, Any] | str | None = None,
    extra_http_headers: dict[str, str] | None = None,
    local_storage: dict[str, str] | None = None,
    skip_login: bool = False,
) -> tuple[list[dict[str, Any]], str]:
    """Prefer playwright-cli explore; legacy whole-task aiAct only when prefer_cli=False."""
    del browser, viewport
    explore_ctx = merge_explore_ctx(ctx, username=username, password=password)
    if prefer_cli and llm is not None:
        return run_playwright_cli_engine(
            base_url=base_url,
            start_path=start_path,
            goal=goal,
            username=username,
            password=password,
            llm=llm,
            headed=headed,
            timeout_ms=timeout_ms,
            max_steps=max_steps,
            plan=plan,
            ctx=explore_ctx,
            on_log=on_log,
            should_cancel=should_cancel,
            on_need_human=on_need_human,
            on_screenshot=on_screenshot,
            midscene_model_config=midscene.as_model_config(),
            storage_state=storage_state,
            extra_http_headers=extra_http_headers,
            local_storage=local_storage,
            skip_login=skip_login,
        )
    task = explore_task_text(goal=goal, ctx=explore_ctx)
    if on_log is not None:
        on_log("使用旧版 Midscene aiAct 整段探索…")
    actions = explore_with_midscene(
        base_url=base_url,
        start_path=start_path,
        task=task,
        model_config=midscene.as_model_config(),
        browser="chromium",
        headed=headed,
        viewport=None,
        timeout_ms=timeout_ms,
        on_log=on_log,
        should_cancel=should_cancel,
        on_need_human=on_need_human,
    )
    script = actions_to_node_script(
        actions,
        ctx=explore_ctx,
        username=username,
        password=password,
        start_path=start_path or "/",
        # Append submit only when actions already recorded a click locate (no 「提交」 hardcode).
        ensure_submit=True,
    )
    if "agent.ai" not in script and ".click(" not in script and ".fill(" not in script:
        # Still avoid silent empty script, but prefer empty goto over aiAct when possible
        script = (
            "async function run(page, agent) {\n"
            f"  await page.goto({json_task(start_path or '/')});\n"
            "}\n"
        )
        actions = [{"kind": "goto", "path": start_path or "/"}]
    return _trace_from_actions(actions, ctx=explore_ctx), script


def json_task(text: str) -> str:
    import json

    return json.dumps(text, ensure_ascii=False)
