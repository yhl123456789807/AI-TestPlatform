"""Schemas for conversational UI scenario agent sessions."""

from __future__ import annotations

from datetime import datetime
from typing import Any, Literal

from pydantic import BaseModel, Field, field_validator, model_validator

from app.schemas.ui_automation.ui_automation import BrowserName


class UiScenarioAgentSessionCreate(BaseModel):
    prompt: str = Field(default="", max_length=8000)
    # Preferred: multi-select functional cases. testcase_id kept for compat (merged into ids).
    testcase_ids: list[int] = Field(default_factory=list)
    testcase_id: int | None = None
    env_id: int | None = None
    browser: str | None = Field(default=None, max_length=32)
    headed: bool = True
    max_steps: int = Field(default=25, ge=1, le=50)
    engine: Literal["midscene", "playwright"] = "midscene"
    # None = follow env inject; none = skip inject (login cases)
    auth_mode: Literal["none", "account", "token"] | None = None
    account_name: str | None = Field(default=None, max_length=128)
    execution_mode: Literal["explore_codegen", "agent_once"] = "explore_codegen"

    @field_validator("testcase_ids", mode="before")
    @classmethod
    def _coerce_ids(cls, v: Any) -> list[int]:
        if v is None:
            return []
        if isinstance(v, list):
            out: list[int] = []
            for x in v:
                try:
                    out.append(int(x))
                except (TypeError, ValueError):
                    continue
            return out
        return []

    @model_validator(mode="after")
    def _merge_testcase_id(self) -> UiScenarioAgentSessionCreate:
        ids = list(self.testcase_ids or [])
        if self.testcase_id is not None and self.testcase_id not in ids:
            ids.insert(0, int(self.testcase_id))
        # Dedupe preserving order
        seen: set[int] = set()
        merged: list[int] = []
        for i in ids:
            if i not in seen:
                seen.add(i)
                merged.append(i)
        self.testcase_ids = merged
        if merged and self.testcase_id is None:
            self.testcase_id = merged[0]
        elif not merged:
            self.testcase_id = None
        return self


class UiScenarioAgentMessage(BaseModel):
    content: str = Field(min_length=1, max_length=4000)
    # When set, revise that case_scripts row; otherwise first ready / playwright_code.
    case_id: str = Field(default="", max_length=64)
    # Optional retune fields when re-exploring from error (manual stop / failed explore).
    env_id: int | None = None
    browser: str | None = Field(default=None, max_length=32)
    headed: bool | None = None
    auth_mode: Literal["none", "account", "token"] | None = None
    account_name: str | None = Field(default=None, max_length=128)
    testcase_ids: list[int] | None = None
    testcase_id: int | None = None

    @field_validator("testcase_ids", mode="before")
    @classmethod
    def _coerce_ids(cls, v: Any) -> list[int] | None:
        if v is None:
            return None
        if isinstance(v, list):
            out: list[int] = []
            for x in v:
                try:
                    out.append(int(x))
                except (TypeError, ValueError):
                    continue
            return out
        return None


class UiScenarioAgentCaseOverride(BaseModel):
    id: str = Field(..., max_length=64)
    code: str = Field(..., max_length=200000)


class UiScenarioAgentConfirm(BaseModel):
    action: Literal["confirm", "cancel"]
    name: str | None = Field(default=None, max_length=512)
    script: str | None = Field(default=None, max_length=200000)
    status: Literal["draft", "ready"] = "ready"
    case_ids: list[str] | None = None
    case_overrides: list[UiScenarioAgentCaseOverride] | None = None
    create_suite: bool = True
    suite_name: str | None = Field(default=None, max_length=512)
    suite_description: str | None = Field(default=None, max_length=65535)
    suite_env_id: int | None = None
    suite_browsers: list[BrowserName] | None = None
    suite_stop_on_fail: bool | None = None

    @model_validator(mode="after")
    def _reject_empty_case_ids(self) -> UiScenarioAgentConfirm:
        if self.action == "confirm" and self.case_ids is not None and len(self.case_ids) == 0:
            raise ValueError("case_ids 不能为空")
        return self


class UiScenarioAgentTrialRun(BaseModel):
    case_id: str = Field(default="", max_length=64)
    headed: bool = True
    script: str | None = Field(default=None, max_length=200000)


class UiScenarioAgentTrialRepair(BaseModel):
    case_id: str = Field(default="", max_length=64)


class UiScenarioAgentTrialRepairApply(BaseModel):
    script: str = Field(..., max_length=200000)


class UiScenarioAgentSessionSummary(BaseModel):
    id: int
    title: str
    status: str
    updated_at: datetime
    message_count: int


class UiScenarioAgentSessionOut(BaseModel):
    id: int
    project_id: int
    user_id: int
    thread_id: str
    status: str
    prompt: str
    testcase_id: int | None = None
    testcase_ids: list[int] = Field(default_factory=list)
    env_id: int | None = None
    browser: str = "chromium"
    headed: bool = True
    messages: list[dict[str, str]] = Field(default_factory=list)
    plan: dict[str, Any] | None = None
    matrix: list[dict[str, Any]] = Field(default_factory=list)
    explore_report: dict[str, Any] | None = None
    trace: list[dict[str, Any]] = Field(default_factory=list)
    result_steps: list[dict[str, Any]] = Field(default_factory=list)
    playwright_code: str = ""
    has_credentials: bool = False
    events: list[dict[str, Any]] = Field(default_factory=list)
    dry_run_status: str | None = None
    dry_run_error: str = ""
    error_message: str = ""
    saved_ui_case_id: int | None = None
    saved_ui_suite_id: int | None = None
    run_id: int | None = None
    case_run_id: int | None = None
    execution_mode: str = "explore_codegen"
    auth_mode: str | None = None
    account_name: str | None = None
    created_at: datetime
    updated_at: datetime
