"""ui scenario agent saved suite id

Revision ID: v1w2x3y4z5a6
Revises: u0v1w2x3y4z5
Create Date: 2026-11-11

"""

from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

revision: str = "v1w2x3y4z5a6"
down_revision: Union[str, Sequence[str], None] = "u0v1w2x3y4z5"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    bind = op.get_bind()
    insp = sa.inspect(bind)
    if "ui_scenario_agent_sessions" not in set(insp.get_table_names()):
        return
    cols = {c["name"] for c in insp.get_columns("ui_scenario_agent_sessions")}
    if "saved_ui_suite_id" in cols:
        return
    op.add_column(
        "ui_scenario_agent_sessions",
        sa.Column("saved_ui_suite_id", sa.Integer(), nullable=True),
    )
    op.create_foreign_key(
        "fk_ui_scenario_agent_sessions_saved_ui_suite_id",
        "ui_scenario_agent_sessions",
        "ui_suites",
        ["saved_ui_suite_id"],
        ["id"],
        ondelete="SET NULL",
    )


def downgrade() -> None:
    bind = op.get_bind()
    insp = sa.inspect(bind)
    if "ui_scenario_agent_sessions" not in set(insp.get_table_names()):
        return
    cols = {c["name"] for c in insp.get_columns("ui_scenario_agent_sessions")}
    if "saved_ui_suite_id" not in cols:
        return
    op.drop_constraint(
        "fk_ui_scenario_agent_sessions_saved_ui_suite_id",
        "ui_scenario_agent_sessions",
        type_="foreignkey",
    )
    op.drop_column("ui_scenario_agent_sessions", "saved_ui_suite_id")
