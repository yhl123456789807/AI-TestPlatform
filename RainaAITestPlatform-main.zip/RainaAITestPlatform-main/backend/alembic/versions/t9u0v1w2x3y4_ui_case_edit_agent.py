"""ui case edit agent sessions

Revision ID: t9u0v1w2x3y4
Revises: s7t8u9v0w1x2
Create Date: 2026-11-06

"""

from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

revision: str = "t9u0v1w2x3y4"
down_revision: Union[str, Sequence[str], None] = "s7t8u9v0w1x2"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def _tables() -> set[str]:
    bind = op.get_bind()
    insp = sa.inspect(bind)
    return set(insp.get_table_names())


def upgrade() -> None:
    if "ui_case_edit_agent_sessions" in _tables():
        return
    op.create_table(
        "ui_case_edit_agent_sessions",
        sa.Column("id", sa.Integer(), autoincrement=True, nullable=False),
        sa.Column("project_id", sa.Integer(), nullable=False),
        sa.Column("user_id", sa.Integer(), nullable=False),
        sa.Column("thread_id", sa.String(length=64), nullable=False),
        sa.Column("status", sa.String(length=32), nullable=False, server_default="running"),
        sa.Column("prompt", sa.Text(), nullable=False),
        sa.Column("case_ids_json", sa.JSON(), nullable=True),
        sa.Column("base_snapshots_json", sa.JSON(), nullable=True),
        sa.Column("messages_json", sa.JSON(), nullable=True),
        sa.Column("plan_json", sa.JSON(), nullable=True),
        sa.Column("events_json", sa.JSON(), nullable=True),
        sa.Column("applied_case_ids_json", sa.JSON(), nullable=True),
        sa.Column("error_message", sa.Text(), nullable=False),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("CURRENT_TIMESTAMP"),
            nullable=False,
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("CURRENT_TIMESTAMP"),
            nullable=False,
        ),
        sa.ForeignKeyConstraint(["project_id"], ["projects.id"], ondelete="CASCADE"),
        sa.ForeignKeyConstraint(["user_id"], ["users.id"], ondelete="CASCADE"),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index(
        "ix_ui_case_edit_agent_sessions_project_id",
        "ui_case_edit_agent_sessions",
        ["project_id"],
    )
    op.create_index(
        "ix_ui_case_edit_agent_sessions_thread_id",
        "ui_case_edit_agent_sessions",
        ["thread_id"],
        unique=True,
    )


def downgrade() -> None:
    if "ui_case_edit_agent_sessions" not in _tables():
        return
    op.drop_index(
        "ix_ui_case_edit_agent_sessions_thread_id",
        table_name="ui_case_edit_agent_sessions",
    )
    op.drop_index(
        "ix_ui_case_edit_agent_sessions_project_id",
        table_name="ui_case_edit_agent_sessions",
    )
    op.drop_table("ui_case_edit_agent_sessions")
