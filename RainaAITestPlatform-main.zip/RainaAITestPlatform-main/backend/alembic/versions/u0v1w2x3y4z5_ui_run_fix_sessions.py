"""ui run fix sessions

Revision ID: u0v1w2x3y4z5
Revises: t9u0v1w2x3y4
Create Date: 2026-11-08

"""

from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

revision: str = "u0v1w2x3y4z5"
down_revision: Union[str, Sequence[str], None] = "t9u0v1w2x3y4"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def _tables() -> set[str]:
    bind = op.get_bind()
    insp = sa.inspect(bind)
    return set(insp.get_table_names())


def upgrade() -> None:
    if "ui_run_fix_sessions" in _tables():
        return
    op.create_table(
        "ui_run_fix_sessions",
        sa.Column("id", sa.String(length=64), nullable=False),
        sa.Column("project_id", sa.Integer(), nullable=False),
        sa.Column("run_id", sa.Integer(), nullable=False),
        sa.Column("case_id", sa.Integer(), nullable=True),
        sa.Column("status", sa.String(length=32), nullable=False, server_default="analyzing"),
        sa.Column("plan_json", sa.JSON(), nullable=True),
        sa.Column("triage_json", sa.JSON(), nullable=True),
        sa.Column("current_script", sa.Text(), nullable=False),
        sa.Column("error_message", sa.Text(), nullable=False),
        sa.Column("patch_message", sa.Text(), nullable=False),
        sa.Column("rerun_id", sa.Integer(), nullable=True),
        sa.Column("explore_session_id", sa.Integer(), nullable=True),
        sa.Column("failure_screenshot_key", sa.String(length=1024), nullable=True),
        sa.Column("failure_step_id", sa.Integer(), nullable=True),
        sa.Column("created_by", sa.Integer(), nullable=True),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("CURRENT_TIMESTAMP"),
            nullable=False,
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("CURRENT_TIMESTAMP"),
            nullable=False,
        ),
        sa.ForeignKeyConstraint(["created_by"], ["users.id"], ondelete="SET NULL"),
        sa.ForeignKeyConstraint(["project_id"], ["projects.id"], ondelete="CASCADE"),
        sa.ForeignKeyConstraint(["run_id"], ["ui_runs.id"], ondelete="CASCADE"),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index("ix_ui_run_fix_sessions_project_id", "ui_run_fix_sessions", ["project_id"])
    op.create_index("ix_ui_run_fix_sessions_run_id", "ui_run_fix_sessions", ["run_id"])
    op.create_index("ix_ui_run_fix_sessions_status", "ui_run_fix_sessions", ["status"])


def downgrade() -> None:
    if "ui_run_fix_sessions" not in _tables():
        return
    op.drop_index("ix_ui_run_fix_sessions_status", table_name="ui_run_fix_sessions")
    op.drop_index("ix_ui_run_fix_sessions_run_id", table_name="ui_run_fix_sessions")
    op.drop_index("ix_ui_run_fix_sessions_project_id", table_name="ui_run_fix_sessions")
    op.drop_table("ui_run_fix_sessions")
