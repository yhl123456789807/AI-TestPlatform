"""Batch delete for api-cases / api-definitions / test-cases."""

from fastapi.testclient import TestClient

from app.main import app
from app.models.identity.user import User
from app.services.identity import auth_service
from tests.conftest import TestingSessionLocal


def _user(username: str, pw: str):
    db = TestingSessionLocal()
    try:
        db.add(User(username=username, password_hash=auth_service.hash_password(pw), is_active=True))
        db.commit()
    finally:
        db.close()


def _login(username: str, pw: str) -> str:
    r = TestClient(app).post("/api/v1/auth/login", json={"username": username, "password": pw})
    assert r.status_code == 200
    return r.json()["access_token"]


def _project(token: str, name: str) -> int:
    r = TestClient(app).post(
        "/api/v1/projects/",
        headers={"Authorization": f"Bearer {token}"},
        json={"name": name},
    )
    assert r.status_code == 201
    return r.json()["id"]


def test_api_cases_batch_delete():
    _user("bd_api_case", "p")
    tok = _login("bd_api_case", "p")
    pid = _project(tok, "BdApiCase")
    client = TestClient(app)
    h = {"Authorization": f"Bearer {tok}"}

    ids = []
    for i in range(3):
        r = client.post(
            f"/api/v1/projects/{pid}/api-cases/",
            headers=h,
            json={"name": f"c{i}", "method": "GET", "path": f"/x{i}"},
        )
        assert r.status_code == 201, r.text
        ids.append(r.json()["id"])

    empty = client.post(
        f"/api/v1/projects/{pid}/api-cases/batch-delete",
        headers=h,
        json={"ids": []},
    )
    assert empty.status_code == 422

    res = client.post(
        f"/api/v1/projects/{pid}/api-cases/batch-delete",
        headers=h,
        json={"ids": ids[:2] + [ids[0], 999999]},
    )
    assert res.status_code == 200, res.text
    assert res.json()["deleted"] == 2

    listed = client.get(f"/api/v1/projects/{pid}/api-cases/?page=1&page_size=50", headers=h)
    assert listed.status_code == 200
    assert listed.json()["total"] == 1
    assert listed.json()["items"][0]["id"] == ids[2]


def test_api_definitions_batch_delete():
    _user("bd_api_def", "p")
    tok = _login("bd_api_def", "p")
    pid = _project(tok, "BdApiDef")
    client = TestClient(app)
    h = {"Authorization": f"Bearer {tok}"}

    ids = []
    for i in range(2):
        r = client.post(
            f"/api/v1/projects/{pid}/api-definitions/",
            headers=h,
            json={"name": f"d{i}", "method": "GET", "path": f"/d{i}", "status": "active"},
        )
        assert r.status_code == 201, r.text
        ids.append(r.json()["id"])

    # bind a case to first definition — delete should SET NULL api_id
    cr = client.post(
        f"/api/v1/projects/{pid}/api-definitions/{ids[0]}/create-case",
        headers=h,
        json={},
    )
    assert cr.status_code == 201, cr.text
    case_id = cr.json()["case_id"]

    res = client.post(
        f"/api/v1/projects/{pid}/api-definitions/batch-delete",
        headers=h,
        json={"ids": ids},
    )
    assert res.status_code == 200, res.text
    assert res.json()["deleted"] == 2

    listed = client.get(f"/api/v1/projects/{pid}/api-definitions/?page=1&page_size=50", headers=h)
    assert listed.json()["total"] == 0

    # case row remains (api_id SET NULL on MySQL; SQLite tests may not enforce FK)
    case = client.get(f"/api/v1/projects/{pid}/api-cases/{case_id}", headers=h)
    assert case.status_code == 200


def test_test_cases_batch_delete():
    _user("bd_tc", "p")
    tok = _login("bd_tc", "p")
    pid = _project(tok, "BdTc")
    client = TestClient(app)
    h = {"Authorization": f"Bearer {tok}"}

    ids = []
    for i in range(3):
        r = client.post(
            f"/api/v1/projects/{pid}/test-cases/",
            headers=h,
            json={"title": f"t{i}", "overall_expected": "ok", "steps": []},
        )
        assert r.status_code == 201, r.text
        ids.append(r.json()["id"])

    res = client.post(
        f"/api/v1/projects/{pid}/test-cases/batch-delete",
        headers=h,
        json={"ids": ids[:2]},
    )
    assert res.status_code == 200, res.text
    assert res.json()["deleted"] == 2

    listed = client.get(f"/api/v1/projects/{pid}/test-cases/?page=1&page_size=50", headers=h)
    assert listed.json()["total"] == 1
    assert listed.json()["items"][0]["id"] == ids[2]


def test_ui_cases_batch_delete():
    _user("bd_ui_case", "p")
    tok = _login("bd_ui_case", "p")
    pid = _project(tok, "BdUiCase")
    client = TestClient(app)
    h = {"Authorization": f"Bearer {tok}"}

    ids = []
    for i in range(3):
        r = client.post(
            f"/api/v1/projects/{pid}/ui-cases/",
            headers=h,
            json={
                "name": f"ui{i}",
                "script": 'def run(page):\n    page.goto("/")\n',
                "status": "draft",
            },
        )
        assert r.status_code == 201, r.text
        ids.append(r.json()["id"])

    empty = client.post(
        f"/api/v1/projects/{pid}/ui-cases/batch-delete",
        headers=h,
        json={"ids": []},
    )
    assert empty.status_code == 422

    res = client.post(
        f"/api/v1/projects/{pid}/ui-cases/batch-delete",
        headers=h,
        json={"ids": ids[:2] + [ids[0], 999999]},
    )
    assert res.status_code == 200, res.text
    assert res.json()["deleted"] == 2

    listed = client.get(f"/api/v1/projects/{pid}/ui-cases/?page=1&page_size=50", headers=h)
    assert listed.status_code == 200
    assert listed.json()["total"] == 1
    assert listed.json()["items"][0]["id"] == ids[2]
