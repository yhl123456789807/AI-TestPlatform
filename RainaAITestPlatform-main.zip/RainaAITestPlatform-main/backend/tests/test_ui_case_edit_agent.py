from unittest.mock import patch

from fastapi.testclient import TestClient

from app.config import settings
from app.main import app
from app.models.identity.user import User
from app.services.identity import auth_service
from tests.conftest import TestingSessionLocal

_SCRIPT = """async function run(page, agent) {
  await page.goto('/login');
  await expect(page).not.toHaveURL(/\\/(login|signin)\\/?$/i);
}
"""

_FIXED = """async function run(page, agent) {
  await page.goto('/login');
  await page.getByRole('button', { name: '登录' }).click();
  await page.waitForURL((url) => !/\\/(login|signin)\\/?$/i.test(url.pathname), { timeout: 15000 });
  await expect(page).not.toHaveURL(/\\/(login|signin)\\/?$/i);
}
"""

_FIXED2 = """async function run(page, agent) {
  await page.goto('/login');
  await page.getByRole('button', { name: '登录' }).click();
  await page.waitForURL((url) => !/\\/(login|signin)\\/?$/i.test(url.pathname), { timeout: 15000 });
  await expect(page.getByText('首页')).toBeVisible();
}
"""


def _user(username: str, pw: str):
    db = TestingSessionLocal()
    try:
        db.add(User(username=username, password_hash=auth_service.hash_password(pw), is_active=True))
        db.commit()
    finally:
        db.close()


def _login(username: str, pw: str) -> str:
    r = TestClient(app).post("/api/v1/auth/login", json={"username": username, "password": pw})
    assert r.status_code == 200
    return r.json()["access_token"]


def _project(token: str, name: str) -> int:
    r = TestClient(app).post(
        "/api/v1/projects/",
        headers={"Authorization": f"Bearer {token}"},
        json={"name": name},
    )
    assert r.status_code == 201
    return r.json()["id"]


def _create_case(client: TestClient, h: dict, pid: int, name: str, script: str = _SCRIPT) -> int:
    r = client.post(
        f"/api/v1/projects/{pid}/ui-cases/",
        headers=h,
        json={"name": name, "script": script, "status": "ready"},
    )
    assert r.status_code == 201, r.text
    return r.json()["id"]


@patch("app.services.ui_automation.ui_case_edit_agent.revise_script_with_llm")
def test_ui_case_edit_agent_create_message_confirm(mock_revise, monkeypatch):
    monkeypatch.setattr(settings, "llm_api_key", "sk-test")
    _user("uiedit_ok", "p")
    tok = _login("uiedit_ok", "p")
    pid = _project(tok, "UiEditOk")
    client = TestClient(app)
    h = {"Authorization": f"Bearer {tok}"}

    c1 = _create_case(client, h, pid, "登录正向")
    c2 = _create_case(client, h, pid, "登录异常")
    mock_revise.side_effect = [_FIXED, _FIXED, _FIXED2, _FIXED]

    cr = client.post(
        f"/api/v1/projects/{pid}/ui-case-edit-agent/sessions",
        headers=h,
        json={"case_ids": [c1, c2], "prompt": "登录后增加 waitForURL"},
    )
    assert cr.status_code == 201, cr.text
    sess = cr.json()
    assert sess["status"] == "awaiting_confirm"
    assert sess["case_ids"] == [c1, c2]
    assert len(sess["plan"]["revisions"]) == 2
    assert "waitForURL" in (sess["plan"]["revisions"][0]["draft_script"] or "")
    assert mock_revise.call_count == 2

    before = client.get(f"/api/v1/projects/{pid}/ui-cases/{c1}", headers=h).json()
    assert "waitForURL" not in (before.get("script") or "")

    mr = client.post(
        f"/api/v1/projects/{pid}/ui-case-edit-agent/sessions/{sess['id']}/messages",
        headers=h,
        json={"content": "正向再断言首页可见"},
    )
    assert mr.status_code == 200, mr.text
    assert mr.json()["status"] == "awaiting_confirm"
    assert "首页" in (mr.json()["plan"]["revisions"][0]["draft_script"] or "")
    assert len(mr.json()["messages"]) >= 4

    conf = client.post(
        f"/api/v1/projects/{pid}/ui-case-edit-agent/sessions/{sess['id']}/confirm",
        headers=h,
        json={"action": "confirm", "case_ids": [c1]},
    )
    assert conf.status_code == 200, conf.text
    assert conf.json()["status"] == "confirmed"
    assert conf.json()["applied_case_ids"] == [c1]

    after1 = client.get(f"/api/v1/projects/{pid}/ui-cases/{c1}", headers=h).json()
    after2 = client.get(f"/api/v1/projects/{pid}/ui-cases/{c2}", headers=h).json()
    assert "首页" in (after1.get("script") or "")
    assert after2.get("script") == _SCRIPT or "首页" not in (after2.get("script") or "")


@patch("app.services.ui_automation.ui_case_edit_agent.revise_script_with_llm")
def test_ui_case_edit_agent_cancel(mock_revise, monkeypatch):
    monkeypatch.setattr(settings, "llm_api_key", "sk-test")
    _user("uiedit_cancel", "p")
    tok = _login("uiedit_cancel", "p")
    pid = _project(tok, "UiEditCancel")
    client = TestClient(app)
    h = {"Authorization": f"Bearer {tok}"}
    cid = _create_case(client, h, pid, "登录")
    mock_revise.return_value = _FIXED

    cr = client.post(
        f"/api/v1/projects/{pid}/ui-case-edit-agent/sessions",
        headers=h,
        json={"case_ids": [cid], "prompt": "加 waitForURL"},
    )
    assert cr.status_code == 201, cr.text
    sid = cr.json()["id"]
    conf = client.post(
        f"/api/v1/projects/{pid}/ui-case-edit-agent/sessions/{sid}/confirm",
        headers=h,
        json={"action": "cancel"},
    )
    assert conf.status_code == 200
    assert conf.json()["status"] == "cancelled"
    saved = client.get(f"/api/v1/projects/{pid}/ui-cases/{cid}", headers=h).json()
    assert "waitForURL" not in (saved.get("script") or "")


@patch("app.services.ui_automation.ui_case_edit_agent.revise_script_with_llm")
def test_ui_case_edit_agent_confirm_manual_draft(mock_revise, monkeypatch):
    monkeypatch.setattr(settings, "llm_api_key", "sk-test")
    _user("uiedit_manual", "p")
    tok = _login("uiedit_manual", "p")
    pid = _project(tok, "UiEditManual")
    client = TestClient(app)
    h = {"Authorization": f"Bearer {tok}"}
    cid = _create_case(client, h, pid, "登录")
    mock_revise.return_value = _FIXED
    manual = """async function run(page, agent) {
  await page.goto('/login');
  await page.getByRole('button', { name: '登录' }).click();
  await expect(page.getByText('手改断言')).toBeVisible();
}
"""

    cr = client.post(
        f"/api/v1/projects/{pid}/ui-case-edit-agent/sessions",
        headers=h,
        json={"case_ids": [cid], "prompt": "加 waitForURL"},
    )
    assert cr.status_code == 201, cr.text
    sid = cr.json()["id"]
    conf = client.post(
        f"/api/v1/projects/{pid}/ui-case-edit-agent/sessions/{sid}/confirm",
        headers=h,
        json={
            "action": "confirm",
            "case_ids": [cid],
            "drafts": [{"case_id": cid, "draft_script": manual}],
        },
    )
    assert conf.status_code == 200, conf.text
    assert conf.json()["status"] == "confirmed"
    saved = client.get(f"/api/v1/projects/{pid}/ui-cases/{cid}", headers=h).json()
    assert "手改断言" in (saved.get("script") or "")
    assert "waitForURL" not in (saved.get("script") or "")


@patch("app.services.ui_automation.ui_case_edit_agent.revise_script_with_llm")
def test_ui_case_edit_agent_skips_failed_case(mock_revise, monkeypatch):
    monkeypatch.setattr(settings, "llm_api_key", "sk-test")
    _user("uiedit_skip", "p")
    tok = _login("uiedit_skip", "p")
    pid = _project(tok, "UiEditSkip")
    client = TestClient(app)
    h = {"Authorization": f"Bearer {tok}"}
    c1 = _create_case(client, h, pid, "好")
    c2 = _create_case(client, h, pid, "坏")
    mock_revise.side_effect = [_FIXED, ValueError("boom")]

    cr = client.post(
        f"/api/v1/projects/{pid}/ui-case-edit-agent/sessions",
        headers=h,
        json={"case_ids": [c1, c2], "prompt": "改脚本"},
    )
    assert cr.status_code == 201, cr.text
    revs = cr.json()["plan"]["revisions"]
    assert revs[0]["skipped"] is False
    assert revs[1]["skipped"] is True
    assert cr.json()["status"] == "awaiting_confirm"
