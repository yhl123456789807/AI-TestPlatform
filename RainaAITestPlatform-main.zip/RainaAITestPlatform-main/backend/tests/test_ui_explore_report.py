import json

from app.services.ui_automation.ui_explore_report import (
    annotate_steps,
    apply_sequential_explore_matrix,
    bind_trace_to_matrix,
    build_explore_report,
    count_test_design_fields,
    derive_matrix_from_explore,
    ensure_plan_matrix,
    case_name_is_modal_fragment,
    expand_cases_from_test_design,
    filter_modal_fragment_matrix,
    infer_business_action,
    matrix_from_sequential_checklist,
    matrix_missing_crud_actions,
    hydrate_matrix_from_trace,
    infer_driver,
    matrix_bind_issues,
    matrix_rows_from_testcases,
    normalize_matrix,
    skeletonize_plan_matrix,
)
from app.services.ui_automation.ui_node_script import (
    matrix_to_case_scripts,
    matrix_to_node_script,
    script_has_assert,
)


def _assert_llm_codegen_pending(case: dict) -> None:
    assert case.get("code") == ""
    assert case.get("ready") is False
    assert case.get("codegen_pending") is True


def test_normalize_matrix_from_llm_rows():
    rows = normalize_matrix(
        [
            {
                "id": "AL-001",
                "name": "列表加载",
                "preconditions": "已登录",
                "steps": ["打开列表", "检查表头"],
                "expected": "表格可见",
            },
            {"name": "搜索", "操作": "输入名称点查询", "预期": "结果含关键字"},
        ],
        goal="公寓列表",
        start_path="/apartment/list",
    )
    assert rows[0]["id"] == "AL-001"
    assert isinstance(rows[0]["steps"][0], dict)
    assert rows[0]["steps"][0]["action"] == "goto"
    assert any(s.get("action", "").startswith("assert") for s in rows[0]["steps"])
    assert rows[1]["id"] == "UC-002"
    assert any("查询" in str(s.get("target") or "") for s in rows[1]["steps"])


def test_normalize_matrix_structured_steps():
    rows = normalize_matrix(
        [
            {
                "id": "L-001",
                "name": "登录成功",
                "steps": [
                    {"action": "goto", "target": "/login", "value": "/login"},
                    {"action": "fill", "target": "账号", "value": "{{username}}"},
                    {"action": "fill", "target": "密码", "value": "{{password}}"},
                    {
                        "action": "fill",
                        "target": "验证码图片",
                        "value": "{{captcha}}",
                        "driver": "midscene",
                    },
                    {"action": "click", "target": "登录"},
                    {"action": "assert_url", "value": "/"},
                ],
            }
        ],
        start_path="/login",
    )
    assert rows[0]["steps"][0]["action"] == "goto"
    assert rows[0]["steps"][-1]["action"] == "assert_url"
    assert any(s.get("driver") == "midscene" for s in rows[0]["steps"])


def test_ensure_plan_matrix_synthesizes_when_missing():
    plan = ensure_plan_matrix(
        {
            "goal": "登录后打开首页",
            "start_path": "/login",
            "checklist": ["填账号", "点登录", "进入首页"],
            "case_name": "登录冒烟",
        }
    )
    assert len(plan["matrix"]) == 1
    assert plan["matrix"][0]["name"] == "登录冒烟"
    assert isinstance(plan["matrix"][0]["steps"][0], dict)
    assert any(s.get("action") == "goto" for s in plan["matrix"][0]["steps"])
    assert any(s.get("action", "").startswith("assert") for s in plan["matrix"][0]["steps"])


def test_ensure_plan_matrix_allow_empty_for_explore_first():
    plan = ensure_plan_matrix(
        {"goal": "登录与项目管理", "start_path": "/login", "checklist": ["登录", "项目"], "matrix": []},
        synthesize_if_empty=False,
    )
    assert plan["matrix"] == []


def test_matrix_from_sequential_checklist_splits_crud():
    rows = matrix_from_sequential_checklist(
        goal="需求 CRUD",
        start_path="/",
        checklist=[
            "创建项目并进入",
            "新建需求文档",
            "查询需求列表可见",
            "编辑需求标题",
            "删除需求",
        ],
        test_data='{"project_name":"P1","requirement_title":"R1","requirement_title_edited":"R1e"}',
    )
    assert len(rows) == 5
    assert rows[2]["business_action"] == "query"
    assert rows[1]["business_action"] == "create"
    assert "R1" in str(rows[1].get("expected") or "")
    assert rows[2]["id"] != rows[1]["id"]


def test_apply_sequential_explore_matrix_sets_flag():
    plan = apply_sequential_explore_matrix(
        {
            "goal": "g",
            "start_path": "/",
            "checklist": ["登录", "打开列表"],
        }
    )
    assert plan.get("_sequential_matrix") is True
    assert len(plan["matrix"]) == 2


def test_hydrate_matrix_tags_per_case_id():
    matrix = matrix_from_sequential_checklist(
        goal="g",
        start_path="/",
        checklist=["新建需求", "查询列表"],
        test_data="requirement_title: 样例",
    )
    trace = [
        {"case_id": matrix[0]["id"], "kind": "click", "name": "新建需求", "status": "ok"},
        {"case_id": matrix[0]["id"], "kind": "fill", "name": "标题", "value": "样例", "status": "ok"},
        {"case_id": matrix[1]["id"], "kind": "click", "name": "需求管理", "status": "ok"},
    ]
    hydrated = hydrate_matrix_from_trace(matrix, trace)
    assert len(hydrated) == 2
    q_steps = hydrated[1].get("steps") or []
    assert not any(
        "新建" in str(s.get("name") or s.get("target") or "")
        for s in q_steps
        if str(s.get("action")) == "click"
    )


def test_infer_business_action():
    assert infer_business_action("查询需求列表") == "query"
    assert infer_business_action("新建需求") == "create"


def test_split_oversized_checklist():
    from app.services.ui_automation.ui_explore_report import (
        case_done_allowed,
        split_oversized_checklist,
    )

    parts = split_oversized_checklist(
        ["创建项目并进入→新增需求文档", "查询列表"]
    )
    assert len(parts) >= 3
    plan = {
        "_active_case": {"id": "uc_001", "expected": "探索需求文档"},
    }
    ok, _ = case_done_allowed(plan, "页面 探索需求文档 列表", [], "uc_001")
    assert ok
    blocked, msg = case_done_allowed(plan, "无相关内容", [], "uc_001")
    assert not blocked
    assert "预期" in msg


def test_infer_driver_playwright_vs_midscene():
    assert infer_driver({"action": "goto", "value": "/"})[0] == "playwright"
    assert infer_driver({"action": "click", "role": "button", "name": "登录"})[0] == "playwright"
    assert infer_driver({"action": "fill", "placeholder": "用户名", "value": "a"})[0] == "playwright"
    driver, reason, prompt = infer_driver(
        {"kind": "fill_captcha", "locate": "验证码输入框", "captcha": True}
    )
    assert driver == "midscene"
    assert reason and "captcha" in reason
    assert prompt
    driver2, reason2, _ = infer_driver(
        {"action": "click", "locate": "图表放大按钮", "selector": ""}
    )
    assert driver2 == "midscene"
    assert reason2


def test_build_explore_report_summary():
    plan = ensure_plan_matrix(
        {
            "goal": "登录",
            "start_path": "/",
            "case_name": "登录",
            "checklist": ["登录"],
            "matrix": [{"id": "L-001", "name": "登录成功", "expected": "进入首页"}],
        }
    )
    steps = annotate_steps(
        [
            {"action": "goto", "value": "/login", "status": "ok"},
            {"action": "fill", "placeholder": "账号", "value": "demo", "status": "ok"},
            {"action": "fill", "locate": "验证码输入框", "captcha": True, "kind": "fill_captcha"},
            {"action": "click", "role": "button", "name": "登录", "status": "ok"},
        ],
        matrix=plan["matrix"],
    )
    report = build_explore_report(plan=plan, steps=steps, script="async function run(){}", engine="midscene")
    assert report["case_name"] == "登录"
    assert report["mapping"][0]["id"] == "L-001"
    assert report["summary"]["total_steps"] == 4
    assert report["summary"]["midscene_steps"] >= 1
    assert report["summary"]["playwright_steps"] >= 2
    assert report["captcha"] is not None
    assert any(s.get("driver") == "midscene" for s in report["steps"])


def test_bind_trace_and_matrix_to_script_has_expect():
    matrix = normalize_matrix(
        [
            {
                "id": "L-001",
                "name": "登录成功",
                "steps": [
                    {"action": "goto", "target": "/login"},
                    {"action": "fill", "target": "账号", "value": "{{username}}"},
                    {"action": "fill", "target": "密码", "value": "{{password}}"},
                    {"action": "fill", "target": "验证码", "value": "{{captcha}}"},
                    {"action": "click", "target": "登录"},
                    {"action": "assert_url", "value": "/home"},
                ],
            }
        ],
        start_path="/login",
    )
    trace = [
        {"kind": "goto", "path": "/login", "status": "ok", "driver": "playwright"},
        {
            "kind": "fill",
            "action": "fill",
            "status": "ok",
            "driver": "playwright",
            "cli_locator": 'page.getByRole("textbox", { name: "账号" })',
            "value": "admin",
        },
        {
            "kind": "fill",
            "action": "fill",
            "status": "ok",
            "driver": "playwright",
            "placeholder": "密码",
            "value": "secret",
        },
        {
            "kind": "fill_captcha",
            "action": "fill",
            "status": "ok",
            "driver": "playwright",
            "captcha": True,
            "placeholder": "请输入图中字符",
        },
        {
            "kind": "click",
            "action": "click",
            "status": "ok",
            "driver": "playwright",
            "role": "button",
            "name": "登录",
        },
        {
            "kind": "click",
            "driver": "midscene",
            "prompt": "读取登录页验证码图片中的字符",
            "explore_noop": True,
            "status": "ok",
        },
        {
            "kind": "click",
            "driver": "midscene",
            "prompt": "读取登录页验证码图片中的字符",
            "explore_noop": True,
            "status": "ok",
        },
    ]
    bound = bind_trace_to_matrix(matrix, trace)
    assert bound[0]["ready"] is True
    assert matrix_bind_issues(bound) == []
    code = matrix_to_node_script(bound, username="admin", password="secret", start_path="/login")
    assert code.startswith("async function run(page, agent)")
    assert "expect(page)" in code
    assert "toHaveURL" in code
    assert script_has_assert(code)


def test_collapse_noisy_captcha_retry_trace_for_codegen():
    """Explore retries must not become repeated login/refresh clicks in the script."""
    from app.services.ui_automation.ui_explore_report import _collapse_trace_for_bind, hydrate_matrix_from_trace

    trace = [
        {"kind": "goto", "path": "/login", "status": "ok", "driver": "playwright"},
        {
            "kind": "fill",
            "status": "ok",
            "driver": "playwright",
            "name": "账号",
            "cli_locator": 'page.getByRole("textbox", { name: "账号" })',
            "value": "admin123",  # wrong value recorded; field name wins in codegen
        },
        {
            "kind": "fill",
            "status": "ok",
            "driver": "playwright",
            "name": "密码",
            "value": "admin123",
        },
        {
            "kind": "fill_captcha",
            "status": "ok",
            "captcha": True,
            "placeholder": "请输入图中字符",
            "value": "{{captcha}}",
        },
        {"kind": "click", "status": "ok", "role": "button", "name": "登录"},
        {"kind": "click", "status": "ok", "name": "换一张验证码", "reason": "captcha_retry_refresh"},
        {
            "kind": "fill_captcha",
            "status": "ok",
            "captcha": True,
            "placeholder": "请输入图中字符",
            "value": "{{captcha}}",
        },
        {"kind": "click", "status": "ok", "role": "button", "name": "登录"},
        {"kind": "click", "status": "ok", "role": "button", "name": "登录"},
        {"kind": "click", "status": "ok", "role": "button", "name": "登录"},
        {"kind": "click", "status": "ok", "role": "button", "name": "登录"},
    ]
    collapsed = _collapse_trace_for_bind(trace)
    kinds = [t.get("kind") or t.get("action") for t in collapsed]
    assert kinds.count("goto") == 1
    assert sum(1 for t in collapsed if (t.get("kind") == "fill" and t.get("name") == "账号")) == 1
    assert sum(1 for t in collapsed if t.get("kind") == "fill_captcha" or t.get("captcha")) == 1
    assert sum(1 for t in collapsed if t.get("name") == "登录") == 1
    assert not any(t.get("reason") == "captcha_retry_refresh" for t in collapsed)
    assert not any("换一张" in str(t.get("name") or "") for t in collapsed)

    matrix = [
        {"id": "TC-01", "name": "使用正确账号密码登录成功", "expected": "离开登录页", "start_url": "/login"}
    ]
    hydrated = hydrate_matrix_from_trace(matrix, trace)
    case0 = matrix_to_case_scripts(
        hydrated, username="admin", password="admin123", start_path="/login"
    )[0]
    _assert_llm_codegen_pending(case0)
    steps = hydrated[0].get("steps") or []
    click_names = [str(s.get("name") or "") for s in steps if s.get("action") == "click"]
    assert click_names.count("登录") <= 1
    assert not any("换一张" in str(s.get("name") or "") for s in steps)
    placeholders = [str(s.get("placeholder") or s.get("name") or "") for s in steps if s.get("action") == "fill"]
    assert any("账号" in p for p in placeholders)


def test_skeleton_then_hydrate_generates_case_scripts():
    plan = skeletonize_plan_matrix(
        ensure_plan_matrix(
            {
                "goal": "登录与建项目",
                "start_path": "/login",
                "matrix": [
                    {"id": "TC-01", "name": "登录成功", "expected": "进入首页"},
                    {"id": "TC-02", "name": "创建项目", "expected": "项目列表可见"},
                ],
            }
        )
    )
    assert all(r.get("ready") is False for r in plan["matrix"])
    assert all(
        all(isinstance(s, dict) and s.get("action") in ("goto", "assert_text", "assert_url") for s in r["steps"])
        for r in plan["matrix"]
    )
    # One explore session tags steps with case_id → both rows hydrate
    trace = [
        {
            "kind": "goto",
            "path": "/login",
            "status": "ok",
            "driver": "playwright",
            "case_id": "TC-01",
        },
        {
            "kind": "fill",
            "action": "fill",
            "status": "ok",
            "driver": "playwright",
            "placeholder": "账号",
            "value": "admin",
            "case_id": "TC-01",
        },
        {
            "kind": "click",
            "action": "click",
            "status": "ok",
            "driver": "playwright",
            "role": "button",
            "name": "登录",
            "case_id": "TC-01",
        },
        {
            "kind": "click",
            "action": "click",
            "status": "ok",
            "driver": "playwright",
            "role": "button",
            "name": "新建项目",
            "case_id": "TC-02",
        },
    ]
    hydrated = hydrate_matrix_from_trace(plan["matrix"], trace)
    assert hydrated[0]["ready"] is True
    assert hydrated[1]["ready"] is True
    cases = matrix_to_case_scripts(hydrated, username="admin", password="secret", start_path="/login")
    _assert_llm_codegen_pending(cases[0])
    _assert_llm_codegen_pending(cases[1])
    assert cases[1].get("needs_auth") is True
    biz_step_names = [
        str(s.get("name") or "")
        for s in (hydrated[1].get("steps") or [])
        if isinstance(s, dict)
    ]
    assert "新建项目" in biz_step_names
    login_step_names = [str(s.get("name") or "") for s in (hydrated[0].get("steps") or [])]
    assert "新建项目" not in login_step_names


def test_hydrate_without_case_id_splits_at_login():
    matrix = [
        {"id": "TC-01", "name": "登录成功", "expected": "进入首页", "start_url": "/login"},
        {"id": "TC-02", "name": "进入项目管理", "expected": "项目列表", "start_url": "/"},
    ]
    trace = [
        {"kind": "goto", "path": "/login", "status": "ok", "driver": "playwright"},
        {
            "kind": "fill",
            "status": "ok",
            "driver": "playwright",
            "placeholder": "账号",
            "value": "admin",
        },
        {
            "kind": "click",
            "status": "ok",
            "driver": "playwright",
            "role": "button",
            "name": "登录",
        },
        {
            "kind": "click",
            "status": "ok",
            "driver": "playwright",
            "name": "项目管理",
        },
    ]
    hydrated = hydrate_matrix_from_trace(matrix, trace)
    assert hydrated[0]["ready"] is True
    assert hydrated[1]["ready"] is True
    cases = matrix_to_case_scripts(hydrated, username="admin", start_path="/login")
    _assert_llm_codegen_pending(cases[0])
    _assert_llm_codegen_pending(cases[1])
    assert cases[1].get("needs_auth") is True
    biz_steps = hydrated[1].get("steps") or []
    assert any("项目管理" in str(s.get("name") or "") for s in biz_steps)


def test_derive_matrix_from_explore_fallback_splits_checklist():
    """Checklist length must not drive 1:1 matrix rows — login + one business E2E."""
    trace = [
        {"kind": "goto", "path": "/login", "status": "ok", "driver": "playwright"},
        {
            "kind": "fill",
            "status": "ok",
            "driver": "playwright",
            "placeholder": "账号",
            "value": "admin",
        },
        {
            "kind": "click",
            "status": "ok",
            "driver": "playwright",
            "role": "button",
            "name": "登录",
        },
        {
            "kind": "click",
            "status": "ok",
            "driver": "playwright",
            "name": "项目管理",
        },
        {
            "kind": "click",
            "status": "ok",
            "driver": "playwright",
            "name": "新建项目",
        },
    ]
    rows = derive_matrix_from_explore(
        prompt="登录后做项目管理",
        goal="登录与项目管理",
        trace=trace,
        llm=None,
        start_path="/login",
        checklist=["登录", "项目列表", "新建项目"],
        case_name="项目管理",
    )
    assert len(rows) == 2
    assert rows[0]["id"] == "TC-01"
    assert rows[1]["id"] == "TC-02"
    assert "项目管理" in (rows[1].get("name") or "")
    assert all(r.get("ready") for r in rows)
    cases = matrix_to_case_scripts(rows, username="admin", password="x", start_path="/login")
    assert len(cases) == 2
    non_login = cases[1]
    _assert_llm_codegen_pending(non_login)
    assert non_login.get("needs_auth") is True
    assert any(
        "新建项目" in str(s.get("name") or "")
        for s in (rows[1].get("steps") or [])
    )


def test_derive_matrix_from_explore_llm_step_indexes():
    class FakeLlm:
        def chat_complete(self, *args, **kwargs):
            return (
                '{"matrix":['
                '{"id":"TC-01","name":"登录成功","expected":"首页","step_indexes":[0,1,2]},'
                '{"id":"TC-02","name":"进入项目","expected":"列表","step_indexes":[3,4]}'
                "]}"
            )

    trace = [
        {"kind": "goto", "path": "/login", "status": "ok", "driver": "playwright"},
        {
            "kind": "fill",
            "status": "ok",
            "driver": "playwright",
            "placeholder": "账号",
            "value": "admin",
        },
        {
            "kind": "click",
            "status": "ok",
            "driver": "playwright",
            "role": "button",
            "name": "登录",
        },
        {
            "kind": "click",
            "status": "ok",
            "driver": "playwright",
            "name": "项目管理",
        },
        {
            "kind": "click",
            "status": "ok",
            "driver": "playwright",
            "name": "项目列表",
        },
    ]
    rows = derive_matrix_from_explore(
        prompt="登录后进项目",
        goal="登录与项目",
        trace=trace,
        llm=FakeLlm(),
        start_path="/login",
        checklist=["登录", "项目"],
    )
    assert len(rows) == 2
    assert rows[0]["id"] == "TC-01" and rows[1]["id"] == "TC-02"
    assert rows[0]["ready"] and rows[1]["ready"]
    cases = matrix_to_case_scripts(rows, username="admin", start_path="/login")
    _assert_llm_codegen_pending(cases[1])
    assert cases[1].get("needs_auth") is True
    assert any(
        "项目管理" in str(s.get("name") or "")
        for s in (rows[1].get("steps") or [])
    )


def test_derive_matrix_empty_checklist_still_splits():
    """Empty checklist must not collapse a login+business explore into UC-001."""
    trace = [
        {"kind": "goto", "path": "/login", "status": "ok", "driver": "playwright"},
        {
            "kind": "fill",
            "status": "ok",
            "driver": "playwright",
            "placeholder": "账号",
            "value": "admin",
        },
        {
            "kind": "fill",
            "status": "ok",
            "driver": "playwright",
            "placeholder": "密码",
            "value": "x",
        },
        {
            "kind": "click",
            "status": "ok",
            "driver": "playwright",
            "role": "button",
            "name": "登录",
        },
        {
            "kind": "click",
            "status": "ok",
            "driver": "playwright",
            "name": "项目管理",
        },
        {
            "kind": "click",
            "status": "ok",
            "driver": "playwright",
            "name": "新建项目",
        },
        {
            "kind": "click",
            "status": "ok",
            "driver": "playwright",
            "name": "新建需求",
        },
    ]
    rows = derive_matrix_from_explore(
        prompt="登录后项目管理与需求",
        goal="登录后项目管理与需求管理端到端探索",
        trace=trace,
        llm=None,
        start_path="/login",
        checklist=[],
        case_name="端到端探索",
    )
    # Coarse fallback: login + one SPA business E2E (no CRUD keyword cuts)
    assert len(rows) == 2
    assert rows[0]["id"] == "TC-01"
    assert rows[1]["name"] == "端到端探索"
    assert not any(r.get("id") == "UC-001" for r in rows)


def test_derive_matrix_fallback_same_path_is_one_business_case():
    """Without LLM, same-path CRUD stays one business case — no 确定/控件成案."""
    trace = [
        {"kind": "goto", "path": "/login", "status": "ok", "driver": "playwright"},
        {
            "kind": "fill",
            "status": "ok",
            "driver": "playwright",
            "placeholder": "账号",
            "value": "admin",
        },
        {
            "kind": "click",
            "status": "ok",
            "driver": "playwright",
            "role": "button",
            "name": "登录",
        },
        {"kind": "click", "status": "ok", "driver": "playwright", "name": "侧栏入口"},
        {"kind": "click", "status": "ok", "driver": "playwright", "name": "新建需求"},
        {"kind": "fill", "status": "ok", "driver": "playwright", "placeholder": "标题", "value": "t1"},
        {"kind": "click", "status": "ok", "driver": "playwright", "name": "保存"},
        {"kind": "click", "status": "ok", "driver": "playwright", "name": "编辑"},
        {"kind": "fill", "status": "ok", "driver": "playwright", "placeholder": "标题", "value": "t2"},
        {"kind": "click", "status": "ok", "driver": "playwright", "name": "保存"},
        {"kind": "click", "status": "ok", "driver": "playwright", "name": "删除"},
        {"kind": "click", "status": "ok", "driver": "playwright", "name": "确定"},
    ]
    rows = derive_matrix_from_explore(
        prompt="登录后需求 CRUD",
        goal="需求创建编辑删除",
        trace=trace,
        llm=None,
        start_path="/login",
        checklist=["登录", "创建", "编辑", "删除"],
        case_name="需求全流程",
    )
    assert rows[0]["id"] == "TC-01"
    assert len(rows) == 2
    assert rows[1]["name"] == "需求全流程"
    biz_names = [str(r.get("name") or "") for r in rows[1:]]
    assert not any(n in ("保存", "确定", "标题") for n in biz_names)


def test_derive_matrix_no_login_button_uses_captcha_boundary():
    """Auth fills + captcha without a named 登录 click still split login vs business."""
    trace = [
        {"kind": "goto", "path": "/login", "status": "ok", "driver": "playwright"},
        {
            "kind": "fill",
            "status": "ok",
            "driver": "playwright",
            "placeholder": "账号",
            "value": "admin",
        },
        {
            "kind": "fill",
            "status": "ok",
            "driver": "playwright",
            "placeholder": "密码",
            "value": "secret",
        },
        {
            "kind": "fill",
            "status": "ok",
            "driver": "playwright",
            "placeholder": "验证码",
            "value": "AB12",
            "captcha": True,
        },
        {
            "kind": "click",
            "status": "ok",
            "driver": "playwright",
            "name": "项目管理",
        },
        {
            "kind": "click",
            "status": "ok",
            "driver": "playwright",
            "name": "新建需求",
        },
    ]
    rows = derive_matrix_from_explore(
        prompt="登录后做需求",
        goal="登录与需求",
        trace=trace,
        llm=None,
        start_path="/login",
        checklist=[],
    )
    assert len(rows) >= 2
    assert rows[0]["id"] == "TC-01"
    assert rows[0]["name"] == "登录成功"
    assert not any(r.get("id") == "UC-001" for r in rows)
    cases = matrix_to_case_scripts(rows, username="admin", password="x", start_path="/login")
    pending = [c for c in cases if c.get("codegen_pending")]
    assert len(pending) >= 2


def test_derive_matrix_llm_single_crud_keeps_e2e():
    """Single post-login create op: LLM one E2E case is kept."""

    class MegaLlm:
        def chat_complete(self, *args, **kwargs):
            return (
                '{"matrix":['
                '{"id":"UC-001","name":"端到端探索","expected":"完成",'
                '"step_indexes":[0,1,2,3,4]}'
                "]}"
            )

    trace = [
        {"kind": "goto", "path": "/login", "status": "ok", "driver": "playwright"},
        {
            "kind": "fill",
            "status": "ok",
            "driver": "playwright",
            "placeholder": "账号",
            "value": "admin",
        },
        {
            "kind": "click",
            "status": "ok",
            "driver": "playwright",
            "role": "button",
            "name": "登录",
        },
        {
            "kind": "click",
            "status": "ok",
            "driver": "playwright",
            "name": "侧栏",
        },
        {
            "kind": "click",
            "status": "ok",
            "driver": "playwright",
            "name": "新建项目",
        },
    ]
    rows = derive_matrix_from_explore(
        prompt="登录后项目管理",
        goal="登录与项目",
        trace=trace,
        llm=MegaLlm(),
        start_path="/login",
        checklist=["登录", "项目列表", "新建项目"],
    )
    assert len(rows) == 1
    assert rows[0]["id"] == "UC-001"
    assert rows[0].get("ready")


def test_derive_matrix_llm_under_split_falls_back_by_path_modules():
    """Login + one mega case spanning multiple path modules must fall back."""

    class FatLlm:
        def chat_complete(self, *args, **kwargs):
            return (
                '{"matrix":['
                '{"id":"TC-01","name":"登录成功","expected":"ok","step_indexes":[0,1,2]},'
                '{"id":"TC-02","name":"项目与需求全流程","expected":"完成",'
                '"step_indexes":[3,4,5,6]}'
                "]}"
            )

    trace = [
        {"kind": "goto", "path": "/login", "status": "ok", "driver": "playwright"},
        {
            "kind": "fill",
            "status": "ok",
            "driver": "playwright",
            "placeholder": "账号",
            "value": "admin",
        },
        {
            "kind": "click",
            "status": "ok",
            "driver": "playwright",
            "role": "button",
            "name": "登录",
        },
        {
            "kind": "click",
            "status": "ok",
            "driver": "playwright",
            "name": "项目菜单",
            "path": "/projects",
        },
        {
            "kind": "click",
            "status": "ok",
            "driver": "playwright",
            "name": "新建项目",
            "path": "/projects",
        },
        {
            "kind": "click",
            "status": "ok",
            "driver": "playwright",
            "name": "需求菜单",
            "path": "/requirements",
        },
        {
            "kind": "click",
            "status": "ok",
            "driver": "playwright",
            "name": "新建需求",
            "path": "/requirements",
        },
    ]
    rows = derive_matrix_from_explore(
        prompt="登录后项目与需求",
        goal="多模块探索",
        trace=trace,
        llm=FatLlm(),
        start_path="/login",
        checklist=["登录", "项目", "需求"],
        case_name="多模块探索",
    )
    assert rows[0]["name"] == "登录成功"
    assert not any("全流程" in str(r.get("name") or "") for r in rows)
    # Path-module coarse fallback: login + projects + requirements
    assert len(rows) >= 3
    names = " ".join(str(r.get("name") or "") for r in rows[1:])
    assert "projects" in names and "requirements" in names


def test_derive_matrix_login_ignores_reason_containing_login():
    """Business click with reason『登录后…』must not become the login boundary."""
    trace = [
        {"kind": "goto", "path": "/login", "status": "ok", "driver": "playwright"},
        {
            "kind": "fill",
            "status": "ok",
            "driver": "playwright",
            "placeholder": "账号",
            "value": "admin",
        },
        {
            "kind": "fill",
            "status": "ok",
            "driver": "playwright",
            "placeholder": "密码",
            "value": "x",
        },
        {
            "kind": "click",
            "status": "ok",
            "driver": "playwright",
            "role": "button",
            "name": "登录",
        },
        {
            "kind": "click",
            "status": "ok",
            "driver": "playwright",
            "name": "新建项目",
            "reason": "登录后点击新建项目打开弹窗",
        },
        {
            "kind": "fill",
            "status": "ok",
            "driver": "playwright",
            "placeholder": "* 名称",
            "value": "demo",
        },
    ]
    rows = derive_matrix_from_explore(
        prompt="登录后新建项目",
        goal="新建项目",
        trace=trace,
        llm=None,
        start_path="/login",
        case_name="新建项目",
    )
    assert len(rows) == 2
    assert rows[0]["name"] == "登录成功"
    login_case = matrix_to_case_scripts(rows, username="admin", password="x", start_path="/login")[0]
    _assert_llm_codegen_pending(login_case)
    login_blob = json.dumps(rows[0].get("steps") or [], ensure_ascii=False)
    assert "新建项目" not in login_blob
    assert "登录" in login_blob or "账号" in login_blob
    assert "新建项目" in (rows[1].get("name") or "") or any(
        (s.get("name") == "新建项目")
        for s in (rows[1].get("steps") or [])
        if isinstance(s, dict)
    )


def test_derive_matrix_llm_over_split_falls_back():
    """Tiny LLM cases named after controls are rejected for coarse fallback."""

    class TinyLlm:
        def chat_complete(self, *args, **kwargs):
            return (
                '{"matrix":['
                '{"id":"TC-01","name":"登录成功","expected":"ok","step_indexes":[0,1,2]},'
                '{"id":"TC-02","name":"* 名称","expected":"x","step_indexes":[3]},'
                '{"id":"TC-03","name":"确定","expected":"y","step_indexes":[4]}'
                "]}"
            )

    trace = [
        {"kind": "goto", "path": "/login", "status": "ok", "driver": "playwright"},
        {
            "kind": "fill",
            "status": "ok",
            "driver": "playwright",
            "placeholder": "账号",
            "value": "admin",
        },
        {
            "kind": "click",
            "status": "ok",
            "driver": "playwright",
            "role": "button",
            "name": "登录",
        },
        {
            "kind": "fill",
            "status": "ok",
            "driver": "playwright",
            "placeholder": "* 名称",
            "value": "demo",
        },
        {
            "kind": "click",
            "status": "ok",
            "driver": "playwright",
            "name": "确定",
        },
        {
            "kind": "click",
            "status": "ok",
            "driver": "playwright",
            "name": "查看详情",
        },
    ]
    rows = derive_matrix_from_explore(
        prompt="登录后新建",
        goal="新建流程",
        trace=trace,
        llm=TinyLlm(),
        start_path="/login",
        case_name="新建流程",
    )
    assert rows[0]["name"] == "登录成功"
    assert len(rows) == 2
    assert rows[1]["name"] == "新建流程"
    assert not any(str(r.get("name") or "") in ("* 名称", "确定") for r in rows)


def test_warn_if_login_stuck_when_thin_tail():
    from app.services.ui_automation.ui_explore_report import warn_if_login_stuck

    trace = [
        {"kind": "goto", "path": "/login", "status": "ok", "driver": "playwright"},
        {
            "kind": "fill",
            "status": "ok",
            "driver": "playwright",
            "placeholder": "账号",
            "value": "admin",
        },
        {
            "kind": "click",
            "status": "ok",
            "driver": "playwright",
            "role": "button",
            "name": "登录",
        },
        {
            "kind": "fill",
            "status": "ok",
            "driver": "playwright",
            "placeholder": "密码",
            "value": "x",
        },
    ]
    msg = warn_if_login_stuck(
        trace,
        matrix=[{"id": "TC-01", "name": "登录成功"}],
        single_case=False,
    )
    assert msg and "未进入业务页" in msg
    assert warn_if_login_stuck(trace, single_case=True) is None


def test_derive_matrix_fallback_hollow_tail_keeps_login_only():
    """Post-login 0–1 interactive steps must not invent a goal-named TC-02."""
    trace = [
        {"kind": "goto", "path": "/login", "status": "ok", "driver": "playwright"},
        {
            "kind": "fill",
            "status": "ok",
            "driver": "playwright",
            "placeholder": "账号",
            "value": "admin",
        },
        {
            "kind": "fill",
            "status": "ok",
            "driver": "playwright",
            "placeholder": "密码",
            "value": "123456",
        },
        {
            "kind": "click",
            "status": "ok",
            "driver": "playwright",
            "role": "button",
            "name": "登录",
        },
        {
            "kind": "fill",
            "status": "ok",
            "driver": "playwright",
            "placeholder": "密码",
            "value": "admin123",
        },
    ]
    rows = derive_matrix_from_explore(
        prompt="登录系统 admin admin123 创建项目 CRUD",
        goal="登录后创建项目并完成需求 CRUD 全流程探索",
        trace=trace,
        llm=None,
        start_path="/login",
        case_name="登录后创建项目并完成需求 CRUD 全流程探索",
    )
    assert len(rows) == 1
    assert rows[0]["id"] == "TC-01"
    assert rows[0]["name"] == "登录成功"
    assert not any("全流程" in str(r.get("name") or "") for r in rows)


def test_derive_matrix_llm_same_path_keeps_complete_business_case():
    """Same-path multi-step LLM business case is kept (no CRUD under-split)."""

    class OkLlm:
        def chat_complete(self, *args, **kwargs):
            return (
                '{"matrix":['
                '{"id":"TC-01","name":"登录成功","expected":"ok","step_indexes":[0,1,2]},'
                '{"id":"TC-02","name":"需求全流程","expected":"完成",'
                '"step_indexes":[3,4,5,6,7]}'
                "]}"
            )

    trace = [
        {"kind": "goto", "path": "/login", "status": "ok", "driver": "playwright"},
        {
            "kind": "fill",
            "status": "ok",
            "driver": "playwright",
            "placeholder": "账号",
            "value": "admin",
        },
        {
            "kind": "click",
            "status": "ok",
            "driver": "playwright",
            "role": "button",
            "name": "登录",
        },
        {"kind": "click", "status": "ok", "driver": "playwright", "name": "新建需求"},
        {"kind": "fill", "status": "ok", "driver": "playwright", "placeholder": "标题", "value": "a"},
        {"kind": "click", "status": "ok", "driver": "playwright", "name": "保存"},
        {"kind": "click", "status": "ok", "driver": "playwright", "name": "编辑"},
        {"kind": "click", "status": "ok", "driver": "playwright", "name": "删除"},
    ]
    rows = derive_matrix_from_explore(
        prompt="登录后需求",
        goal="需求全流程",
        trace=trace,
        llm=OkLlm(),
        start_path="/login",
    )
    assert len(rows) == 2
    assert rows[1]["name"] == "需求全流程"


def test_matrix_rows_from_testcases_preserves_manual_case_id():
    rows = matrix_rows_from_testcases(
        [
            {
                "id": 101,
                "title": "创建需求成功",
                "steps": [{"action": "点击新建", "expected": "弹窗出现"}],
                "test_data": "标题：demo",
                "overall_expected": "列表出现 demo",
                "precondition": "已登录",
            },
            {
                "id": 102,
                "title": "标题为空校验",
                "steps": [{"action": "不填标题点保存", "expected": "提示必填"}],
                "overall_expected": "提示必填",
            },
        ],
        default_start="/projects/1/requirements",
    )
    assert len(rows) == 2
    assert rows[0]["manual_case_id"] == 101
    assert rows[0]["name"] == "创建需求成功"
    assert rows[1]["manual_case_id"] == 102
    scripts = matrix_to_case_scripts(rows, start_path="/projects/1/requirements")
    assert scripts[0].get("manual_case_id") == 101
    assert scripts[1].get("manual_case_id") == 102


def test_expand_cases_from_test_design_adds_per_field_when_llm_fails():
    class Boom:
        def chat_complete(self, *a, **k):
            raise RuntimeError("llm down")

    trace = [
        {"kind": "goto", "path": "/", "status": "ok", "driver": "playwright"},
        {
            "kind": "fill",
            "status": "ok",
            "driver": "playwright",
            "name": "标题",
            "role": "textbox",
            "value": "demo",
            "cli_locator": 'page.getByRole("textbox", { name: "标题" })',
        },
        {
            "kind": "fill",
            "status": "ok",
            "driver": "playwright",
            "name": "描述",
            "role": "textbox",
            "value": "正文",
            "cli_locator": 'page.getByRole("textbox", { name: "描述" })',
        },
        {
            "kind": "click",
            "status": "ok",
            "driver": "playwright",
            "name": "保存",
            "role": "button",
            "cli_locator": 'page.getByRole("button", { name: "保存" })',
        },
    ]
    rows = expand_cases_from_test_design(
        prompt="新增需求",
        goal="新增需求",
        trace=trace,
        llm=Boom(),
        start_path="/",
        case_name="新增需求",
    )
    names = [r.get("name") for r in rows]
    assert any("主成功" in str(n) or n == "新增需求" for n in names)
    assert any("标题" in str(n) and "空" in str(n) for n in names)
    assert any("描述" in str(n) and "空" in str(n) for n in names)
    assert len(rows) >= 3


def test_expand_crud_single_llm_case_forces_business_cases_without_fields():
    class OneCaseLlm:
        def chat_complete(self, *args, **kwargs):
            return (
                '{"matrix":[{"id":"TC-01","name":"需求文档全流程",'
                '"expected":"操作成功","step_indexes":[0,1,2,3]}]}'
            )

    trace = [
        {"kind": "goto", "path": "/requirements", "status": "ok", "driver": "playwright"},
        {
            "kind": "click",
            "status": "ok",
            "driver": "playwright",
            "name": "新建需求",
            "role": "button",
            "cli_locator": 'page.getByRole("button", { name: "新建需求" })',
        },
        {
            "kind": "click",
            "status": "ok",
            "driver": "playwright",
            "name": "编辑",
            "role": "button",
            "cli_locator": 'page.getByRole("button", { name: "编辑" })',
        },
        {
            "kind": "click",
            "status": "ok",
            "driver": "playwright",
            "name": "删除",
            "role": "button",
            "cli_locator": 'page.getByRole("button", { name: "删除" })',
        },
    ]
    rows = expand_cases_from_test_design(
        prompt="创建项目并完成需求文档新增、查询、编辑、删除",
        goal="需求文档增删改查",
        checklist=["新增需求", "查询需求", "编辑需求", "删除需求"],
        trace=trace,
        llm=OneCaseLlm(),
        start_path="/requirements",
    )
    names = [str(row.get("name") or "") for row in rows]
    assert len(rows) >= 4
    for action in ("新增", "查询", "编辑", "删除"):
        assert any(action in name for name in names)


def test_count_test_design_fields_reads_cli_locator_names():
    trace = [
        {
            "kind": "fill",
            "status": "ok",
            "driver": "playwright",
            "value": "demo",
            "cli_locator": 'page.getByRole("textbox", { name: "项目名称" })',
        },
        {
            "kind": "fill",
            "status": "ok",
            "driver": "playwright",
            "value": "description",
            "cli_locator": 'page.getByPlaceholder("项目描述")',
        },
    ]
    assert count_test_design_fields(trace) == 2


def test_case_name_is_modal_fragment():
    assert case_name_is_modal_fragment("取消并重新打开新建项目弹窗") is True
    assert case_name_is_modal_fragment("新增需求文档并在列表可见") is False


def test_filter_modal_fragment_matrix():
    rows = [
        {"id": "TC-01", "name": "提交新增需求表单"},
        {"id": "TC-02", "name": "返回项目管理并对新建项目弹窗做打开关闭往返"},
    ]
    out = filter_modal_fragment_matrix(rows)
    assert len(out) == 1
    assert out[0]["name"] == "提交新增需求表单"


def test_matrix_missing_crud_actions():
    rows = [{"name": "新增需求文档"}, {"name": "新增校验"}]
    missing = matrix_missing_crud_actions(rows, ["新增", "查询", "编辑", "删除"])
    assert "新增" not in missing
    assert "查询" in missing
    assert "编辑" in missing
    assert "删除" in missing
