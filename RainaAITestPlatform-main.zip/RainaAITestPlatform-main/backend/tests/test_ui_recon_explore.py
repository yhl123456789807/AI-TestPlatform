"""Recon hook in explore engine (mocked CLI)."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

from app.services.ui_automation.ui_explore_engines import run_playwright_cli_engine


def test_engine_runs_recon_before_sequential_explore(monkeypatch) -> None:
    from app.config import settings

    monkeypatch.setattr(settings, "ui_recon_enabled", True)
    recon_called: list[bool] = []

    def fake_recon(**_kwargs):
        recon_called.append(True)
        cli = MagicMock()
        trace = [
            {
                "kind": "recon_visit",
                "path": "/",
                "controls": [{"role": "link", "name": "项目"}],
            }
        ]
        return trace, cli

    monkeypatch.setattr(
        "app.services.ui_automation.ui_explore_engines.run_recon_explore",
        fake_recon,
    )
    monkeypatch.setattr(
        "app.services.ui_automation.ui_explore_engines.run_cli_explore_loop",
        lambda **_kw: [{"kind": "goto", "path": "/", "status": "ok"}],
    )
    plan = {
        "_sequential_matrix": True,
        "matrix": [{"id": "TC-1", "name": "项目", "start_url": "/"}],
        "checklist": ["项目"],
    }
    llm = MagicMock()
    trace, _script = run_playwright_cli_engine(
        base_url="https://example.com",
        start_path="/",
        goal="项目",
        llm=llm,
        headed=False,
        timeout_ms=5000,
        plan=plan,
    )
    assert recon_called
    assert trace
    assert plan.get("page_knowledge")
