from __future__ import annotations

from typing import Any

from app.services.ai.effective_ai_settings import LlmRuntime
from app.services.ui_automation import ui_codegen_agents as agents
from app.services.ui_automation.ui_node_script import matrix_to_case_scripts


LLM = LlmRuntime(api_base="http://llm", api_key="test", model="test", allowed_models_csv="")


def _trace() -> list[dict[str, Any]]:
    return [
        {
            "kind": "goto",
            "path": "/users",
            "status": "ok",
            "observe": {
                "url_after": "http://example.test/users",
                "new_text": ["用户管理"],
                "dialog_open": False,
            },
        },
        {
            "kind": "click",
            "role": "button",
            "name": "新增用户",
            "cli_locator": "page.getByRole('button', { name: '新增用户' })",
            "status": "ok",
            "observe": {
                "url_after": "http://example.test/users",
                "new_text": ["新增用户", "用户名"],
                "dialog_open": True,
            },
        },
        {
            "kind": "fill",
            "role": "textbox",
            "name": "用户名",
            "value": "alice",
            "cli_locator": "page.getByRole('textbox', { name: '用户名' })",
            "status": "ok",
            "observe": {
                "url_after": "http://example.test/users",
                "new_text": [],
                "dialog_open": True,
            },
        },
    ]


def test_design_cases_filters_modal_fragment_cases(monkeypatch) -> None:
    monkeypatch.setattr(
        agents,
        "_chat",
        lambda *_args, **_kwargs: """
        {"cases":[
          {"id":"TC-01","name":"新增需求文档","start_i":0,"end_i":2,"asserts":[]},
          {"id":"TC-02","name":"取消并重新打开新建项目弹窗","start_i":0,"end_i":1,"asserts":[]}
        ]}
        """,
    )
    rows = agents.design_cases(
        prompt="需求 CRUD",
        goal="需求增删改查",
        trace=_trace(),
        llm=LLM,
        start_path="/users",
    )
    names = [r.get("name") for r in rows]
    assert any("新增需求" in str(n) for n in names)
    assert not any("重新打开" in str(n) for n in names)


def test_design_cases_keeps_only_grounded_asserts(monkeypatch) -> None:
    monkeypatch.setattr(
        agents,
        "_chat",
        lambda *_args, **_kwargs: """
        {"cases":[{
          "id":"TC-01","name":"新增用户","start_i":0,"end_i":2,
          "asserts":[
            {"action":"assert_text","value":"用户管理"},
            {"action":"assert_text","value":"凭空成功"}
          ]
        }]}
        """,
    )
    rows = agents.design_cases(
        prompt="新增用户",
        goal="新增用户",
        trace=_trace(),
        llm=LLM,
        start_path="/users",
    )
    assert len(rows) == 1
    asserts = [s for s in rows[0]["steps"] if str(s.get("action", "")).startswith("assert")]
    assert [s["value"] for s in asserts] == ["用户管理"]
    assert rows[0]["trace_range"] == [0, 2]


def test_negative_case_is_pending_without_inventing_error(monkeypatch) -> None:
    monkeypatch.setattr(
        agents,
        "_chat",
        lambda *_args, **_kwargs: """
        {"cases":[{
          "id":"TC-02","name":"用户名必填","start_i":1,"end_i":2,
          "negative":true,"assert_pending":true,
          "variant":{"field":"用户名","mode":"empty"},"asserts":[]
        }]}
        """,
    )
    row = agents.design_cases(
        prompt="校验用户名必填",
        goal="校验用户名必填",
        trace=_trace(),
        llm=LLM,
        start_path="/users",
    )[0]
    assert row["negative"] is True
    assert row["assert_pending"] is True
    assert all("__INVALID__" not in str(step.get("value", "")) for step in row["steps"])


def test_matrix_to_case_scripts_leaves_codegen_pending() -> None:
    rows = matrix_to_case_scripts(
        [{"id": "TC-1", "name": "用例", "ready": True, "steps": [{"action": "goto", "target": "/"}]}],
        start_path="/",
    )
    assert rows[0]["code"] == ""
    assert rows[0]["ready"] is False
    assert rows[0].get("codegen_pending") is True


def test_build_locator_catalog_from_trace() -> None:
    catalog = agents.build_locator_catalog(_trace())
    assert len(catalog) >= 3
    click = next(e for e in catalog if e.get("action") == "click")
    assert "新增用户" in click.get("cli_locator", "")
    assert agents.catalog_has_actionable_locators(catalog)


def test_guard_off_delivers_ungrounded_script(monkeypatch) -> None:
    monkeypatch.setattr(agents.settings, "ui_codegen_guard", "off")
    bad = (
        "async function run(page, agent) {\n"
        "  await page.getByRole('button', { name: '不存在按钮' }).click();\n"
        "}\n"
    )
    code, errors = agents.guard_script(
        bad,
        draft="",
        row={"steps": []},
        trace_slice=_trace(),
        fallback_on_error=False,
    )
    assert "不存在按钮" in code
    assert errors == []


def test_guard_primary_does_not_fallback(monkeypatch) -> None:
    monkeypatch.setattr(agents.settings, "ui_codegen_guard", "strict")
    draft = "async function run(page, agent) {\n  await page.goto('/');\n}\n"
    bad = (
        "async function run(page, agent) {\n"
        "  await page.getByRole('button', { name: '不存在按钮' }).click();\n"
        "  await expect(page.getByText('用户管理')).toBeVisible();\n"
        "}\n"
    )
    catalog = agents.build_locator_catalog(_trace())
    code, errors = agents.guard_script(
        bad,
        draft=draft,
        row={"steps": []},
        trace_slice=_trace(),
        catalog=catalog,
        fallback_on_error=False,
    )
    assert code == ""
    assert errors


def test_guard_falls_back_for_ungrounded_locator(monkeypatch) -> None:
    monkeypatch.setattr(agents.settings, "ui_codegen_guard", "strict")
    draft = (
        "async function run(page, agent) {\n"
        "  await page.goto('/users');\n"
        "  await expect(page.getByText('用户管理')).toBeVisible();\n"
        "}\n"
    )
    bad = (
        "async function run(page, agent) {\n"
        "  await page.getByRole('button', { name: '不存在按钮' }).click();\n"
        "  await expect(page.getByText('用户管理')).toBeVisible();\n"
        "}\n"
    )
    code, errors = agents.guard_script(
        bad,
        draft=draft,
        row={"steps": [{"action": "assert_text", "value": "用户管理"}]},
        trace_slice=_trace(),
    )
    assert code == draft
    assert any("定位器无探索依据" in error for error in errors)


def test_semantic_guard_rejects_swallowed_edit_failure() -> None:
    script = """
async function run(page, agent) {
  await page.getByRole('button', { name: '编辑' }).first().click();
  const dialog = page.getByRole('dialog');
  await dialog.getByRole('textbox', { name: '标题' }).fill('需求文档（编辑后）');
  await dialog.getByRole('button', { name: '确定' }).click();
  await dialog.waitFor({ state: 'hidden' }).catch(() => {});
  await expect(page.getByText('需求文档（编辑后）').first()).toBeVisible();
}
"""
    issues = agents.script_semantic_issues(
        script,
        {"id": "tc-requirement-view-edit", "name": "查看需求文档并编辑"},
    )
    assert any("空 catch" in issue for issue in issues)
    assert not any("编辑按钮位于列表页" in issue for issue in issues)
    assert any("精确断言" in issue for issue in issues)


def test_semantic_guard_requires_delete_postcondition() -> None:
    bad = """
async function run(page, agent) {
  await page.goto('/requirements');
  const row = page.getByRole('row', { name: /需求文档/ });
  await row.getByRole('button', { name: '删除' }).click();
  const dialog = page.getByRole('dialog');
  await dialog.getByRole('button', { name: '确定' }).click();
  await expect(page.getByText('删除成功')).toBeVisible();
}
"""
    assert any(
        "目标记录消失" in issue
        for issue in agents.script_semantic_issues(
            bad, {"id": "tc-requirement-delete", "name": "删除需求文档"}
        )
    )
    good = bad.replace(
        "await expect(page.getByText('删除成功')).toBeVisible();",
        "await expect(row).toHaveCount(0);",
    )
    assert agents.script_semantic_issues(
        good, {"id": "tc-requirement-delete", "name": "删除需求文档"}
    ) == []


def test_verify_negative_observation_then_passes() -> None:
    calls: list[str] = []

    def execute(*, script: str, **_kwargs: Any) -> list[dict[str, Any]]:
        calls.append(script)
        if agents._OBSERVE_ASSERT in script:
            return [
                {
                    "status": "failed",
                    "error_message": "not visible",
                    "failure_snapshot": "- alert: 用户名不能为空",
                }
            ]
        return [{"status": "passed"}]

    result = agents.verify_and_repair(
        row={"id": "TC-02", "negative": True},
        script=(
            "async function run(page, agent) {\n"
            f"  await expect(page.getByText('{agents._OBSERVE_ASSERT}')).toBeVisible();\n"
            "}\n"
        ),
        llm=LLM,
        runner_kwargs={},
        max_repair=2,
        execute=execute,
    )
    assert result["verify_status"] == "passed"
    assert result["attempts"] == 2
    assert "用户名不能为空" in result["code"]


def test_verify_honors_cancel() -> None:
    result = agents.verify_and_repair(
        row={"id": "TC-01"},
        script="async function run(page, agent) {}\n",
        llm=LLM,
        runner_kwargs={},
        should_cancel=lambda: True,
        execute=lambda **_kwargs: [],
    )
    assert result["verify_status"] == "skipped"


def test_verify_does_not_report_passed_when_semantic_gate_fails(monkeypatch) -> None:
    monkeypatch.setattr(agents, "_repair_script", lambda **kwargs: kwargs["script"])
    executed = False

    def execute(**_kwargs: Any) -> list[dict[str, Any]]:
        nonlocal executed
        executed = True
        return [{"status": "passed"}]

    result = agents.verify_and_repair(
        row={"id": "tc-requirement-delete", "name": "删除需求文档"},
        script=(
            "async function run(page, agent) {\n"
            "  await page.getByText('需求文档').click();\n"
            "  await expect(page.getByText('删除成功')).toBeVisible();\n"
            "}\n"
        ),
        llm=LLM,
        runner_kwargs={},
        max_repair=1,
        execute=execute,
    )
    assert executed is False
    assert result["verify_status"] == "failed"
    assert "目标记录消失" in result["verify_error"]


def test_repair_trial_script_accepts_valid_semantic_patch(monkeypatch) -> None:
    original = (
        "async function run(page, agent) {\n"
        "  await page.goto('/requirements');\n"
        "  const row = page.getByRole('row', { name: /需求文档/ });\n"
        "  await row.getByRole('button', { name: '删除' }).click();\n"
        "}\n"
    )
    repaired = original.replace(
        "\n}",
        "\n  await expect(row).toHaveCount(0);\n}\n",
    )
    monkeypatch.setattr(agents, "_repair_script", lambda **_kwargs: repaired)
    code, issues = agents.repair_trial_script(
        script=original,
        row={"id": "tc-requirement-delete", "name": "删除需求文档"},
        failure={"error_message": "缺少删除终态断言"},
        llm=LLM,
    )
    assert issues == []
    assert code == repaired


def test_repair_trial_script_rejects_invented_locator(monkeypatch) -> None:
    original = (
        "async function run(page, agent) {\n"
        "  await page.getByText('需求文档').click();\n"
        "}\n"
    )
    repaired = (
        "async function run(page, agent) {\n"
        "  await page.getByText('凭空出现的定位器').click();\n"
        "}\n"
    )
    monkeypatch.setattr(agents, "_repair_script", lambda **_kwargs: repaired)
    code, issues = agents.repair_trial_script(
        script=original,
        row={"id": "tc-view", "name": "查看需求"},
        failure={"error_message": "locator failed", "failure_snapshot": "需求文档"},
        llm=LLM,
    )
    assert code == original
    assert any("无失败现场依据" in issue for issue in issues)


def test_verify_and_repair_rejects_invented_locator(monkeypatch) -> None:
    original = (
        "async function run(page, agent) {\n"
        "  await page.getByText('需求文档').click();\n"
        "  await expect(page.getByText('需求文档')).toBeVisible();\n"
        "}\n"
    )
    repaired = (
        "async function run(page, agent) {\n"
        "  await page.getByText('凭空出现的定位器').click();\n"
        "  await expect(page.getByText('需求文档')).toBeVisible();\n"
        "}\n"
    )
    calls = {"n": 0}

    def execute(**_kwargs: Any) -> list[dict[str, Any]]:
        calls["n"] += 1
        return [
            {
                "status": "failed",
                "error_message": "locator failed",
                "failure_snapshot": "需求文档",
            }
        ]

    monkeypatch.setattr(agents, "_repair_script", lambda **_kwargs: repaired)
    result = agents.verify_and_repair(
        row={"id": "tc-view", "name": "查看需求"},
        script=original,
        llm=LLM,
        runner_kwargs={},
        max_repair=1,
        execute=execute,
    )
    assert calls["n"] == 1
    assert result["code"] == original
    assert result["verify_status"] == "failed"
    assert "无失败现场依据" in result["verify_error"]


def test_repair_trial_script_allows_standard_dialog_role(monkeypatch) -> None:
    original = (
        "async function run(page, agent) {\n"
        "  await page.getByText('需求文档').click();\n"
        "  await expect(page.getByText('需求文档')).toBeVisible();\n"
        "}\n"
    )
    repaired = original.replace(
        "  await expect",
        "  const dialog = page.getByRole('dialog');\n"
        "  await expect(dialog).toBeVisible();\n"
        "  await expect",
    )
    monkeypatch.setattr(agents, "_repair_script", lambda **_kwargs: repaired)
    code, issues = agents.repair_trial_script(
        script=original,
        row={"id": "tc-view", "name": "查看需求"},
        failure={"error_message": "需要等待弹窗", "failure_snapshot": "- dialog: 编辑需求"},
        llm=LLM,
    )
    assert issues == []
    assert code == repaired


def test_semantic_guard_rejects_root_only_mutation_without_navigation() -> None:
    script = """
async function run(page, agent) {
  await page.goto('/');
  const row = page.getByRole('row', { name: /需求文档/ });
  await row.getByRole('button', { name: '删除' }).click();
  await expect(row).toHaveCount(0);
}
"""
    issues = agents.script_semantic_issues(
        script, {"id": "tc-requirement-delete", "name": "删除需求文档"}
    )
    assert any("缺少进入目标项目/模块" in issue for issue in issues)


def test_run_codegen_pipeline_no_template_on_failure(monkeypatch) -> None:
    monkeypatch.setattr(agents.settings, "ui_codegen_guard", "strict")

    def bad_code_case(**_kwargs: Any) -> tuple[str, list[str]]:
        return "", ["定位器无探索依据: 幻觉"]

    monkeypatch.setattr(agents, "code_case", bad_code_case)
    matrix = [
        {
            "id": "TC-01",
            "name": "新增用户",
            "ready": True,
            "steps": [
                {
                    "action": "click",
                    "name": "新增用户",
                    "role": "button",
                    "cli_locator": "page.getByRole('button', { name: '新增用户' })",
                    "driver": "playwright",
                    "ready": True,
                }
            ],
        }
    ]
    rows, _ = agents.run_codegen_pipeline(
        matrix=matrix,
        trace=_trace(),
        llm=LLM,
        base_url="https://app.test",
        ctx={},
        verify=False,
    )
    assert rows[0]["code"] == ""
    assert rows[0]["ready"] is False
    assert rows[0]["guard_errors"]


def test_run_codegen_pipeline_always_calls_casecoder(monkeypatch) -> None:
    called = {"n": 0}
    good = (
        "async function run(page, agent) {\n"
        "  await page.getByRole('button', { name: '保存' }).click();\n"
        "  await expect(page.getByText('ok')).toBeVisible();\n"
        "}\n"
    )

    def track_code_case(**_kwargs: Any) -> tuple[str, list[str]]:
        called["n"] += 1
        return good, []

    monkeypatch.setattr(agents, "code_case", track_code_case)
    matrix = [
        {
            "id": "TC-01",
            "name": "主流程",
            "ready": True,
            "steps": [
                {
                    "action": "click",
                    "name": "保存",
                    "role": "button",
                    "cli_locator": "page.getByRole('button', { name: '保存' })",
                    "driver": "playwright",
                    "ready": True,
                }
            ],
        }
    ]
    rows, _ = agents.run_codegen_pipeline(
        matrix=matrix,
        trace=[],
        llm=LLM,
        base_url="https://app.test",
        ctx={},
        verify=False,
    )
    assert called["n"] == 1
    assert "getByRole" in rows[0]["code"]


def test_run_codegen_pipeline_skips_headless_verify(monkeypatch) -> None:
    executed = False

    def execute(**_kwargs: Any) -> list[dict[str, Any]]:
        nonlocal executed
        executed = True
        return []

    script = (
        "async function run(page, agent) {\n"
        "  await page.goto('/');\n"
        "  await expect(page).toBeVisible();\n"
        "}\n"
    )
    monkeypatch.setattr(agents, "code_case", lambda **_kwargs: (script, []))
    matrix = [
        {
            "id": "TC-01",
            "name": "主流程",
            "ready": True,
            "steps": [{"action": "goto", "target": "/", "driver": "playwright", "ready": True}],
        }
    ]
    rows, auth_path = agents.run_codegen_pipeline(
        matrix=matrix,
        trace=[],
        llm=LLM,
        base_url="https://app.test",
        ctx={},
        verify=False,
        execute=execute,
    )
    assert executed is False
    assert auth_path is None
    assert len(rows) == 1
    assert rows[0]["verify_status"] == "skipped"
    assert rows[0]["ready"] is True
    assert "async function run" in rows[0]["code"]


def test_navigation_context_uses_observed_module_path_and_menu_prefix() -> None:
    trace = [
        {
            "kind": "goto",
            "path": "/",
            "status": "ok",
            "observe": {"url_after": "https://app.test/"},
        },
        {
            "kind": "click",
            "role": "link",
            "name": "进入项目",
            "status": "ok",
            "observe": {"url_after": "https://app.test/projects/7"},
        },
        {
            "kind": "click",
            "role": "link",
            "name": "需求管理",
            "status": "ok",
            "observe": {"url_after": "https://app.test/projects/7/requirements"},
        },
        {
            "kind": "click",
            "role": "button",
            "name": "删除",
            "case_id": "TC-DELETE",
            "status": "ok",
        },
    ]
    nav = agents._navigation_context(trace, {"id": "TC-DELETE"})
    assert nav["start_path"] == "/projects/7/requirements"
    assert [step.get("name") for step in nav["steps"] if step.get("name")] == [
        "进入项目",
        "需求管理",
    ]
