"""PlaywrightCliSession explore snapshot (depth + DOM modal appendix)."""

from __future__ import annotations

from unittest.mock import MagicMock

from app.services.ui_automation.playwright_cli_session import PlaywrightCliSession


def test_snapshot_text_has_dialog():
    assert PlaywrightCliSession.snapshot_text_has_dialog('- dialog "新建"\n') is True
    assert (
        PlaywrightCliSession.snapshot_text_has_dialog('- button "新建" [ref=e1]\n')
        is False
    )


def test_snapshot_for_explore_retries_depth_then_appends_dom():
    cli = PlaywrightCliSession.__new__(PlaywrightCliSession)
    cli.snapshot = MagicMock(side_effect=["- button [ref=e1]", "- button [ref=e1]"])
    cli.dom_modal_visible = MagicMock(return_value=True)
    cli._dom_dialog_snapshot_appendix = MagicMock(
        return_value='- dialog "（DOM 可见弹窗）"\n  - textbox "名称" [ref=dom1]'
    )
    out = PlaywrightCliSession.snapshot_for_explore(cli, depth=8, retry_depth=16)
    assert cli.snapshot.call_count == 2
    assert 'dialog "（DOM 可见弹窗）"' in out
    assert "名称" in out
