"""cli_ready() should detect missing @playwright/cli Chromium."""

from __future__ import annotations

import os
from unittest.mock import patch

from app.services.ui_automation.playwright_cli_session import cli_ready


def test_cli_ready_warns_when_chromium_executable_missing(tmp_path) -> None:
    fake_exe = tmp_path / "no-chromium"
    with (
        patch(
            "app.services.ui_automation.playwright_cli_session._RUNNER_DIR",
            tmp_path / "ui-runner",
        ),
        patch(
            "app.services.ui_automation.playwright_cli_session._cli_chromium_executable_path",
            return_value=str(fake_exe),
        ),
    ):
        (tmp_path / "ui-runner" / "node_modules" / "@playwright" / "cli").mkdir(parents=True)
        msg = cli_ready()
    assert msg
    assert "install-browser chrome-for-testing" in msg
    assert str(fake_exe) in msg


def test_cli_ready_ok_when_executable_exists(tmp_path) -> None:
    exe = tmp_path / "chrome"
    exe.write_text("x", encoding="utf-8")
    with (
        patch(
            "app.services.ui_automation.playwright_cli_session._RUNNER_DIR",
            tmp_path / "ui-runner",
        ),
        patch(
            "app.services.ui_automation.playwright_cli_session._cli_chromium_executable_path",
            return_value=str(exe),
        ),
    ):
        (tmp_path / "ui-runner" / "node_modules" / "@playwright" / "cli").mkdir(parents=True)
        # make executable on unix
        os.chmod(exe, 0o755)
        assert cli_ready() is None
