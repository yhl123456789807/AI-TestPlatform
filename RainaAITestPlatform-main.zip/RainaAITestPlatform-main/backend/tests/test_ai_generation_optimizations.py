import json
from unittest.mock import MagicMock, patch

import httpx
import pytest
from pydantic import TypeAdapter

from app.api.ai.ai_generate import (
    _build_retrieval_query,
)
from app.errors import AppError
from app.models.functional.requirement import Requirement
from app.models.identity.user import User
from app.models.project.project import Project
from app.schemas.ai.ai_agent import (
    AgentArtifacts as PipelineArtifacts,
    RequirementAnalysisOut,
    TestPointOut as AgentTestPointOut,
    TestPointsResponse as GeneratedTestPointsResponse,
)
from app.schemas.ai.ai_gen import AiGenerateRequest, ChatMessage, GeneratedCase
from app.services.ai.ai_gen_pipeline import (
    _json_complete_with_retry,
    _cases_from_points_prompt,
    _iter_cases_and_review,
    _test_points_prompt,
    iter_case_review,
)
from app.services.ai.ai_case_common import trim_chat_messages
from app.services.ai.ai_http_errors import check_ai_http_response
from app.services.ai.embedding import MAX_EMBEDDING_INPUT_CHARS, _clean_embedding_texts
from tests.conftest import TestingSessionLocal


def test_embedding_inputs_are_trimmed_and_limited():
    cleaned = _clean_embedding_texts(["  hello  ", "中" * 3000])
    assert cleaned[0] == "hello"
    assert len(cleaned[1]) == MAX_EMBEDDING_INPUT_CHARS
    with pytest.raises(AppError, match="Embedding 输入为空"):
        _clean_embedding_texts(["  "])


def test_embedding_http_400_includes_upstream_message():
    request = httpx.Request("POST", "https://example.test/embeddings")
    response = httpx.Response(
        400,
        request=request,
        json={"error": {"message": "Range of input length should be [1, 2048]"}},
    )
    with pytest.raises(AppError) as caught:
        check_ai_http_response(response, "Embedding")
    assert caught.value.status_code == 400
    assert "Range of input length" in caught.value.message


def test_retrieval_query_is_short_and_does_not_repeat_injected_requirement():
    db = TestingSessionLocal()
    try:
        user = User(username="query_limit", password_hash="x", is_active=True)
        db.add(user)
        db.flush()
        project = Project(name="query-limit", description="", owner_id=user.id)
        db.add(project)
        db.flush()
        requirement = Requirement(
            project_id=project.id,
            title="超长需求",
            body_md="验收正文" * 2000,
        )
        db.add(requirement)
        db.commit()
        body = AiGenerateRequest(
            requirement_id=requirement.id,
            messages=[ChatMessage(role="user", content="只关注登录边界")],
        )
        injected = [
            ChatMessage(role="user", content="需求标题: 超长需求\n" + "验收正文" * 2000)
        ]
        query = _build_retrieval_query(db, project.id, body, injected)
        assert len(query) <= MAX_EMBEDDING_INPUT_CHARS
        assert query.count("需求标题:") == 1
        assert "只关注登录边界" in query
    finally:
        db.close()


def test_chat_history_keeps_first_and_recent_messages():
    messages = [
        ChatMessage(role="user" if i % 2 == 0 else "assistant", content=f"m{i}")
        for i in range(14)
    ]
    trimmed = trim_chat_messages(messages)
    assert trimmed[0].content == "m0"
    assert "已省略" in trimmed[1].content
    assert trimmed[-1].content == "m13"


def test_test_point_module_round_trip_and_prompts():
    point = AgentTestPointOut.model_validate(
        {
            "id": "TP-01",
            "module": "登录与认证",
            "title": "正常登录",
            "category": "功能",
        }
    )
    assert point.model_dump()["module"] == "登录与认证"
    assert "module" in _test_points_prompt()
    prompt = _cases_from_points_prompt()
    assert "继承对应测试点" in prompt
    assert "恰好生成 1 条" in prompt
    assert "test_point_id" in prompt
    assert "不超过 40" not in prompt


def test_generated_test_points_require_module_but_legacy_artifacts_load():
    legacy = {
        "requirement_analysis": {
            "is_clear": True,
            "summary": "登录",
            "ambiguities": [],
            "questions": [],
        },
        "test_points": [
            {"id": "TP-01", "title": "正常登录", "category": "功能"}
        ],
    }
    artifacts = PipelineArtifacts.model_validate(legacy)
    assert artifacts.test_points[0].module == ""
    with pytest.raises(ValueError, match="missing non-empty module"):
        GeneratedTestPointsResponse.model_validate(
            {"test_points": legacy["test_points"]}
        )


@patch("app.services.ai.ai_gen_pipeline.llm.chat_complete")
def test_json_retry_emits_user_friendly_log_events(mock_complete):
    mock_complete.side_effect = [
        "not-json",
        '{"is_clear":true,"summary":"登录","ambiguities":[],"questions":[]}',
    ]
    retry_events: list[dict] = []
    result = _json_complete_with_retry(
        [{"role": "user", "content": "分析需求"}],
        adapter=TypeAdapter(RequirementAnalysisOut),
        use_llm_model="test",
        llm_cfg=MagicMock(),
        retry_user_hint="请修复 JSON",
        phase="requirement_analysis",
        retry_events=retry_events,
    )
    assert result.is_clear is True
    assert [event["level"] for event in retry_events] == ["warning", "success"]
    assert "自动修复" in retry_events[0]["message"]


@patch("app.services.ai.ai_gen_pipeline.llm.chat_complete")
def test_review_gets_requirement_and_restores_silent_deletion(mock_complete):
    mock_complete.return_value = (
        '{"summary":"完成","issues":[],"dimension_scores":{"coverage":4},'
        '"cases":[{"title":"保留项","overall_expected":"ok","steps":[{"action":"a"}]}]}'
    )
    drafts = [
        GeneratedCase(title="保留项", overall_expected="ok", steps=[{"action": "a"}]),
        GeneratedCase(title="被静默删除", overall_expected="ok", steps=[{"action": "b"}]),
    ]
    events = list(
        iter_case_review(
            draft_cases=drafts,
            dims=[MagicMock(key="coverage", weight=5)],
            use_llm_model="test",
            llm_cfg=MagicMock(),
            context="知识片段",
            requirement_text="需求原文内容",
        )
    )
    done = next(event for event in events if event["type"] == "review_done")
    assert [case.title for case in done["cases"]] == ["保留项", "被静默删除"]
    review_messages = mock_complete.call_args.args[0]
    assert "需求原文内容" in review_messages[1]["content"]


def _point(index: int) -> AgentTestPointOut:
    return AgentTestPointOut(
        id=f"TP-{index:02d}",
        module="登录",
        title=f"测试点{index}",
        category="功能",
    )


def _cases_json(indexes: list[int], *, with_point_id: bool = True) -> str:
    cases = []
    for index in indexes:
        item = {
            "title": f"用例{index}",
            "overall_expected": "ok",
            "steps": [{"action": "执行"}],
        }
        if with_point_id:
            item["test_point_id"] = f"TP-{index:02d}"
        cases.append(item)
    return json.dumps({"cases": cases}, ensure_ascii=False)


def _run_case_generation(points: list[AgentTestPointOut]) -> list[dict]:
    analysis = RequirementAnalysisOut(is_clear=True, summary="登录")
    artifacts = PipelineArtifacts(requirement_analysis=analysis, test_points=points)
    return list(
        _iter_cases_and_review(
            context="知识片段",
            analysis=analysis,
            test_points=points,
            artifacts=artifacts,
            use_llm_model="test",
            llm_cfg=MagicMock(),
            enable_case_review=False,
        )
    )


@patch("app.services.ai.ai_gen_pipeline.llm.chat_complete_stream")
def test_case_generation_batches_and_retries_missing_points(mock_stream):
    points = [_point(index) for index in range(1, 13)]
    payloads = [
        _cases_json(list(range(1, 10))),
        _cases_json([10]),
        _cases_json([11, 12]),
    ]

    def fake_stream(*_args, **_kwargs):
        yield payloads.pop(0)

    mock_stream.side_effect = fake_stream
    events = _run_case_generation(points)
    done = next(event for event in events if event["type"] == "done")
    assert [case["test_point_id"] for case in done["cases"]] == [
        f"TP-{index:02d}" for index in range(1, 13)
    ]
    assert mock_stream.call_count == 3
    retry_request = mock_stream.call_args_list[1].args[0][1]["content"]
    assert "TP-10" in retry_request
    assert "TP-01" not in retry_request
    warnings = [
        event["message"]
        for event in events
        if event.get("type") == "log" and event.get("level") == "warning"
    ]
    assert any("正在补生成" in message for message in warnings)
    assert not any("未生成用例" in message for message in warnings)
    assert any("覆盖 12/12" in event.get("message", "") for event in events)
    batches = [event for event in events if event["type"] == "cases_batch"]
    assert [len(event["cases"]) for event in batches] == [10, 2]
    assert [event["count"] for event in batches] == [10, 12]
    assert [case["test_point_id"] for case in batches[0]["cases"]] == [
        f"TP-{index:02d}" for index in range(1, 11)
    ]
    assert not any(
        event.get("type") == "status" and str(event.get("message", "")).startswith("正在生成用例（")
        for event in events
    )


@patch("app.services.ai.ai_gen_pipeline.llm.chat_complete_stream")
def test_case_generation_logs_points_still_missing_after_retry(mock_stream):
    def fake_stream(*_args, **_kwargs):
        yield _cases_json([1], with_point_id=False)

    mock_stream.side_effect = fake_stream
    events = _run_case_generation([_point(1)])
    warnings = [
        event["message"]
        for event in events
        if event.get("type") == "log" and event.get("level") == "warning"
    ]
    assert mock_stream.call_count == 2
    assert any("未生成用例" in message and "TP-01" in message for message in warnings)
    assert any("覆盖 0/1" in event.get("message", "") for event in events)


@patch("app.services.ai.ai_gen_pipeline.llm.chat_complete")
def test_review_restores_test_point_removed_with_an_issue(mock_complete):
    mock_complete.return_value = json.dumps(
        {
            "summary": "合并了一条",
            "issues": [
                {
                    "case_title": "明示删除",
                    "issue_type": "redundancy",
                    "detail": "与保留项重复，删除明示删除",
                }
            ],
            "dimension_scores": {"redundancy": 4},
            "cases": [
                {
                    "title": "保留项",
                    "test_point_id": "TP-01",
                    "overall_expected": "ok",
                    "steps": [{"action": "a"}],
                }
            ],
        },
        ensure_ascii=False,
    )
    drafts = [
        GeneratedCase(
            title="保留项",
            test_point_id="TP-01",
            overall_expected="ok",
            steps=[{"action": "a"}],
        ),
        GeneratedCase(
            title="静默删除",
            test_point_id="TP-02",
            overall_expected="ok",
            steps=[{"action": "b"}],
        ),
        GeneratedCase(
            title="明示删除",
            test_point_id="TP-03",
            overall_expected="ok",
            steps=[{"action": "c"}],
        ),
    ]
    events = list(
        iter_case_review(
            draft_cases=drafts,
            dims=[MagicMock(key="redundancy", weight=5)],
            use_llm_model="test",
            llm_cfg=MagicMock(),
        )
    )
    done = next(event for event in events if event["type"] == "review_done")
    assert [case.title for case in done["cases"]] == ["保留项", "静默删除", "明示删除"]
    assert [case.test_point_id for case in done["cases"]] == ["TP-01", "TP-02", "TP-03"]
    review_prompt = mock_complete.call_args.args[0][0]["content"]
    assert "不得合并不同 test_point_id" in review_prompt
    assert any("已按草稿补回" in event.get("message", "") for event in events)
