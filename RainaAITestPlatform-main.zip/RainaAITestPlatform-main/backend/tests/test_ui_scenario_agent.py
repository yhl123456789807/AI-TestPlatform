from unittest.mock import patch

from cryptography.fernet import Fernet
from fastapi.testclient import TestClient

from app.config import settings
from app.main import app
from app.models.identity.user import User
from app.services.identity import auth_service
from app.services.ui_automation.ui_scenario_agent import (
    build_plan_from_prompt,
    credentials_to_ctx,
    extract_credentials_from_text,
    resolve_plan_browser_auth,
)
from tests.conftest import TestingSessionLocal


def test_ui_scenario_events_receive_stable_sequence_without_mutating_source():
    from app.api.ui_automation.ui_scenario_agent import (
        _event_with_seq,
        _events_with_seq,
    )

    source = [
        {"type": "log", "message": "first"},
        {"type": "trial_done", "status": "passed"},
    ]

    sequenced = _events_with_seq(source)

    assert [event["seq"] for event in sequenced] == [0, 1]
    assert "seq" not in source[0]
    assert sequenced[0]["message"] == "first"
    assert _event_with_seq(source[1], 1) == sequenced[1]


def _user(username: str, pw: str):
    db = TestingSessionLocal()
    try:
        db.add(User(username=username, password_hash=auth_service.hash_password(pw), is_active=True))
        db.commit()
    finally:
        db.close()


def _login(username: str, pw: str) -> str:
    r = TestClient(app).post("/api/v1/auth/login", json={"username": username, "password": pw})
    assert r.status_code == 200
    return r.json()["access_token"]


def _project(token: str, name: str = "UISA") -> int:
    r = TestClient(app).post(
        f"/api/v1/projects/",
        headers={"Authorization": f"Bearer {token}"},
        json={"name": name},
    )
    assert r.status_code == 201
    return r.json()["id"]


def test_build_plan_from_prompt_has_empty_matrix(monkeypatch):
    from app.services.ai.effective_ai_settings import LlmRuntime
    from app.services.ui_automation.ui_scenario_agent import credentials_from_plan

    captured: dict = {}

    def fake_chat(messages, **kwargs):
        captured["messages"] = messages
        return (
            '{"goal":"登录后项目管理","start_path":"/login",'
            '"checklist":["登录","项目列表","新建"],"case_name":"项目管理",'
            '"username":"admin","password":"admin123"}'
        )

    monkeypatch.setattr(
        "app.services.ui_automation.ui_scenario_agent.llm.chat_complete",
        fake_chat,
    )
    plan = build_plan_from_prompt(
        prompt="登录系统 admin admin123 后做项目",
        base_url="https://ex.com",
        llm_cfg=LlmRuntime(api_base="https://example.com/v1", api_key="k", model="m", allowed_models_csv=""),
    )
    assert plan["case_scripts"] == []
    assert plan["goal"]
    assert len(plan["checklist"]) >= 1
    assert plan.get("_sequential_matrix") and len(plan.get("matrix") or []) >= 2
    assert "不要输出 matrix" in captured["messages"][0]["content"]
    assert "创建项目" not in captured["messages"][0]["content"]
    assert "规划提示" in captured["messages"][1]["content"] or "业务操作" in captured["messages"][0]["content"]
    assert "username" in captured["messages"][0]["content"]
    creds = credentials_from_plan(plan)
    assert creds.get("username") == "admin"
    assert creds.get("password") == "admin123"
    assert "_extracted_username" not in plan


def test_build_plan_from_prompt_falls_back_on_bad_json(monkeypatch):
    from app.services.ai.effective_ai_settings import LlmRuntime

    def fake_chat(messages, **kwargs):
        return '{"goal": "坏掉的 "JSON", "start_path": "/"}'

    monkeypatch.setattr(
        "app.services.ui_automation.ui_scenario_agent.llm.chat_complete",
        fake_chat,
    )
    plan = build_plan_from_prompt(
        prompt="1、登录\n2、创建项目",
        base_url="https://ex.com",
        llm_cfg=LlmRuntime(api_base="https://example.com/v1", api_key="k", model="m", allowed_models_csv=""),
    )
    assert plan["goal"]
    assert plan["start_path"].startswith("/")
    assert len(plan["checklist"]) >= 1
    assert len(plan.get("matrix") or []) >= 1


def test_revise_script_asks_for_python_not_json(monkeypatch):
    captured: dict = {}

    def fake_chat(messages, **kwargs):
        captured["messages"] = messages
        captured.update(kwargs)
        return "def run(page):\n    page.goto('/home')\n"

    monkeypatch.setattr(
        "app.services.ui_automation.ui_scenario_agent.llm.chat_complete",
        fake_chat,
    )
    from app.services.ai.effective_ai_settings import LlmRuntime
    from app.services.ui_automation.ui_scenario_agent import revise_script_with_llm

    code = revise_script_with_llm(
        script="def run(page):\n    page.goto('/')\n",
        instruction="改成打开 /home",
        plan={"goal": "登录"},
        llm_cfg=LlmRuntime(api_base="https://example.com/v1", api_key="k", model="m", allowed_models_csv=""),
    )
    assert code.startswith("def run(page):")
    assert captured["json_mode"] is False
    assert "只输出 Python" in captured["messages"][0]["content"]


def test_revise_node_script_includes_midscene_policy(monkeypatch):
    captured: dict = {}

    def fake_chat(messages, **kwargs):
        captured["messages"] = messages
        return (
            "async function run(page, agent) {\n"
            "  await page.goto('/home');\n"
            "}\n"
        )

    monkeypatch.setattr(
        "app.services.ui_automation.ui_scenario_agent.llm.chat_complete",
        fake_chat,
    )
    from app.services.ai.effective_ai_settings import LlmRuntime
    from app.services.ui_automation.ui_scenario_agent import revise_script_with_llm
    from app.services.ui_automation.ui_script_midscene_policy import MIDSCENE_SCRIPT_POLICY

    revise_script_with_llm(
        script="async function run(page, agent) {\n  await page.goto('/');\n}\n",
        instruction="打开 /home",
        plan={"goal": "导航"},
        llm_cfg=LlmRuntime(api_base="https://example.com/v1", api_key="k", model="m", allowed_models_csv=""),
    )
    system = captured["messages"][0]["content"]
    assert MIDSCENE_SCRIPT_POLICY in system
    assert "禁止新增 agent.aiTap" in system


def test_apply_user_message_writes_back_case_scripts(monkeypatch):
    from types import SimpleNamespace
    from unittest.mock import MagicMock

    from app.services.ai.effective_ai_settings import LlmRuntime
    from app.services.ui_automation.ui_scenario_agent import apply_user_message

    old = "async function run(page, agent) {\n  await page.goto('/');\n}\n"
    new = "async function run(page, agent) {\n  await page.goto('/home');\n}\n"
    session = SimpleNamespace(
        status="awaiting_confirm",
        playwright_code=old,
        plan_json={
            "goal": "CRUD",
            "case_scripts": [
                {"id": "TC-001", "name": "CRUD", "ready": True, "code": old},
            ],
        },
        messages_json=[],
        events_json=[],
        credentials_json=None,
        thread_id="tid-revise",
        project_id=1,
        env_id=None,
        prompt="",
        dry_run_status=None,
        dry_run_error="",
        error_message="",
    )
    db = MagicMock()
    monkeypatch.setattr(
        "app.services.ui_automation.ui_scenario_agent.revise_script_with_llm",
        lambda **kwargs: new,
    )
    monkeypatch.setattr(
        "app.services.ui_automation.ui_scenario_agent.emit_log",
        lambda *a, **k: None,
    )

    apply_user_message(
        db,
        session,  # type: ignore[arg-type]
        "起始改成 /home",
        case_id="TC-001",
        llm_cfg=LlmRuntime(
            api_base="https://example.com/v1",
            api_key="k",
            model="m",
            allowed_models_csv="",
        ),
    )
    assert session.playwright_code == new
    assert session.plan_json["case_scripts"][0]["code"] == new
    assert session.status == "awaiting_confirm"
    asst = [m for m in session.messages_json if m.get("role") == "assistant"]
    assert asst and "TC-001" in asst[-1]["content"]


def test_apply_user_message_error_reexplore_applies_tune(monkeypatch):
    from types import SimpleNamespace
    from unittest.mock import MagicMock

    from app.services.ai.effective_ai_settings import LlmRuntime
    from app.services.ui_automation.ui_scenario_agent import apply_user_message

    session = SimpleNamespace(
        id=99,
        status="error",
        playwright_code="",
        plan_json={
            "_headed": True,
            "_auth_mode": None,
            "_single_case": False,
            "_testcase_ids": [],
        },
        messages_json=[],
        events_json=[],
        credentials_json=None,
        thread_id="tid-retune",
        project_id=1,
        env_id=10,
        browser="chromium",
        testcase_id=None,
        prompt="旧目标",
        dry_run_status=None,
        dry_run_error="",
        error_message="已手动停止探索",
        celery_task_id=None,
    )
    db = MagicMock()
    env = SimpleNamespace(id=22, queue_name="ui")
    enqueued: list[tuple[int, str]] = []

    monkeypatch.setattr(
        "app.services.ui_automation.ui_scenario_agent.resolve_env",
        lambda _db, _pid, _env_id: env,
    )
    monkeypatch.setattr(
        "app.services.ui_automation.ui_scenario_agent.emit_log",
        lambda *a, **k: None,
    )

    def _enqueue(sid: int, queue: str) -> str:
        enqueued.append((sid, queue))
        return "task-1"

    apply_user_message(
        db,
        session,  # type: ignore[arg-type]
        "改成无头并绑定功能用例",
        llm_cfg=LlmRuntime(
            api_base="https://example.com/v1",
            api_key="k",
            model="m",
            allowed_models_csv="",
        ),
        enqueue_explore=_enqueue,
        explore_tune={
            "env_id": 22,
            "browser": "firefox",
            "headed": False,
            "auth_mode": "none",
            "testcase_ids": [11, 12],
        },
    )

    assert session.status == "running"
    assert session.env_id == 22
    assert session.browser == "firefox"
    assert session.testcase_id == 11
    assert session.error_message == ""
    assert session.plan_json["_headed"] is False
    assert session.plan_json["_auth_mode"] == "none"
    assert session.plan_json["_testcase_ids"] == [11, 12]
    assert session.plan_json["_bound_functional_cases"] is True
    assert session.plan_json["_single_case"] is False
    assert enqueued == [(99, "ui")]
    assert session.celery_task_id == "task-1"
    assert "改成无头并绑定功能用例" in (session.prompt or "")


def test_extract_credentials_from_text():
    c = extract_credentials_from_text("账号 demo 密码 secret123，登录后打开列表")
    assert c.get("username") == "demo"
    assert c.get("password") == "secret123"
    colon = extract_credentials_from_text("账号：admin；密码：admin123；图片验证码：按页面实际显示正确填写")
    assert colon.get("username") == "admin"
    assert colon.get("password") == "admin123"
    step = extract_credentials_from_text(
        "1. 打开登录页 2. 输入用户名 admin 与密码 admin123 3. 点击登录"
    )
    assert step.get("username") == "admin"
    assert step.get("password") == "admin123"
    ctx = credentials_to_ctx(c)
    assert ctx["LOGIN_USERNAME"] == "demo"
    assert ctx["LOGIN_PASSWORD"] == "secret123"
    # Always string keys even when empty
    empty = credentials_to_ctx({})
    assert empty["username"] == ""
    assert empty["password"] == ""


def test_extract_credentials_combo_账号密码():
    from app.services.ui_automation.ui_scenario_agent import script_env_from_ctx
    from app.services.ui_automation.node_ui_runner import _script_env

    c = extract_credentials_from_text("账号密码：admin admin123\n完成登录 创建项目、需求")
    assert c.get("username") == "admin"
    assert c.get("password") == "admin123"
    c2 = extract_credentials_from_text("账号密码 admin admin123")
    assert c2.get("username") == "admin"
    assert c2.get("password") == "admin123"
    env = script_env_from_ctx(credentials_to_ctx(c))
    assert env["username"] == "admin"
    assert env["password"] == "admin123"
    assert _script_env({}).get("username") == ""
    assert _script_env({}).get("password") == ""
    assert "username" in _script_env({"foo": "bar"})


def test_extract_credentials_登录系统_user_pass():
    """「登录系统 admin admin123」must bind credentials (not only 账号密码 …)."""
    c = extract_credentials_from_text(
        "登录系统 admin admin123\n创建项目、创建需求、完成需求的 CRUD"
    )
    assert c.get("username") == "admin"
    assert c.get("password") == "admin123"
    c2 = extract_credentials_from_text("登录 admin admin123 然后打开项目")
    assert c2.get("username") == "admin"
    assert c2.get("password") == "admin123"
    # Outcome-only phrases still rejected
    assert extract_credentials_from_text("登录成功") == {}
    assert extract_credentials_from_text("登录系统 成功 失败") == {}


def test_extract_credentials_rejects_title_outcome_登录成功():
    """Title 「用户名密码登录成功」+ step index must not become username=登录成功."""
    title = "已审批启用用户使用正确用户名密码登录成功"
    steps = "1. 打开登录页\n2. 输入用户名 admin 与密码 admin123\n3. 点击登录"
    # Title alone / title+noise must not yield outcome tokens
    assert extract_credentials_from_text(title) == {}
    assert extract_credentials_from_text(title + "\n1. 打开登录页").get("username") != "登录成功"
    # Steps (or title+steps) yield real creds
    joined = extract_credentials_from_text(title + "\n" + steps)
    assert joined.get("username") == "admin"
    assert joined.get("password") == "admin123"
    # Step-only prose (production scrape excludes title)
    only_steps = extract_credentials_from_text(steps)
    assert only_steps.get("username") == "admin"
    assert only_steps.get("password") == "admin123"


def test_ui_scenario_agent_confirm_writes_case(monkeypatch):
    key = Fernet.generate_key().decode()
    monkeypatch.setattr(settings, "settings_encryption_key", key)

    from app.services.ai.effective_ai_settings import LlmRuntime
    from app.api.ui_automation import ui_scenario_agent as agent_api

    monkeypatch.setattr(
        "app.api.ui_automation.ui_scenario_agent.get_llm_runtime",
        lambda db: LlmRuntime(
            api_base="https://example.com/v1",
            api_key="test-key",
            model="m",
            allowed_models_csv="m",
        ),
    )

    _user("uisa_a", "p")
    tok = _login("uisa_a", "p")
    pid = _project(tok, "UISA1")
    client = TestClient(app)
    h = {"Authorization": f"Bearer {tok}"}

    er = client.post(
        f"/api/v1/projects/{pid}/ui-envs/",
        headers=h,
        json={"name": "local", "base_url": "https://app.example.com", "is_default": True},
    )
    assert er.status_code == 201, er.text
    env_id = er.json()["id"]

    def fake_explore(db, session_id: int) -> None:
        from app.models.ui_automation.ui_automation import UiScenarioAgentSession
        from app.services.api_automation.api_scenario_events import get_event_bus

        row = db.get(UiScenarioAgentSession, session_id)
        assert row is not None
        row.status = "awaiting_confirm"
        row.plan_json = {"goal": "打开首页", "start_path": "/", "checklist": [], "case_name": "打开首页"}
        row.trace_json = [
            {"action": "goto", "value": "/", "status": "ok"},
            {"action": "assert_url", "value": "/", "status": "ok"},
            {"action": "done", "status": "ok"},
        ]
        row.result_steps_json = [
            {"action": "goto", "value": "/"},
            {"action": "assert_url", "value": "/"},
        ]
        row.playwright_code = 'def run(page):\n    page.goto("/")\n'
        row.dry_run_status = "passed"
        row.dry_run_error = ""
        msgs = list(row.messages_json) if isinstance(row.messages_json, list) else []
        msgs.append({"role": "assistant", "content": "已生成 2 步。"})
        row.messages_json = msgs
        get_event_bus().append(row.thread_id, {"type": "interrupted", "message": "等待确认"})
        get_event_bus().append(row.thread_id, {"type": "done", "status": "awaiting_confirm"})
        db.commit()

    agent_api.set_explore_runner(fake_explore)
    try:
        cr = client.post(
            f"/api/v1/projects/{pid}/ui-scenario-agent/sessions",
            headers=h,
            json={
                "prompt": "账号 demo 密码 xxx，打开首页",
                "env_id": env_id,
                "browser": "chromium",
            },
        )
        assert cr.status_code == 201, cr.text
        sess = cr.json()
        assert sess["status"] == "awaiting_confirm"
        assert sess["has_credentials"] is True
        assert len(sess["result_steps"]) == 2

        # revise without re-explore: mock LLM revise
        with patch(
            "app.services.ui_automation.ui_scenario_agent.revise_script_with_llm",
            return_value='def run(page):\n    page.goto("/home")\n',
        ):
            mr = client.post(
                f"/api/v1/projects/{pid}/ui-scenario-agent/sessions/{sess['id']}/messages",
                headers=h,
                json={"content": "起始路径改成 /home"},
            )
        assert mr.status_code == 200, mr.text
        assert 'page.goto("/home")' in mr.json()["playwright_code"]

        conf = client.post(
            f"/api/v1/projects/{pid}/ui-scenario-agent/sessions/{sess['id']}/confirm",
            headers=h,
            json={"action": "confirm", "name": "打开首页 (Agent)", "status": "ready"},
        )
        assert conf.status_code == 200, conf.text
        assert conf.json()["status"] == "confirmed"
        assert conf.json()["saved_ui_case_id"] is not None
        assert conf.json()["saved_ui_suite_id"] is not None

        case_id = conf.json()["saved_ui_case_id"]
        suite_id = conf.json()["saved_ui_suite_id"]
        sr = client.get(f"/api/v1/projects/{pid}/ui-suites/{suite_id}", headers=h)
        assert sr.status_code == 200
        assert sr.json()["case_ids"] == [case_id]
        assert sr.json()["env_id"] == env_id

        gr = client.get(f"/api/v1/projects/{pid}/ui-cases/{case_id}", headers=h)
        assert gr.status_code == 200
        assert gr.json()["name"] == "打开首页 (Agent)"
        assert "def run(page):" in gr.json()["script"]
        assert 'page.goto("/home")' in gr.json()["script"]
        saved_steps = gr.json().get("steps") or []
        assert len(saved_steps) >= 2
        assert saved_steps[0].get("action") == "goto"
        assert saved_steps[1].get("action") == "assert_url"
        # Credentials stay on env / explore session — not copied onto UI case test data
        vars_ = gr.json().get("variables") or {}
        assert vars_ == {}
        assert gr.json().get("auth_mode") is None
    finally:
        agent_api.set_explore_runner(None)


def test_confirm_cancel_action_rejected(monkeypatch):
    from app.api.ui_automation import ui_scenario_agent as agent_api
    from app.models.ui_automation.ui_automation import UiScenarioAgentSession
    from app.services.api_automation.api_scenario_events import get_event_bus

    monkeypatch.setattr(
        "app.api.ui_automation.ui_scenario_agent.get_llm_runtime",
        lambda db: __import__(
            "app.services.ai.effective_ai_settings", fromlist=["LlmRuntime"]
        ).LlmRuntime(
            api_base="https://example.com/v1",
            api_key="test-key",
            model="m",
            allowed_models_csv="m",
        ),
    )

    _user("uisa_nocancel", "p")
    tok = _login("uisa_nocancel", "p")
    pid = _project(tok, "UISANoCancel")
    client = TestClient(app)
    h = {"Authorization": f"Bearer {tok}"}

    er = client.post(
        f"/api/v1/projects/{pid}/ui-envs/",
        headers=h,
        json={"name": "local", "base_url": "https://app.example.com", "is_default": True},
    )
    assert er.status_code == 201
    env_id = er.json()["id"]

    def fake_explore(db, session_id: int) -> None:
        row = db.get(UiScenarioAgentSession, session_id)
        assert row is not None
        row.status = "awaiting_confirm"
        row.playwright_code = 'async function run(page) {\n  await page.goto("/");\n}\n'
        get_event_bus().append(row.thread_id, {"type": "done", "status": "awaiting_confirm"})
        db.commit()

    agent_api.set_explore_runner(fake_explore)
    try:
        cr = client.post(
            f"/api/v1/projects/{pid}/ui-scenario-agent/sessions",
            headers=h,
            json={"prompt": "打开首页", "env_id": env_id, "browser": "chromium"},
        )
        assert cr.status_code == 201
        sid = cr.json()["id"]

        bad = client.post(
            f"/api/v1/projects/{pid}/ui-scenario-agent/sessions/{sid}/confirm",
            headers=h,
            json={"action": "cancel"},
        )
        assert bad.status_code == 400
        got = client.get(
            f"/api/v1/projects/{pid}/ui-scenario-agent/sessions/{sid}",
            headers=h,
        )
        assert got.status_code == 200
        assert got.json()["status"] == "awaiting_confirm"
    finally:
        agent_api.set_explore_runner(None)


def test_reopen_cancelled_session_restores_draft(monkeypatch):
    from app.api.ui_automation import ui_scenario_agent as agent_api
    from app.models.ui_automation.ui_automation import UiScenarioAgentSession
    from app.services.api_automation.api_scenario_events import get_event_bus

    monkeypatch.setattr(
        "app.api.ui_automation.ui_scenario_agent.get_llm_runtime",
        lambda db: __import__(
            "app.services.ai.effective_ai_settings", fromlist=["LlmRuntime"]
        ).LlmRuntime(
            api_base="https://example.com/v1",
            api_key="test-key",
            model="m",
            allowed_models_csv="m",
        ),
    )

    _user("uisa_reopen", "p")
    tok = _login("uisa_reopen", "p")
    pid = _project(tok, "UISAReopen")
    client = TestClient(app)
    h = {"Authorization": f"Bearer {tok}"}

    er = client.post(
        f"/api/v1/projects/{pid}/ui-envs/",
        headers=h,
        json={"name": "local", "base_url": "https://app.example.com", "is_default": True},
    )
    assert er.status_code == 201
    env_id = er.json()["id"]

    script = 'async function run(page) {\n  await page.goto("/");\n}\n'

    def fake_explore(db, session_id: int) -> None:
        row = db.get(UiScenarioAgentSession, session_id)
        assert row is not None
        row.status = "awaiting_confirm"
        row.playwright_code = script
        get_event_bus().append(row.thread_id, {"type": "done", "status": "awaiting_confirm"})
        db.commit()

    agent_api.set_explore_runner(fake_explore)
    try:
        cr = client.post(
            f"/api/v1/projects/{pid}/ui-scenario-agent/sessions",
            headers=h,
            json={"prompt": "打开首页", "env_id": env_id, "browser": "chromium"},
        )
        assert cr.status_code == 201
        sid = cr.json()["id"]

        db = TestingSessionLocal()
        try:
            row = db.get(UiScenarioAgentSession, sid)
            assert row is not None
            row.status = "cancelled"
            db.commit()
        finally:
            db.close()

        reopened = client.post(
            f"/api/v1/projects/{pid}/ui-scenario-agent/sessions/{sid}/reopen",
            headers=h,
        )
        assert reopened.status_code == 200, reopened.text
        assert reopened.json()["status"] == "awaiting_confirm"
    finally:
        agent_api.set_explore_runner(None)


def test_reopen_confirmed_session_then_confirm_writes_new_case(monkeypatch):
    key = Fernet.generate_key().decode()
    monkeypatch.setattr(settings, "settings_encryption_key", key)

    from app.api.ui_automation import ui_scenario_agent as agent_api
    from app.models.ui_automation.ui_automation import UiCase, UiScenarioAgentSession

    monkeypatch.setattr(
        "app.api.ui_automation.ui_scenario_agent.get_llm_runtime",
        lambda db: __import__(
            "app.services.ai.effective_ai_settings", fromlist=["LlmRuntime"]
        ).LlmRuntime(
            api_base="https://example.com/v1",
            api_key="test-key",
            model="m",
            allowed_models_csv="m",
        ),
    )

    _user("uisa_reopen_conf", "p")
    tok = _login("uisa_reopen_conf", "p")
    pid = _project(tok, "UISAReopenConf")
    client = TestClient(app)
    h = {"Authorization": f"Bearer {tok}"}

    er = client.post(
        f"/api/v1/projects/{pid}/ui-envs/",
        headers=h,
        json={"name": "local", "base_url": "https://app.example.com", "is_default": True},
    )
    assert er.status_code == 201
    env_id = er.json()["id"]

    script = 'async function run(page) {\n  await page.goto("/");\n}\n'

    def fake_explore(db, session_id: int) -> None:
        from app.services.api_automation.api_scenario_events import get_event_bus

        row = db.get(UiScenarioAgentSession, session_id)
        assert row is not None
        row.status = "awaiting_confirm"
        row.playwright_code = script
        get_event_bus().append(row.thread_id, {"type": "done", "status": "awaiting_confirm"})
        db.commit()

    agent_api.set_explore_runner(fake_explore)
    try:
        cr = client.post(
            f"/api/v1/projects/{pid}/ui-scenario-agent/sessions",
            headers=h,
            json={"prompt": "打开首页", "env_id": env_id, "browser": "chromium"},
        )
        assert cr.status_code == 201
        sid = cr.json()["id"]

        first = client.post(
            f"/api/v1/projects/{pid}/ui-scenario-agent/sessions/{sid}/confirm",
            headers=h,
            json={"action": "confirm", "name": "首页", "status": "ready"},
        )
        assert first.status_code == 200, first.text
        assert first.json()["status"] == "confirmed"
        first_case_id = first.json()["saved_ui_case_id"]
        assert first_case_id is not None

        reopened = client.post(
            f"/api/v1/projects/{pid}/ui-scenario-agent/sessions/{sid}/reopen",
            headers=h,
        )
        assert reopened.status_code == 200, reopened.text
        assert reopened.json()["status"] == "awaiting_confirm"

        second = client.post(
            f"/api/v1/projects/{pid}/ui-scenario-agent/sessions/{sid}/confirm",
            headers=h,
            json={"action": "confirm", "name": "首页 副本", "status": "ready"},
        )
        assert second.status_code == 200, second.text
        assert second.json()["status"] == "confirmed"
        second_case_id = second.json()["saved_ui_case_id"]
        assert second_case_id is not None
        assert second_case_id != first_case_id

        db = TestingSessionLocal()
        try:
            assert db.get(UiCase, first_case_id) is not None
            assert db.get(UiCase, second_case_id) is not None
        finally:
            db.close()
    finally:
        agent_api.set_explore_runner(None)


def test_confirm_writes_when_session_status_error(monkeypatch):
    key = Fernet.generate_key().decode()
    monkeypatch.setattr(settings, "settings_encryption_key", key)

    from app.api.ui_automation import ui_scenario_agent as agent_api
    from app.models.ui_automation.ui_automation import UiScenarioAgentSession
    from app.services.api_automation.api_scenario_events import get_event_bus
    from app.services.ui_automation.ui_scenario_agent import MANUAL_STOP_MESSAGE

    monkeypatch.setattr(
        "app.api.ui_automation.ui_scenario_agent.get_llm_runtime",
        lambda db: __import__(
            "app.services.ai.effective_ai_settings", fromlist=["LlmRuntime"]
        ).LlmRuntime(
            api_base="https://example.com/v1",
            api_key="test-key",
            model="m",
            allowed_models_csv="m",
        ),
    )

    _user("uisa_err", "p")
    tok = _login("uisa_err", "p")
    pid = _project(tok, "UISAErr")
    client = TestClient(app)
    h = {"Authorization": f"Bearer {tok}"}

    er = client.post(
        f"/api/v1/projects/{pid}/ui-envs/",
        headers=h,
        json={"name": "local", "base_url": "https://app.example.com", "is_default": True},
    )
    assert er.status_code == 201
    env_id = er.json()["id"]

    script = 'async function run(page) {\n  await page.goto("/");\n}\n'

    def fake_explore(db, session_id: int) -> None:
        row = db.get(UiScenarioAgentSession, session_id)
        assert row is not None
        row.status = "error"
        row.error_message = MANUAL_STOP_MESSAGE
        row.plan_json = {"goal": "打开首页", "start_path": "/", "case_name": "打开首页"}
        row.playwright_code = script
        get_event_bus().append(row.thread_id, {"type": "done", "status": "error"})
        db.commit()

    agent_api.set_explore_runner(fake_explore)
    try:
        cr = client.post(
            f"/api/v1/projects/{pid}/ui-scenario-agent/sessions",
            headers=h,
            json={"prompt": "打开首页", "env_id": env_id, "browser": "chromium"},
        )
        assert cr.status_code == 201, cr.text
        sess = cr.json()
        assert sess["status"] == "error"

        conf = client.post(
            f"/api/v1/projects/{pid}/ui-scenario-agent/sessions/{sess['id']}/confirm",
            headers=h,
            json={"action": "confirm", "name": "停止后导入", "status": "ready"},
        )
        assert conf.status_code == 200, conf.text
        assert conf.json()["status"] == "confirmed"
        assert conf.json()["saved_ui_case_id"] is not None
    finally:
        agent_api.set_explore_runner(None)


def test_ui_scenario_agent_confirm_case_ids_and_overrides(monkeypatch):
    key = Fernet.generate_key().decode()
    monkeypatch.setattr(settings, "settings_encryption_key", key)

    from app.services.ai.effective_ai_settings import LlmRuntime
    from app.api.ui_automation import ui_scenario_agent as agent_api

    monkeypatch.setattr(
        "app.api.ui_automation.ui_scenario_agent.get_llm_runtime",
        lambda db: LlmRuntime(
            api_base="https://example.com/v1",
            api_key="test-key",
            model="m",
            allowed_models_csv="m",
        ),
    )

    _user("uisa_batch", "p")
    tok = _login("uisa_batch", "p")
    pid = _project(tok, "UISABatch")
    client = TestClient(app)
    h = {"Authorization": f"Bearer {tok}"}

    er = client.post(
        f"/api/v1/projects/{pid}/ui-envs/",
        headers=h,
        json={"name": "local", "base_url": "https://app.example.com", "is_default": True},
    )
    assert er.status_code == 201
    env_id = er.json()["id"]

    script1 = "async function run(page) {\n  await page.goto('/one');\n}"
    script2 = "async function run(page) {\n  await page.goto('/two');\n}"

    def fake_explore(db, session_id: int) -> None:
        from app.models.ui_automation.ui_automation import UiScenarioAgentSession
        from app.services.api_automation.api_scenario_events import get_event_bus

        row = db.get(UiScenarioAgentSession, session_id)
        assert row is not None
        row.status = "awaiting_confirm"
        row.plan_json = {
            "goal": "multi",
            "case_scripts": [
                {"id": "case-1", "name": "One", "ready": False, "code": script1},
                {"id": "case-2", "name": "Two", "ready": True, "code": script2},
            ],
        }
        row.playwright_code = script1
        get_event_bus().append(row.thread_id, {"type": "done", "status": "awaiting_confirm"})
        db.commit()

    agent_api.set_explore_runner(fake_explore)
    try:
        cr = client.post(
            f"/api/v1/projects/{pid}/ui-scenario-agent/sessions",
            headers=h,
            json={"prompt": "生成两条", "env_id": env_id, "browser": "chromium"},
        )
        assert cr.status_code == 201
        sess_id = cr.json()["id"]

        override = "async function run(page) {\n  await page.goto('/one-override');\n}"
        conf = client.post(
            f"/api/v1/projects/{pid}/ui-scenario-agent/sessions/{sess_id}/confirm",
            headers=h,
            json={
                "action": "confirm",
                "status": "ready",
                "case_ids": ["case-1"],
                "case_overrides": [{"id": "case-1", "code": override}],
            },
        )
        assert conf.status_code == 200, conf.text
        body = conf.json()
        assert body["status"] == "confirmed"
        assert len(body["plan"]["saved_ui_case_ids"]) == 1
        assert body["saved_ui_suite_id"] is not None

        case_id = body["saved_ui_case_id"]
        suite_id = body["saved_ui_suite_id"]
        sr = client.get(f"/api/v1/projects/{pid}/ui-suites/{suite_id}", headers=h)
        assert sr.status_code == 200
        assert sr.json()["case_ids"] == [case_id]

        gr = client.get(f"/api/v1/projects/{pid}/ui-cases/{case_id}", headers=h)
        assert gr.status_code == 200
        assert "/one-override" in gr.json()["script"]

        list_r = client.get(f"/api/v1/projects/{pid}/ui-cases/?page=1&page_size=50", headers=h)
        assert list_r.status_code == 200
        names = [item["name"] for item in list_r.json()["items"]]
        assert sum(1 for n in names if "case-2" in n or "Two" in n) == 0
    finally:
        agent_api.set_explore_runner(None)


def test_ui_scenario_agent_confirm_creates_ordered_suite(monkeypatch):
    key = Fernet.generate_key().decode()
    monkeypatch.setattr(settings, "settings_encryption_key", key)

    from app.services.ai.effective_ai_settings import LlmRuntime
    from app.api.ui_automation import ui_scenario_agent as agent_api

    monkeypatch.setattr(
        "app.api.ui_automation.ui_scenario_agent.get_llm_runtime",
        lambda db: LlmRuntime(
            api_base="https://example.com/v1",
            api_key="test-key",
            model="m",
            allowed_models_csv="m",
        ),
    )

    _user("uisa_suite", "p")
    tok = _login("uisa_suite", "p")
    pid = _project(tok, "UISASuite")
    client = TestClient(app)
    h = {"Authorization": f"Bearer {tok}"}

    er = client.post(
        f"/api/v1/projects/{pid}/ui-envs/",
        headers=h,
        json={"name": "local", "base_url": "https://app.example.com", "is_default": True},
    )
    assert er.status_code == 201
    env_id = er.json()["id"]

    s1 = "async function run(page) {\n  await page.goto('/a');\n}"
    s2 = "async function run(page) {\n  await page.goto('/b');\n}"

    def fake_explore(db, session_id: int) -> None:
        from app.models.ui_automation.ui_automation import UiScenarioAgentSession
        from app.services.api_automation.api_scenario_events import get_event_bus

        row = db.get(UiScenarioAgentSession, session_id)
        assert row is not None
        row.status = "awaiting_confirm"
        row.plan_json = {
            "goal": "CRUD 探索",
            "case_name": "项目 CRUD",
            "case_scripts": [
                {"id": "uc-1", "name": "Create", "ready": True, "code": s1},
                {"id": "uc-2", "name": "Read", "ready": True, "code": s2},
            ],
        }
        get_event_bus().append(row.thread_id, {"type": "done", "status": "awaiting_confirm"})
        db.commit()

    agent_api.set_explore_runner(fake_explore)
    try:
        cr = client.post(
            f"/api/v1/projects/{pid}/ui-scenario-agent/sessions",
            headers=h,
            json={"prompt": "探索", "env_id": env_id, "browser": "chromium"},
        )
        assert cr.status_code == 201
        sess_id = cr.json()["id"]

        conf = client.post(
            f"/api/v1/projects/{pid}/ui-scenario-agent/sessions/{sess_id}/confirm",
            headers=h,
            json={"action": "confirm", "status": "ready", "create_suite": True},
        )
        assert conf.status_code == 200, conf.text
        body = conf.json()
        assert body["saved_ui_suite_id"] is not None
        assert len(body["plan"]["saved_ui_case_ids"]) == 2

        suite_id = body["saved_ui_suite_id"]
        sr = client.get(f"/api/v1/projects/{pid}/ui-suites/{suite_id}", headers=h)
        assert sr.status_code == 200
        assert sr.json()["name"] == "项目 CRUD"
        assert sr.json()["env_id"] == env_id
        assert sr.json()["case_ids"] == body["plan"]["saved_ui_case_ids"]
    finally:
        agent_api.set_explore_runner(None)


def test_ui_scenario_agent_confirm_suite_custom_fields(monkeypatch):
    key = Fernet.generate_key().decode()
    monkeypatch.setattr(settings, "settings_encryption_key", key)

    from app.services.ai.effective_ai_settings import LlmRuntime
    from app.api.ui_automation import ui_scenario_agent as agent_api

    monkeypatch.setattr(
        "app.api.ui_automation.ui_scenario_agent.get_llm_runtime",
        lambda db: LlmRuntime(
            api_base="https://example.com/v1",
            api_key="test-key",
            model="m",
            allowed_models_csv="m",
        ),
    )

    _user("uisa_suite_fields", "p")
    tok = _login("uisa_suite_fields", "p")
    pid = _project(tok, "UISASuiteFields")
    client = TestClient(app)
    h = {"Authorization": f"Bearer {tok}"}

    er = client.post(
        f"/api/v1/projects/{pid}/ui-envs/",
        headers=h,
        json={"name": "session-env", "base_url": "https://app.example.com", "is_default": True},
    )
    assert er.status_code == 201
    session_env_id = er.json()["id"]

    er2 = client.post(
        f"/api/v1/projects/{pid}/ui-envs/",
        headers=h,
        json={"name": "suite-env", "base_url": "https://suite.example.com", "is_default": False},
    )
    assert er2.status_code == 201
    suite_env_id = er2.json()["id"]

    script = "async function run(page) {\n  await page.goto('/');\n}"

    def fake_explore(db, session_id: int) -> None:
        from app.models.ui_automation.ui_automation import UiScenarioAgentSession

        row = db.get(UiScenarioAgentSession, session_id)
        row.status = "awaiting_confirm"
        row.plan_json = {
            "goal": "fallback goal",
            "case_scripts": [{"id": "x", "name": "X", "code": script}],
        }
        db.commit()

    agent_api.set_explore_runner(fake_explore)
    try:
        cr = client.post(
            f"/api/v1/projects/{pid}/ui-scenario-agent/sessions",
            headers=h,
            json={"prompt": "solo", "env_id": session_env_id, "browser": "chromium"},
        )
        assert cr.status_code == 201
        conf = client.post(
            f"/api/v1/projects/{pid}/ui-scenario-agent/sessions/{cr.json()['id']}/confirm",
            headers=h,
            json={
                "action": "confirm",
                "status": "ready",
                "create_suite": True,
                "suite_name": "我的套件",
                "suite_description": "导入时填写",
                "suite_env_id": suite_env_id,
                "suite_browsers": ["firefox", "webkit"],
                "suite_stop_on_fail": False,
            },
        )
        assert conf.status_code == 200, conf.text
        suite_id = conf.json()["saved_ui_suite_id"]
        assert suite_id is not None
        sr = client.get(f"/api/v1/projects/{pid}/ui-suites/{suite_id}", headers=h)
        assert sr.status_code == 200
        suite = sr.json()
        assert suite["name"] == "我的套件"
        assert suite["description"] == "导入时填写"
        assert suite["env_id"] == suite_env_id
        assert suite["browsers"] == ["firefox", "webkit"]
        assert suite["stop_on_fail"] is False
    finally:
        agent_api.set_explore_runner(None)


def test_ui_scenario_agent_confirm_skips_suite_when_disabled(monkeypatch):
    key = Fernet.generate_key().decode()
    monkeypatch.setattr(settings, "settings_encryption_key", key)

    from app.services.ai.effective_ai_settings import LlmRuntime
    from app.api.ui_automation import ui_scenario_agent as agent_api

    monkeypatch.setattr(
        "app.api.ui_automation.ui_scenario_agent.get_llm_runtime",
        lambda db: LlmRuntime(
            api_base="https://example.com/v1",
            api_key="test-key",
            model="m",
            allowed_models_csv="m",
        ),
    )

    _user("uisa_nosuite", "p")
    tok = _login("uisa_nosuite", "p")
    pid = _project(tok, "UISANoSuite")
    client = TestClient(app)
    h = {"Authorization": f"Bearer {tok}"}

    er = client.post(
        f"/api/v1/projects/{pid}/ui-envs/",
        headers=h,
        json={"name": "local", "base_url": "https://app.example.com", "is_default": True},
    )
    assert er.status_code == 201
    env_id = er.json()["id"]

    script = "async function run(page) {\n  await page.goto('/');\n}"

    def fake_explore(db, session_id: int) -> None:
        from app.models.ui_automation.ui_automation import UiScenarioAgentSession

        row = db.get(UiScenarioAgentSession, session_id)
        row.status = "awaiting_confirm"
        row.plan_json = {"goal": "solo", "case_scripts": [{"id": "x", "name": "X", "code": script}]}
        db.commit()

    agent_api.set_explore_runner(fake_explore)
    try:
        cr = client.post(
            f"/api/v1/projects/{pid}/ui-scenario-agent/sessions",
            headers=h,
            json={"prompt": "solo", "env_id": env_id, "browser": "chromium"},
        )
        assert cr.status_code == 201
        conf = client.post(
            f"/api/v1/projects/{pid}/ui-scenario-agent/sessions/{cr.json()['id']}/confirm",
            headers=h,
            json={"action": "confirm", "status": "ready", "create_suite": False},
        )
        assert conf.status_code == 200
        assert conf.json()["saved_ui_case_id"] is not None
        assert conf.json()["saved_ui_suite_id"] is None
    finally:
        agent_api.set_explore_runner(None)


def test_ui_scenario_agent_confirm_persists_auth_mode_none(monkeypatch):
    key = Fernet.generate_key().decode()
    monkeypatch.setattr(settings, "settings_encryption_key", key)

    from app.services.ai.effective_ai_settings import LlmRuntime
    from app.api.ui_automation import ui_scenario_agent as agent_api

    monkeypatch.setattr(
        "app.api.ui_automation.ui_scenario_agent.get_llm_runtime",
        lambda db: LlmRuntime(
            api_base="https://example.com/v1",
            api_key="test-key",
            model="m",
            allowed_models_csv="m",
        ),
    )

    _user("uisa_auth_none", "p")
    tok = _login("uisa_auth_none", "p")
    pid = _project(tok, "UISANONE")
    client = TestClient(app)
    h = {"Authorization": f"Bearer {tok}"}

    er = client.post(
        f"/api/v1/projects/{pid}/ui-envs/",
        headers=h,
        json={
            "name": "local",
            "base_url": "https://app.example.com",
            "is_default": True,
            "variables": {"access_token": "tok"},
            "inject_local_storage": {"access_token": "{{access_token}}"},
            "token_inject": "none",
        },
    )
    assert er.status_code == 201, er.text
    env_id = er.json()["id"]

    def fake_explore(db, session_id: int) -> None:
        from app.models.ui_automation.ui_automation import UiScenarioAgentSession
        from app.services.api_automation.api_scenario_events import get_event_bus

        row = db.get(UiScenarioAgentSession, session_id)
        assert row is not None
        prior = row.plan_json if isinstance(row.plan_json, dict) else {}
        assert prior.get("_auth_mode") == "none"
        row.status = "awaiting_confirm"
        row.plan_json = {
            **prior,
            "goal": "登录",
            "start_path": "/login",
            "checklist": [],
            "case_name": "登录",
            "case_scripts": [
                {
                    "id": "UC1",
                    "name": "登录",
                    "ready": True,
                    "code": 'def run(page):\n    page.goto("/login")\n',
                }
            ],
        }
        row.playwright_code = 'def run(page):\n    page.goto("/login")\n'
        row.dry_run_status = "passed"
        get_event_bus().append(row.thread_id, {"type": "done", "status": "awaiting_confirm"})
        db.commit()

    agent_api.set_explore_runner(fake_explore)
    try:
        cr = client.post(
            f"/api/v1/projects/{pid}/ui-scenario-agent/sessions",
            headers=h,
            json={
                "prompt": "登录系统",
                "env_id": env_id,
                "auth_mode": "none",
            },
        )
        assert cr.status_code == 201, cr.text
        sess = cr.json()
        assert sess["auth_mode"] == "none"
        assert sess["status"] == "awaiting_confirm"

        conf = client.post(
            f"/api/v1/projects/{pid}/ui-scenario-agent/sessions/{sess['id']}/confirm",
            headers=h,
            json={"action": "confirm", "name": "登录用例", "status": "ready"},
        )
        assert conf.status_code == 200, conf.text
        case_id = conf.json()["saved_ui_case_id"]
        gr = client.get(f"/api/v1/projects/{pid}/ui-cases/{case_id}", headers=h)
        assert gr.status_code == 200
        assert gr.json()["auth_mode"] == "none"
        assert (gr.json().get("variables") or {}) == {}
    finally:
        agent_api.set_explore_runner(None)


def test_resolve_plan_browser_auth_follow_vs_none():
    class _Env:
        variables_json = {"access_token": "tok-1"}
        secrets_encrypted = None
        inject_headers_json = {}
        inject_local_storage_json = {"access_token": "{{access_token}}"}
        token_inject = "none"
        token_storage_key = None
        accounts_json = []
        auth_states_encrypted = None

    env = _Env()
    follow = resolve_plan_browser_auth(env, {"_auth_mode": None})
    assert follow.local_storage == {"access_token": "tok-1"}
    assert follow.skip_login is True

    none = resolve_plan_browser_auth(env, {"_auth_mode": "none"})
    assert none.mode == "none"
    assert none.local_storage is None
    assert none.skip_login is False


def test_ui_scenario_agent_automate_auth_mode_follow_and_none(monkeypatch):
    """Functional-case automate: follow injects; none skips even when env has inject."""
    key = Fernet.generate_key().decode()
    monkeypatch.setattr(settings, "settings_encryption_key", key)

    from app.services.ai.effective_ai_settings import LlmRuntime
    from app.api.ui_automation import ui_scenario_agent as agent_api

    monkeypatch.setattr(
        "app.api.ui_automation.ui_scenario_agent.get_llm_runtime",
        lambda db: LlmRuntime(
            api_base="https://example.com/v1",
            api_key="test-key",
            model="m",
            allowed_models_csv="m",
        ),
    )

    _user("uisa_auto_auth", "p")
    tok = _login("uisa_auto_auth", "p")
    pid = _project(tok, "UISAAUTH")
    client = TestClient(app)
    h = {"Authorization": f"Bearer {tok}"}

    er = client.post(
        f"/api/v1/projects/{pid}/ui-envs/",
        headers=h,
        json={
            "name": "local",
            "base_url": "https://app.example.com",
            "is_default": True,
            "variables": {"access_token": "tok"},
            "inject_local_storage": {"access_token": "{{access_token}}"},
            "token_inject": "none",
        },
    )
    assert er.status_code == 201, er.text
    env_id = er.json()["id"]

    tcr = client.post(
        f"/api/v1/projects/{pid}/test-cases/",
        headers=h,
        json={
            "title": "登录成功",
            "overall_expected": "进入首页",
            "steps": [{"action": "打开登录页", "expected": "看到表单"}],
        },
    )
    assert tcr.status_code == 201, tcr.text
    tc_id = tcr.json()["id"]

    seen: list[str | None] = []

    def fake_explore(db, session_id: int) -> None:
        from app.models.ui_automation.ui_automation import UiScenarioAgentSession
        from app.services.api_automation.api_scenario_events import get_event_bus

        row = db.get(UiScenarioAgentSession, session_id)
        assert row is not None
        prior = row.plan_json if isinstance(row.plan_json, dict) else {}
        seen.append(prior.get("_auth_mode"))
        row.status = "awaiting_confirm"
        row.plan_json = {**prior, "goal": "登录", "case_scripts": []}
        row.playwright_code = 'def run(page):\n    page.goto("/login")\n'
        row.dry_run_status = "passed"
        get_event_bus().append(row.thread_id, {"type": "done", "status": "awaiting_confirm"})
        db.commit()

    agent_api.set_explore_runner(fake_explore)
    try:
        follow = client.post(
            f"/api/v1/projects/{pid}/ui-scenario-agent/sessions",
            headers=h,
            json={
                "testcase_id": tc_id,
                "env_id": env_id,
                "execution_mode": "explore_codegen",
            },
        )
        assert follow.status_code == 201, follow.text
        assert follow.json().get("auth_mode") is None

        none = client.post(
            f"/api/v1/projects/{pid}/ui-scenario-agent/sessions",
            headers=h,
            json={
                "testcase_id": tc_id,
                "env_id": env_id,
                "auth_mode": "none",
                "execution_mode": "explore_codegen",
            },
        )
        assert none.status_code == 201, none.text
        assert none.json().get("auth_mode") == "none"
        assert seen == [None, "none"]
    finally:
        agent_api.set_explore_runner(None)


def test_ui_scenario_agent_error_can_continue(monkeypatch):
    key = Fernet.generate_key().decode()
    monkeypatch.setattr(settings, "settings_encryption_key", key)

    from app.services.ai.effective_ai_settings import LlmRuntime
    from app.api.ui_automation import ui_scenario_agent as agent_api

    monkeypatch.setattr(
        "app.api.ui_automation.ui_scenario_agent.get_llm_runtime",
        lambda db: LlmRuntime(
            api_base="https://example.com/v1",
            api_key="test-key",
            model="m",
            allowed_models_csv="m",
        ),
    )

    _user("uisa_err", "p")
    tok = _login("uisa_err", "p")
    pid = _project(tok, "UISAErr")
    client = TestClient(app)
    h = {"Authorization": f"Bearer {tok}"}

    er = client.post(
        f"/api/v1/projects/{pid}/ui-envs/",
        headers=h,
        json={"name": "local", "base_url": "https://app.example.com", "is_default": True},
    )
    assert er.status_code == 201, er.text
    env_id = er.json()["id"]

    calls = {"n": 0}

    def fake_explore(db, session_id: int) -> None:
        from app.models.ui_automation.ui_automation import UiScenarioAgentSession
        from app.services.api_automation.api_scenario_events import get_event_bus

        row = db.get(UiScenarioAgentSession, session_id)
        assert row is not None
        calls["n"] += 1
        if calls["n"] == 1:
            row.status = "error"
            row.error_message = "未安装 ui-runner 依赖"
            msgs = list(row.messages_json) if isinstance(row.messages_json, list) else []
            msgs.append({"role": "assistant", "content": row.error_message})
            row.messages_json = msgs
            get_event_bus().append(row.thread_id, {"type": "error", "message": row.error_message})
            db.commit()
            return
        row.status = "awaiting_confirm"
        row.error_message = ""
        row.plan_json = {"goal": "登录首页", "start_path": "/", "checklist": [], "case_name": "登录"}
        row.result_steps_json = [{"action": "goto", "value": "/"}]
        row.playwright_code = 'def run(page):\n    page.goto("/")\n'
        row.dry_run_status = "passed"
        row.dry_run_error = ""
        msgs = list(row.messages_json) if isinstance(row.messages_json, list) else []
        msgs.append({"role": "assistant", "content": "已生成步骤。"})
        row.messages_json = msgs
        get_event_bus().append(row.thread_id, {"type": "interrupted", "message": "等待确认"})
        get_event_bus().append(row.thread_id, {"type": "done", "status": "awaiting_confirm"})
        db.commit()

    agent_api.set_explore_runner(fake_explore)
    try:
        cr = client.post(
            f"/api/v1/projects/{pid}/ui-scenario-agent/sessions",
            headers=h,
            json={"prompt": "账号 admin 密码 admin123，登录首页", "env_id": env_id},
        )
        assert cr.status_code == 201, cr.text
        sess = cr.json()
        assert sess["status"] == "error"
        sid = sess["id"]

        mr = client.post(
            f"/api/v1/projects/{pid}/ui-scenario-agent/sessions/{sid}/messages",
            headers=h,
            json={"content": "装好依赖后再试，验证码 2998"},
        )
        assert mr.status_code == 200, mr.text
        body = mr.json()
        assert body["status"] == "awaiting_confirm"
        assert calls["n"] == 2
        assert "装好依赖后再试" in (body.get("prompt") or "")
        assert "登录首页" in (body.get("prompt") or "")
    finally:
        agent_api.set_explore_runner(None)


def test_ui_scenario_agent_stop_running(monkeypatch):
    key = Fernet.generate_key().decode()
    monkeypatch.setattr(settings, "settings_encryption_key", key)

    from app.services.ai.effective_ai_settings import LlmRuntime, MidsceneRuntime
    from app.api.ui_automation import ui_scenario_agent as agent_api

    monkeypatch.setattr(
        "app.api.ui_automation.ui_scenario_agent.get_llm_runtime",
        lambda db: LlmRuntime(
            api_base="https://example.com/v1",
            api_key="test-key",
            model="m",
            allowed_models_csv="m",
        ),
    )
    monkeypatch.setattr(
        "app.api.ui_automation.ui_scenario_agent.get_midscene_runtime",
        lambda db: MidsceneRuntime(
            api_base="https://example.com/v1",
            api_key="test-key",
            model="m",
            model_family="",
        ),
    )

    _user("uisa_stop", "p")
    tok = _login("uisa_stop", "p")
    pid = _project(tok, "UISAStop")
    client = TestClient(app)
    h = {"Authorization": f"Bearer {tok}"}

    er = client.post(
        f"/api/v1/projects/{pid}/ui-envs/",
        headers=h,
        json={"name": "local", "base_url": "https://app.example.com", "is_default": True},
    )
    assert er.status_code == 201, er.text
    env_id = er.json()["id"]

    def fake_explore(db, session_id: int) -> None:
        from app.models.ui_automation.ui_automation import UiScenarioAgentSession

        row = db.get(UiScenarioAgentSession, session_id)
        assert row is not None
        row.status = "running"
        row.celery_task_id = "test-task"
        db.commit()

    agent_api.set_explore_runner(fake_explore)
    try:
        cr = client.post(
            f"/api/v1/projects/{pid}/ui-scenario-agent/sessions",
            headers=h,
            json={"prompt": "打开首页", "env_id": env_id},
        )
        assert cr.status_code == 201, cr.text
        assert cr.json()["status"] == "running"
        sid = cr.json()["id"]

        stopped = client.post(
            f"/api/v1/projects/{pid}/ui-scenario-agent/sessions/{sid}/stop",
            headers=h,
        )
        assert stopped.status_code == 200, stopped.text
        body = stopped.json()
        assert body["status"] == "error"
        assert "已手动停止" in (body.get("error_message") or "")

        from app.services.ui_automation.ui_scenario_agent import execute_session_explore

        db = TestingSessionLocal()
        try:
            execute_session_explore(db, sid)
            from app.models.ui_automation.ui_automation import UiScenarioAgentSession

            row = db.get(UiScenarioAgentSession, sid)
            assert row is not None
            assert row.status == "error"
            assert "已手动停止" in (row.error_message or "")
        finally:
            db.close()
    finally:
        agent_api.set_explore_runner(None)


def test_ui_scenario_agent_awaiting_human_message_and_stop(monkeypatch):
    key = Fernet.generate_key().decode()
    monkeypatch.setattr(settings, "settings_encryption_key", key)

    from app.services.ai.effective_ai_settings import LlmRuntime, MidsceneRuntime
    from app.api.ui_automation import ui_scenario_agent as agent_api
    from app.models.ui_automation.ui_automation import UiScenarioAgentSession

    monkeypatch.setattr(
        "app.api.ui_automation.ui_scenario_agent.get_llm_runtime",
        lambda db: LlmRuntime(
            api_base="https://example.com/v1",
            api_key="test-key",
            model="m",
            allowed_models_csv="m",
        ),
    )
    monkeypatch.setattr(
        "app.api.ui_automation.ui_scenario_agent.get_midscene_runtime",
        lambda db: MidsceneRuntime(
            api_base="https://example.com/v1",
            api_key="test-key",
            model="m",
            model_family="",
        ),
    )

    _user("uisa_human", "p")
    tok = _login("uisa_human", "p")
    pid = _project(tok, "UISAHuman")
    client = TestClient(app)
    h = {"Authorization": f"Bearer {tok}"}

    er = client.post(
        f"/api/v1/projects/{pid}/ui-envs/",
        headers=h,
        json={"name": "local", "base_url": "https://app.example.com", "is_default": True},
    )
    assert er.status_code == 201, er.text
    env_id = er.json()["id"]

    explore_calls = {"n": 0}

    def fake_explore(db, session_id: int) -> None:
        explore_calls["n"] += 1
        row = db.get(UiScenarioAgentSession, session_id)
        assert row is not None
        plan = dict(row.plan_json) if isinstance(row.plan_json, dict) else {}
        plan["_headed"] = True
        row.plan_json = plan
        row.status = "awaiting_human"
        row.celery_task_id = "human-task"
        db.commit()

    agent_api.set_explore_runner(fake_explore)
    try:
        cr = client.post(
            f"/api/v1/projects/{pid}/ui-scenario-agent/sessions",
            headers=h,
            json={"prompt": "登录", "env_id": env_id, "headed": True},
        )
        assert cr.status_code == 201, cr.text
        assert cr.json()["status"] == "awaiting_human"
        sid = cr.json()["id"]
        assert explore_calls["n"] == 1

        mr = client.post(
            f"/api/v1/projects/{pid}/ui-scenario-agent/sessions/{sid}/messages",
            headers=h,
            json={"content": "验证码 8821"},
        )
        assert mr.status_code == 200, mr.text
        body = mr.json()
        assert body["status"] == "awaiting_human"
        # Must not kick off a new explore; worker resumes the same Node process.
        assert explore_calls["n"] == 1

        db = TestingSessionLocal()
        try:
            row = db.get(UiScenarioAgentSession, sid)
            assert row is not None
            plan = row.plan_json if isinstance(row.plan_json, dict) else {}
            assert plan.get("_human_reply") == "验证码 8821"
        finally:
            db.close()

        db = TestingSessionLocal()
        try:
            row = db.get(UiScenarioAgentSession, sid)
            assert row is not None
            plan = dict(row.plan_json) if isinstance(row.plan_json, dict) else {}
            plan.pop("_human_reply", None)
            row.plan_json = plan
            row.status = "awaiting_human"
            db.commit()
        finally:
            db.close()

        stopped = client.post(
            f"/api/v1/projects/{pid}/ui-scenario-agent/sessions/{sid}/stop",
            headers=h,
        )
        assert stopped.status_code == 200, stopped.text
        assert stopped.json()["status"] == "error"
        assert "已手动停止" in (stopped.json().get("error_message") or "")
    finally:
        agent_api.set_explore_runner(None)


def test_ui_scenario_agent_requires_prompt_or_testcase(monkeypatch):
    key = Fernet.generate_key().decode()
    monkeypatch.setattr(settings, "settings_encryption_key", key)
    from app.services.ai.effective_ai_settings import LlmRuntime

    monkeypatch.setattr(
        "app.api.ui_automation.ui_scenario_agent.get_llm_runtime",
        lambda db: LlmRuntime(
            api_base="https://example.com/v1",
            api_key="test-key",
            model="m",
            allowed_models_csv="m",
        ),
    )

    _user("uisa_b", "p")
    tok = _login("uisa_b", "p")
    pid = _project(tok, "UISA2")
    client = TestClient(app)
    h = {"Authorization": f"Bearer {tok}"}
    er = client.post(
        f"/api/v1/projects/{pid}/ui-envs/",
        headers=h,
        json={"name": "local", "base_url": "https://app.example.com", "is_default": True},
    )
    assert er.status_code == 201
    bad = client.post(
        f"/api/v1/projects/{pid}/ui-scenario-agent/sessions",
        headers=h,
        json={"prompt": "", "env_id": er.json()["id"]},
    )
    assert bad.status_code == 400


def _add_member(pid: int, username: str, role: str = "editor"):
    db = TestingSessionLocal()
    try:
        from app.models.project.project import ProjectMember

        u = db.query(User).filter(User.username == username).one()
        db.add(ProjectMember(project_id=pid, user_id=u.id, role=role))
        db.commit()
    finally:
        db.close()


def test_ui_scenario_agent_session_list_delete_isolation(monkeypatch):
    key = Fernet.generate_key().decode()
    monkeypatch.setattr(settings, "settings_encryption_key", key)

    from app.services.ai.effective_ai_settings import LlmRuntime
    from app.api.ui_automation import ui_scenario_agent as agent_api

    monkeypatch.setattr(
        "app.api.ui_automation.ui_scenario_agent.get_llm_runtime",
        lambda db: LlmRuntime(
            api_base="https://example.com/v1",
            api_key="test-key",
            model="m",
            allowed_models_csv="m",
        ),
    )

    _user("uisa_hist_a", "p")
    _user("uisa_hist_b", "p")
    tok_a = _login("uisa_hist_a", "p")
    tok_b = _login("uisa_hist_b", "p")
    pid = _project(tok_a, "UISAHist")
    _add_member(pid, "uisa_hist_b", "editor")
    client = TestClient(app)
    h_a = {"Authorization": f"Bearer {tok_a}"}
    h_b = {"Authorization": f"Bearer {tok_b}"}

    er = client.post(
        f"/api/v1/projects/{pid}/ui-envs/",
        headers=h_a,
        json={"name": "local", "base_url": "https://app.example.com", "is_default": True},
    )
    assert er.status_code == 201
    env_id = er.json()["id"]

    def fake_explore(db, session_id: int) -> None:
        from app.models.ui_automation.ui_automation import UiScenarioAgentSession
        from app.services.api_automation.api_scenario_events import get_event_bus

        row = db.get(UiScenarioAgentSession, session_id)
        assert row is not None
        row.status = "awaiting_confirm"
        row.plan_json = {"goal": "打开首页", "start_path": "/", "checklist": [], "case_name": "打开首页"}
        row.result_steps_json = [{"action": "goto", "value": "/"}]
        row.playwright_code = 'def run(page):\n    page.goto("/")\n'
        row.dry_run_status = "passed"
        msgs = list(row.messages_json) if isinstance(row.messages_json, list) else []
        msgs.append({"role": "assistant", "content": "已生成步骤"})
        row.messages_json = msgs
        get_event_bus().append(row.thread_id, {"type": "done", "status": "awaiting_confirm"})
        db.commit()

    agent_api.set_explore_runner(fake_explore)
    try:
        cr = client.post(
            f"/api/v1/projects/{pid}/ui-scenario-agent/sessions",
            headers=h_a,
            json={"prompt": "打开首页并校验列表", "env_id": env_id},
        )
        assert cr.status_code == 201, cr.text
        sid = cr.json()["id"]

        r_list = client.get(f"/api/v1/projects/{pid}/ui-scenario-agent/sessions", headers=h_a)
        assert r_list.status_code == 200
        items = r_list.json()
        assert len(items) == 1
        assert items[0]["id"] == sid
        assert items[0]["title"].startswith("打开首页")
        assert items[0]["status"] == "awaiting_confirm"

        r_other = client.get(f"/api/v1/projects/{pid}/ui-scenario-agent/sessions", headers=h_b)
        assert r_other.status_code == 200
        assert r_other.json() == []

        assert (
            client.get(
                f"/api/v1/projects/{pid}/ui-scenario-agent/sessions/{sid}",
                headers=h_b,
            ).status_code
            == 404
        )

        assert (
            client.delete(
                f"/api/v1/projects/{pid}/ui-scenario-agent/sessions/{sid}",
                headers=h_a,
            ).status_code
            == 204
        )
        assert client.get(f"/api/v1/projects/{pid}/ui-scenario-agent/sessions", headers=h_a).json() == []
    finally:
        agent_api.set_explore_runner(None)


def test_session_explore_screenshot_get(tmp_path, monkeypatch):
    key = Fernet.generate_key().decode()
    monkeypatch.setattr(settings, "settings_encryption_key", key)
    monkeypatch.setattr(settings, "upload_dir", str(tmp_path))

    from app.services.ai.effective_ai_settings import LlmRuntime
    from app.api.ui_automation import ui_scenario_agent as agent_api
    from app.services.file_storage import save_ui_explore_screenshot

    monkeypatch.setattr(
        "app.api.ui_automation.ui_scenario_agent.get_llm_runtime",
        lambda db: LlmRuntime(
            api_base="https://example.com/v1",
            api_key="test-key",
            model="m",
            allowed_models_csv="m",
        ),
    )

    _user("uisa_shot", "p")
    tok = _login("uisa_shot", "p")
    pid = _project(tok, "UISA-SHOT")
    client = TestClient(app)
    h = {"Authorization": f"Bearer {tok}"}
    er = client.post(
        f"/api/v1/projects/{pid}/ui-envs/",
        headers=h,
        json={"name": "local", "base_url": "https://app.example.com", "is_default": True},
    )
    assert er.status_code == 201
    env_id = er.json()["id"]
    saved: dict[str, str] = {}

    def fake_explore(db, session_id: int) -> None:
        from app.models.ui_automation.ui_automation import UiScenarioAgentSession
        from app.services.ui_automation.ui_scenario_agent import _emit_commit

        row = db.get(UiScenarioAgentSession, session_id)
        assert row is not None
        storage_key, _ = save_ui_explore_screenshot(
            row.project_id, row.id, "000_open.png", b"png-bytes"
        )
        saved["key"] = storage_key
        _emit_commit(
            db,
            row,
            node="explore",
            message="已截图 step=0 action=open",
            data={"screenshot_key": storage_key},
        )
        row.status = "awaiting_confirm"
        row.playwright_code = 'def run(page):\n    page.goto("/")\n'
        db.commit()

    agent_api.set_explore_runner(fake_explore)
    try:
        cr = client.post(
            f"/api/v1/projects/{pid}/ui-scenario-agent/sessions",
            headers=h,
            json={"prompt": "打开首页", "env_id": env_id},
        )
        assert cr.status_code == 201, cr.text
        sid = cr.json()["id"]
        events = cr.json().get("events") or []
        assert any(
            isinstance(ev, dict)
            and (ev.get("data") or {}).get("screenshot_key") == saved["key"]
            for ev in events
        )
        shot = client.get(
            f"/api/v1/projects/{pid}/ui-scenario-agent/sessions/{sid}/screenshots",
            headers=h,
            params={"key": saved["key"]},
        )
        assert shot.status_code == 200
        assert shot.content == b"png-bytes"
        denied = client.get(
            f"/api/v1/projects/{pid}/ui-scenario-agent/sessions/{sid}/screenshots",
            headers=h,
            params={"key": f"{pid}/ui-runs/1/x.png"},
        )
        assert denied.status_code == 404
    finally:
        agent_api.set_explore_runner(None)


def test_ui_scenario_agent_trial_run(monkeypatch, tmp_path):
    key = Fernet.generate_key().decode()
    monkeypatch.setattr(settings, "settings_encryption_key", key)
    monkeypatch.setattr(settings, "upload_dir", str(tmp_path))

    from app.services.ai.effective_ai_settings import LlmRuntime
    from app.api.ui_automation import ui_scenario_agent as agent_api

    monkeypatch.setattr(
        "app.api.ui_automation.ui_scenario_agent.get_llm_runtime",
        lambda db: LlmRuntime(
            api_base="https://example.com/v1",
            api_key="test-key",
            model="m",
            allowed_models_csv="m",
        ),
    )

    _user("uisa_trial", "p")
    tok = _login("uisa_trial", "p")
    pid = _project(tok, "UISATrial")
    client = TestClient(app)
    h = {"Authorization": f"Bearer {tok}"}

    er = client.post(
        f"/api/v1/projects/{pid}/ui-envs/",
        headers=h,
        json={"name": "local", "base_url": "https://app.example.com", "is_default": True},
    )
    assert er.status_code == 201, er.text
    env_id = er.json()["id"]

    script = (
        "async function run(page, agent) {\n"
        "  await page.goto('/login');\n"
        "  await expect(page).toHaveURL(/\\/home/);\n"
        "}\n"
    )

    def fake_explore(db, session_id: int) -> None:
        from app.models.ui_automation.ui_automation import UiScenarioAgentSession
        from app.services.api_automation.api_scenario_events import get_event_bus

        row = db.get(UiScenarioAgentSession, session_id)
        assert row is not None
        row.status = "awaiting_confirm"
        row.plan_json = {
            "goal": "登录",
            "start_path": "/login",
            "checklist": ["登录"],
            "case_name": "登录成功",
            "case_scripts": [
                {
                    "id": "TC-01",
                    "name": "登录成功",
                    "ready": True,
                    "code": script,
                    "is_login": True,
                    "needs_auth": False,
                }
            ],
            "_headed": True,
        }
        row.playwright_code = script
        row.dry_run_status = None
        row.dry_run_error = ""
        msgs = list(row.messages_json) if isinstance(row.messages_json, list) else []
        msgs.append({"role": "assistant", "content": "已生成脚本。"})
        row.messages_json = msgs
        get_event_bus().append(row.thread_id, {"type": "interrupted", "message": "等待确认"})
        db.commit()

    def fake_trial(db, session_id: int) -> None:
        from app.services.ui_automation.ui_scenario_agent import execute_session_trial_run

        execute_session_trial_run(db, session_id)

    returned_rows = [{"action": "goto", "status": "passed", "error_message": ""}]

    def fake_execute_ui_script(**kwargs):
        from pathlib import Path

        save = kwargs.get("save_storage_state_path")
        if save:
            Path(save).write_text('{"cookies":[],"origins":[]}', encoding="utf-8")
        rows = [dict(item) for item in returned_rows]
        screenshot_saver = kwargs.get("screenshot_saver")
        on_step = kwargs.get("on_step")
        for index, item in enumerate(rows):
            item.setdefault("order", index)
            item.setdefault("duration_ms", 25 + index)
            item.setdefault("selector", "/login")
            item.setdefault("detail_json", {"url": "https://app.example.com/home"})
            if screenshot_saver:
                item["screenshot_key"] = screenshot_saver(b"\x89PNG\r\n\x1a\ntrial", f"step_{index}.png")
            if on_step:
                on_step(item)
        return rows

    agent_api.set_explore_runner(fake_explore)
    agent_api.set_trial_runner(fake_trial)
    try:
        with patch(
            "app.services.ui_automation.ui_runner.execute_ui_script",
            side_effect=fake_execute_ui_script,
        ):
            cr = client.post(
                f"/api/v1/projects/{pid}/ui-scenario-agent/sessions",
                headers=h,
                json={"prompt": "账号 admin 密码 admin123，登录", "env_id": env_id, "headed": True},
            )
            assert cr.status_code == 201, cr.text
            sess = cr.json()
            assert sess["status"] == "awaiting_confirm"

            tr = client.post(
                f"/api/v1/projects/{pid}/ui-scenario-agent/sessions/{sess['id']}/trial-run",
                headers=h,
                json={"case_id": "TC-01", "headed": False, "script": script},
            )
            assert tr.status_code == 200, tr.text
            body = tr.json()
            assert body["dry_run_status"] == "passed"
            assert body["dry_run_error"] == ""
            assert body["status"] == "awaiting_confirm"
            trial_msgs = [
                m
                for m in (body.get("messages") or [])
                if isinstance(m, dict)
                and m.get("role") == "assistant"
                and "试跑" in str(m.get("content") or "")
            ]
            assert trial_msgs == []
            events = body.get("events") or []
            assert any(isinstance(ev, dict) and ev.get("type") == "trial_start" for ev in events)
            assert any(
                isinstance(ev, dict)
                and ev.get("type") == "trial_done"
                and ev.get("status") == "passed"
                and ev.get("steps") == 1
                for ev in events
            )
            trial_steps = [
                ev for ev in events if isinstance(ev, dict) and ev.get("type") == "trial_step"
            ]
            assert len(trial_steps) == 1
            assert trial_steps[0]["phase"] == "login"
            assert (trial_steps[0].get("data") or {}).get("screenshot_key")
            plan = body.get("plan") or {}
            step_results = (plan.get("_trial") or {}).get("step_results") or []
            assert len(step_results) == 1
            assert step_results[0]["status"] == "passed"
            assert step_results[0]["duration_ms"] == 25
            shot_key = step_results[0]["screenshot_key"]
            assert shot_key.startswith(f"{pid}/ui-explore/{sess['id']}/")
            shot = client.get(
                (
                    f"/api/v1/projects/{pid}/ui-scenario-agent/sessions/"
                    f"{sess['id']}/screenshots"
                ),
                headers=h,
                params={"key": shot_key},
            )
            assert shot.status_code == 200
            assert shot.content.startswith(b"\x89PNG")
            auth = plan.get("_trial_auth") or {}
            assert auth.get("path")
            assert auth.get("from_case") == "TC-01"
            from pathlib import Path

            assert Path(auth["path"]).is_file()

            returned_rows.clear()
            empty = client.post(
                f"/api/v1/projects/{pid}/ui-scenario-agent/sessions/{sess['id']}/trial-run",
                headers=h,
                json={"case_id": "TC-01", "headed": False, "script": script},
            )
            assert empty.status_code == 200, empty.text
            empty_body = empty.json()
            assert empty_body["dry_run_status"] == "error"
            assert "未返回任何执行步骤" in empty_body["dry_run_error"]
            assert (empty_body["plan"]["_trial"].get("step_results") or []) == []
            assert not any(
                isinstance(m, dict)
                and m.get("role") == "assistant"
                and "试跑" in str(m.get("content") or "")
                for m in (empty_body.get("messages") or [])
            )

            returned_rows.append({"action": "click", "status": "unknown"})
            unknown = client.post(
                f"/api/v1/projects/{pid}/ui-scenario-agent/sessions/{sess['id']}/trial-run",
                headers=h,
                json={"case_id": "TC-01", "headed": False, "script": script},
            )
            assert unknown.status_code == 200, unknown.text
            unknown_body = unknown.json()
            assert unknown_body["dry_run_status"] == "error"
            unknown_steps = unknown_body["plan"]["_trial"].get("step_results") or []
            assert len(unknown_steps) == 1
            assert unknown_steps[0]["action"] == "click"
            assert "状态异常" in unknown_body["dry_run_error"]
    finally:
        agent_api.set_explore_runner(None)
        agent_api.set_trial_runner(None)


def test_ui_scenario_agent_trial_needs_auth_bootstraps_login(monkeypatch, tmp_path):
    """needs_auth case with no saved state auto-runs login then business script."""
    key = Fernet.generate_key().decode()
    monkeypatch.setattr(settings, "settings_encryption_key", key)
    monkeypatch.setattr(settings, "upload_dir", str(tmp_path))

    from app.services.ai.effective_ai_settings import LlmRuntime
    from app.api.ui_automation import ui_scenario_agent as agent_api

    monkeypatch.setattr(
        "app.api.ui_automation.ui_scenario_agent.get_llm_runtime",
        lambda db: LlmRuntime(
            api_base="https://example.com/v1",
            api_key="test-key",
            model="m",
            allowed_models_csv="m",
        ),
    )

    _user("uisa_trial_auth", "p")
    tok = _login("uisa_trial_auth", "p")
    pid = _project(tok, "UISATrialAuth")
    client = TestClient(app)
    h = {"Authorization": f"Bearer {tok}"}

    er = client.post(
        f"/api/v1/projects/{pid}/ui-envs/",
        headers=h,
        json={"name": "local", "base_url": "https://app.example.com", "is_default": True},
    )
    assert er.status_code == 201, er.text
    env_id = er.json()["id"]

    login_script = (
        "async function run(page, agent) {\n"
        "  await page.goto('/login');\n"
        "  await expect(page).toHaveURL(/\\/home/);\n"
        "}\n"
    )
    biz_script = (
        "async function run(page, agent) {\n"
        "  // auth: reuse storageState from login case (dry-run loads saved auth)\n"
        "  await page.goto('/projects');\n"
        "  await expect(page.getByText('列表')).toBeVisible();\n"
        "}\n"
    )

    calls: list[dict] = []

    def fake_explore(db, session_id: int) -> None:
        from app.models.ui_automation.ui_automation import UiScenarioAgentSession
        from app.services.api_automation.api_scenario_events import get_event_bus

        row = db.get(UiScenarioAgentSession, session_id)
        assert row is not None
        row.status = "awaiting_confirm"
        row.plan_json = {
            "goal": "登录后项目管理",
            "start_path": "/login",
            "checklist": ["登录", "项目"],
            "case_name": "端到端",
            "case_scripts": [
                {
                    "id": "TC-01",
                    "name": "登录成功",
                    "ready": True,
                    "code": login_script,
                    "is_login": True,
                    "needs_auth": False,
                },
                {
                    "id": "TC-02",
                        "name": "查看项目列表",
                    "ready": True,
                    "code": biz_script,
                    "is_login": False,
                    "needs_auth": True,
                },
            ],
            "_headed": True,
        }
        row.playwright_code = biz_script
        row.dry_run_status = None
        row.dry_run_error = ""
        get_event_bus().append(row.thread_id, {"type": "interrupted", "message": "等待确认"})
        db.commit()

    def fake_trial(db, session_id: int) -> None:
        from app.services.ui_automation.ui_scenario_agent import execute_session_trial_run

        execute_session_trial_run(db, session_id)

    def fake_execute_ui_script(**kwargs):
        from pathlib import Path

        calls.append(
            {
                "script": kwargs.get("script") or "",
                "storage_state_path": kwargs.get("storage_state_path"),
                "save_storage_state_path": kwargs.get("save_storage_state_path"),
            }
        )
        save = kwargs.get("save_storage_state_path")
        if save:
            Path(save).write_text('{"cookies":[],"origins":[]}', encoding="utf-8")
        row = {
            "order": 0,
            "action": "goto",
            "status": "passed",
            "error_message": "",
            "duration_ms": 10,
        }
        screenshot_saver = kwargs.get("screenshot_saver")
        if screenshot_saver:
            row["screenshot_key"] = screenshot_saver(b"\x89PNG\r\n\x1a\ntrial", "step_0.png")
        on_step = kwargs.get("on_step")
        if on_step:
            on_step(row)
        return [row]

    agent_api.set_explore_runner(fake_explore)
    agent_api.set_trial_runner(fake_trial)
    try:
        with patch(
            "app.services.ui_automation.ui_runner.execute_ui_script",
            side_effect=fake_execute_ui_script,
        ):
            cr = client.post(
                f"/api/v1/projects/{pid}/ui-scenario-agent/sessions",
                headers=h,
                json={"prompt": "账号 admin 密码 x，登录后项目管理", "env_id": env_id, "headed": True},
            )
            assert cr.status_code == 201, cr.text
            sess = cr.json()

            tr = client.post(
                f"/api/v1/projects/{pid}/ui-scenario-agent/sessions/{sess['id']}/trial-run",
                headers=h,
                json={"case_id": "TC-02", "headed": False},
            )
            assert tr.status_code == 200, tr.text
            body = tr.json()
            assert body["dry_run_status"] == "passed", body.get("dry_run_error")
            assert len(calls) == 2
            assert "goto('/login')" in (calls[0]["script"] or "")
            assert calls[0]["save_storage_state_path"]
            assert calls[0]["storage_state_path"] is None
            assert "goto('/projects')" in (calls[1]["script"] or "")
            assert calls[1]["storage_state_path"] == calls[0]["save_storage_state_path"]
            plan = body.get("plan") or {}
            assert (plan.get("_trial_auth") or {}).get("from_case") == "TC-01"
            steps = (plan.get("_trial") or {}).get("step_results") or []
            assert [step["phase"] for step in steps] == ["login", "business"]
            assert all(step.get("screenshot_key") for step in steps)
            assert (plan.get("_trial") or {}).get("steps") == 2
    finally:
        agent_api.set_explore_runner(None)
        agent_api.set_trial_runner(None)


def test_ui_scenario_agent_trial_run_rejects_while_running(monkeypatch):
    key = Fernet.generate_key().decode()
    monkeypatch.setattr(settings, "settings_encryption_key", key)

    from app.services.ai.effective_ai_settings import LlmRuntime
    from app.api.ui_automation import ui_scenario_agent as agent_api
    from app.models.ui_automation.ui_automation import UiScenarioAgentSession

    monkeypatch.setattr(
        "app.api.ui_automation.ui_scenario_agent.get_llm_runtime",
        lambda db: LlmRuntime(
            api_base="https://example.com/v1",
            api_key="test-key",
            model="m",
            allowed_models_csv="m",
        ),
    )

    _user("uisa_trial2", "p")
    tok = _login("uisa_trial2", "p")
    pid = _project(tok, "UISATrial2")
    client = TestClient(app)
    h = {"Authorization": f"Bearer {tok}"}

    er = client.post(
        f"/api/v1/projects/{pid}/ui-envs/",
        headers=h,
        json={"name": "local", "base_url": "https://app.example.com", "is_default": True},
    )
    assert er.status_code == 201, er.text
    env_id = er.json()["id"]

    def fake_explore(db, session_id: int) -> None:
        from app.services.api_automation.api_scenario_events import get_event_bus

        row = db.get(UiScenarioAgentSession, session_id)
        assert row is not None
        row.status = "awaiting_confirm"
        row.plan_json = {
            "goal": "x",
            "case_scripts": [
                {
                    "id": "TC-01",
                    "name": "x",
                    "ready": True,
                    "code": "async function run(page, agent) {\n  await page.goto('/');\n}\n",
                }
            ],
        }
        row.playwright_code = "async function run(page, agent) {\n  await page.goto('/');\n}\n"
        get_event_bus().append(row.thread_id, {"type": "interrupted", "message": "等待确认"})
        db.commit()

    def noop_trial(db, session_id: int) -> None:
        # Leave dry_run_status as running (set by enqueue)
        return

    agent_api.set_explore_runner(fake_explore)
    agent_api.set_trial_runner(noop_trial)
    try:
        cr = client.post(
            f"/api/v1/projects/{pid}/ui-scenario-agent/sessions",
            headers=h,
            json={"prompt": "打开", "env_id": env_id},
        )
        assert cr.status_code == 201, cr.text
        sid = cr.json()["id"]
        first = client.post(
            f"/api/v1/projects/{pid}/ui-scenario-agent/sessions/{sid}/trial-run",
            headers=h,
            json={"case_id": "TC-01", "headed": True},
        )
        assert first.status_code == 200, first.text
        assert first.json()["dry_run_status"] == "running"
        second = client.post(
            f"/api/v1/projects/{pid}/ui-scenario-agent/sessions/{sid}/trial-run",
            headers=h,
            json={"case_id": "TC-01", "headed": True},
        )
        assert second.status_code == 400
    finally:
        agent_api.set_explore_runner(None)
        agent_api.set_trial_runner(None)


def test_ui_scenario_agent_trial_repair_reruns_and_writes_back(monkeypatch):
    key = Fernet.generate_key().decode()
    monkeypatch.setattr(settings, "settings_encryption_key", key)
    from app.api.ui_automation import ui_scenario_agent as agent_api
    from app.services.ai.effective_ai_settings import LlmRuntime

    runtime = LlmRuntime(
        api_base="https://example.com/v1",
        api_key="test-key",
        model="m",
        allowed_models_csv="m",
    )
    monkeypatch.setattr("app.api.ui_automation.ui_scenario_agent.get_llm_runtime", lambda db: runtime)
    monkeypatch.setattr(
        "app.services.ui_automation.ui_scenario_agent.get_llm_runtime", lambda db: runtime
    )

    _user("uisa_trial_repair", "p")
    tok = _login("uisa_trial_repair", "p")
    pid = _project(tok, "UISATrialRepair")
    client = TestClient(app)
    h = {"Authorization": f"Bearer {tok}"}
    er = client.post(
        f"/api/v1/projects/{pid}/ui-envs/",
        headers=h,
        json={"name": "local", "base_url": "https://app.example.com", "is_default": True},
    )
    env_id = er.json()["id"]
    old_script = (
        "async function run(page, agent) {\n"
        "  await page.goto('/requirements');\n"
        "  await expect(page.getByText('需求文档')).toBeVisible();\n"
        "}\n"
    )
    fixed_script = old_script.replace("'需求文档'", "'需求文档详情'")

    def fake_explore(db, session_id: int) -> None:
        from app.models.ui_automation.ui_automation import UiScenarioAgentSession

        row = db.get(UiScenarioAgentSession, session_id)
        row.status = "awaiting_confirm"
        row.plan_json = {
            "goal": "查看需求",
            "case_scripts": [
                {
                    "id": "TC-01",
                    "name": "查看需求",
                    "ready": True,
                    "code": old_script,
                    "needs_auth": False,
                    "is_login": False,
                }
            ],
        }
        row.playwright_code = old_script
        db.commit()

    def fake_trial(db, session_id: int) -> None:
        from app.services.ui_automation.ui_scenario_agent import execute_session_trial_run

        execute_session_trial_run(db, session_id)

    calls = 0

    def fake_execute(**_kwargs):
        nonlocal calls
        calls += 1
        if calls == 1:
            return [
                {
                    "status": "error",
                    "error_message": "locator not found",
                    "selector": "text=需求文档",
                    "failure_url": "https://app.example.com/requirements",
                    "failure_snapshot": "- heading: 需求文档详情",
                }
            ]
        return [{"status": "passed", "error_message": ""}]

    monkeypatch.setattr(
        "app.services.ui_automation.ui_codegen_agents.repair_trial_script",
        lambda **_kwargs: (fixed_script, []),
    )
    agent_api.set_explore_runner(fake_explore)
    agent_api.set_trial_runner(fake_trial)
    try:
        with patch(
            "app.services.ui_automation.ui_runner.execute_ui_script",
            side_effect=fake_execute,
        ):
            created = client.post(
                f"/api/v1/projects/{pid}/ui-scenario-agent/sessions",
                headers=h,
                json={"prompt": "查看需求", "env_id": env_id},
            ).json()
            failed = client.post(
                f"/api/v1/projects/{pid}/ui-scenario-agent/sessions/{created['id']}/trial-run",
                headers=h,
                json={"case_id": "TC-01", "headed": False},
            )
            assert failed.status_code == 200, failed.text
            failed_body = failed.json()
            assert failed_body["dry_run_status"] == "error"
            assert (failed_body["plan"]["_trial"]["failure"]["failure_snapshot"])

            assert failed_body["plan"]["case_scripts"][0]["code"] == old_script

            preview = client.post(
                f"/api/v1/projects/{pid}/ui-scenario-agent/sessions/{created['id']}/trial-repair/preview",
                headers=h,
                json={"case_id": "TC-01"},
            )
            assert preview.status_code == 200, preview.text
            preview_body = preview.json()
            rp = preview_body["plan"]["_trial"]["repair_preview"]
            assert rp["before"].strip() == old_script.strip()
            assert rp["after"].strip() == fixed_script.strip()
            assert preview_body["plan"]["case_scripts"][0]["code"] == old_script

            applied = client.post(
                f"/api/v1/projects/{pid}/ui-scenario-agent/sessions/{created['id']}/trial-repair/apply",
                headers=h,
                json={"script": fixed_script},
            )
            assert applied.status_code == 200, applied.text
            apply_body = applied.json()
            assert apply_body["plan"]["_trial"]["repair_attempts"] == 1
            assert apply_body["plan"]["_trial"]["repair_preview"] is None
            assert apply_body["plan"]["case_scripts"][0]["code"].strip() == fixed_script.strip()
            assert apply_body["playwright_code"].strip() == fixed_script.strip()

            passed = client.post(
                f"/api/v1/projects/{pid}/ui-scenario-agent/sessions/{created['id']}/trial-run",
                headers=h,
                json={"case_id": "TC-01", "headed": False, "script": fixed_script},
            )
            assert passed.status_code == 200, passed.text
            body = passed.json()
            assert body["dry_run_status"] == "passed"
            assert body["plan"]["_trial"]["repair_attempts"] == 1

            from app.models.ui_automation.ui_automation import UiScenarioAgentSession

            db = TestingSessionLocal()
            try:
                row = db.get(UiScenarioAgentSession, created["id"])
                plan = dict(row.plan_json)
                plan["_trial"] = {
                    **dict(plan["_trial"]),
                    "status": "failed",
                    "failure": {"error_message": "still failed"},
                    "repair_attempts": 2,
                }
                row.plan_json = plan
                row.dry_run_status = "failed"
                db.commit()
            finally:
                db.close()
            limited = client.post(
                f"/api/v1/projects/{pid}/ui-scenario-agent/sessions/{created['id']}/trial-repair/preview",
                headers=h,
                json={"case_id": "TC-01"},
            )
            assert limited.status_code == 400
            assert "2 轮上限" in limited.text

            legacy = client.post(
                f"/api/v1/projects/{pid}/ui-scenario-agent/sessions/{created['id']}/trial-repair",
                headers=h,
                json={"case_id": "TC-01"},
            )
            assert legacy.status_code == 400
    finally:
        agent_api.set_explore_runner(None)
        agent_api.set_trial_runner(None)


def test_ui_scenario_agent_trial_repair_discard_preview(monkeypatch):
    key = Fernet.generate_key().decode()
    monkeypatch.setattr(settings, "settings_encryption_key", key)
    from app.api.ui_automation import ui_scenario_agent as agent_api
    from app.services.ai.effective_ai_settings import LlmRuntime

    runtime = LlmRuntime(
        api_base="https://example.com/v1",
        api_key="test-key",
        model="m",
        allowed_models_csv="m",
    )
    monkeypatch.setattr("app.api.ui_automation.ui_scenario_agent.get_llm_runtime", lambda db: runtime)
    monkeypatch.setattr(
        "app.services.ui_automation.ui_scenario_agent.get_llm_runtime", lambda db: runtime
    )

    _user("uisa_trial_discard", "p")
    tok = _login("uisa_trial_discard", "p")
    pid = _project(tok, "UISATrialDiscard")
    client = TestClient(app)
    h = {"Authorization": f"Bearer {tok}"}
    er = client.post(
        f"/api/v1/projects/{pid}/ui-envs/",
        headers=h,
        json={"name": "local", "base_url": "https://app.example.com", "is_default": True},
    )
    env_id = er.json()["id"]
    script = "async function run(page, agent) {\n  await page.goto('/');\n}\n"

    def fake_explore(db, session_id: int) -> None:
        from app.models.ui_automation.ui_automation import UiScenarioAgentSession

        row = db.get(UiScenarioAgentSession, session_id)
        row.status = "awaiting_confirm"
        row.plan_json = {
            "case_scripts": [
                {"id": "TC-01", "name": "t", "ready": True, "code": script, "needs_auth": False}
            ],
        }
        row.playwright_code = script
        db.commit()

    def fake_trial(db, session_id: int) -> None:
        from app.services.ui_automation.ui_scenario_agent import execute_session_trial_run

        execute_session_trial_run(db, session_id)

    monkeypatch.setattr(
        "app.services.ui_automation.ui_codegen_agents.repair_trial_script",
        lambda **_kwargs: (script + "\n", []),
    )
    agent_api.set_explore_runner(fake_explore)
    agent_api.set_trial_runner(fake_trial)
    try:
        with patch(
            "app.services.ui_automation.ui_runner.execute_ui_script",
            return_value=[{"status": "error", "error_message": "boom"}],
        ):
            created = client.post(
                f"/api/v1/projects/{pid}/ui-scenario-agent/sessions",
                headers=h,
                json={"prompt": "x", "env_id": env_id},
            ).json()
            client.post(
                f"/api/v1/projects/{pid}/ui-scenario-agent/sessions/{created['id']}/trial-run",
                headers=h,
                json={"case_id": "TC-01", "headed": False},
            )
            client.post(
                f"/api/v1/projects/{pid}/ui-scenario-agent/sessions/{created['id']}/trial-repair/preview",
                headers=h,
                json={"case_id": "TC-01"},
            )
            discarded = client.post(
                f"/api/v1/projects/{pid}/ui-scenario-agent/sessions/{created['id']}/trial-repair/discard",
                headers=h,
            )
            assert discarded.status_code == 200, discarded.text
            assert discarded.json()["plan"]["_trial"]["repair_preview"] is None
            assert discarded.json()["plan"]["case_scripts"][0]["code"] == script
            assert discarded.json()["plan"]["_trial"]["repair_attempts"] == 0
    finally:
        agent_api.set_explore_runner(None)
        agent_api.set_trial_runner(None)
