"""Playwright-cli explore loop + codegen (mocked CLI session)."""

from __future__ import annotations

import re
from typing import Any
from unittest.mock import MagicMock, patch

from app.services.ai.effective_ai_settings import LlmRuntime
from app.services.ui_automation.playwright_cli_session import (
    is_element_ref,
    is_snapshot_ref_locator,
    normalize_ref,
)
from app.services.ui_automation.ui_cli_explorer import (
    actions_from_cli_trace,
    compile_cli_trace_script,
    run_cli_explore_loop,
)
from app.services.ui_automation.ui_explore_engines import run_playwright_cli_engine
from app.services.ui_automation.ui_explore_report import matrix_bind_issues

ENGINE_LLM = LlmRuntime(
    api_base="http://llm",
    api_key="test",
    model="test",
    allowed_models_csv="",
)


def _patch_codegen_pipeline(
    monkeypatch: Any,
    script: str,
    *,
    ready: bool = True,
) -> None:
    def fake_pipeline(*, matrix, trace, llm, **kwargs):  # noqa: ANN001, ARG001
        rows = []
        for m in matrix:
            rows.append(
                {
                    "id": str(m.get("id") or "TC-001"),
                    "name": str(m.get("name") or ""),
                    "code": script if ready else "",
                    "ready": ready and bool(script),
                    "start_url": str(m.get("start_url") or "/"),
                    "needs_auth": False,
                    "is_login": bool(
                        re.search(r"登录|login", str(m.get("name") or ""), re.I)
                    ),
                    "verify_status": "skipped",
                    "verify_error": "",
                    "attempts": 0,
                    "guard_errors": [] if ready else ["blocked"],
                    "navigation_start_path": "",
                    "navigation_prefix": [],
                }
            )
        return rows, None

    monkeypatch.setattr(
        "app.services.ui_automation.ui_explore_engines.run_codegen_pipeline",
        fake_pipeline,
    )


def test_ref_helpers():
    assert is_element_ref("e12")
    assert is_element_ref("ref=e3")
    assert is_element_ref("f1e12")
    assert is_element_ref("ref=f1e3")
    assert not is_element_ref("role=button[name=登录]")
    assert normalize_ref("ref=e9") == "e9"
    assert normalize_ref("ref=f1e367") == "f1e367"
    assert normalize_ref("f1e49") == "f1e49"
    assert is_snapshot_ref_locator("e23")
    assert is_snapshot_ref_locator("f1e367")
    assert is_snapshot_ref_locator('page.locator("e23")')
    assert is_snapshot_ref_locator('page.locator("f1e23")')
    assert not is_snapshot_ref_locator('page.getByRole("button", { name: "登录" })')
    assert not is_snapshot_ref_locator('page.locator("#username")')


def test_is_captcha_decision_ignores_reason_mentioning_captcha():
    from app.services.ui_automation.ui_cli_explorer import (
        _is_captcha_decision,
        fill_field_kind,
    )

    # reason mentions 验证码 but field is password / username → not captcha
    assert not _is_captcha_decision(
        {
            "action": "fill",
            "name": "密码",
            "selector": "e12",
            "reason": "账号与验证码已就绪，先补齐密码再登录",
        }
    )
    assert fill_field_kind({"name": "密码", "reason": "验证码已填，补密码"}) == "password"
    assert not _is_captcha_decision(
        {
            "action": "fill",
            "name": "账号",
            "selector": "e10",
            "reason": "填写登录账号，随后继续密码与验证码",
        }
    )
    assert fill_field_kind({"name": "账号", "reason": "随后继续验证码"}) == "username"
    # real captcha field
    assert _is_captcha_decision({"action": "fill", "name": "验证码", "selector": "e16"})
    assert fill_field_kind({"placeholder": "请输入图中字符"}) == "captcha"
    assert fill_field_kind({"name": "验证码"}) == "captcha"


def test_locator_fields_from_snapshot():
    from app.services.ui_automation.ui_cli_explorer import locator_fields_from_snapshot

    snap = '- button "新建项目" [ref=e23] [cursor=pointer]\n- textbox "账号" [ref=e12]'
    assert locator_fields_from_snapshot(snap, "e23") == {"role": "button", "name": "新建项目"}
    assert locator_fields_from_snapshot(snap, "ref=e12") == {"role": "textbox", "name": "账号"}

    snap_frame = (
        '- link "RainaAI测试平台" [ref=f1e7] [cursor=pointer]\n'
        '- button "新建项目" [ref=f1e49] [cursor=pointer]\n'
        '- textbox "名称" [ref=f1e367]'
    )
    assert locator_fields_from_snapshot(snap_frame, "f1e7") == {
        "role": "link",
        "name": "RainaAI测试平台",
    }
    assert locator_fields_from_snapshot(snap_frame, "ref=f1e49") == {
        "role": "button",
        "name": "新建项目",
    }
    assert locator_fields_from_snapshot(snap_frame, "f1e367") == {
        "role": "textbox",
        "name": "名称",
    }


def test_locator_fields_from_snapshot_child_text_and_colon():
    from app.services.ui_automation.ui_cli_explorer import locator_fields_from_snapshot

    snap_colon = '- button [ref=e40]: 保存\n- textbox "账号" [ref=e12]'
    assert locator_fields_from_snapshot(snap_colon, "e40") == {"role": "button", "name": "保存"}

    snap_child = (
        '- button [ref=e41] [cursor=pointer]\n'
        '  - text: "进入项目"\n'
        '- link "首页" [ref=e1]'
    )
    assert locator_fields_from_snapshot(snap_child, "e41") == {
        "role": "button",
        "name": "进入项目",
    }


def test_fields_from_dom_attrs_prefer_testid_and_role():
    from app.services.ui_automation.ui_cli_explorer import _fields_from_dom_attrs

    tid = _fields_from_dom_attrs({"testid": "login-btn", "name": "登录", "role": "button"})
    assert tid["selector"] == "testid=login-btn"
    assert "getByTestId" in tid["cli_locator"]

    role = _fields_from_dom_attrs({"role": "button", "name": "file-text 新建项目"})
    assert role["role"] == "button"
    assert role["name"] == "新建项目"
    assert "getByRole" in role["cli_locator"]


def test_recover_durable_locator_falls_back_to_eval_then_snapshot():
    from app.services.ui_automation.ui_cli_explorer import recover_durable_locator

    fake_cli = MagicMock()
    fake_cli.generate_locator.return_value = ""
    fake_cli.extract_locator_attrs.return_value = {
        "role": "button",
        "name": "新建项目",
        "testid": "",
        "placeholder": "",
    }
    decision: dict = {"action": "click", "selector": "e23"}
    expr = recover_durable_locator(fake_cli, "e23", decision)
    assert "getByRole" in expr
    assert decision.get("role") == "button"
    assert decision.get("name") == "新建项目"
    fake_cli.snapshot.assert_not_called()

    fake_cli2 = MagicMock()
    fake_cli2.generate_locator.return_value = 'page.locator("e99")'
    fake_cli2.extract_locator_attrs.return_value = {}
    fake_cli2.snapshot.return_value = '- button "提交" [ref=e99]'
    decision2: dict = {"action": "click", "selector": "e99"}
    expr2 = recover_durable_locator(fake_cli2, "e99", decision2)
    assert "getByRole" in expr2
    assert decision2.get("name") == "提交"

    fake_cli3 = MagicMock()
    fake_cli3.generate_locator.return_value = 'page.locator("f1e99")'
    fake_cli3.extract_locator_attrs.return_value = {}
    fake_cli3.snapshot.return_value = '- button "提交" [ref=f1e99]'
    decision3: dict = {"action": "click", "selector": "f1e99"}
    expr3 = recover_durable_locator(fake_cli3, "f1e99", decision3)
    assert "getByRole" in expr3
    assert decision3.get("name") == "提交"
    assert 'locator("f1e99")' not in expr3


def test_format_snapshot_action_candidates_includes_suggested_locator():
    from app.services.ui_automation.ui_cli_explorer import format_snapshot_action_candidates

    text = format_snapshot_action_candidates(
        '- button "登录" [ref=e2]\n- textbox "账号" [ref=e1]'
    )
    assert "建议locator=role=button[name=\"登录\"]" in text
    assert "[ref=e2]" in text


def test_modal_open_for_explore_uses_dom_when_snapshot_lacks_dialog():
    from app.services.ui_automation.playwright_cli_session import PlaywrightCliSession
    from app.services.ui_automation.ui_cli_explorer import (
        modal_open_for_explore,
        should_skip_background_under_modal,
        snapshot_has_open_dialog,
    )

    shallow = (
        '- button "新建项目" [ref=e43] [cursor=pointer]\n'
        '- link "进入项目" [ref=e53] [cursor=pointer]\n'
    )
    assert snapshot_has_open_dialog(shallow) is False
    cli = PlaywrightCliSession.__new__(PlaywrightCliSession)
    cli.dom_modal_visible = MagicMock(return_value=True)
    assert modal_open_for_explore(cli, shallow) is True
    assert should_skip_background_under_modal(
        cli,
        shallow,
        action="click",
        selector="e43",
        dialog_expected=False,
        dialog_opener_refs=[],
    )


def test_modal_intercept_nudge_dom_candidates_exclude_background():
    from app.services.ui_automation.ui_cli_explorer import modal_intercept_nudge

    shallow = '- button "新建项目" [ref=e43]\n'
    dom = '- textbox "名称" 建议locator=role=textbox[name="名称"]\n- button "创建"'
    text = modal_intercept_nudge(
        shallow,
        error="ant-modal-wrap intercepts pointer events",
        dom_candidates=dom,
    )
    assert "DOM 检测" in text
    assert "名称" in text
    assert "e43" not in text


def test_format_snapshot_action_candidates_scopes_to_open_dialog():
    from app.services.ui_automation.ui_cli_explorer import (
        format_snapshot_action_candidates,
        modal_intercept_nudge,
        ref_in_dialog_scope,
        resolve_named_control_ref,
        snapshot_has_open_dialog,
    )

    snap = (
        '- button "新建项目" [ref=e43] [cursor=pointer]\n'
        '- link "进入项目" [ref=e53] [cursor=pointer]\n'
        '- dialog "新建项目"\n'
        '  - textbox "项目名称" [ref=e100]\n'
        '  - button "取消" [ref=e101]\n'
        '  - button "创 建" [ref=e102]\n'
    )
    assert snapshot_has_open_dialog(snap)
    text = format_snapshot_action_candidates(snap)
    assert "弹窗已打开" in text
    assert "e100" in text
    assert "e102" in text
    assert "e43" not in text
    assert "e53" not in text
    assert ref_in_dialog_scope(snap, "e100")
    assert not ref_in_dialog_scope(snap, "e43")
    assert (
        resolve_named_control_ref(snap, role="button", name="创 建")
        == "e102"
    )
    nudge = modal_intercept_nudge(
        snap, error="TimeoutError: ant-modal-wrap intercepts pointer events"
    )
    assert "禁止再点" in nudge
    assert "e100" in nudge
    assert "e43" not in nudge


def test_apply_cli_decision_recovers_locator_via_eval():
    from app.services.ui_automation.ui_cli_explorer import apply_cli_decision

    fake_cli = MagicMock()
    fake_cli.generate_locator.return_value = ""
    fake_cli.extract_locator_attrs.return_value = {
        "role": "button",
        "name": "登录",
    }
    rows, _url = apply_cli_decision(
        fake_cli,
        {"action": "click", "selector": "e2"},
        base_url="https://example.com",
        url="https://example.com/login",
        ctx={},
    )
    fake_cli.click.assert_called_once()
    assert rows
    assert "getByRole" in str(rows[0].get("cli_locator") or "")
    assert rows[0].get("name") == "登录"
    assert rows[0].get("driver") != "midscene"
    assert not str(rows[0].get("selector") or "").startswith("e")


def test_apply_cli_decision_named_button_stays_playwright_when_locator_missing():
    from app.services.ui_automation.ui_cli_explorer import apply_cli_decision

    fake_cli = MagicMock()
    fake_cli.generate_locator.return_value = ""
    fake_cli.extract_locator_attrs.return_value = {}
    fake_cli.snapshot.return_value = "- generic [ref=e2]"
    logs: list[str] = []
    rows, _url = apply_cli_decision(
        fake_cli,
        {
            "action": "click",
            "selector": "e2",
            "reason": "验证码已识别填入，点击登录按钮提交",
        },
        base_url="https://example.com",
        url="https://example.com/",
        ctx={},
        on_log=logs.append,
    )
    assert rows
    # Recoverable button name → Playwright role+name, not midscene promote
    assert rows[0].get("driver") == "playwright"
    assert rows[0].get("name") == "登录"
    assert rows[0].get("role") == "button"
    assert rows[0].get("locate") == "登录"
    assert "验证码已识别" not in str(rows[0].get("locate") or "")
    assert rows[0].get("locator_fallback_midscene") is not True
    assert not any("Midscene" in m for m in logs)
    fake_cli.click.assert_called_once()


def test_apply_cli_decision_promotes_midscene_for_visual_only_target():
    from app.services.ui_automation.ui_cli_explorer import apply_cli_decision

    fake_cli = MagicMock()
    fake_cli.generate_locator.return_value = ""
    fake_cli.extract_locator_attrs.return_value = {}
    fake_cli.snapshot.return_value = "- generic [ref=e2]"
    logs: list[str] = []
    rows, _url = apply_cli_decision(
        fake_cli,
        {
            "action": "click",
            "selector": "e2",
            "reason": "完全没有可识别按钮词的冗长说明" * 3,
        },
        base_url="https://example.com",
        url="https://example.com/",
        ctx={},
        on_log=logs.append,
    )
    assert rows
    assert rows[0].get("driver") == "midscene"
    assert rows[0].get("locate") == "目标按钮"
    assert rows[0].get("locator_fallback_midscene") is True
    assert any("Midscene" in m for m in logs)
    fake_cli.click.assert_called_once()


def test_midscene_locate_hint_extracts_from_reason():
    from app.services.ui_automation.ui_midscene_locate import midscene_locate_hint

    assert (
        midscene_locate_hint(
            {"reason": "名称已填写，描述为可选，点击创建提交新建项目"},
            action="click",
        )
        == "创建"
    )
    assert (
        midscene_locate_hint(
            {"reason": "弹窗字段已填，点击「创 建」提交"},
            action="click",
        )
        == "创 建"
    )
    assert (
        midscene_locate_hint(
            {
                "reason": "删除需求二次确认弹窗已出现（「确定删除该需求？」），点击「确 定」完成删除"
            },
            action="click",
        )
        == "确 定"
    )
    assert midscene_locate_hint({"locate": "图表放大按钮"}, action="click") == "图表放大按钮"
    long_reason = midscene_locate_hint(
        {"reason": "完全没有可识别按钮词的冗长说明" * 3},
        action="click",
    )
    assert long_reason == "目标按钮"
    assert len(long_reason) <= 40


def test_midscene_locate_hint_curly_quotes_confirm():
    from app.services.ui_automation.ui_midscene_locate import midscene_locate_hint

    # Ant Design spaced label inside curly quotes previously became aiTap("“确")
    assert (
        midscene_locate_hint(
            {"reason": "编辑需求弹窗中标题已改，点击“确 定”保存修改"},
            action="click",
        )
        == "确 定"
    )
    assert (
        midscene_locate_hint(
            {"reason": "删除二次确认，点击“确 定”完成删除"},
            action="click",
        )
        == "确 定"
    )
    assert (
        midscene_locate_hint(
            {"reason": "点击「确 定」保存"},
            action="click",
        )
        == "确 定"
    )
    # Refuse scrap locate left over from bad extraction
    assert (
        midscene_locate_hint(
            {"locate": "“确", "reason": "点击「确 定」"},
            action="click",
        )
        == "确 定"
    )
    for s in (
        midscene_locate_hint({"reason": "点击“确 定”完成删除"}, action="click"),
        midscene_locate_hint({"locate": "“确"}, action="click"),
    ):
        assert "“" not in s
        assert s != "确"


def test_compile_cli_trace_prefers_playwright_locators():
    trace = [
        {"kind": "goto", "path": "/login", "status": "ok", "driver": "playwright"},
        {
            "kind": "fill",
            "action": "fill",
            "status": "ok",
            "driver": "playwright",
            "cli_locator": 'page.getByRole("textbox", { name: "账号" })',
            "selector": 'page.getByRole("textbox", { name: "账号" })',
            "value": "admin",
        },
        {
            "kind": "fill_captcha",
            "action": "fill",
            "status": "ok",
            "driver": "playwright",
            "captcha": True,
            "placeholder": "请输入图中字符",
            "locate": "验证码输入框",
        },
        {
            "kind": "click",
            "action": "click",
            "status": "ok",
            "driver": "midscene",
            "locate": "图表放大按钮",
            "prompt": "图表放大按钮",
        },
    ]
    code = compile_cli_trace_script(trace, start_path="/login", username="admin")
    assert code.startswith("async function run(page, agent)")
    assert "getByRole" in code or "cli_locator" in str(actions_from_cli_trace(trace))
    assert "agent.aiQuery" in code
    assert 'getByPlaceholder("请输入图中字符")' in code  # from trace placeholder
    assert 'getByPlaceholder("验证码")' not in code
    # Named midscene locate compiles to getByRole, not aiTap
    assert "aiTap" not in code
    assert "图表放大" in code
    assert "getByRole" in code
    assert "aiAct(" not in code


def test_snapshot_has_captcha_error_generic_copy():
    from app.services.ui_automation.ui_cli_explorer import snapshot_has_captcha_error
    from app.user_messages import CAPTCHA_INVALID

    assert snapshot_has_captcha_error(f"- paragraph: {CAPTCHA_INVALID}") is True
    assert snapshot_has_captcha_error("- alert: Invalid captcha code") is True
    assert snapshot_has_captcha_error("- text: captcha expired") is True
    assert snapshot_has_captcha_error('- button "登录"') is False
    assert snapshot_has_captcha_error("") is False


def test_run_cli_explore_loop_executes_generic_midscene():
    fake_cli = MagicMock()
    fake_cli.snapshot.return_value = '- textbox "账号" [ref=e1]\n- button "登录" [ref=e2]'
    fake_cli.generate_locator.return_value = 'page.getByRole("textbox", { name: "账号" })'
    fake_cli.cdp_endpoint = "http://127.0.0.1:9222"
    fake_cli.timeout_ms = 5000
    decisions = [
        {"action": "fill", "selector": "e1", "value": "admin"},
        {"action": "click", "driver": "midscene", "prompt": "特殊按钮"},
        {"action": "done"},
    ]

    def fake_decide(**kwargs):
        return decisions.pop(0)

    with (
        patch(
            "app.services.ui_automation.ui_explore_graph.decide_next_action",
            side_effect=fake_decide,
        ),
        patch(
            "app.services.ui_automation.node_ui_runner.midscene_step_over_cdp",
            return_value={"ok": True},
        ) as mock_mid,
    ):
        trace = run_cli_explore_loop(
            base_url="https://example.com",
            plan={"goal": "登录", "start_path": "/login"},
            ctx={"username": "admin", "password": "x"},
            llm_cfg=MagicMock(),
            max_steps=5,
            session=fake_cli,
            midscene_model_config={"MIDSCENE_MODEL_NAME": "test"},
        )
    fake_cli.open.assert_called_once()
    fake_cli.fill.assert_called()
    fake_cli.click.assert_not_called()
    mock_mid.assert_called()
    mid_rows = [t for t in trace if t.get("driver") == "midscene"]
    assert mid_rows
    assert not any(t.get("explore_noop") for t in mid_rows)
    assert any(t.get("explore_midscene_act") for t in mid_rows)
    assert mock_mid.call_args.kwargs.get("action") == "tap"
    assert "aiAct" not in str(trace)


def test_apply_cli_decision_generic_midscene_fill():
    from app.services.ui_automation.ui_cli_explorer import apply_cli_decision

    fake_cli = MagicMock()
    fake_cli.cdp_endpoint = "http://127.0.0.1:9222"
    fake_cli.timeout_ms = 5000
    with patch(
        "app.services.ui_automation.node_ui_runner.midscene_step_over_cdp",
        return_value={"ok": True},
    ) as mock_mid:
        rows, _ = apply_cli_decision(
            fake_cli,
            {
                "action": "fill",
                "driver": "midscene",
                "prompt": "画布上的搜索框",
                "value": "hello",
            },
            base_url="https://example.com",
            ctx={},
            url="https://example.com/",
            midscene_model_config={"MIDSCENE_MODEL_NAME": "test"},
        )
    mock_mid.assert_called_once()
    assert mock_mid.call_args.kwargs["action"] == "fill"
    assert mock_mid.call_args.kwargs["value"] == "hello"
    assert rows[0].get("explore_midscene_act") is True
    assert rows[0].get("explore_noop") is not True
    assert rows[0].get("status") == "ok"


def test_apply_cli_decision_midscene_skip_without_cdp():
    from app.services.ui_automation.ui_cli_explorer import apply_cli_decision

    fake_cli = MagicMock()
    fake_cli.cdp_endpoint = ""
    rows, _ = apply_cli_decision(
        fake_cli,
        {"action": "click", "driver": "midscene", "prompt": "图标按钮"},
        base_url="https://example.com",
        ctx={},
        url="https://example.com/",
        midscene_model_config={"MIDSCENE_MODEL_NAME": "test"},
    )
    assert rows[0].get("status") == "error"
    assert "CDP" in str(rows[0].get("error") or "")
    assert rows[0].get("explore_noop") is not True


def test_bind_fill_is_pass_through_agent_owns_value():
    from app.services.ui_automation.ui_cli_explorer import bind_fill_value_from_ctx

    # Agent value is not overridden by ctx (even if ctx looks "cleaner")
    kept = bind_fill_value_from_ctx(
        {"action": "fill", "name": "账号", "value": "admin"},
        {"username": "other", "password": "x"},
    )
    assert kept["value"] == "admin"
    # Still pass-through for outcome text — decide prompt must prevent this, not bind
    raw = bind_fill_value_from_ctx(
        {"action": "fill", "name": "账号", "value": "登录成功"},
        {"username": "admin"},
    )
    assert raw["value"] == "登录成功"


def test_apply_cli_decision_clear_then_fill_username():
    from app.services.ui_automation.ui_cli_explorer import apply_cli_decision

    fake_cli = MagicMock()
    fake_cli.cdp_endpoint = None
    fake_cli.snapshot.return_value = '- textbox "账号" [ref=e10]'
    fake_cli.generate_locator.return_value = 'page.getByRole("textbox", { name: "账号" })'
    apply_cli_decision(
        fake_cli,
        {"action": "fill", "selector": "e10", "name": "账号", "value": "admin"},
        base_url="https://example.com",
        ctx={"username": "admin", "password": "x"},
        url="https://example.com/login",
    )
    # clear then fill with Agent-provided value
    assert fake_cli.fill.call_count >= 2
    assert fake_cli.fill.call_args_list[0].args[1] == ""
    assert fake_cli.fill.call_args_list[-1].args[1] == "admin"


def test_midscene_fingerprint_includes_non_captcha_fill():
    from app.services.ui_automation.ui_cli_explorer import midscene_noop_fingerprint

    fp = midscene_noop_fingerprint(
        {"driver": "midscene", "action": "fill", "prompt": "画布搜索框", "value": "x"}
    )
    assert fp.startswith("midscene::fill::")
    assert "画布搜索框" in fp


def test_run_playwright_cli_engine_crud_fallback_when_design_incomplete(monkeypatch):
    trace = [
        {"kind": "goto", "path": "/", "status": "ok", "driver": "playwright"},
        {
            "kind": "click",
            "status": "ok",
            "driver": "playwright",
            "name": "保存",
            "role": "button",
        },
    ]
    monkeypatch.setattr(
        "app.services.ui_automation.ui_explore_engines.run_cli_explore_loop",
        lambda **kwargs: trace,
    )
    monkeypatch.setattr(
        "app.services.ui_automation.ui_explore_engines.apply_sequential_explore_matrix",
        lambda plan: plan,
    )
    expand_calls: list[dict] = []

    def fake_design(**kwargs):
        return []

    def fake_expand(**kwargs):
        expand_calls.append(kwargs)
        return [
            {
                "id": "TC-01",
                "name": "新增流程验证",
                "steps": [{"action": "goto", "target": "/", "ready": True}],
                "ready": True,
            },
            {
                "id": "TC-02",
                "name": "查询流程验证",
                "steps": [{"action": "goto", "target": "/", "ready": True}],
                "ready": True,
            },
        ]

    monkeypatch.setattr(
        "app.services.ui_automation.ui_explore_engines.design_cases",
        fake_design,
    )
    monkeypatch.setattr(
        "app.services.ui_automation.ui_explore_engines.expand_cases_from_test_design",
        fake_expand,
    )
    plan: dict = {
        "goal": "需求文档增删改查",
        "start_path": "/",
        "matrix": [],
        "checklist": ["新增", "查询", "编辑", "删除"],
    }
    _patch_codegen_pipeline(
        monkeypatch,
        "async function run(page, agent) {\n  await page.goto('/');\n}\n",
    )
    run_playwright_cli_engine(
        base_url="https://example.com",
        start_path="/",
        goal=plan["goal"],
        username="",
        password="",
        llm=ENGINE_LLM,
        headed=False,
        timeout_ms=5000,
        max_steps=5,
        plan=plan,
    )
    assert expand_calls
    names = [r.get("name") for r in plan.get("matrix") or []]
    assert any("查询" in str(n) for n in names)


def test_run_playwright_cli_engine_compiles(monkeypatch):
    def fake_loop(**kwargs):
        return [
            {"kind": "goto", "path": "/", "status": "ok", "driver": "playwright"},
            {
                "kind": "click",
                "action": "click",
                "status": "ok",
                "driver": "playwright",
                "role": "button",
                "name": "新建项目",
            },
        ]

    monkeypatch.setattr(
        "app.services.ui_automation.ui_explore_engines.run_cli_explore_loop",
        fake_loop,
    )
    llm = ENGINE_LLM
    _patch_codegen_pipeline(
        monkeypatch,
        (
            "async function run(page, agent) {\n"
            "  await page.getByRole('button', { name: '新建项目' }).click();\n"
            "  await expect(page.getByText('新建项目')).toBeVisible();\n"
            "}\n"
        ),
    )
    plan: dict = {"goal": "新建项目", "start_path": "/", "matrix": [], "checklist": []}
    trace, script = run_playwright_cli_engine(
        base_url="https://example.com",
        start_path="/",
        goal="新建项目",
        username="",
        password="",
        llm=llm,
        headed=False,
        timeout_ms=5000,
        max_steps=3,
        plan=plan,
    )
    assert trace
    assert "async function run" in script
    assert "aiAct(" not in script
    assert "新建项目" in script or "getByRole" in script
    assert plan.get("case_scripts")
    assert any(c.get("ready") and c.get("code") for c in plan["case_scripts"])


def test_run_playwright_cli_engine_single_case_skips_derive(monkeypatch):
    def fake_loop(**kwargs):
        return [
            {"kind": "goto", "path": "/login", "status": "ok", "driver": "playwright"},
            {
                "kind": "fill",
                "status": "ok",
                "driver": "playwright",
                "placeholder": "账号",
                "value": "admin",
            },
            {
                "kind": "click",
                "status": "ok",
                "driver": "playwright",
                "role": "button",
                "name": "登录",
            },
        ]

    monkeypatch.setattr(
        "app.services.ui_automation.ui_explore_engines.run_cli_explore_loop",
        fake_loop,
    )

    def boom(*args, **kwargs):
        raise AssertionError("expand_cases_from_test_design should not run for _single_case")

    monkeypatch.setattr(
        "app.services.ui_automation.ui_explore_engines.expand_cases_from_test_design",
        boom,
    )
    llm = ENGINE_LLM
    _patch_codegen_pipeline(
        monkeypatch,
        (
            "async function run(page, agent) {\n"
            "  await page.goto('/login');\n"
            "  await expect(page).toHaveURL(/home/);\n"
            "}\n"
        ),
    )
    plan: dict = {
        "goal": "登录成功",
        "start_path": "/login",
        "matrix": [],
        "checklist": ["登录"],
        "case_name": "使用正确账号密码登录成功",
        "test_data": "账号：admin；密码：admin123",
        "expected": "登录成功，跳转至系统首页",
        "_single_case": True,
    }
    _trace, script = run_playwright_cli_engine(
        base_url="https://example.com",
        start_path="/login",
        goal="登录成功",
        username="admin",
        password="admin123",
        llm=llm,
        headed=False,
        timeout_ms=5000,
        max_steps=10,
        plan=plan,
    )
    assert "async function run" in script
    assert "expect(page)" in script
    assert "toHaveURL" in script
    assert len(plan.get("case_scripts") or []) == 1
    assert plan["case_scripts"][0]["name"] == "使用正确账号密码登录成功"
    assert plan["case_scripts"][0].get("ready")
    row = (plan.get("matrix") or [])[0]
    assert row.get("ready")
    assert row.get("has_assert")
    assert any(str(s.get("action") or "").startswith("assert") for s in (row.get("steps") or []))
    assert matrix_bind_issues(plan.get("matrix")) == []


def test_run_playwright_cli_engine_single_case_without_expected_not_ready(monkeypatch):
    monkeypatch.setattr(
        "app.services.ui_automation.ui_explore_engines.run_cli_explore_loop",
        lambda **kwargs: [
            {"kind": "goto", "path": "/login", "status": "ok", "driver": "playwright"},
            {
                "kind": "click",
                "status": "ok",
                "driver": "playwright",
                "role": "button",
                "name": "登录",
            },
        ],
    )
    _patch_codegen_pipeline(monkeypatch, "", ready=False)
    plan: dict = {
        "goal": "登录",
        "start_path": "/login",
        "matrix": [],
        "case_name": "登录",
        "_single_case": True,
    }
    _trace, script = run_playwright_cli_engine(
        base_url="https://example.com",
        start_path="/login",
        goal="登录",
        username="",
        password="",
        llm=ENGINE_LLM,
        headed=False,
        timeout_ms=5000,
        max_steps=10,
        plan=plan,
    )
    assert not (script or "").strip()
    assert plan["matrix"][0].get("ready") is True
    assert plan["case_scripts"][0].get("ready") is False


def test_run_playwright_cli_engine_explore_first_derives_multi_cases(monkeypatch):
    def fake_loop(**kwargs):
        return [
            {"kind": "goto", "path": "/login", "status": "ok", "driver": "playwright"},
            {
                "kind": "fill",
                "status": "ok",
                "driver": "playwright",
                "placeholder": "账号",
                "value": "admin",
            },
            {
                "kind": "click",
                "status": "ok",
                "driver": "playwright",
                "role": "button",
                "name": "登录",
            },
            {
                "kind": "click",
                "status": "ok",
                "driver": "playwright",
                "name": "项目管理",
            },
            {
                "kind": "click",
                "status": "ok",
                "driver": "playwright",
                "name": "新建项目",
            },
        ]

    monkeypatch.setattr(
        "app.services.ui_automation.ui_explore_engines.run_cli_explore_loop",
        fake_loop,
    )
    def boom_design(**_kwargs):
        raise RuntimeError("use fallback split")

    monkeypatch.setattr(
        "app.services.ui_automation.ui_explore_engines.design_cases",
        boom_design,
    )
    _patch_codegen_pipeline(
        monkeypatch,
        "async function run(page, agent) {\n  await expect(page.getByText('ok')).toBeVisible();\n}\n",
    )
    plan: dict = {
        "goal": "登录与项目管理",
        "start_path": "/login",
        "matrix": [],
        "checklist": ["登录", "项目列表", "新建项目"],
        "user_prompt": "登录后看项目并新建",
    }
    _trace, script = run_playwright_cli_engine(
        base_url="https://example.com",
        start_path="/login",
        goal="登录与项目管理",
        username="admin",
        password="secret",
        llm=ENGINE_LLM,
        headed=False,
        timeout_ms=5000,
        max_steps=10,
        plan=plan,
    )
    assert "async function run" in script
    ready = [c for c in (plan.get("case_scripts") or []) if c.get("ready") and (c.get("code") or "").strip()]
    assert len(ready) >= 2
    assert len(plan.get("matrix") or []) >= 2


def test_apply_cli_decision_logs_selector_and_masks_password():
    from app.services.ui_automation.ui_cli_explorer import apply_cli_decision

    cli = MagicMock()
    cli.generate_locator.return_value = 'page.getByLabel("密码")'
    logs: list[str] = []
    apply_cli_decision(
        cli,
        {
            "action": "fill",
            "selector": "e1",
            "value": "s3cret",
            "case_id": "UC-001",
            "reason": "填写登录密码",
        },
        base_url="https://example.com",
        ctx={"username": "admin", "password": "s3cret"},
        url="https://example.com/login",
        on_log=logs.append,
    )
    joined = "\n".join(logs)
    assert "UC-001" in joined
    assert "fill" in joined
    assert "e1" in joined or "getByLabel" in joined
    assert "填写登录密码" in joined
    assert "s3cret" not in joined
    assert "***" in joined


def test_apply_cli_decision_uses_agent_password_value_not_ctx_override():
    from app.services.ui_automation.ui_cli_explorer import apply_cli_decision

    cli = MagicMock()
    cli.generate_locator.return_value = 'page.getByLabel("密码")'
    apply_cli_decision(
        cli,
        {
            "action": "fill",
            "selector": "e10",
            "value": "typed-by-agent",
            "reason": "填写登录密码",
        },
        base_url="https://example.com",
        ctx={"username": "admin", "password": "admin123"},
        url="https://example.com/login",
    )
    cli.fill.assert_called()
    # Last fill is the value (after clear ""); Agent value wins over ctx
    assert cli.fill.call_args_list[-1].args[1] == "typed-by-agent"


def test_apply_cli_decision_uses_agent_username_value_not_ctx_override():
    from app.services.ui_automation.ui_cli_explorer import apply_cli_decision

    cli = MagicMock()
    cli.generate_locator.return_value = 'page.getByLabel("账号")'
    apply_cli_decision(
        cli,
        {
            "action": "fill",
            "selector": "e8",
            "value": "guest",
            "reason": "填写账号",
        },
        base_url="https://example.com",
        ctx={"username": "admin", "password": "admin123"},
        url="https://example.com/login",
    )
    assert cli.fill.call_args_list[-1].args[1] == "guest"


def test_apply_cli_decision_skips_problem_text_assert():
    from app.services.ui_automation.ui_cli_explorer import (
        PROBLEM_TEXT_NOT_PROGRESS,
        apply_cli_decision,
    )

    cli = MagicMock()
    rows, _url = apply_cli_decision(
        cli,
        {"action": "assert_text", "value": "请输入项目名称", "selector": "e178"},
        base_url="https://example.com",
        ctx={},
        url="https://example.com/",
    )
    assert len(rows) == 1
    assert rows[0]["status"] == "skipped"
    assert rows[0]["reason"] == PROBLEM_TEXT_NOT_PROGRESS
    assert rows[0].get("explore_problem_assert_skip") is True


def test_playwright_cli_screenshot_uses_context_page():
    from app.services.ui_automation.playwright_cli_session import PlaywrightCliSession

    page = MagicMock()
    page.screenshot.return_value = b"png-bytes"
    ctx = MagicMock()
    ctx.pages = [page]
    sess = PlaywrightCliSession.__new__(PlaywrightCliSession)
    sess._context = ctx
    sess.cdp_endpoint = "http://127.0.0.1:9222"
    assert sess.screenshot() == b"png-bytes"
    page.screenshot.assert_called()


def test_playwright_cli_open_fallback_uses_chromium_browser():
    from app.services.ui_automation.playwright_cli_session import PlaywrightCliSession

    with patch("app.services.ui_automation.playwright_cli_session.cli_ready", return_value=None):
        sess = PlaywrightCliSession(use_cdp=False, headed=False)
    captured: list[tuple[str, ...]] = []

    def _run(*parts: str, check: bool = True) -> str:
        captured.append(parts)
        return "ok"

    sess.run = _run  # type: ignore[method-assign]
    sess.open("https://example.com/")
    assert captured
    assert captured[0][:2] == ("open", "https://example.com/")
    assert "--browser" in captured[0]
    assert "chromium" in captured[0]
    assert "--headed" not in captured[0]


def test_playwright_cli_open_fallback_headed_keeps_flag_outside_container():
    from app.services.ui_automation.playwright_cli_session import PlaywrightCliSession

    with (
        patch("app.services.ui_automation.playwright_cli_session.cli_ready", return_value=None),
        patch(
            "app.services.ui_automation.playwright_cli_session.running_in_container",
            return_value=False,
        ),
    ):
        sess = PlaywrightCliSession(use_cdp=False, headed=True)
    captured: list[tuple[str, ...]] = []

    def _run(*parts: str, check: bool = True) -> str:
        captured.append(parts)
        return "ok"

    sess.run = _run  # type: ignore[method-assign]
    sess.open("https://example.com/")
    assert "--browser" in captured[0] and "chromium" in captured[0]
    assert "--headed" in captured[0]


def test_playwright_cli_session_forces_headless_in_container():
    from app.services.ui_automation.playwright_cli_session import PlaywrightCliSession

    with (
        patch("app.services.ui_automation.playwright_cli_session.cli_ready", return_value=None),
        patch(
            "app.services.ui_automation.playwright_cli_session.running_in_container",
            return_value=True,
        ),
    ):
        sess = PlaywrightCliSession(headed=True)
    assert sess.headed is False
