"""Tests for site map page_knowledge builders."""

from __future__ import annotations

from app.services.ui_automation.ui_explore_report import build_explore_report
from app.services.ui_automation.ui_page_knowledge import (
    build_page_knowledge,
    merge_snapshot_into_knowledge,
    summarize_page_knowledge_for_decide,
    validate_matrix_against_knowledge,
)


def test_build_page_knowledge_from_recon_trace() -> None:
    trace = [
        {
            "kind": "recon_visit",
            "path": "/",
            "controls": [
                {"role": "link", "name": "项目管理", "locator": "page.getByRole('link', { name: '项目管理' })"},
                {"role": "link", "name": "项目管理"},
            ],
        },
        {
            "kind": "recon_visit",
            "path": "/projects",
            "controls": [{"role": "button", "name": "新建项目"}],
        },
        {
            "kind": "recon_nav",
            "from_path": "/",
            "to_path": "/projects",
            "via": "link:项目管理",
        },
    ]
    pk = build_page_knowledge(trace)
    assert len(pk["pages"]) == 2
    assert pk["summary"]["pages_visited"] == 2
    assert pk["summary"]["edge_count"] == 1
    home = next(p for p in pk["pages"] if p["path"] == "/")
    assert len(home["controls"]) == 1
    assert home["controls"][0]["name"] == "项目管理"


def test_recon_skips_external_in_path_helper() -> None:
    pk = build_page_knowledge(
        [
            {
                "kind": "recon_visit",
                "path": "/login",
                "controls": [],
            }
        ]
    )
    assert pk["pages"][0]["path"] == "/login"


def test_merge_snapshot_into_knowledge_dedup_and_edge() -> None:
    pk = build_page_knowledge([])
    snap = (
        '- link "项目管理" [ref=e1]\n'
        '- button "新建项目" [ref=e2]\n'
        '- textbox "账号" [ref=e3]\n'
    )
    pk = merge_snapshot_into_knowledge(pk, path="/", snapshot=snap)
    assert len(pk["pages"]) == 1
    assert len(pk["pages"][0]["controls"]) >= 2
    pk2 = merge_snapshot_into_knowledge(
        pk,
        path="/projects",
        snapshot='- button "保存" [ref=e4]',
        prev_path="/",
        via="link:项目管理",
    )
    assert pk2["summary"]["pages_visited"] == 2
    assert pk2["summary"]["edge_count"] == 1


def test_validate_matrix_skips_success_title() -> None:
    pk = build_page_knowledge(
        [{"kind": "recon_visit", "path": "/", "controls": [{"role": "link", "name": "仪表盘"}]}]
    )
    matrix = [{"id": "TC-1", "name": "成功创建一个新的项目"}]
    assert validate_matrix_against_knowledge(matrix, pk) == []


def test_validate_matrix_against_knowledge_warns_missing_entry() -> None:
    pk = build_page_knowledge(
        [
            {
                "kind": "recon_visit",
                "path": "/",
                "controls": [{"role": "link", "name": "仪表盘"}],
            }
        ]
    )
    matrix = [{"id": "TC-1", "name": "需求管理全流程"}]
    warns = validate_matrix_against_knowledge(matrix, pk)
    assert warns
    assert "需求" in warns[0] or "未找到" in warns[0]


def test_decide_payload_includes_page_knowledge_summary() -> None:
    pk = build_page_knowledge(
        [
            {
                "kind": "recon_visit",
                "path": "/req",
                "controls": [{"role": "link", "name": "需求管理"}],
            }
        ]
    )
    summary = summarize_page_knowledge_for_decide(pk)
    assert summary["pages"]
    assert summary["pages"][0]["path"] == "/req"
    assert any(l.get("name") == "需求管理" for l in summary["pages"][0]["links"])


def test_build_explore_report_includes_page_knowledge() -> None:
    plan = {
        "goal": "g",
        "start_path": "/",
        "page_knowledge": build_page_knowledge(
            [{"kind": "recon_visit", "path": "/", "controls": [{"role": "link", "name": "首页"}]}]
        ),
        "_recon_warnings": ["warn1"],
    }
    report = build_explore_report(plan=plan, steps=[], synthesize_matrix=False)
    assert report.get("page_knowledge")
    assert report["summary"]["pages_visited"] == 1
    assert report.get("recon_warnings") == ["warn1"]
