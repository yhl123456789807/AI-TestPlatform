"""CDP explore act fallback (modal fill, wait_for, name variants)."""

from __future__ import annotations

from unittest.mock import MagicMock

from app.services.ui_automation.playwright_cli_session import PlaywrightCliSession
from app.services.ui_automation.ui_cli_explorer import (
    apply_cli_decision,
    format_dom_dialog_candidates,
)


def test_role_name_candidates_includes_star_prefix():
    names = PlaywrightCliSession.role_name_candidates("名称")
    assert "名称" in names
    assert "* 名称" in names


def test_format_dom_dialog_candidates_shows_hash_id():
    cli = PlaywrightCliSession.__new__(PlaywrightCliSession)
    cli.dom_modal_visible = MagicMock(return_value=True)
    cli.dom_dialog_control_candidates = MagicMock(
        return_value=[
            {
                "role": "textbox",
                "name": "名称",
                "dom_id": "name",
                "accessible_name": "* 名称",
            },
            {"role": "button", "name": "创 建", "dom_id": ""},
        ]
    )
    text = format_dom_dialog_candidates(cli)
    assert "#name" in text
    assert "* 名称" in text or "名称" in text


def test_apply_cli_decision_uses_cdp_fill_for_label_selector():
    fake_cli = PlaywrightCliSession.__new__(PlaywrightCliSession)
    fake_cli.timeout_ms = 8000
    fake_cli.cdp_endpoint = "http://cdp"
    fake_cli.active_page = MagicMock(return_value=MagicMock())
    fake_cli.cdp_fill = MagicMock(
        return_value=(True, 'page.getByRole("textbox", { name: "* 名称" })')
    )
    rows, _url = apply_cli_decision(
        fake_cli,
        {
            "action": "fill",
            "selector": "label=名称",
            "role": "textbox",
            "name": "名称",
            "value": "demo-proj",
        },
        base_url="https://example.com",
        ctx={},
        url="https://example.com/projects",
    )
    fake_cli.cdp_fill.assert_called_once()
    assert rows and rows[0].get("status") == "ok"


def test_apply_cli_decision_wait_for_uses_cdp():
    fake_cli = PlaywrightCliSession.__new__(PlaywrightCliSession)
    fake_cli.timeout_ms = 8000
    fake_cli.cdp_wait_for = MagicMock(return_value=True)
    rows, _ = apply_cli_decision(
        fake_cli,
        {"action": "wait_for", "selector": "role=dialog", "value": "visible"},
        base_url="https://example.com",
        ctx={},
        url="https://example.com/",
    )
    fake_cli.cdp_wait_for.assert_called_once()
    assert rows[0].get("kind") == "wait_for"
