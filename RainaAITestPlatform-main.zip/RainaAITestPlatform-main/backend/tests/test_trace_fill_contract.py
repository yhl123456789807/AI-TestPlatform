from app.services.ui_automation.ui_cli_explorer import (
    _finalize_trace_row,
    should_block_fill_before_modal_open,
)


def test_finalize_trace_row_forces_textbox_on_fill() -> None:
    row = _finalize_trace_row(
        {
            "kind": "fill",
            "action": "fill",
            "role": "button",
            "name": "* 名称",
            "cli_locator": "page.getByRole('button', { name: \"* 名称\" })",
        }
    )
    assert row["role"] == "textbox"
    assert "textbox" in row["cli_locator"]


def test_block_modal_fill_without_opener() -> None:
    class _Cli:
        def dom_modal_visible(self) -> bool:
            return False

    assert should_block_fill_before_modal_open(
        _Cli(),
        "首页",
        {"action": "fill", "name": "* 标题"},
        [],
    )
    assert not should_block_fill_before_modal_open(
        _Cli(),
        "首页",
        {"action": "fill", "name": "* 标题"},
        [{"kind": "click", "name": "新建项目", "status": "ok"}],
    )
