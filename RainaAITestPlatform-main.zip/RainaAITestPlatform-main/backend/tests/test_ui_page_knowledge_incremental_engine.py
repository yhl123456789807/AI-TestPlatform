"""Explore engine without BFS recon still seeds page_knowledge."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

from app.config import settings
from app.services.ui_automation.ui_explore_engines import run_playwright_cli_engine


def test_engine_skips_recon_and_seeds_page_knowledge(monkeypatch) -> None:
    monkeypatch.setattr(settings, "ui_recon_enabled", False)
    recon_calls: list[int] = []

    def fake_recon(**_kwargs):
        recon_calls.append(1)
        return [], MagicMock()

    monkeypatch.setattr(
        "app.services.ui_automation.ui_explore_engines.run_recon_explore",
        fake_recon,
    )

    trace_payload = [
        {
            "kind": "click",
            "status": "ok",
            "role": "link",
            "name": "项目管理",
            "cli_locator": "page.getByRole('link', { name: '项目管理' })",
            "observe": {"url_after": "http://example.com/projects"},
        }
    ]

    def fake_loop(**kwargs):
        plan = kwargs.get("plan") or {}
        if isinstance(plan, dict):
            from app.services.ui_automation.ui_page_knowledge import increment_plan_page_knowledge

            plan.update(
                increment_plan_page_knowledge(
                    plan,
                    url="http://example.com/projects",
                    snapshot='- link "项目管理" [ref=e1]',
                    trace=trace_payload,
                )
            )
        return trace_payload

    monkeypatch.setattr(
        "app.services.ui_automation.ui_explore_engines.run_cli_explore_loop",
        fake_loop,
    )
    plan = {
        "_sequential_matrix": True,
        "matrix": [{"id": "TC-1", "name": "项目", "start_url": "/"}],
    }
    llm = MagicMock()
    _trace, _script = run_playwright_cli_engine(
        base_url="https://example.com",
        start_path="/",
        goal="项目",
        llm=llm,
        headed=False,
        timeout_ms=5000,
        plan=plan,
    )
    assert not recon_calls
    pk = plan.get("page_knowledge") or {}
    assert pk.get("summary", {}).get("pages_visited", 0) >= 1
